import argparse
import hashlib
import json
from pathlib import Path


def validate(index_path):
    index = json.loads(index_path.read_text(encoding="utf-8"))
    required = {"cohort_manifest", "fold_manifest", "feature_schema", "outcome_definitions", "model_registry", "runtime_locks", "evaluation_code", "threshold_registry"}
    if index.get("scope") != "pre2025_protected_replay" or index.get("source_contains_2025") is not False:
        raise ValueError("Explicit pre-2025 protected replay scope is required")
    records = index.get("artifacts", [])
    if {r["role"] for r in records} != required:
        raise ValueError("Missing or extra private prerequisite roles")
    for item in records:
        path = index_path.parent / item["path"]
        if not path.resolve().is_relative_to(index_path.parent.resolve()):
            raise ValueError("Private prerequisite path is outside supplied package")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != item["sha256"]:
            raise ValueError(f"Private prerequisite hash differs: {item['role']}")
    return {"status": "PRIVATE_PREREQUISITE_BYTES_VERIFIED", "artifact_count": len(records), "model_executed": False, "patient_data_loaded": False, "full_training_reproduced": False, "note": "Prerequisite manifest verification only; protected training/evaluation orchestration is not implemented in this public aggregate package."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Verify supplied private research prerequisite manifests without executing models")
    parser.add_argument("index", type=Path)
    args = parser.parse_args()
    print(json.dumps(validate(args.index)))
