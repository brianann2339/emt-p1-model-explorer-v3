import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

PACK = Path(__file__).resolve().parent


def sha(path):
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256")
    return digest.hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def verify_code():
    manifest = load(PACK / "protected/source_manifest.json")
    for entry in manifest["files"]:
        path = (PACK / entry["path"]).resolve()
        path.relative_to(PACK.resolve())
        if sha(path) != entry["sha256"]:
            raise ValueError("Original source/lock hash differs: " + entry["path"])
    return manifest


def plan(input_map, stage, output_root):
    manifest = verify_code()
    definition = manifest["stages"][stage]
    configuration = load(input_map)
    workspace = Path(configuration["workspace"]).resolve(strict=True)
    target = (output_root / stage).resolve()
    if target.exists():
        raise FileExistsError("Use a fresh output directory: " + str(target))
    resolved_inputs = {}
    for key, item in configuration["inputs"].items():
        path = Path(item["path"]).resolve(strict=True)
        if path.is_file():
            if sha(path) != item["sha256"]:
                raise ValueError("Protected input hash differs: " + key)
        else:
            if not item.get("files"):
                raise ValueError("Directory input needs exact file inventory: " + key)
            for member in item["files"]:
                source = (path / member["path"]).resolve(strict=True)
                source.relative_to(path)
                if sha(source) != member["sha256"]:
                    raise ValueError("Protected directory member differs: " + key)
        resolved_inputs[key] = str(path)
    args = []
    for value in configuration["stages"][stage]["args"]:
        value = value.replace("{output}", str(target)).replace("{workspace}", str(workspace))
        value = re.sub(r"\{input:([^}]+)\}", lambda m: resolved_inputs[m.group(1)], value)
        if "{" in value:
            raise ValueError("Unresolved input argument")
        if value.startswith("--") and value.split("=", 1)[0] not in definition["native_cli_flags"]:
            raise ValueError("Argument is not in original CLI: " + value)
        if value == "--overwrite":
            raise ValueError("This fresh replay route does not overwrite existing output")
        args.append(value)
    if str(target) not in args:
        raise ValueError("Native arguments must use {output}")
    relative_entrypoint = Path(definition["entrypoint"]).relative_to("protected/native")
    command = [configuration["python_by_stage"][stage], str(workspace / relative_entrypoint), *args]
    return {"stage": stage, "command": command, "workspace": str(workspace), "output": str(target), "input_map_sha256": sha(input_map), "source_manifest_sha256": sha(PACK / "protected/source_manifest.json"), "scientific_execution_performed": False, "native_code_staging": "On explicit run, copy exact source files into the approved replay workspace without overwriting different existing code"}


def stage_code(workspace):
    manifest = verify_code()
    targets = []
    for entry in manifest["files"]:
        if not entry["path"].startswith("protected/native/"):
            continue
        destination = workspace / Path(entry["path"]).relative_to("protected/native")
        if destination.exists() and sha(destination) != entry["sha256"]:
            raise ValueError("Replay workspace contains different code: " + str(destination))
        targets.append((entry, destination))
    for entry, destination in targets:
        if not destination.exists():
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(PACK / entry["path"], destination)
        if sha(destination) != entry["sha256"]:
            raise ValueError("Staged source hash differs")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["verify-code", "stage-code", "plan", "run"])
    parser.add_argument("--input-map", type=Path)
    parser.add_argument("--stage")
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if args.mode == "verify-code":
        manifest = verify_code()
        print(json.dumps({"status": "PASS", "files": len(manifest["files"]), "scientific_execution_performed": False}))
        return
    if args.mode == "stage-code":
        if not args.input_map:
            parser.error("stage-code requires input-map with approved replay workspace")
        workspace = Path(load(args.input_map)["workspace"]).resolve(strict=True)
        stage_code(workspace)
        print(json.dumps({"status": "EXACT_NATIVE_CODE_STAGED", "workspace": str(workspace), "scientific_execution_performed": False}))
        return
    if not all([args.input_map, args.stage, args.output_root]):
        parser.error("input-map, stage and output-root are required")
    receipt = plan(args.input_map, args.stage, args.output_root)
    if args.mode == "run":
        if not args.execute:
            parser.error("run requires explicit --execute")
        target = Path(receipt["output"])
        target.parent.mkdir(parents=True, exist_ok=True)
        workspace = Path(receipt["workspace"])
        stage_code(workspace)
        env = os.environ.copy()
        env["PYTHONPATH"] = str(workspace) + os.pathsep + str(workspace / "scripts")
        result = subprocess.run(receipt["command"], cwd=receipt["workspace"], env=env, shell=False)
        receipt.update(scientific_execution_performed=True, returncode=result.returncode)
        (target.parent / (args.stage + ".execution_receipt.json")).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        if result.returncode:
            raise SystemExit(result.returncode)
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    main()
