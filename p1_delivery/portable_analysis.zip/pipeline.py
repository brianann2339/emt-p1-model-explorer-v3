from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows, fields=None):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields or list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def run(source, output):
    lock = json.loads((source / "fixture_manifest.json").read_text(encoding="utf-8"))
    for entry in lock["files"]:
        target = source / entry["path"]
        if not target.resolve().is_relative_to(source.resolve()) or sha(target) != entry["sha256"]:
            raise ValueError(f"Fixture bytes changed: {entry['path']}")
    completion = read_csv(source / "completion.csv")
    if len(completion) != 494 or len({r["task_id"] for r in completion}) != 494:
        raise ValueError("Expected 494 distinct task dispositions")
    arms = []
    for entry in lock["files"]:
        if entry["role"] == "p104_arm_table":
            arms.extend(read_csv(source / entry["path"]))
    if any("2025" in row["split"] for row in arms):
        raise ValueError("This replay accepts pre-2025 aggregate tables only")
    seen = set()
    arithmetic_checks = 0
    for row in arms:
        key = tuple(row[k] for k in ["task_id", "arm", "split", "presentation"])
        if key in seen:
            raise ValueError(f"Duplicate aggregate arm key: {key}")
        seen.add(key)
        if row["N"] and row["events"]:
            n, events = int(row["N"]), int(row["events"])
            if not 0 <= events <= n:
                raise ValueError(f"Invalid event count: {key}")
            if all(row[k] != "" for k in ["TP", "FP", "TN", "FN"]):
                tp, fp, tn, fn = (int(row[k]) for k in ["TP", "FP", "TN", "FN"])
                if tp + fp + tn + fn != n or tp + fn != events:
                    raise ValueError(f"Confusion-matrix denominator differs: {key}")
                arithmetic_checks += 1
                if row["F1"] and 2 * tp + fp + fn:
                    if not math.isclose(float(row["F1"]), 2 * tp / (2 * tp + fp + fn), rel_tol=1e-10, abs_tol=1e-12):
                        raise ValueError(f"F1 arithmetic differs: {key}")
                    arithmetic_checks += 1
    validation = [r for r in arms if r["split"] == "validation_2024"]
    groups = defaultdict(list)
    for row in arms:
        groups[tuple(row[k] for k in ["task_id", "split", "presentation"])].append(row)
    pair_source = read_csv(source / "descriptive_point_comparisons.csv")
    pairs = []
    for row in pair_source:
        if row["exact_cohort_match"] != "True":
            continue
        candidates = groups[(row["task_id"], row["split"], row["presentation"])]
        left = next(r for r in candidates if r["arm"] == row["reference_arm"])
        right = next(r for r in candidates if r["arm"] == row["comparison_arm"])
        result = {k: row[k] for k in ["task_id", "group", "outcome", "analysis", "split", "presentation", "reference_arm", "comparison_arm"]}
        for metric in ["AUROC", "AUPRC", "Brier"]:
            delta = float(right[metric]) - float(left[metric]) if left[metric] and right[metric] else None
            recorded = float(row["delta_" + metric]) if row["delta_" + metric] else None
            if (delta is None) != (recorded is None) or (delta is not None and not math.isclose(delta, recorded, rel_tol=1e-10, abs_tol=1e-12)):
                raise ValueError(f"Recorded descriptive delta differs: {result}")
            result["delta_" + metric] = delta
            arithmetic_checks += 1
        result["paired_ci"] = "NOT_ESTIMATED_FROM_AGGREGATE_ARMS"
        pairs.append(result)
    epd = []
    for row in arms:
        if row["analysis"] == "01_standardization" and row["arm"] == "logistic_scaled" and row["split"] == "oof_2020_2023" and row["presentation"] == "raw":
            n, events, d = int(row["N"]), int(row["events"]), int(row["feature_count"])
            epd.append({"group": row["group"], "outcome": row["outcome"], "development_encounters": n, "events": events, "transformed_input_dimensions": d, "events_per_input_dimension": events / d, "model_scope": "P104 logistic_scaled input; not every final model", "independent_patients": "NOT_IN_THIS_AGGREGATE", "effective_parameters": "NOT_IDENTIFIED_BY_INPUT_DIMENSION"})
    outcome_manifest = json.loads((source / "overall_development_summary.json").read_text(encoding="utf-8"))
    for outcome, events in outcome_manifest["events"].items():
        epd.append({"group": "overall", "outcome": outcome, "development_encounters": outcome_manifest["N"], "events": events, "transformed_input_dimensions": outcome_manifest["stage1a_feature_count"], "events_per_input_dimension": events / outcome_manifest["stage1a_feature_count"], "model_scope": "Stage1a candidate input; not every final model", "independent_patients": outcome_manifest["patients"], "effective_parameters": "NOT_IDENTIFIED_BY_INPUT_DIMENSION"})
    missing = [r for r in completion if r["status"] != "VALIDATED_COMPUTED"]
    catalog = [{"collection": entry["path"], "rows": len(read_csv(source / entry["path"])), "sha256": entry["sha256"], "role": entry["role"]} for entry in lock["files"] if entry["role"] == "source_aligned_supplement"]
    for entry in catalog:
        expected = next(f["rows"] for f in lock["files"] if f["path"] == entry["collection"])
        if entry["rows"] != expected:
            raise ValueError(f"Supplement row count differs: {entry['collection']}")
    summary = {"schema": "emt-real-aggregate-replay/1", "scope": "Analysis of already-computed pre-2025 aggregate outputs", "completed_task_dispositions": len(completion), "status_counts": dict(sorted(Counter(r["status"] for r in completion).items())), "group_counts": dict(sorted(Counter(r["group"] for r in completion).items())), "aggregate_arm_rows": len(arms), "validation_2024_arm_rows": len(validation), "same_cohort_descriptive_pairs": len(pairs), "different_cohort_pairs_not_subtracted": sum(r["exact_cohort_match"] != "True" for r in pair_source), "events_dimension_rows": len(epd), "arithmetic_checks": arithmetic_checks, "model_fit_count": 0, "prediction_calls": 0, "new_raw_2025_access_count": 0, "bootstrap_recomputed": False, "full_training_reproduced": False, "scientific_acceptance": False, "formal_acceptance": False}
    output.mkdir(parents=True, exist_ok=False)
    write_csv(output / "p104_validation_2024.csv", validation)
    write_csv(output / "same_cohort_deltas.csv", pairs)
    write_csv(output / "events_feature_dimensions.csv", epd)
    write_csv(output / "limited_or_not_estimable.csv", missing)
    if catalog:
        write_csv(output / "source_collections.csv", catalog)
        summary["supplement_collections"] = len(catalog)
        summary["supplement_rows"] = sum(c["rows"] for c in catalog)
        summary["scope"] = "Pre-2025 P104 analysis plus previously computed aggregate supplements; no new frozen evaluation"
    write_json(output / "results_manifest.json", summary)
    write_json(output / "output_hashes.json", {p.name: sha(p) for p in sorted(output.iterdir())})
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Reproduce real EMT aggregate research summaries, without raw data or model calls")
    parser.add_argument("--inputs", type=Path, default=Path(__file__).with_name("fixtures"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.inputs, args.output), ensure_ascii=False))
