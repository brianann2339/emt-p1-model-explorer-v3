import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

import protected_pipeline as route


class ProtectedRoute(unittest.TestCase):
    def setup_map(self, root):
        source = root / "source_manifest.json"
        source.write_text('{"synthetic_interface_test": true}', encoding="utf-8")
        path = root / "map.json"
        config = {"workspace": str(root), "python_by_stage": {"stage1a": sys.executable}, "inputs": {"source": {"path": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest()}}, "stages": {"stage1a": {"args": ["--source-manifest", "{input:source}", "--output-dir", "{output}"]}}}
        path.write_text(json.dumps(config), encoding="utf-8")
        return path, config

    def test_real_original_code_hashes(self):
        manifest = route.verify_code()
        self.assertEqual(len(manifest["stages"]), 7)
        self.assertFalse(manifest["full_training_replayed"])

    def test_bound_plan_is_read_only(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, config = self.setup_map(root)
            result = route.plan(path, "stage1a", root / "fresh")
            self.assertEqual(result["command"][0], sys.executable)
            self.assertIn(str(root / "source_manifest.json"), result["command"])
            self.assertFalse(result["scientific_execution_performed"])
            self.assertFalse((root / "fresh").exists())

    def test_modified_input_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, config = self.setup_map(root)
            (root / "source_manifest.json").write_text("modified", encoding="utf-8")
            with self.assertRaises(ValueError):
                route.plan(path, "stage1a", root / "fresh")

    def test_existing_output_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, config = self.setup_map(root)
            (root / "fresh/stage1a").mkdir(parents=True)
            with self.assertRaises(FileExistsError):
                route.plan(path, "stage1a", root / "fresh")

    def test_unknown_native_flag_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, config = self.setup_map(root)
            config["stages"]["stage1a"]["args"].append("--invented-model-option")
            path.write_text(json.dumps(config), encoding="utf-8")
            with self.assertRaises(ValueError):
                route.plan(path, "stage1a", root / "fresh")

    def test_no_unsealing_dispatch(self):
        self.assertNotIn("stage6", route.verify_code()["stages"])

    def test_exact_source_staging_and_no_clobber(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            route.stage_code(root)
            native = root / "scripts/run_stage1a_v2.py"
            self.assertEqual(route.sha(native), route.sha(route.PACK / "protected/native/scripts/run_stage1a_v2.py"))
            native.write_text("changed", encoding="utf-8")
            with self.assertRaises(ValueError):
                route.stage_code(root)


if __name__ == "__main__":
    unittest.main()
