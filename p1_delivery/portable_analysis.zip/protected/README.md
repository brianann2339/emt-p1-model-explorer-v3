# Protected native pipeline route

The package now contains byte-exact original scientific entry points for stages 01, 02, 03, 04, 05a and 05b plus their statically resolved local Python dependencies. Stage04 comes from the exact accepted W02 source package; no GPU transport credential scripts are required. `source_manifest.json` binds every copied source file and records native CLI flags. The original source entrypoints are not modified into an approximate replacement.

The public default `pipeline.py` still performs only the verified real aggregate analysis. For authorized protected data, use `protected_pipeline.py`:

```text
python protected_pipeline.py verify-code
python protected_pipeline.py plan --input-map private_inputs.json --stage stage1a --output-root C:/fresh/emt_replay
python protected_pipeline.py run --input-map private_inputs.json --stage stage1a --output-root C:/fresh/emt_replay --execute
```

The plan command verifies input hashes, the native source tree and flags, resolves named private inputs, and prints the exact non-shell command without executing the scientific stage. Run invokes that same command using the explicitly mapped stage-specific Python and original native arguments, with a fresh output directory and an execution receipt. Stage01's working example is supplied. Other stages use their exact original task/registry/rebind arguments, listed in the source manifest; default seed/trial settings must not be substituted for the source authority. Native code can still reject unavailable/incompatible data, registry, runtime or authorization bindings.

The input map is a local private document, never a public upload. Use an approved fresh replay workspace, not the existing accepted research root. On explicit run, byte-exact native sources are staged into that workspace (existing different code is rejected), so original workspace-relative lookups resolve correctly. Restore the original protected artifacts there, including required canonical reference/fold files, or supply the original pipeline's audited transport/path-rebind metadata. Do not edit scientific model/fold/seed bytes to repair paths. Directory inputs require an explicitly hashed inventory. Runtime locks are separate: W02 requirements and the accepted final-producer runtime are not one interchangeable pip environment. GPU model files/wheels and protected cohort artifacts are intentionally absent from this public ZIP; obtain them through the custodian process documented in AUTHOR_DECLARATIONS.md.

Stages06 unsealing/2025 inference are deliberately not dispatched by this route. The existing one-time frozen evaluation must not be repeated by an aggregate-reproduction command. Existing results/thresholds/figures may be replayed through the public analysis package. A separately authorized new-study private execution would require its own holdout authorization, not reuse this report as permission.

Verification performed here: exact file copy, Python syntax compilation, real code-tree hash validation, isolated-venv wrapper tests and real aggregate replay. **No protected fitting, prediction, raw-data loading, GPU call or full training reproduction has been executed.** This is an actual callable source-code/input route, not a claim that unavailable private inputs or heterogeneous GPU runtimes were reproduced.

## Legacy uncertainty warning

The original Stage3a entry point is preserved byte-exact for model/prediction provenance. Its legacy text/no-text bootstrap can place a mixed-outcome patient in both strata; such intervals must not be adopted as ordinary cluster-bootstrap evidence. The separate disjoint group-event CPU correction must be applied before current text-gain CI adoption. Original Overall W02 intervals are row-stratified by design and are reported with that unit, not silently converted to patient-group intervals.

## Required corrected text-gain postprocessing

The original Stage3a runner is retained byte-exact. Use the additional corrected statistics entrypoint in `source_manifest.json.postprocessing_entrypoints` to reproduce the reported confidence intervals, not the flawed legacy helper. First stage exact native sources with `python protected_pipeline.py stage-code --input-map private_inputs.json`; restore the bound saved OOF/2024 paired probabilities, metadata, source task/candidate manifests and capture frontier in the original workspace-relative layout. Then run `python outputs/v2/.p1gap_20260907/no_text_capture/paired_disjoint/correct_paired_ci.py --workers 4` from that approved private replay workspace. Its preparation/identity checks, per-task checkpoints, independent replicate validation and export are built into the unchanged correction entrypoint. No model is refit or predicted, and no raw2025 is accessed. This code/route is included; the public aggregate replay does not load those protected records.
