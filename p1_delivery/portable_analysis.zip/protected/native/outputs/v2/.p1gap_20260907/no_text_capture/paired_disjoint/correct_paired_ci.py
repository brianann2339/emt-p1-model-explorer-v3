from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
import argparse
import hashlib
import inspect
import json
import sys
import time

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parents[5]
sys.path.insert(0, str(ROOT))
from scripts import run_stage2a_v2 as evaluation

OUT = Path(__file__).resolve().parent
CAPTURE = OUT.parent
PACKAGE = ROOT / "outputs/v2/.p1gap_20260907/text_comparator_preparation/dataset"
OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
CONTEXTS = ("outer_0", "outer_1", "outer_2", "outer_3", "outer_4", "final")
REPS = 2000
ALGORITHM = "disjoint_patient_max_outcome_shared_original_choice_seed_2000_v1"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf8"))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1048576), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


def bind(path):
    return {"path": Path(path).resolve().relative_to(ROOT).as_posix(), "sha256": sha(path)}


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False), encoding="utf8")
    temp.replace(path)


def shared_weights(groups, y, seed, replicates=REPS, batch=64):
    codes, names = pd.factorize(np.asarray(groups, str), sort=True)
    group_event = np.zeros(len(names), dtype=int)
    np.maximum.at(group_event, codes, y)
    strata = [np.flatnonzero(group_event == event) for event in (0, 1)]
    assert not np.intersect1d(*strata).size
    assert np.array_equal(np.sort(np.concatenate(strata)), np.arange(len(names)))
    expected_multiplicity = np.zeros(len(names), dtype=int)
    for stratum in strata:
        expected_multiplicity[stratum] += 1
    assert np.array_equal(expected_multiplicity, np.ones(len(names), dtype=int))
    if any(len(s) == 0 for s in strata):
        return
    rng = np.random.default_rng(seed)
    for start in range(0, replicates, batch):
        count = min(batch, replicates - start)
        weights = np.empty((count, len(y)), dtype=float)
        for row in range(count):
            counts = np.zeros(len(names), dtype="int64")
            for stratum in strata:
                sampled = rng.choice(stratum, size=len(stratum), replace=True)
                counts += np.bincount(sampled, minlength=len(names))
            weights[row] = counts[codes]
        yield weights


def bootstrap(frame, seed, replicates=REPS):
    y = frame.y_true.to_numpy(int)
    probabilities = [frame.prediction_with.to_numpy(float), frame.prediction_no.to_numpy(float)]
    chunks = []
    for weights in shared_weights(frame.group_hash, y, seed, replicates):
        chunks.append(np.column_stack([evaluation.weighted_rank_metrics(weights, y, p)[1] for p in probabilities]))
    return np.vstack(chunks) if chunks else np.empty((0, 2))


def independent_bootstrap(frame, seed, replicates=REPS):
    patient_names = sorted(frame.group_hash.astype(str).unique())
    patient_index = {name: i for i, name in enumerate(patient_names)}
    codes = np.array([patient_index[str(g)] for g in frame.group_hash], dtype=int)
    y = frame.y_true.to_numpy(int)
    patient_max = frame.groupby(frame.group_hash.astype(str)).y_true.max()
    pools = [np.array([patient_index[g] for g in patient_names if patient_max[g] == event]) for event in (0, 1)]
    assert len(set(pools[0]) & set(pools[1])) == 0
    assert sum(len(x) for x in pools) == len(patient_names)
    if any(not len(x) for x in pools):
        return np.empty((0, 2))
    layouts = []
    for key in ("prediction_with", "prediction_no"):
        p = frame[key].to_numpy(float)
        order = np.argsort(p, kind="mergesort")[::-1]
        ends = np.r_[np.flatnonzero(np.diff(p[order])), len(p) - 1]
        layouts.append((order, ends))
    random = np.random.default_rng(seed)
    result = np.empty((replicates, 2))
    for replicate in range(replicates):
        multiplicity = np.zeros(len(patient_names), dtype=int)
        for pool in pools:
            draw = random.choice(pool, size=len(pool), replace=True)
            np.add.at(multiplicity, draw, 1)
        weights = multiplicity[codes]
        for column, (order, ends) in enumerate(layouts):
            positives = np.cumsum(weights[order] * y[order])[ends]
            totals = np.cumsum(weights[order])[ends]
            precision = np.divide(positives, totals, out=np.zeros_like(positives, dtype=float), where=totals != 0)
            result[replicate, column] = np.sum(np.diff(np.r_[0., positives]) / positives[-1] * precision)
    return result


def regression():
    frame = pd.DataFrame({"group_hash": ["mixed", "mixed", "negative", "positive", "negative2"],
        "y_true": [0, 1, 0, 1, 0], "prediction_with": [.2, .8, .2, .8, .1], "prediction_no": [.2, .8, .2, .8, .1]})
    codes, names = pd.factorize(frame.group_hash, sort=True)
    group_event = np.zeros(len(names), int)
    np.maximum.at(group_event, codes, frame.y_true)
    correct = [np.flatnonzero(group_event == x) for x in (0, 1)]
    legacy = [np.unique(codes[frame.y_true.to_numpy() == x]) for x in (0, 1)]
    expected_correct = sum((np.isin(np.arange(len(names)), x).astype(int) for x in correct))
    expected_legacy = sum((np.isin(np.arange(len(names)), x).astype(int) for x in legacy))
    assert expected_correct.tolist() == [1] * len(names)
    assert expected_legacy[list(names).index("mixed")] == 2
    with threadpool_limits(limits=1):
        a, b = bootstrap(frame, 1773), independent_bootstrap(frame, 1773)
    assert np.allclose(a, b, rtol=0, atol=1e-12)
    assert np.array_equal(a[:, 0] - a[:, 1], np.zeros(REPS))
    for weights in list(shared_weights(frame.group_hash, frame.y_true.to_numpy(), 1773, 8, 8)):
        native = evaluation.weighted_rank_metrics(weights, frame.y_true.to_numpy(), frame.prediction_with.to_numpy())[1]
        reference = [average_precision_score(frame.y_true, frame.prediction_with, sample_weight=w) for w in weights]
        assert np.allclose(native, reference, rtol=0, atol=1e-12)
    write(OUT / "method_regression.json", {"status": "PASS", "mixed_patient_stratum_memberships": 1,
        "expected_patient_multiplicity": expected_correct.tolist(), "legacy_mixed_patient_expected_multiplicity": 2,
        "same_vector_paired_delta_all_2000_exactly_zero": True, "two_independent_implementations_max_difference": float(np.max(np.abs(a-b))),
        "weighted_tie_regression_against_sklearn": "PASS", "model_calls": 0, "new_raw_2025_access": 0})


def prepare():
    plan = read(PACKAGE / "no_text_task_plan.json")
    valid = {}
    for path in sorted((CAPTURE / "validations").glob("*.json")):
        receipt = read(path)
        assert receipt["plan_sha256"] == sha(PACKAGE / "no_text_task_plan.json")
        for task in receipt["tasks"]:
            if task["status"] == "COMPLETE_CONTEXTS_CPU_READY":
                assert set(task["validated_contexts"]) == set(CONTEXTS)
                assert task["task_id"] not in valid
                valid[task["task_id"]] = (task, path)
    items, pending = [], []
    for task in plan["tasks"]:
        if task["task_id"] not in valid:
            pending.append(task["task_id"])
            continue
        authority, vp = valid[task["task_id"]]
        original = ROOT / authority["root"]
        with_path = PACKAGE / task["with_text_predictions"]
        assert sha(with_path) == task["with_text_predictions_sha256"]
        no_paths = []
        model_hashes = []
        for c in authority["contexts"]:
            pred = c["files"]["predictions"]
            path = ROOT / pred["path"]
            assert sha(path) == pred["sha256"]
            no_paths.append(path)
            model_hashes.append({"context": c["context"], **c["files"]["model"]})
        cm = next(e for e in task["source_files"] if e["path"].endswith("candidate_manifest.json"))
        candidate = read(PACKAGE / cm["path"])
        assert sha(PACKAGE / cm["path"]) == task["source_candidate_sha256"]
        items.append({"id": task["task_id"], "source_task_id": task["source_task_id"], "group": task["group"],
            "outcome": task["outcome"], "model": task["model"], "scope": "current_opname_specialty",
            "with": with_path, "no": no_paths, "metadata": PACKAGE / task["model_input"],
            "folds": PACKAGE / task["fold_input"], "authority": bind(vp), "source_candidate_sha256": task["source_candidate_sha256"],
            "with_text_model_sha256": candidate["model_sha256"], "no_text_context_models": model_hashes,
            "legacy_metrics_scope": "superseded_overlapping_patient_strata_CI_only; predictions_and_points_preserved"})
    for outcome in OUTCOMES:
        for model in ("mlp_plr", "ft_transformer"):
            root = ROOT / f"outputs/v2/stage3a/w03b_tabular_v2/P1_05a-{outcome}-{model}"
            acceptance = read(root / "scientific_acceptance_manifest.json")
            assert acceptance["status"] == "PASS" and acceptance["2025_access_count"] == 0 and acceptance["maximum_year"] <= 2024
            for name in ("predictions.parquet", "no_text_predictions.parquet"):
                assert sha(root / name) == acceptance["artifact_hashes"][name]
            sealed = read(root / "sealed_model_manifest.json")
            items.append({"id": f"overall_legacy_{outcome}_{model}_no_text", "source_task_id": f"P1_05a-{outcome}-{model}",
                "group": "overall", "outcome": outcome, "model": model, "scope": "earlier_strict_v2_overall_stage3a",
                "with": root / "predictions.parquet", "no": [root / "no_text_predictions.parquet"],
                "metadata": ROOT / "outputs/v2/stage1a/stage1a_features_le2024.parquet", "folds": ROOT / "qa_v2/fixed_group_folds_v2.parquet",
                "authority": bind(root / "scientific_acceptance_manifest.json"), "source_acceptance_manifest_sha256": sha(root / "scientific_acceptance_manifest.json"),
                "with_text_model_sha256": sealed["final_model"]["sha256"], "no_text_context_models": [{"path": str((root/p).relative_to(ROOT)).replace('\\','/'), "sha256": h} for p,h in sealed["no_text_model_hashes"].items()],
                "legacy_metrics": bind(root / "metrics.parquet"),
                "legacy_metrics_scope": "superseded_overlapping_patient_strata_CI_only; original_w03b_cohort_not_current_v3"})
    ready = []
    for item in items:
        with_frame = pd.read_parquet(item["with"])
        no = pd.concat([pd.read_parquet(p) for p in item["no"]], ignore_index=True)
        keys = ["row_hash", "split", "fold", "y_true"]
        joined = with_frame.merge(no[keys + ["prediction"]], on=keys, how="outer", suffixes=("_with", "_no"), indicator=True, validate="one_to_one")
        assert joined['_merge'].eq('both').all()
        assert set(joined.split) == {"oof_2020_2023", "validation_2024"}
        assert joined.model.eq(item["model"]).all() and joined.task_id.eq(item["source_task_id"]).all()
        meta = pd.read_parquet(item["metadata"], columns=["row_hash", "group_hash", "split_year", "split", "y_"+item["outcome"]])
        meta["group_hash"] = meta.group_hash.astype("string").mask(meta.group_hash.isna() | meta.group_hash.astype("string").str.strip().eq(""), meta.row_hash).astype(str)
        joined = joined.merge(meta, on="row_hash", suffixes=("", "_source"), validate="one_to_one")
        assert len(joined) == len(with_frame) == len(no)
        assert (joined.y_true == joined["y_"+item["outcome"]]).all()
        assert joined.loc[joined.split.eq("validation_2024"), "split_year"].eq(2024).all()
        assert joined.loc[joined.split.eq("oof_2020_2023"), "split_year"].between(2020, 2023).all()
        folds = pd.read_parquet(item["folds"])
        folds = folds.loc[folds.outcome.eq(item["outcome"])]
        dev = joined.loc[joined.split.eq("oof_2020_2023")]
        match = dev.merge(folds[["row_hash", "fold"]], on="row_hash", validate="one_to_one", suffixes=("", "_source"))
        assert len(match) == len(dev) and (match.fold == match.fold_source).all()
        assert not set(dev.group_hash).intersection(joined.loc[joined.split.eq("validation_2024"), "group_hash"])
        frame = joined[["row_hash", "group_hash", "split", "fold", "y_true", "prediction_with", "prediction_no"]].copy()
        assert np.isfinite(frame[["prediction_with", "prediction_no"]].to_numpy()).all()
        assert frame[["prediction_with", "prediction_no"]].ge(0).all().all() and frame[["prediction_with", "prediction_no"]].le(1).all().all()
        sources = [bind(item["with"]), *[bind(p) for p in item["no"]], bind(item["metadata"]), bind(item["folds"])]
        identity = canonical({"sources": sources, "id": item["id"], "algorithm": ALGORITHM,
            "evaluator": sha(Path(evaluation.__file__)), "weights_code": inspect.getsource(shared_weights), "bootstrap_code": inspect.getsource(bootstrap)})
        dest = OUT / "inputs" / item["id"]
        path = dest / "paired.parquet"
        info = {k:v for k,v in item.items() if k not in ["with", "no", "metadata", "folds"]}
        info.update({"identity": identity, "sources": sources, "n": len(frame), "split_counts": frame.split.value_counts().to_dict(), "algorithm": ALGORITHM})
        if (dest / "receipt.json").exists():
            previous = read(dest / "receipt.json")
            assert previous["identity"] == identity and sha(path) == previous["input"]["sha256"]
            info = previous
        else:
            dest.mkdir(parents=True, exist_ok=True)
            frame.to_parquet(path, index=False)
            info["input"] = bind(path)
            write(dest / "receipt.json", info)
        ready.append(info)
    write(OUT / "preparation.json", {"status": "READY" if len(ready)==54 else "PARTIAL_READY", "required": 54,
        "ready_count": len(ready), "pending_specialty": pending, "tasks": ready, "model_calls": 0, "new_raw_2025_access": 0})
    print(json.dumps({"stage": "prepare", "ready": len(ready), "pending": pending}), flush=True)
    return ready


def run_task(item):
    dest = OUT / "tasks" / item["id"]
    if (dest / "receipt.json").exists():
        receipt = read(dest / "receipt.json")
        assert receipt["identity"] == item["identity"]
        assert sha(dest / "metrics.json") == receipt["metrics_sha256"]
        assert read(dest / "independent_validation.json")["status"] == "PASS"
        return receipt
    started = time.perf_counter()
    assert sha(ROOT / item["input"]["path"]) == item["input"]["sha256"]
    frame = pd.read_parquet(ROOT / item["input"]["path"])
    output, checks, audit, samples = [], [], [], {}
    for split, data in frame.groupby("split", sort=True):
        seed = int(hashlib.sha256(f"{item['source_task_id']}:{split}:paired_text_delta".encode()).hexdigest()[:8],16)
        with threadpool_limits(limits=1):
            drawn, independent = bootstrap(data, seed), independent_bootstrap(data, seed)
        assert drawn.shape == independent.shape
        difference = float(np.max(np.abs(drawn - independent))) if len(drawn) else 0.0
        assert np.allclose(drawn, independent, rtol=0, atol=1e-12)
        samples[split] = drawn
        ap_with = float(average_precision_score(data.y_true, data.prediction_with))
        ap_no = float(average_precision_score(data.y_true, data.prediction_no))
        paired_values = [("AUPRC", ap_with, drawn[:,0]), ("AUPRC_no_text", ap_no, drawn[:,1]), ("Delta_AUPRC_text_minus_no_text", ap_with-ap_no, drawn[:,0]-drawn[:,1])]
        mixed = data.groupby("group_hash").y_true.nunique().gt(1)
        group_max = data.groupby("group_hash").y_true.max()
        for metric, point, values in paired_values:
            finite = values[np.isfinite(values)]
            estimated = len(finite) == REPS
            bounds = np.quantile(finite, [.025,.975]).tolist() if estimated else [None,None]
            output.append({"task_id": item["source_task_id"], "no_text_task_id": item["id"], "group": item["group"], "outcome": item["outcome"], "model": item["model"],
                "split": split, "metric": metric, "value": point, "lower_ci": bounds[0], "upper_ci": bounds[1], "status": "ESTIMATED" if estimated else "NOT_ESTIMABLE",
                "n": len(data), "events": int(data.y_true.sum()), "patient_groups": int(data.group_hash.nunique()),
                "mixed_outcome_patient_groups": int(mixed.sum()), "bootstrap_replicates": REPS, "bootstrap_success": len(finite),
                "bootstrap_seed": seed, "bootstrap_method": "outcome_stratified_disjoint_patient_cluster_shared_paired_draws", "group_stratum_rule": "max(y) within split",
                "expected_group_multiplicity": 1, "legacy_overlapping_strata_ci": "SUPERSEDED_RETAINED_FOR_AUDIT", "scope": item["scope"], "source_id": item["id"],
                "source_candidate_sha256": item.get("source_candidate_sha256"), "source_acceptance_manifest_sha256": item.get("source_acceptance_manifest_sha256"),
                "source_with_text_model_sha256": item["with_text_model_sha256"]})
        audit.append({"split": split, "seed": seed, "replicates": len(drawn), "independent_replicate_max_error": difference,
            "patient_groups": int(len(group_max)), "negative_patient_stratum": int((group_max==0).sum()), "positive_patient_stratum": int((group_max==1).sum()),
            "mixed_groups": int(mixed.sum()), "each_patient_in_exactly_one_stratum": True, "expected_group_multiplicity": 1,
            "with_probability_sha256": hashlib.sha256(data.prediction_with.to_numpy(float).tobytes()).hexdigest(),
            "no_probability_sha256": hashlib.sha256(data.prediction_no.to_numpy(float).tobytes()).hexdigest(),
            "ordered_row_sha256": canonical(data.row_hash.tolist()), "ordered_group_sha256": canonical(data.group_hash.tolist())})
    dest.mkdir(parents=True, exist_ok=True)
    write(dest / "metrics.json", output)
    np.savez_compressed(dest / "bootstrap_samples.npz", **samples)
    write(dest / "independent_validation.json", {"status": "PASS", "identity": item["identity"], "split_audits": audit,
        "method": "Separate patient-index construction and tie-aware cumulative-precision AP for all 2000 paired replicates; same original derived seed and shared draws",
        "failure_count": 0, "new_model_fit": 0, "new_model_predict": 0, "new_raw_2025_access": 0})
    result = {"status": "COMPLETE", "task_id": item["id"], "identity": item["identity"], "metric_rows": len(output), "paired_contrasts": len(audit),
        "metrics_sha256": sha(dest / "metrics.json"), "validation": bind(dest / "independent_validation.json"), "samples_sha256": sha(dest / "bootstrap_samples.npz"),
        "seconds": time.perf_counter()-started, "model_calls": 0, "new_raw_2025_access": 0}
    write(dest / "receipt.json", result)
    return result


def run(workers):
    regression()
    ready = prepare()
    done, failed = [], []
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(run_task,item):item for item in ready}
        for f in as_completed(futures):
            item = futures[f]
            try:
                result = f.result()
                done.append(result)
                print(json.dumps({"task": item["id"], "done": len(done), "ready": len(ready), "seconds": result["seconds"]}), flush=True)
            except Exception as exc:
                failed.append({"task": item["id"], "error": repr(exc)})
            write(OUT / "frontier.json", {"status": "COMPLETE" if len(done)==54 else "RUNNING_OR_PARTIAL", "completed": len(done), "required":54, "ready":len(ready), "failed":failed, "receipts":done})
    if failed:
        raise RuntimeError(str(failed))
    export()


def export():
    prep = read(OUT / "preparation.json")
    rows, sources = [], []
    for item in prep["tasks"]:
        dest = OUT / "tasks" / item["id"]
        if not (dest / "receipt.json").exists():
            continue
        receipt = read(dest / "receipt.json")
        assert receipt["identity"] == item["identity"] and sha(dest/"metrics.json")==receipt["metrics_sha256"]
        assert read(dest/"independent_validation.json")["status"] == "PASS"
        assert sha(dest/"independent_validation.json") == receipt["validation"]["sha256"]
        for source in item["sources"]:
            assert sha(ROOT/source["path"]) == source["sha256"]
        data = read(dest / "metrics.json")
        assert len(data) == 6 and {r["split"] for r in data} == {"oof_2020_2023", "validation_2024"}
        rows.extend(data)
        sources.append({"source_id":item["id"], "scope":item["scope"], "source_authority":item["authority"], "paired_input_receipt":bind(OUT/"inputs"/item["id"]/"receipt.json"),
            "corrected_metrics":bind(dest/"metrics.json"), "independent_validation":bind(dest/"independent_validation.json"),
            "source_candidate_sha256":item.get("source_candidate_sha256"), "source_acceptance_manifest_sha256":item.get("source_acceptance_manifest_sha256"),
            "source_with_text_model_sha256":item["with_text_model_sha256"], "no_text_context_models":item["no_text_context_models"],
            "legacy_ci_status":"SUPERSEDED_OVERLAPPING_STRATA_RETAINED_FOR_AUDIT"})
    target = OUT / "web_data"
    collections = []
    for name, group, title in [("text_gain", "overall", "Earlier Overall MLP/FT: corrected disjoint-patient paired text gain"), ("specialty_text_gain", "specialty", "Current Medicine/Surgery: corrected disjoint-patient paired text gain")]:
        subset = [r for r in rows if (r["group"]=="overall") == (group=="overall")]
        subset.sort(key=lambda r:(r['group'],r['outcome'],r['model'],r['split'],r['metric']))
        write(target / f"{name}.json", subset)
        pd.DataFrame(subset).to_csv(target/f"{name}.csv",index=False,lineterminator="\n")
        collections.append({"id":name,"title":title,"scope":"earlier_strict_v2_overall_stage3a_disjoint_correction" if group=="overall" else "current_opname_specialty_disjoint_correction",
            "notes":["Each patient belongs to one stratum defined by group_event=max(y) within split; shared paired group draws, original task/split seed and 2000 replicates.",
                "Positive delta is AUPRC(with text) minus AUPRC(no text); OOF and 2024 are separate. No model retraining, prediction, selection or raw2025 access.",
                "Legacy overlapping-strata intervals are superseded and retained only as historical audit evidence; point estimates and model artifacts are preserved.",
                "Nominal descriptive 95% intervals are unadjusted for multiplicity; the earlier Overall cohort is not the current v3 Overall cohort."],
            "rows":len(subset),"columns":list(subset[0]) if subset else [],"json":f"{name}.json","csv":f"{name}.csv",
            "json_sha256":sha(target/f"{name}.json"),"csv_sha256":sha(target/f"{name}.csv")})
    coverage={"completed_tasks":len(sources),"total_tasks":54,"paired_contrasts":len(rows)//3,"total_paired_contrasts":108,
        "specialty_completed":len({r['no_text_task_id'] for r in rows if r['group']!='overall'}),"specialty_required":36,
        "overall_legacy_completed":len({r['no_text_task_id'] for r in rows if r['group']=='overall'}),"overall_legacy_required":18}
    catalog={"schema":"emt-disjoint-paired-text-correction/1","collections":collections,"sources":sources,"coverage":coverage,
        "method_regression":bind(OUT/'method_regression.json'),"scientific_acceptance":False,"formal_acceptance":False,"new_raw_2025_access_count":0,
        "new_model_fit":0,"new_model_predict":0,"legacy_ci":"SUPERSEDED_OVERLAPPING_STRATA_CI_ONLY"}
    write(target/'supplement.json',catalog)
    write(OUT/'web_export_receipt.json',{"status":"PASS" if len(sources)==54 else "PARTIAL","coverage":coverage,
        "supplement":bind(target/'supplement.json'),"files":[bind(target/f'{n}.{e}') for n in ['text_gain','specialty_text_gain'] for e in ['json','csv']],
        "all_completed_tasks_independently_validated":True,"model_calls":0,"new_raw_2025_access_count":0})
    print(json.dumps({"export":coverage}),flush=True)


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument('--workers',type=int,default=4)
    parser.add_argument('--export-only',action='store_true')
    args=parser.parse_args()
    export() if args.export_only else run(args.workers)
