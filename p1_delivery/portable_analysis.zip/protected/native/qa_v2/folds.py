from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold

from .contract import OUTCOMES, sha256_file


def build_fixed_folds(
    features_path: Path,
    output_path: Path,
    manifest_path: Path,
    *,
    n_splits: int = 5,
    seed: int = 20260710,
) -> dict[str, Any]:
    required = {"row_hash", "group_hash", "split_year", *(f"y_{outcome}" for outcome in OUTCOMES)}
    frame = pd.read_parquet(features_path, columns=sorted(required))
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Stage1a feature artifact lacks fold inputs: {missing}")
    frame = frame.loc[pd.to_numeric(frame["split_year"], errors="coerce").between(2020, 2023)].copy()
    if frame["row_hash"].isna().any() or frame["row_hash"].duplicated().any():
        raise ValueError("training row_hash must be non-null and unique")
    frame["row_hash"] = frame["row_hash"].astype(str)
    group = frame["group_hash"].astype("string")
    missing_group = group.isna() | group.str.strip().eq("")
    frame["group_hash"] = group.mask(missing_group, frame["row_hash"]).astype(str)
    frame = frame.sort_values("row_hash", kind="mergesort").reset_index(drop=True)

    assignments = []
    summaries: dict[str, Any] = {}
    for outcome in OUTCOMES:
        target_column = f"y_{outcome}"
        target = pd.to_numeric(frame[target_column], errors="raise").astype(int)
        if not set(target.unique()).issubset({0, 1}):
            raise ValueError(f"{target_column} is not binary")
        if int(target.sum()) < n_splits or int((1 - target).sum()) < n_splits:
            raise ValueError(f"{target_column} cannot support {n_splits} stratified folds")
        splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        folds = np.full(len(frame), -1, dtype=np.int8)
        for fold, (_, validation_index) in enumerate(
            splitter.split(frame, target, groups=frame["group_hash"])
        ):
            folds[validation_index] = fold
        if (folds < 0).any():
            raise AssertionError(f"unassigned rows for {outcome}")
        for fold in range(n_splits):
            fold_target = target.loc[folds == fold]
            if int(fold_target.sum()) == 0 or int(fold_target.sum()) == len(fold_target):
                raise ValueError(f"{target_column} fold {fold} lacks one outcome class")
        outcome_frame = frame[["row_hash", "group_hash", "split_year"]].copy()
        outcome_frame.insert(2, "outcome", outcome)
        outcome_frame.insert(3, "fold", folds)
        assignments.append(outcome_frame)
        summaries[outcome] = {
            "rows": int(len(frame)),
            "events": int(target.sum()),
            "fold_rows": {str(fold): int((folds == fold).sum()) for fold in range(n_splits)},
            "fold_events": {
                str(fold): int(target.loc[folds == fold].sum()) for fold in range(n_splits)
            },
        }

    output = pd.concat(assignments, ignore_index=True)
    if output.duplicated(["row_hash", "outcome"]).any():
        raise AssertionError("duplicate row/outcome fold assignments")
    if output.groupby(["outcome", "group_hash"])["fold"].nunique().max() != 1:
        raise AssertionError("a patient group spans folds")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_path.with_suffix(".tmp.parquet")
    output.to_parquet(temporary, index=False)
    temporary.replace(output_path)
    manifest = {
        "schema_version": "1.0",
        "algorithm": "StratifiedGroupKFold",
        "n_splits": n_splits,
        "shuffle": True,
        "seed": seed,
        "training_years": [2020, 2021, 2022, 2023],
        "features_path": str(features_path),
        "features_sha256": sha256_file(features_path),
        "fold_map_path": str(output_path),
        "fold_map_sha256": sha256_file(output_path),
        "missing_group_fallback_to_row_hash": int(missing_group.sum()),
        "outcomes": summaries,
    }
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Build deterministic EMT P1 v2 group-stratified folds")
    parser.add_argument("--features", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--n-splits", type=int, default=5)
    parser.add_argument("--seed", type=int, default=20260710)
    args = parser.parse_args()
    build_fixed_folds(
        args.features.resolve(),
        args.output.resolve(),
        args.manifest.resolve(),
        n_splits=args.n_splits,
        seed=args.seed,
    )


if __name__ == "__main__":
    main()
