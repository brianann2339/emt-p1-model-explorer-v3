from __future__ import annotations

from pathlib import Path
from typing import Any

from qa_v2 import p1_06_explorer as legacy


CONTRACT_RELATIVE = "qa_v2/p1_06_layered_companion_explorer_contract_v1.json"
LEGACY_CONTRACT_RELATIVE = "qa_v2/p1_06_companion_explorer_contract.yaml"
LAYERED_BROWSER_RECEIPT_SCHEMA_RELATIVE = (
    "qa_v2/schemas/p1_06_layered_browser_qa_receipt_v2.schema.json"
)
LEGACY_BROWSER_RECEIPT_SCHEMA_RELATIVE = (
    "qa_v2/schemas/p1_06_browser_qa_receipt.schema.json"
)


def validate_companion_explorer_manifest_file(
    manifest_path: Path,
    schema_path: Path,
    project_root: Path,
    task_registry_path: Path,
    contract_path: Path,
    expected_acceptance_anchor_sha256: str,
) -> dict[str, Any]:
    root = project_root.resolve(strict=True)
    resolved_contract, contract_relative = legacy._argument_regular_file(
        root,
        contract_path,
        "layered contract",
    )
    if contract_relative != CONTRACT_RELATIVE:
        raise ValueError("layered companion governance contract path is not canonical")
    original_argument = legacy._argument_regular_file
    original_seal_json = legacy._seal_relative_json

    def mapped_argument(
        mapped_root: Path,
        path: Path,
        label: str,
    ) -> tuple[Path, str]:
        resolved, relative = original_argument(mapped_root, path, label)
        if label == "contract":
            if resolved != resolved_contract or relative != CONTRACT_RELATIVE:
                raise ValueError("layered companion governance contract changed")
            return resolved, LEGACY_CONTRACT_RELATIVE
        return resolved, relative

    def mapped_seal_json(
        mapped_root: Path,
        value: object,
        label: str,
        seals: dict[Path, legacy.FileSeal],
        expected_sha256: object | None = None,
    ) -> tuple[dict[str, Any], Path]:
        mapped_value = value
        if (
            label == "browser receipt schema"
            and value == LEGACY_BROWSER_RECEIPT_SCHEMA_RELATIVE
        ):
            mapped_value = LAYERED_BROWSER_RECEIPT_SCHEMA_RELATIVE
        return original_seal_json(
            mapped_root,
            mapped_value,
            label,
            seals,
            expected_sha256,
        )

    legacy._argument_regular_file = mapped_argument
    legacy._seal_relative_json = mapped_seal_json
    try:
        result = legacy.validate_companion_explorer_manifest_file(
            manifest_path,
            schema_path,
            root,
            task_registry_path,
            resolved_contract,
            expected_acceptance_anchor_sha256,
        )
    finally:
        legacy._argument_regular_file = original_argument
        legacy._seal_relative_json = original_seal_json
    result["contract_path"] = CONTRACT_RELATIVE
    return result
