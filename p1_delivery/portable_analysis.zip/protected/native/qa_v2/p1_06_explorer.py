from __future__ import annotations

import json
import hashlib
import io
import math
import os
import re
import stat
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import unquote, urlparse

import pandas as pd
from jsonschema import Draft202012Validator, FormatChecker


REPARSE_POINT = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
GENERATED_ACCEPTED_FILES = {
    "bundle.json": "artifact",
    "metric_source_displayed.parquet": "metric",
    "metric_independent_recompute.parquet": "metric",
    "bundle_numeric_records.parquet": "metric",
    "curve_source.parquet": "metric",
    "curve_independent_recompute.parquet": "metric",
}
ACCEPTED_INVENTORY_KEYS = {
    "path",
    "sha256",
    "role",
    "generation",
    "acceptance_status",
    "acceptance_receipt_path",
    "acceptance_receipt_sha256",
    "rows",
    "schema_sha256",
    "stage",
    "outcome",
    "model",
    "split",
    "model_sha256",
}


@dataclass(frozen=True)
class FileSeal:
    path: Path
    sha256: str
    size: int
    device: int
    inode: int
    mtime_ns: int
    ctime_ns: int


def load_document(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def _accepted_v2_path(value: object, label: str) -> None:
    if not isinstance(value, str) or "\\" in value:
        raise ValueError(f"{label} must be a normalized v2 artifact path")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or path.parts[:2] != ("outputs", "v2"):
        raise ValueError(f"{label} must remain under outputs/v2")


def _normalized_relative(value: object, label: str) -> PurePosixPath:
    if not isinstance(value, str) or not value or "\\" in value:
        raise ValueError(f"{label} must be a normalized relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or not path.parts or any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"{label} must be a normalized relative path")
    if path.as_posix() != value:
        raise ValueError(f"{label} must be a normalized relative path")
    return path


def _is_reparse(path: Path, file_stat: os.stat_result | None = None) -> bool:
    if path.is_symlink():
        return True
    is_junction = getattr(path, "is_junction", None)
    if callable(is_junction) and is_junction():
        return True
    value = file_stat if file_stat is not None else os.lstat(path)
    return bool(getattr(value, "st_file_attributes", 0) & REPARSE_POINT)


def _resolve_regular_file(project_root: Path, value: object, label: str) -> Path:
    relative = _normalized_relative(value, label)
    root = project_root.resolve(strict=True)
    path = root.joinpath(*relative.parts)
    current = root
    for part in relative.parts:
        current /= part
        try:
            current_stat = os.lstat(current)
        except FileNotFoundError as exc:
            raise FileNotFoundError(f"{label} is missing: {relative.as_posix()}") from exc
        if _is_reparse(current, current_stat):
            raise ValueError(f"{label} contains a symlink, junction, or reparse point")
    resolved = path.resolve(strict=True)
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"{label} resolves outside the project root") from exc
    file_stat = os.lstat(path)
    if not stat.S_ISREG(file_stat.st_mode) or _is_reparse(path, file_stat):
        raise ValueError(f"{label} is not a regular non-reparse file")
    return path


def _argument_regular_file(project_root: Path, path: Path, label: str) -> tuple[Path, str]:
    root = project_root.resolve(strict=True)
    candidate = path if path.is_absolute() else root / path
    try:
        relative = candidate.resolve(strict=True).relative_to(root).as_posix()
    except ValueError as exc:
        raise ValueError(f"{label} resolves outside the project root") from exc
    return _resolve_regular_file(root, relative, label), relative


def _fingerprint(value: os.stat_result) -> tuple[int, int, int, int, int, int]:
    return (
        int(value.st_dev),
        int(value.st_ino),
        int(value.st_size),
        int(value.st_mtime_ns),
        int(value.st_ctime_ns),
        int(value.st_mode),
    )


def _identity(value: os.stat_result) -> tuple[int, int, int, int]:
    return (int(value.st_dev), int(value.st_ino), int(value.st_size), int(value.st_mode))


def _same_seal(left: FileSeal, right: FileSeal) -> bool:
    return (
        left.path == right.path
        and left.sha256 == right.sha256
        and left.size == right.size
        and left.device == right.device
        and left.inode == right.inode
    )


def _stable_file(path: Path, capture: bool = False) -> tuple[FileSeal, bytes | None]:
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    for attempt in range(3):
        before = os.lstat(path)
        if not stat.S_ISREG(before.st_mode) or _is_reparse(path, before):
            raise ValueError(f"file is not regular or became a reparse point: {path}")
        descriptor = os.open(path, flags)
        payload = bytearray() if capture else None
        digest = hashlib.sha256()
        changed = False
        try:
            opened = os.fstat(descriptor)
            if _identity(opened) != _identity(before):
                changed = True
            else:
                while True:
                    block = os.read(descriptor, 1024 * 1024)
                    if not block:
                        break
                    digest.update(block)
                    if payload is not None:
                        payload.extend(block)
                changed = _fingerprint(os.fstat(descriptor)) != _fingerprint(opened)
        finally:
            os.close(descriptor)
        after_path = os.lstat(path)
        changed = changed or _identity(after_path) != _identity(before)
        if not changed and not _is_reparse(path, after_path):
            return (
                FileSeal(
                    path=path,
                    sha256=digest.hexdigest(),
                    size=int(before.st_size),
                    device=int(before.st_dev),
                    inode=int(before.st_ino),
                    mtime_ns=int(before.st_mtime_ns),
                    ctime_ns=int(before.st_ctime_ns),
                ),
                bytes(payload) if payload is not None else None,
            )
        if attempt == 2:
            raise ValueError(f"TOCTOU detected while reopening file: {path}")
    raise AssertionError("unreachable")


def _json_from_payload(payload: bytes, label: str) -> dict[str, Any]:
    value = json.loads(payload.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{label} must contain a JSON object")
    return value


def _seal_relative_json(
    project_root: Path,
    value: object,
    label: str,
    seals: dict[Path, FileSeal],
    expected_sha256: object | None = None,
) -> tuple[dict[str, Any], Path]:
    path = _resolve_regular_file(project_root, value, label)
    seal, payload = _stable_file(path, capture=True)
    if expected_sha256 is not None and seal.sha256 != expected_sha256:
        raise ValueError(f"{label} SHA256 mismatch")
    existing = seals.get(path)
    if existing is not None and not _same_seal(existing, seal):
        raise ValueError(f"{label} changed between reads")
    seals[path] = seal
    assert payload is not None
    return _json_from_payload(payload, label), path


def _seal_relative_file(
    project_root: Path,
    value: object,
    label: str,
    seals: dict[Path, FileSeal],
    expected_sha256: object,
    expected_size: object | None = None,
) -> Path:
    path = _resolve_regular_file(project_root, value, label)
    seal, _ = _stable_file(path)
    if seal.sha256 != expected_sha256:
        raise ValueError(f"{label} SHA256 mismatch")
    if expected_size is not None and seal.size != expected_size:
        raise ValueError(f"{label} size mismatch")
    existing = seals.get(path)
    if existing is not None and not _same_seal(existing, seal):
        raise ValueError(f"{label} changed between reads")
    seals[path] = seal
    return path


def _revalidate_seals(seals: dict[Path, FileSeal]) -> None:
    for path, expected in seals.items():
        actual, _ = _stable_file(path)
        if not _same_seal(actual, expected):
            raise ValueError(f"TOCTOU detected after validation: {path}")


def _validate_inventory_partitions(manifest: dict[str, Any]) -> None:
    partitions = {"data": {}, "model": {}, "artifact": {}}
    for record in manifest["accepted_artifact_inventory"]:
        target = record["role"]
        if target in {"metric", "artifact"}:
            target = "artifact"
        if record["path"] in partitions[target]:
            raise ValueError("accepted artifact inventory contains a duplicate path")
        partitions[target][record["path"]] = record["sha256"]
    expected = {
        "data": manifest["data_hashes"],
        "model": manifest["model_hashes"],
        "artifact": manifest["artifact_hashes"],
    }
    if partitions != expected:
        raise ValueError("path-keyed hash inventories do not exactly partition accepted artifacts")


def validate_companion_explorer_manifest(
    manifest: dict[str, Any], schema: dict[str, Any]
) -> dict[str, int | float | str]:
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(manifest), key=lambda error: list(error.absolute_path))
    if errors:
        first = errors[0]
        location = ".".join(str(part) for part in first.absolute_path) or "<root>"
        raise ValueError(f"P1_06 companion manifest schema violation at {location}: {first.message}")

    def reject_nonfinite(value: object, label: str) -> None:
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError(f"P1_06 companion contains a nonfinite numeric value at {label}")
        if isinstance(value, dict):
            for key, child in value.items():
                reject_nonfinite(child, f"{label}.{key}")
        elif isinstance(value, list):
            for index, child in enumerate(value):
                reject_nonfinite(child, f"{label}[{index}]")

    reject_nonfinite(manifest, "manifest")
    _validate_inventory_partitions(manifest)

    browser = manifest["browser_qa"]
    if browser["output_sha256"] != manifest["output"]["sha256"]:
        raise ValueError("P1_06 browser evidence is not bound to the companion output")
    viewports = {row["name"]: row for row in browser["viewports"]}
    expected_viewports = {
        "desktop": (1366, 768),
        "mobile": (390, 844),
    }
    if set(viewports) != set(expected_viewports):
        raise ValueError("P1_06 browser evidence must contain exact desktop and mobile viewports")
    for name, dimensions in expected_viewports.items():
        if (viewports[name]["width"], viewports[name]["height"]) != dimensions:
            raise ValueError(f"P1_06 {name} viewport dimensions mismatch")

    inventory = manifest["accepted_artifact_inventory"]
    artifact_paths = [record["path"] for record in inventory]
    if len(set(artifact_paths)) != len(artifact_paths):
        raise ValueError("P1_06 companion accepted artifact paths are not unique")
    for index, record in enumerate(inventory):
        _accepted_v2_path(record["path"], f"accepted_artifact_inventory[{index}].path")
        _accepted_v2_path(
            record["acceptance_receipt_path"],
            f"accepted_artifact_inventory[{index}].acceptance_receipt_path",
        )
    for index, path in enumerate(manifest["metric_recompute"]["source_paths"]):
        _accepted_v2_path(path, f"metric_recompute.source_paths[{index}]")

    recompute = manifest["metric_recompute"]
    comparison_names = ("source_to_recompute", "bundle_to_recompute", "dom_to_bundle")
    compared_counts = {
        recompute[name]["key_count"]
        for name in comparison_names
    }
    compared_digests = {recompute[name]["key_sha256"] for name in comparison_names}
    if compared_counts != {recompute["displayed_key_count"]}:
        raise ValueError("P1_06 companion three-way metric comparison key counts differ")
    if compared_digests != {recompute["displayed_key_sha256"]}:
        raise ValueError("P1_06 companion three-way metric comparison key digests differ")
    return {
        "status": "LOGICAL_PASS",
        "accepted_artifacts": len(inventory),
        "metric_keys_declared": int(recompute["displayed_key_count"]),
        "maximum_absolute_error": max(
            float(recompute[name]["maximum_absolute_error"])
            for name in comparison_names
        ),
    }


def _capture_relative_file(
    project_root: Path,
    value: object,
    label: str,
    seals: dict[Path, FileSeal],
    expected_sha256: object,
) -> tuple[Path, bytes]:
    path = _resolve_regular_file(project_root, value, label)
    seal, payload = _stable_file(path, capture=True)
    if seal.sha256 != expected_sha256:
        raise ValueError(f"{label} SHA256 mismatch")
    existing = seals.get(path)
    if existing is not None and not _same_seal(existing, seal):
        raise ValueError(f"{label} changed between reads")
    seals[path] = seal
    assert payload is not None
    return path, payload


def _expected_mandatory_tasks(registry: dict[str, Any]) -> dict[str, tuple[str, str]]:
    rows = [
        task
        for task in registry.get("tasks", [])
        if task.get("stage") == "P1_06" and task.get("task_family") == "frozen_evaluation"
    ]
    expected_outcomes = {"P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6"}
    expected_components = {
        "rSI_sMS",
        "logistic_regression",
        "catboost",
        "xgboost",
        "lightgbm",
        "bert_finetuned",
        "mlp_plr",
        "ft_transformer",
        "cnn_1d",
        "tabpfn",
        "tabicl",
        "stacking",
    }
    result: dict[str, tuple[str, str]] = {}
    for task in rows:
        task_id = task.get("task_id")
        pair = (task.get("outcome"), task.get("model"))
        if not isinstance(task_id, str) or task_id in result:
            raise ValueError("locked task registry has duplicate or invalid P1_06 task IDs")
        if pair[0] not in expected_outcomes or pair[1] not in expected_components:
            raise ValueError("locked task registry has an unknown P1_06 outcome/component")
        result[task_id] = (str(pair[0]), str(pair[1]))
    expected_pairs = {
        (outcome, component)
        for outcome in expected_outcomes
        for component in expected_components
    }
    if len(result) != 108 or set(result.values()) != expected_pairs:
        raise ValueError("locked task registry does not contain the exact 9x12 P1_06 task grid")
    return result


def _expected_numeric_keys(
    expected_tasks: dict[str, tuple[str, str]]
) -> set[tuple[str, str, str, str, str]]:
    metrics = (
        "AUROC",
        "AUPRC",
        "sensitivity",
        "specificity",
        "PPV",
        "NPV",
        "threshold",
        "N",
        "events",
        "TP",
        "FP",
        "TN",
        "FN",
    )
    return {
        (task_id, outcome, component, split, metric)
        for task_id, (outcome, component) in expected_tasks.items()
        for split in ("validation_2024", "test_2025")
        for metric in metrics
    }


def _validate_mandatory_bindings(
    manifest: dict[str, Any],
    registry: dict[str, Any],
    inventory: dict[str, dict[str, Any]],
) -> None:
    expected = _expected_mandatory_tasks(registry)
    bindings = manifest["mandatory_bindings"]
    by_task: dict[str, dict[str, Any]] = {}
    seen_pairs: set[tuple[str, str]] = set()
    for binding in bindings:
        task_id = binding["task_id"]
        pair = (binding["outcome"], binding["component"])
        if task_id in by_task or pair in seen_pairs:
            raise ValueError("mandatory bindings contain a duplicate task or outcome/component")
        by_task[task_id] = binding
        seen_pairs.add(pair)
    if set(by_task) != set(expected):
        raise ValueError("mandatory bindings have missing or extra locked P1_06 task IDs")
    if {task_id: (row["outcome"], row["component"]) for task_id, row in by_task.items()} != expected:
        raise ValueError("mandatory bindings differ from locked task outcome/component assignments")
    for task_id, binding in by_task.items():
        split_rows = [binding["validation_2024"], binding["test_2025"]]
        if len({(row["model_path"], row["model_sha256"]) for row in split_rows}) != 1:
            raise ValueError(f"{task_id} validation/test model bindings differ")
        if len({(row["sealed_spec_path"], row["sealed_spec_sha256"]) for row in split_rows}) != 1:
            raise ValueError(f"{task_id} validation/test sealed-spec bindings differ")
        for split_name, row in zip(("validation_2024", "test_2025"), split_rows):
            for field in ("artifact_path", "acceptance_receipt_path", "model_path", "sealed_spec_path"):
                _accepted_v2_path(row[field], f"{task_id}.{split_name}.{field}")
            artifact = inventory.get(row["artifact_path"])
            if artifact is None or artifact["sha256"] != row["artifact_sha256"]:
                raise ValueError(f"{task_id} {split_name} artifact is not in accepted inventory")
            if (
                artifact["acceptance_receipt_path"] != row["acceptance_receipt_path"]
                or artifact["acceptance_receipt_sha256"] != row["acceptance_receipt_sha256"]
            ):
                raise ValueError(f"{task_id} {split_name} artifact receipt binding mismatch")
            model = inventory.get(row["model_path"])
            if model is None or model["role"] != "model" or model["sha256"] != row["model_sha256"]:
                raise ValueError(f"{task_id} {split_name} model is not in accepted model inventory")
            spec = inventory.get(row["sealed_spec_path"])
            if spec is None or spec["role"] != "artifact" or spec["sha256"] != row["sealed_spec_sha256"]:
                raise ValueError(f"{task_id} {split_name} spec is not in accepted artifact inventory")


NumericRecords = dict[tuple[str, str, str, str, str], tuple[str, float | None]]
CurveRecords = dict[
    tuple[str, str, str, str, str, int], tuple[float, float, float | None]
]


def _numeric_records(payload: bytes, label: str) -> NumericRecords:
    columns = ["task_id", "outcome", "component", "split", "metric", "status", "value"]
    try:
        frame = pd.read_parquet(io.BytesIO(payload), columns=columns)
    except Exception as exc:
        raise ValueError(f"{label} is not a readable canonical numeric parquet") from exc
    records: NumericRecords = {}
    for row in frame.itertuples(index=False, name=None):
        key = tuple(str(value) for value in row[:5])
        status_value = str(row[5])
        raw_numeric = row[6]
        if status_value == "ESTIMABLE":
            numeric = float(raw_numeric)
            if not math.isfinite(numeric):
                raise ValueError(f"{label} contains a nonfinite displayed numeric value")
        elif status_value == "NOT_ESTIMABLE" and pd.isna(raw_numeric):
            numeric = None
        else:
            raise ValueError(f"{label} has an invalid estimability status/value pair")
        if key in records:
            raise ValueError(f"{label} contains a duplicate displayed numeric key")
        records[key] = (status_value, numeric)
    if not records:
        raise ValueError(f"{label} contains no displayed numeric records")
    return records


def _key_digest(records: NumericRecords) -> str:
    payload = json.dumps(sorted(records), ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _compare_numeric_records(
    left: NumericRecords,
    right: NumericRecords,
    tolerance: float,
) -> tuple[int, str, int, float]:
    if set(left) != set(right):
        raise ValueError("displayed numeric key sets differ")
    errors: dict[tuple[str, str, str, str, str], float] = {}
    status_mismatches = 0
    for key in left:
        left_status, left_value = left[key]
        right_status, right_value = right[key]
        if left_status != right_status:
            status_mismatches += 1
            errors[key] = math.inf
        elif left_status == "NOT_ESTIMABLE":
            errors[key] = 0.0
        else:
            assert left_value is not None and right_value is not None
            errors[key] = abs(left_value - right_value)
    maximum = max(errors.values(), default=0.0)
    mismatches = status_mismatches + sum(
        error > tolerance for error in errors.values() if math.isfinite(error)
    )
    return len(left), _key_digest(left), mismatches, maximum


def _validate_comparison_summary(
    summary: dict[str, Any], actual: tuple[int, str, int, float], label: str
) -> None:
    count, digest, mismatches, maximum = actual
    if summary["key_count"] != count or summary["key_sha256"] != digest:
        raise ValueError(f"{label} declared key coverage differs from independently derived set")
    if summary["mismatch_count"] != mismatches or mismatches != 0:
        raise ValueError(f"{label} has numeric mismatches")
    if not math.isclose(
        float(summary["maximum_absolute_error"]), maximum, rel_tol=0.0, abs_tol=1e-15
    ):
        raise ValueError(f"{label} maximum absolute error is not independently reproduced")


def _curve_records_from_rows(rows: list[dict[str, Any]], label: str) -> CurveRecords:
    required = {
        "task_id",
        "outcome",
        "component",
        "split",
        "curve_type",
        "point_index",
        "x",
        "y",
        "threshold",
    }
    records: CurveRecords = {}
    for index, row in enumerate(rows):
        if not isinstance(row, dict) or set(row) != required:
            raise ValueError(f"{label} curve record {index} fields mismatch")
        key = (
            str(row["task_id"]),
            str(row["outcome"]),
            str(row["component"]),
            str(row["split"]),
            str(row["curve_type"]),
            int(row["point_index"]),
        )
        x_value = float(row["x"])
        y_value = float(row["y"])
        raw_threshold = row["threshold"]
        threshold = None if raw_threshold is None or pd.isna(raw_threshold) else float(raw_threshold)
        if not math.isfinite(x_value) or not math.isfinite(y_value):
            raise ValueError(f"{label} contains nonfinite curve coordinates")
        if threshold is not None and not math.isfinite(threshold):
            raise ValueError(f"{label} contains a nonfinite curve threshold")
        if key in records:
            raise ValueError(f"{label} contains duplicate curve keys")
        records[key] = (x_value, y_value, threshold)
    if not records:
        raise ValueError(f"{label} contains no curve records")
    return records


def _curve_records(payload: bytes, label: str) -> CurveRecords:
    columns = [
        "task_id",
        "outcome",
        "component",
        "split",
        "curve_type",
        "point_index",
        "x",
        "y",
        "threshold",
    ]
    try:
        frame = pd.read_parquet(io.BytesIO(payload), columns=columns)
    except Exception as exc:
        raise ValueError(f"{label} is not a readable canonical curve parquet") from exc
    return _curve_records_from_rows(frame.to_dict("records"), label)


def _curve_digests(records: CurveRecords) -> tuple[str, str]:
    key_payload = json.dumps(sorted(records), ensure_ascii=False, separators=(",", ":"))
    value_payload = json.dumps(
        [[*key, *records[key]] for key in sorted(records)],
        ensure_ascii=False,
        separators=(",", ":"),
    )
    return (
        hashlib.sha256(key_payload.encode("utf-8")).hexdigest(),
        hashlib.sha256(value_payload.encode("utf-8")).hexdigest(),
    )


def _validate_curve_coverage(
    records: CurveRecords, expected_tasks: dict[str, tuple[str, str]], label: str
) -> None:
    grouped: dict[tuple[str, str, str, str, str], list[int]] = {}
    for key in records:
        grouped.setdefault(key[:5], []).append(key[5])
    expected_groups = {
        (task_id, outcome, component, split, curve_type)
        for task_id, (outcome, component) in expected_tasks.items()
        for split in ("validation_2024", "test_2025")
        for curve_type in ("roc", "pr")
    }
    if set(grouped) != expected_groups:
        raise ValueError(f"{label} curve groups differ from exact registry task/split/type grid")
    for group, indices in grouped.items():
        ordered = sorted(indices)
        if len(ordered) < 2 or ordered != list(range(len(ordered))):
            raise ValueError(f"{label} curve point indices are incomplete for {group}")


def _compare_curve_records(
    left: CurveRecords, right: CurveRecords, tolerance: float
) -> tuple[int, str, str, int, float]:
    if set(left) != set(right):
        raise ValueError("curve key sets differ")
    errors: list[float] = []
    mismatches = 0
    for key in left:
        for left_value, right_value in zip(left[key], right[key]):
            if left_value is None or right_value is None:
                if left_value is not None or right_value is not None:
                    mismatches += 1
                continue
            error = abs(left_value - right_value)
            errors.append(error)
            mismatches += int(error > tolerance)
    key_digest, value_digest = _curve_digests(left)
    return len(left), key_digest, value_digest, mismatches, max(errors, default=0.0)


def _validate_curve_summary(
    summary: dict[str, Any], actual: tuple[int, str, str, int, float], label: str
) -> None:
    count, key_digest, value_digest, mismatches, maximum = actual
    if (
        summary["point_count"] != count
        or summary["key_sha256"] != key_digest
        or summary["value_sha256"] != value_digest
    ):
        raise ValueError(f"{label} curve coverage digest differs from independent derivation")
    if summary["mismatch_count"] != mismatches or mismatches != 0:
        raise ValueError(f"{label} curve values mismatch")
    if not math.isclose(
        float(summary["maximum_absolute_error"]), maximum, rel_tol=0.0, abs_tol=1e-15
    ):
        raise ValueError(f"{label} curve maximum error is not independently reproduced")


def _dom_numeric_records(rows: object, label: str) -> NumericRecords:
    if not isinstance(rows, list):
        raise ValueError(f"{label} displayed_numeric_records must be a list")
    records: NumericRecords = {}
    fields = ("task_id", "outcome", "component", "split", "metric")
    for index, row in enumerate(rows):
        if not isinstance(row, dict) or set(row) != {*fields, "status", "value"}:
            raise ValueError(f"{label} numeric record {index} fields mismatch")
        key = tuple(str(row[field]) for field in fields)
        status_value = row["status"]
        if status_value == "ESTIMABLE":
            numeric = float(row["value"])
            if not math.isfinite(numeric):
                raise ValueError(f"{label} contains a nonfinite DOM numeric value")
        elif status_value == "NOT_ESTIMABLE" and row["value"] is None:
            numeric = None
        else:
            raise ValueError(f"{label} has an invalid DOM estimability status/value pair")
        if key in records:
            raise ValueError(f"{label} contains a duplicate DOM numeric key")
        records[key] = (str(status_value), numeric)
    if not records:
        raise ValueError(f"{label} contains no DOM numeric records")
    return records


def _validate_browser_evidence(
    project_root: Path,
    manifest: dict[str, Any],
    seals: dict[Path, FileSeal],
    bundle_records: NumericRecords,
    inventory: dict[str, dict[str, Any]],
    bundle: dict[str, Any],
) -> tuple[int, int, tuple[int, str, int, float]]:
    browser = manifest["browser_qa"]
    expected_dimensions = {"desktop": (1366, 768), "mobile": (390, 844)}
    pointers = {row["name"]: row for row in browser["viewports"]}
    control_sets: list[set[str]] = []
    image_sets: list[set[str]] = []
    dom_results: list[tuple[int, str, int, float]] = []
    asset_tree = manifest["asset_tree"]
    shap_manifest_path = asset_tree["source_manifest_path"]
    shap_inventory = inventory.get(shap_manifest_path)
    if shap_inventory is None or shap_inventory["role"] != "artifact":
        raise ValueError("SHAP source manifest is not in accepted artifact inventory")
    if shap_inventory["sha256"] != asset_tree["source_manifest_sha256"]:
        raise ValueError("SHAP source manifest inventory hash mismatch")
    shap_manifest, _ = _seal_relative_json(
        project_root,
        shap_manifest_path,
        "SHAP source manifest",
        seals,
        asset_tree["source_manifest_sha256"],
    )
    if shap_manifest.get("status") != "PASS" or not isinstance(
        shap_manifest.get("mappings"), list
    ):
        raise ValueError("SHAP source manifest is not PASS or lacks mappings")
    expected_asset_hashes: dict[str, str] = {}
    for index, mapping in enumerate(shap_manifest["mappings"]):
        required_mapping = {
            "source_path",
            "source_sha256",
            "output_path",
            "output_sha256",
        }
        if not isinstance(mapping, dict) or set(mapping) != required_mapping:
            raise ValueError(f"SHAP source mapping {index} fields mismatch")
        source = inventory.get(mapping["source_path"])
        if source is None or source["sha256"] != mapping["source_sha256"]:
            raise ValueError(f"SHAP source mapping {index} is not in accepted inventory")
        _seal_relative_file(
            project_root,
            mapping["source_path"],
            f"SHAP source mapping {index}",
            seals,
            mapping["source_sha256"],
        )
        output_path = _normalized_relative(
            mapping["output_path"], f"SHAP output mapping {index}"
        ).as_posix()
        if not output_path.startswith("outputs/report/figures/v2_model_family_shap/"):
            raise ValueError(f"SHAP output mapping {index} is outside the v2 asset tree")
        if output_path in expected_asset_hashes:
            raise ValueError("SHAP source manifest has duplicate output paths")
        _seal_relative_file(
            project_root,
            output_path,
            f"SHAP output mapping {index}",
            seals,
            mapping["output_sha256"],
        )
        expected_asset_hashes[output_path] = mapping["output_sha256"]
    if not expected_asset_hashes:
        raise ValueError("SHAP source manifest contains no output mappings")
    accepted_shap_assets = bundle.get("accepted_shap_assets")
    if not isinstance(accepted_shap_assets, list) or any(
        not isinstance(row, dict) or set(row) != {"path"}
        for row in accepted_shap_assets
    ):
        raise ValueError("sealed explorer bundle accepted_shap_assets are malformed")
    if {row["path"] for row in accepted_shap_assets} != set(expected_asset_hashes):
        raise ValueError("sealed explorer bundle accepted SHAP paths differ from copy manifest")
    shap_audit = bundle.get("shap_audit")
    if not isinstance(shap_audit, list):
        raise ValueError("sealed explorer bundle SHAP audit is missing")
    referenced_shap_paths: set[str] = set()
    for row in shap_audit:
        if not isinstance(row, dict):
            raise ValueError("sealed explorer bundle SHAP audit row is malformed")
        for field, value in row.items():
            if not field.endswith("_path") or not isinstance(value, str) or not value:
                continue
            formal = f"outputs/report/{value}" if value.startswith("figures/") else value
            normalized = _normalized_relative(formal, f"bundle shap_audit.{field}").as_posix()
            referenced_shap_paths.add(normalized)
    if not referenced_shap_paths.issubset(expected_asset_hashes):
        raise ValueError("sealed explorer bundle SHAP audit references unaccepted assets")
    receipt_schema, _ = _seal_relative_json(
        project_root,
        "qa_v2/schemas/p1_06_browser_qa_receipt.schema.json",
        "browser receipt schema",
        seals,
    )
    Draft202012Validator.check_schema(receipt_schema)
    receipt_validator = Draft202012Validator(
        receipt_schema, format_checker=FormatChecker()
    )
    asset_hashes: dict[str, str] = {}
    receipt_paths: set[str] = set()
    for name, dimensions in expected_dimensions.items():
        pointer = pointers[name]
        receipt_path = pointer["evidence_receipt_path"]
        _accepted_v2_path(receipt_path, f"{name} browser receipt")
        if receipt_path in receipt_paths:
            raise ValueError("desktop and mobile browser evidence receipts must be distinct")
        receipt_paths.add(receipt_path)
        receipt, _ = _seal_relative_json(
            project_root,
            receipt_path,
            f"{name} browser receipt",
            seals,
            pointer["evidence_receipt_sha256"],
        )
        receipt_errors = sorted(
            receipt_validator.iter_errors(receipt),
            key=lambda error: list(error.absolute_path),
        )
        if receipt_errors:
            first = receipt_errors[0]
            location = ".".join(str(part) for part in first.absolute_path) or "<root>"
            raise ValueError(
                f"{name} browser receipt schema violation at {location}: {first.message}"
            )
        if receipt.get("status") != "PASS":
            raise ValueError(f"{name} browser receipt is not PASS")
        if receipt.get("output_path") != manifest["output"]["path"]:
            raise ValueError(f"{name} browser receipt output path mismatch")
        if receipt.get("output_sha256") != manifest["output"]["sha256"]:
            raise ValueError(f"{name} browser receipt output SHA256 mismatch")
        viewport = receipt.get("viewport")
        if viewport != {"name": name, "width": dimensions[0], "height": dimensions[1]}:
            raise ValueError(f"{name} browser receipt viewport mismatch")
        if (pointer["width"], pointer["height"]) != dimensions:
            raise ValueError(f"{name} browser pointer viewport mismatch")
        timestamp = receipt.get("generated_at_utc")
        if not isinstance(timestamp, str):
            raise ValueError(f"{name} browser receipt timestamp missing")
        try:
            parsed_timestamp = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError(f"{name} browser receipt timestamp invalid") from exc
        if parsed_timestamp.tzinfo is None:
            raise ValueError(f"{name} browser receipt timestamp lacks timezone")
        tested_url = receipt.get("tested_url")
        parsed_url = urlparse(tested_url if isinstance(tested_url, str) else "")
        expected_url_path = "/outputs/report/EMT_P1_v2_companion_model_explorer.html"
        if (
            parsed_url.scheme not in {"http", "https"}
            or parsed_url.hostname not in {"127.0.0.1", "localhost", "::1"}
            or not unquote(parsed_url.path).endswith(expected_url_path)
        ):
            raise ValueError(f"{name} browser receipt tested URL invalid")
        runner_path = receipt.get("runner_path")
        _seal_relative_file(
            project_root,
            runner_path,
            f"{name} browser runner",
            seals,
            receipt.get("runner_sha256"),
        )
        screenshot_path = receipt.get("screenshot_path")
        _accepted_v2_path(screenshot_path, f"{name} browser screenshot")
        _seal_relative_file(
            project_root,
            screenshot_path,
            f"{name} browser screenshot",
            seals,
            receipt.get("screenshot_sha256"),
        )
        event_log_path = receipt.get("event_log_path")
        _accepted_v2_path(event_log_path, f"{name} browser event log")
        _seal_relative_file(
            project_root,
            event_log_path,
            f"{name} browser event log",
            seals,
            receipt.get("event_log_sha256"),
        )
        for field in (
            "horizontal_overflow_px",
            "http_404_count",
            "http_error_response_count",
            "console_error_count",
            "page_error_count",
            "request_failure_count",
        ):
            if receipt.get(field) != 0:
                raise ValueError(f"{name} browser receipt {field} must equal zero")

        controls = receipt.get("controls")
        if not isinstance(controls, list) or not controls:
            raise ValueError(f"{name} browser receipt has no control evidence")
        control_ids: set[str] = set()
        for control in controls:
            if not isinstance(control, dict) or set(control) != {"control_id", "tested", "operable"}:
                raise ValueError(f"{name} browser control evidence fields mismatch")
            control_id = control["control_id"]
            if not isinstance(control_id, str) or not control_id or control_id in control_ids:
                raise ValueError(f"{name} browser control IDs are empty or duplicated")
            if control["tested"] is not True or control["operable"] is not True:
                raise ValueError(f"{name} browser control was not tested and operable")
            control_ids.add(control_id)
        control_sets.append(control_ids)

        images = receipt.get("images")
        if not isinstance(images, list) or not images:
            raise ValueError(f"{name} browser receipt has no SHAP image evidence")
        image_paths: set[str] = set()
        for image in images:
            required_image = {"path", "sha256", "complete", "natural_width", "http_status"}
            if not isinstance(image, dict) or set(image) != required_image:
                raise ValueError(f"{name} browser SHAP image evidence fields mismatch")
            image_path = image["path"]
            normalized = _normalized_relative(image_path, f"{name} SHAP image path").as_posix()
            if not normalized.startswith("outputs/report/figures/v2_model_family_shap/"):
                raise ValueError(f"{name} browser SHAP image is outside the v2 asset tree")
            if normalized in image_paths:
                raise ValueError(f"{name} browser SHAP image paths are duplicated")
            if image["complete"] is not True or int(image["natural_width"]) <= 0:
                raise ValueError(f"{name} browser SHAP image is incomplete or has zero naturalWidth")
            if not isinstance(image["http_status"], int) or not 200 <= image["http_status"] < 400:
                raise ValueError(f"{name} browser SHAP image HTTP status is unsuccessful")
            _seal_relative_file(
                project_root,
                normalized,
                f"{name} SHAP image",
                seals,
                image["sha256"],
            )
            image_paths.add(normalized)
            existing_hash = asset_hashes.get(normalized)
            if existing_hash is not None and existing_hash != image["sha256"]:
                raise ValueError("desktop/mobile SHAP image hashes differ")
            asset_hashes[normalized] = image["sha256"]
        image_sets.append(image_paths)

        dom_records = _dom_numeric_records(
            receipt.get("displayed_numeric_records"), f"{name} browser receipt"
        )
        dom_results.append(
            _compare_numeric_records(dom_records, bundle_records, 1e-12)
        )
    if control_sets[0] != control_sets[1]:
        raise ValueError("desktop/mobile tested control ID sets differ")
    expected_controls = {
        "showTopClinical",
        "showAllClinical",
        "tabRoc",
        "tabPr",
        "tabRank",
        "detailChampionTab",
        "detailOperatingTab",
        "detailFeatureTab",
        "detailShapTab",
        "detailEnsembleTab",
        "expandFeatureBtn",
        "closeFeatureModal",
        "closeImageModal",
        "groupSelect::overall",
        "splitSelect::validation_2024",
        "splitSelect::external_2025",
        *{
            f"outcomeSelect::y_{value}"
            for value in ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
        },
        *{
            f"model::y_{outcome}::{component}"
            for outcome in ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
            for component in (
                "rSI_sMS",
                "logistic_regression",
                "catboost",
                "xgboost",
                "lightgbm",
                "bert_finetuned",
                "mlp_plr",
                "ft_transformer",
                "cnn_1d",
                "tabpfn",
                "tabicl",
                "stacking",
            )
        },
    }
    if control_sets[0] != expected_controls:
        raise ValueError("browser tested control IDs differ from exact golden control cases")
    if image_sets[0] != image_sets[1]:
        raise ValueError("desktop/mobile SHAP image path sets differ")
    if image_sets[0] != set(expected_asset_hashes):
        raise ValueError("browser SHAP image set differs from accepted copy manifest")
    if dom_results[0] != dom_results[1]:
        raise ValueError("desktop/mobile displayed numeric evidence differs")
    if asset_tree["root"] != "outputs/report/figures/v2_model_family_shap/":
        raise ValueError("v2 SHAP asset tree root mismatch")
    if asset_hashes != expected_asset_hashes:
        raise ValueError("browser SHAP image hashes differ from accepted copy manifest")
    tree_digest = hashlib.sha256(
        json.dumps(expected_asset_hashes, sort_keys=True, separators=(",", ":")).encode(
            "utf-8"
        )
    ).hexdigest()
    if asset_tree["file_count"] != len(asset_hashes) or asset_tree["tree_sha256"] != tree_digest:
        raise ValueError("v2 SHAP asset tree count or digest mismatch")
    return len(control_sets[0]), len(image_sets[0]), dom_results[0]


def validate_companion_explorer_manifest_file(
    manifest_path: Path,
    schema_path: Path,
    project_root: Path,
    task_registry_path: Path,
    contract_path: Path,
    expected_acceptance_anchor_sha256: str,
) -> dict[str, Any]:
    root = project_root.resolve(strict=True)
    seals: dict[Path, FileSeal] = {}

    contract_file, contract_relative = _argument_regular_file(root, contract_path, "contract")
    if contract_relative != "qa_v2/p1_06_companion_explorer_contract.yaml":
        raise ValueError("companion governance contract path is not canonical")
    contract_seal, contract_payload = _stable_file(contract_file, capture=True)
    seals[contract_file] = contract_seal
    assert contract_payload is not None
    contract = _json_from_payload(contract_payload, "contract")

    expected_manifest = contract["adapter"]["manifest_path"]
    resolved_manifest, manifest_relative = _argument_regular_file(root, manifest_path, "manifest")
    if manifest_relative != expected_manifest:
        raise ValueError("companion manifest path differs from the governance contract")
    manifest_seal, manifest_payload = _stable_file(resolved_manifest, capture=True)
    seals[resolved_manifest] = manifest_seal
    assert manifest_payload is not None
    manifest = _json_from_payload(manifest_payload, "manifest")

    resolved_schema, schema_relative = _argument_regular_file(root, schema_path, "schema")
    if schema_relative != contract["adapter"]["manifest_schema"]:
        raise ValueError("companion schema path differs from the governance contract")
    schema_seal, schema_payload = _stable_file(resolved_schema, capture=True)
    seals[resolved_schema] = schema_seal
    assert schema_payload is not None
    schema = _json_from_payload(schema_payload, "schema")
    logical = validate_companion_explorer_manifest(manifest, schema)

    registry_file, registry_relative = _argument_regular_file(
        root, task_registry_path, "task registry"
    )
    if registry_relative != "qa_v2/task_registry.json":
        raise ValueError("task registry path is not the locked canonical registry")
    registry_seal, registry_payload = _stable_file(registry_file, capture=True)
    seals[registry_file] = registry_seal
    assert registry_payload is not None
    registry = _json_from_payload(registry_payload, "task registry")
    from scripts import build_p1_v2_interactive_model_explorer_adapter as adapter_runtime

    try:
        anchored = adapter_runtime.load_acceptance_anchor(
            root,
            expected_acceptance_anchor_sha256,
        )
    except Exception as exc:
        raise ValueError("P1_06 external acceptance anchor validation failed") from exc
    anchor_binding = manifest.get("p1_06_acceptance_anchor")
    expected_anchor_binding = {
        "path": adapter_runtime.ACCEPTANCE_ANCHOR_RELATIVE,
        "sha256": expected_acceptance_anchor_sha256,
        "authorization_path": anchored.anchor["authorization"]["path"],
        "authorization_sha256": anchored.anchor["authorization"]["sha256"],
        "authorization_id": anchored.anchor["authorization"]["authorization_id"],
        "evaluation_run_id": anchored.anchor["authorization"]["evaluation_run_id"],
        "authorization_binding_universe_sha256": anchored.anchor[
            "authorization_coverage"
        ]["binding_universe_sha256"],
        "scientific_coverage_sha256": adapter_runtime.canonical_sha256(
            anchored.anchor["scientific_coverage"]
        ),
    }
    if anchor_binding != expected_anchor_binding:
        raise ValueError(
            "companion P1_06 acceptance anchor differs from the external trust root"
        )
    for index, snapshot in enumerate(anchored.snapshots):
        _capture_relative_file(
            root,
            snapshot.relative_path,
            f"P1_06 external acceptance-chain file {index}",
            seals,
            snapshot.sha256,
        )
    acceptance = manifest["p1_06_acceptance"]
    if acceptance.get("task_registry_path") != registry_relative:
        raise ValueError("manifest task registry path mismatch")
    if acceptance.get("task_registry_sha256") != registry_seal.sha256:
        raise ValueError("manifest task registry SHA256 mismatch")

    anchored_acceptance = anchored.anchor["accepted_manifest"]
    expected_acceptance = {
        "manifest_path": anchored_acceptance["path"],
        "manifest_sha256": anchored_acceptance["sha256"],
        "manifest_acceptance_receipt_path": anchored_acceptance[
            "acceptance_receipt_path"
        ],
        "manifest_acceptance_receipt_sha256": anchored_acceptance[
            "acceptance_receipt_sha256"
        ],
        "status": "PASS",
        "frozen_evaluation_count": 1,
        "mandatory_component_outcome_count": 108,
        "task_registry_path": "qa_v2/task_registry.json",
        "task_registry_sha256": anchored.anchor["task_registry"]["sha256"],
    }
    if acceptance != expected_acceptance:
        raise ValueError(
            "companion P1_06 acceptance disclosure differs from the external anchor"
        )
    _accepted_v2_path(anchored_acceptance["path"], "P1_06 accepted manifest")
    p1_06_manifest, _ = _seal_relative_json(
        root,
        anchored_acceptance["path"],
        "P1_06 accepted manifest",
        seals,
        anchored_acceptance["sha256"],
    )
    _accepted_v2_path(
        anchored_acceptance["acceptance_receipt_path"],
        "P1_06 manifest acceptance receipt",
    )
    p1_06_receipt, _ = _seal_relative_json(
        root,
        anchored_acceptance["acceptance_receipt_path"],
        "P1_06 manifest acceptance receipt",
        seals,
        anchored_acceptance["acceptance_receipt_sha256"],
    )
    expected_p1_06_receipt = {
        "status": "PASS",
        "artifact_path": anchored_acceptance["path"],
        "artifact_sha256": anchored_acceptance["sha256"],
    }
    if any(p1_06_receipt.get(key) != value for key, value in expected_p1_06_receipt.items()):
        raise ValueError("P1_06 manifest receipt does not bind exact path, hash, and PASS")
    required_acceptance = {
        "status": "PASS",
        "historical_2025_exposure": True,
        "strict_no_arrival_leakage": True,
        "frozen_evaluation_count": 1,
        "mandatory_component_outcome_count": 108,
        "task_registry_sha256": registry_seal.sha256,
        "frozen_evaluation_authorization_id": anchored.anchor["authorization"][
            "authorization_id"
        ],
        "frozen_evaluation_run_id": anchored.anchor["authorization"][
            "evaluation_run_id"
        ],
    }
    if any(p1_06_manifest.get(key) != value for key, value in required_acceptance.items()):
        raise ValueError("P1_06 accepted manifest does not bind the frozen 108-result contract")
    if p1_06_manifest.get("mandatory_bindings") != manifest["mandatory_bindings"]:
        raise ValueError("P1_06 accepted manifest mandatory_bindings differ from companion")

    adapter = manifest["adapter"]
    if adapter["path"] != contract["adapter"]["required_path"]:
        raise ValueError("adapter path differs from governance contract")
    _seal_relative_file(root, adapter["path"], "adapter", seals, adapter["sha256"])
    output = manifest["output"]
    if output["path"] != contract["adapter"]["output_path"]:
        raise ValueError("companion output path differs from governance contract")
    _, output_payload = _capture_relative_file(
        root, output["path"], "companion output", seals, output["sha256"]
    )

    golden_manifest = manifest["golden_reference"]
    golden_contract = contract["golden_reference"]
    for name in ("builder", "html"):
        record = golden_contract[name]
        manifest_prefix = "builder" if name == "builder" else "html"
        if golden_manifest[f"{manifest_prefix}_path"] != record["path"]:
            raise ValueError(f"golden {name} path differs from governance contract")
        if golden_manifest[f"{manifest_prefix}_sha256"] != record["sha256"]:
            raise ValueError(f"golden {name} hash differs from governance contract")
        if golden_manifest[f"{manifest_prefix}_size"] != record["size"]:
            raise ValueError(f"golden {name} size differs from governance contract")
        if golden_manifest[f"post_build_{manifest_prefix}_sha256"] != record["sha256"]:
            raise ValueError(f"post-build golden {name} hash differs from governance contract")
        if golden_manifest[f"post_build_{manifest_prefix}_size"] != record["size"]:
            raise ValueError(f"post-build golden {name} size differs from governance contract")
        _seal_relative_file(
            root,
            record["path"],
            f"golden {name}",
            seals,
            record["sha256"],
            record["size"],
        )
    dependency_hashes = {
        record["path"]: record["sha256"] for record in golden_contract["dependencies"]
    }
    if golden_manifest["dependency_hashes"] != dependency_hashes:
        raise ValueError("golden dependency inventory differs from governance contract")
    for index, record in enumerate(golden_contract["dependencies"]):
        _seal_relative_file(
            root,
            record["path"],
            f"golden dependency {index}",
            seals,
            record["sha256"],
            record["size"],
        )

    inventory_rows = manifest["accepted_artifact_inventory"]
    inventory = {record["path"]: record for record in inventory_rows}
    if len(inventory) != len(inventory_rows):
        raise ValueError("accepted artifact inventory contains duplicate paths")
    bundle_path = output["bundle_path"]
    bundle_relative = PurePosixPath(bundle_path)
    if (
        bundle_relative.name != "bundle.json"
        or bundle_relative.parts[:3] != ("outputs", "v2", "candidates")
    ):
        raise ValueError("sealed explorer bundle path is not the locked candidate path")
    candidate_prefix = bundle_relative.parent.as_posix()
    expected_generated = {
        f"{candidate_prefix}/{filename}": role
        for filename, role in GENERATED_ACCEPTED_FILES.items()
    }
    upstream_rows = p1_06_manifest.get("artifact_inventory")
    if not isinstance(upstream_rows, list) or not upstream_rows:
        raise ValueError("P1_06 accepted artifact inventory is missing")
    upstream = {
        str(record.get("path")): {
            key: record.get(key) for key in ACCEPTED_INVENTORY_KEYS
        }
        for record in upstream_rows
        if isinstance(record, dict)
    }
    if len(upstream) != len(upstream_rows):
        raise ValueError("P1_06 accepted artifact inventory is duplicated or invalid")
    if (
        adapter_runtime.canonical_sha256(upstream_rows)
        != anchored.anchor["artifact_inventory_sha256"]
        or anchored.anchor["task_registry"]
        != {"path": registry_relative, "sha256": registry_seal.sha256}
    ):
        raise ValueError("P1_06 accepted inventory differs from the external anchor")
    accepted_source_paths = p1_06_manifest.get("sources")
    if (
        not isinstance(accepted_source_paths, dict)
        or set(accepted_source_paths) != set(adapter_runtime.SOURCE_KEYS)
    ):
        raise ValueError("P1_06 accepted source bindings are incomplete")
    anchored_sources = {
        name: upstream.get(str(relative), {}).get("sha256")
        for name, relative in accepted_source_paths.items()
    }
    if anchored_sources != anchored.anchor["sources_sha256"]:
        raise ValueError("P1_06 accepted sources differ from the external anchor")
    if set(inventory) != set(upstream) | set(expected_generated):
        raise ValueError(
            "companion accepted inventory is not the exact upstream-plus-adapter set"
        )
    if any(inventory.get(path) != record for path, record in upstream.items()):
        raise ValueError("companion upstream accepted inventory differs from P1_06")
    for path, role in expected_generated.items():
        filename = PurePosixPath(path).name
        record = inventory[path]
        if (
            record.get("role") != role
            or record.get("stage") != "P1_06"
            or record.get("generation") != "v2"
            or record.get("acceptance_status") != "PASS"
            or record.get("outcome") is not None
            or record.get("model") is not None
            or record.get("split") is not None
            or record.get("model_sha256") is not None
            or record.get("acceptance_receipt_path")
            != f"{candidate_prefix}/acceptance_receipts/{filename}.receipt.json"
        ):
            raise ValueError(f"generated companion artifact inventory differs: {path}")
    for index, record in enumerate(manifest["accepted_artifact_inventory"]):
        label = f"accepted artifact {index}"
        _accepted_v2_path(record["path"], f"{label}.path")
        _accepted_v2_path(record["acceptance_receipt_path"], f"{label}.receipt")
        _seal_relative_file(root, record["path"], label, seals, record["sha256"])
        receipt, _ = _seal_relative_json(
            root,
            record["acceptance_receipt_path"],
            f"{label} receipt",
            seals,
            record["acceptance_receipt_sha256"],
        )
        expected_receipt = {
            "status": "PASS",
            "artifact_path": record["path"],
            "artifact_sha256": record["sha256"],
        }
        if any(receipt.get(key) != value for key, value in expected_receipt.items()):
            raise ValueError(f"{label} receipt does not bind exact path, hash, and PASS status")

    _accepted_v2_path(bundle_path, "sealed explorer bundle")
    bundle_record = inventory.get(bundle_path)
    if bundle_record is None or bundle_record["role"] != "artifact":
        raise ValueError("sealed explorer bundle is not in accepted artifact inventory")
    if bundle_record["sha256"] != output["bundle_sha256"]:
        raise ValueError("sealed explorer bundle inventory hash mismatch")
    _, bundle_payload = _capture_relative_file(
        root, bundle_path, "sealed explorer bundle", seals, output["bundle_sha256"]
    )
    bundle = _json_from_payload(bundle_payload, "sealed explorer bundle")
    canonical_bundle = json.dumps(
        bundle, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    canonical_bundle_sha256 = hashlib.sha256(canonical_bundle.encode("utf-8")).hexdigest()
    if output["bundle_canonical_sha256"] != canonical_bundle_sha256:
        raise ValueError("sealed explorer bundle canonical SHA256 mismatch")
    html_text = output_payload.decode("utf-8")
    match = re.search(
        r'<script id="bundle" type="application/json">(.*?)</script>',
        html_text,
        re.DOTALL,
    )
    if match is None:
        raise ValueError("companion output lacks the embedded bundle JSON")
    embedded = json.loads(match.group(1))
    if embedded != bundle:
        raise ValueError("companion output embedded bundle differs from sealed bundle artifact")
    if (
        bundle.get("historical_2025_exposure") is not True
        or bundle.get("strict_no_arrival_leakage") is not True
    ):
        raise ValueError("sealed explorer bundle lacks historical exposure or no-arrival disclosure")
    accepted_artifact_sources = bundle.get("accepted_artifact_sources")
    if not isinstance(accepted_artifact_sources, list) or len(
        accepted_artifact_sources
    ) != len(
        set(accepted_artifact_sources)
    ):
        raise ValueError(
            "sealed explorer bundle accepted_artifact_sources are missing or duplicated"
        )
    for index, relative in enumerate(accepted_artifact_sources):
        _accepted_v2_path(relative, f"bundle accepted_artifact_sources[{index}]")
    if set(accepted_artifact_sources) != set(inventory):
        raise ValueError(
            "sealed explorer bundle accepted_artifact_sources differ from accepted inventory"
        )
    artifact_sources = bundle.get("artifact_sources")
    if not isinstance(artifact_sources, dict):
        raise ValueError("sealed explorer bundle UI artifact_sources must remain an object")
    expected_artifact_sources = {
        "metrics": p1_06_manifest["sources"]["metrics"],
        "curves": p1_06_manifest["sources"]["predictions"],
        "coverage_audit": p1_06_manifest["sources"]["predictions"],
    }
    if artifact_sources != expected_artifact_sources:
        raise ValueError("sealed explorer bundle UI sources differ from accepted P1_06")

    def validate_ui_source_paths(value: object, label: str) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                validate_ui_source_paths(child, f"{label}.{key}")
        elif isinstance(value, list):
            for index, child in enumerate(value):
                validate_ui_source_paths(child, f"{label}[{index}]")
        elif isinstance(value, str) and value.startswith("outputs/"):
            _accepted_v2_path(value, label)
            if value not in inventory:
                raise ValueError(f"{label} references an unaccepted v2 artifact")

    validate_ui_source_paths(artifact_sources, "bundle artifact_sources")

    _validate_mandatory_bindings(manifest, registry, inventory)

    metric_contract = manifest["metric_recompute"]
    expected_metric_paths = {
        "source_paths": [f"{candidate_prefix}/metric_source_displayed.parquet"],
        "independent_recompute_path": (
            f"{candidate_prefix}/metric_independent_recompute.parquet"
        ),
        "bundle_records_path": f"{candidate_prefix}/bundle_numeric_records.parquet",
    }
    if any(metric_contract.get(key) != value for key, value in expected_metric_paths.items()):
        raise ValueError("metric recompute paths differ from the locked adapter outputs")

    def load_numeric(relative: str, label: str) -> dict[tuple[str, str, str, str, str], float]:
        _accepted_v2_path(relative, label)
        record = inventory.get(relative)
        if record is None or record["role"] not in {"metric", "artifact"}:
            raise ValueError(f"{label} is not in accepted metric/artifact inventory")
        _, payload = _capture_relative_file(
            root, relative, label, seals, record["sha256"]
        )
        return _numeric_records(payload, label)

    source_records: NumericRecords = {}
    source_paths = metric_contract["source_paths"]
    if len(source_paths) != len(set(source_paths)):
        raise ValueError("metric source paths are duplicated")
    for index, relative in enumerate(source_paths):
        current = load_numeric(relative, f"metric source {index}")
        overlap = set(source_records) & set(current)
        if overlap:
            raise ValueError("metric source parquets contain duplicate displayed keys")
        source_records.update(current)
    expected_numeric_keys = _expected_numeric_keys(_expected_mandatory_tasks(registry))
    if set(source_records) != expected_numeric_keys:
        raise ValueError("displayed numeric source keys differ from the exact 108x2x13 registry grid")
    recomputed_records = load_numeric(
        metric_contract["independent_recompute_path"], "independent metric recompute"
    )
    bundle_records = load_numeric(metric_contract["bundle_records_path"], "bundle numeric records")
    accepted_sources = p1_06_manifest.get("sources")
    if not isinstance(accepted_sources, dict) or not {
        "predictions",
        "metrics",
        "thresholds",
    }.issubset(accepted_sources):
        raise ValueError("P1_06 accepted scientific source bindings are incomplete")

    def accepted_frame(source_name: str) -> pd.DataFrame:
        relative = accepted_sources[source_name]
        if relative not in upstream:
            raise ValueError(
                f"P1_06 accepted {source_name} source is outside upstream inventory"
            )
        record = inventory[relative]
        _, payload = _capture_relative_file(
            root,
            relative,
            f"P1_06 accepted {source_name}",
            seals,
            record["sha256"],
        )
        try:
            return pd.read_parquet(io.BytesIO(payload))
        except Exception as exc:
            raise ValueError(
                f"P1_06 accepted {source_name} is not readable parquet"
            ) from exc

    accepted_predictions = accepted_frame("predictions")
    accepted_metrics = accepted_frame("metrics")
    accepted_thresholds = accepted_frame("thresholds")
    try:
        accepted_recomputed, _, _ = adapter_runtime._recompute_scientific_rows(
            accepted_predictions,
            accepted_metrics,
            accepted_thresholds,
        )
    except Exception as exc:
        raise ValueError(
            "P1_06 accepted metrics do not recompute from accepted predictions"
        ) from exc
    accepted_numeric_frame = adapter_runtime._canonical_metric_frame(
        accepted_recomputed
    )
    accepted_numeric = _dom_numeric_records(
        accepted_numeric_frame.to_dict("records"),
        "P1_06 accepted metric recompute",
    )
    for label, records in (
        ("source", source_records),
        ("independent", recomputed_records),
        ("bundle", bundle_records),
    ):
        comparison = _compare_numeric_records(records, accepted_numeric, 1e-12)
        if comparison[2] != 0:
            raise ValueError(
                f"{label} displayed metrics differ from accepted P1_06 recompute"
            )
    expected_count = len(source_records)
    expected_digest = _key_digest(source_records)
    if (
        metric_contract["displayed_key_count"] != expected_count
        or metric_contract["displayed_key_sha256"] != expected_digest
    ):
        raise ValueError("displayed numeric key count or digest is not independently derived")
    tolerance = float(metric_contract["absolute_tolerance"])
    source_result = _compare_numeric_records(source_records, recomputed_records, tolerance)
    bundle_result = _compare_numeric_records(bundle_records, recomputed_records, tolerance)
    _validate_comparison_summary(
        metric_contract["source_to_recompute"], source_result, "source-to-recompute"
    )
    _validate_comparison_summary(
        metric_contract["bundle_to_recompute"], bundle_result, "bundle-to-recompute"
    )

    curve_contract = manifest["curve_recompute"]
    expected_curve_paths = {
        "source_path": f"{candidate_prefix}/curve_source.parquet",
        "independent_recompute_path": (
            f"{candidate_prefix}/curve_independent_recompute.parquet"
        ),
    }
    if any(curve_contract.get(key) != value for key, value in expected_curve_paths.items()):
        raise ValueError("curve recompute paths differ from the locked adapter outputs")

    def load_curve(relative: str, label: str) -> CurveRecords:
        _accepted_v2_path(relative, label)
        record = inventory.get(relative)
        if record is None or record["role"] not in {"metric", "artifact"}:
            raise ValueError(f"{label} is not in accepted metric/artifact inventory")
        _, payload = _capture_relative_file(
            root, relative, label, seals, record["sha256"]
        )
        return _curve_records(payload, label)

    curve_source = load_curve(curve_contract["source_path"], "curve source")
    curve_recomputed = load_curve(
        curve_contract["independent_recompute_path"], "independently recomputed curves"
    )
    bundle_curve_rows = bundle.get("curve_numeric_records")
    if not isinstance(bundle_curve_rows, list):
        raise ValueError("sealed explorer bundle lacks canonical curve_numeric_records")
    bundle_curves = _curve_records_from_rows(bundle_curve_rows, "sealed bundle curves")
    accepted_curve_source_frame = adapter_runtime._curve_frame(
        accepted_predictions, independent=False
    )
    accepted_curve_independent_frame = adapter_runtime._curve_frame(
        accepted_predictions, independent=True
    )
    accepted_curve_source = _curve_records_from_rows(
        accepted_curve_source_frame.to_dict("records"),
        "P1_06 accepted source curves",
    )
    accepted_curve_independent = _curve_records_from_rows(
        accepted_curve_independent_frame.to_dict("records"),
        "P1_06 accepted independent curves",
    )
    for label, records, expected in (
        ("source", curve_source, accepted_curve_source),
        ("independent", curve_recomputed, accepted_curve_independent),
        ("bundle", bundle_curves, accepted_curve_source),
    ):
        comparison = _compare_curve_records(records, expected, 1e-12)
        if comparison[3] != 0:
            raise ValueError(
                f"{label} curves differ from accepted P1_06 predictions"
            )
    expected_tasks = _expected_mandatory_tasks(registry)
    for label, records in (
        ("curve source", curve_source),
        ("independently recomputed curves", curve_recomputed),
        ("sealed bundle curves", bundle_curves),
    ):
        _validate_curve_coverage(records, expected_tasks, label)
    curve_key_digest, curve_value_digest = _curve_digests(curve_source)
    if (
        curve_contract["point_count"] != len(curve_source)
        or curve_contract["key_sha256"] != curve_key_digest
        or curve_contract["value_sha256"] != curve_value_digest
    ):
        raise ValueError("curve point count or digest is not independently derived")
    curve_tolerance = float(curve_contract["absolute_tolerance"])
    curve_source_result = _compare_curve_records(
        curve_source, curve_recomputed, curve_tolerance
    )
    curve_bundle_result = _compare_curve_records(
        bundle_curves, curve_recomputed, curve_tolerance
    )
    _validate_curve_summary(
        curve_contract["source_to_recompute"],
        curve_source_result,
        "source-to-recompute",
    )
    _validate_curve_summary(
        curve_contract["bundle_to_recompute"],
        curve_bundle_result,
        "bundle-to-recompute",
    )
    controls_tested, shap_images_verified, dom_result = _validate_browser_evidence(
        root, manifest, seals, bundle_records, inventory, bundle
    )
    _validate_comparison_summary(
        metric_contract["dom_to_bundle"], dom_result, "DOM-to-bundle"
    )

    _revalidate_seals(seals)
    return {
        **logical,
        "status": "PASS",
        "manifest_path": manifest_relative,
        "manifest_sha256": manifest_seal.sha256,
        "contract_path": contract_relative,
        "contract_sha256": contract_seal.sha256,
        "task_registry_sha256": registry_seal.sha256,
        "sealed_file_count": len(seals),
        "toctou_findings": 0,
        "mandatory_bindings_verified": 108,
        "metric_keys_verified": expected_count,
        "curve_points_verified": len(curve_source),
        "controls_tested_per_viewport": controls_tested,
        "shap_images_verified_per_viewport": shap_images_verified,
    }
