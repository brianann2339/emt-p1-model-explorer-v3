from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path
from typing import Any

from . import contextual_security_scan as security_scan


EXPECTED_PROMPTS = (
    "P1_00_共用前置.md",
    "P1_01_Stage1a_資料清理與特徵工程.md",
    "P1_02_Stage1b_特徵選擇與基準模型.md",
    "P1_03_Stage2a_嚴謹評估與校準.md",
    "P1_04_Stage2b_消融與敏感度.md",
    "P1_05a_Stage3a_NLP與深度模型.md",
    "P1_05b_Stage3b_CNN與TabPFN.md",
    "P1_06_最終評估與交付.md",
)

OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
PRIMARY_OUTCOMES = OUTCOMES[:3]
SCORE_LABELS = (
    "NEWS2",
    "rSIG",
    "rSIG_Age",
    "SIA_G",
    "SI_G",
    "SI",
    "mSI",
    "aSI",
    "rSI",
    "rSI_sMS",
    "rSI_GCSM",
    "SIAVPU",
    "sMS",
    "qSOFA",
    "MEWS",
    "REMS",
    "RTS",
    "rSI_GCS_alias",
)
STAGE1B_MODELS = (
    "logistic_l1",
    "logistic_l2",
    "decision_tree",
    "random_forest",
    "svm_rbf",
    "balanced_random_forest",
    "xgboost",
    "lightgbm",
    "catboost",
)
FINAL_COMPONENTS = (
    "rSI_sMS",
    "logistic_regression",
    "catboost",
    "xgboost",
    "lightgbm",
    "bert_finetuned",
    "mlp_plr",
    "ft_transformer",
    "cnn_1d",
    "tabpfn",
    "tabicl",
    "stacking",
)

P1_02_RUNTIME_P80_HOURS = {
    "descriptives": 25 / 60,
    "clinical_score": 0.8 / 60,
    "logistic_l1": 8 / 60,
    "logistic_l2": 5 / 60,
    "decision_tree": 4 / 60,
    "random_forest": 25 / 60,
    "svm_rbf": 60 / 60,
    "balanced_random_forest": 20 / 60,
    "xgboost": 25 / 60,
    "lightgbm": 15 / 60,
    "catboost": 30 / 60,
    "missingness_primary": 180 / 60,
    "missingness_secondary": 150 / 60,
}

P1_02_RAM_FRACTIONS = {
    "descriptives": 0.25,
    "clinical_score": 0.15,
    "logistic_l1": 0.20,
    "logistic_l2": 0.18,
    "decision_tree": 0.18,
    "random_forest": 0.25,
    "svm_rbf": 0.32,
    "balanced_random_forest": 0.25,
    "xgboost": 0.25,
    "lightgbm": 0.25,
    "catboost": 0.25,
    "missingness_primary": 0.50,
    "missingness_secondary": 0.47,
}

CLAUSE_RE = re.compile(
    r"^\s*(?:#{1,6}\s+)?(?:[-*+]\s+|\d+[.)、:]\s*|[一二三四五六七八九十]+[、.]\s*)"
)
def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _prompt_paths(project_root: Path) -> list[Path]:
    found = sorted(path.name for path in project_root.glob("P1_*.md"))
    expected = sorted(EXPECTED_PROMPTS)
    if found != expected:
        missing = sorted(set(expected) - set(found))
        extra = sorted(set(found) - set(expected))
        raise ValueError(f"expected exactly 8 P1 prompts; missing={missing}; extra={extra}")
    return [project_root / name for name in EXPECTED_PROMPTS]


def build_prompt_lock(project_root: Path) -> dict[str, Any]:
    prompts = []
    for path in _prompt_paths(project_root):
        prompts.append(
            {
                "filename": path.name,
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
            }
        )
    return {
        "schema_version": "1.0",
        "expected_prompt_count": 8,
        "prompts": prompts,
    }


def _stage_for_prompt(filename: str) -> str:
    return filename.split("_", 2)[0] + "_" + filename.split("_", 2)[1]


def _classification(text: str) -> tuple[str, str, bool]:
    folded = text.casefold()
    rules = (
        ("references", ("pmid", "doi", "詳見原始論文"), "manual_evidence", False),
        (
            "privacy_security",
            ("pii", "去識別", "隱私", "姓名", "身分證", "病歷號", "token", "secret", "完整地址"),
            "privacy_secret_gate",
            True,
        ),
        (
            "holdout_temporal",
            ("2025", "2024", "2020", "hold-out", "holdout", "oof", "fold", "時序", "封存", "鎖定前"),
            "temporal_split_gate",
            True,
        ),
        (
            "leakage_control",
            ("leakage", "洩漏", "到院", "arrival", "forbidden", "hard_forbidden", "ed-early", "交接", "檢傷"),
            "leakage_gate",
            True,
        ),
        (
            "missingness_cleaning",
            ("缺失", "missing", "imput", "nan", "量測不到", "離群", "範圍", "清哨兵", "complete-case"),
            "missingness_gate",
            True,
        ),
        (
            "data_cohort_labels",
            ("篩選", "去重", "結局", "標籤", "盛行率", "年齡", "資料列", "reg_date", "endo"),
            "cohort_gate",
            True,
        ),
        (
            "artifact_delivery",
            ("儲存", "輸出", "artifact", "manifest", "parquet", "pkl", "zip", "readme", "log", "打包"),
            "artifact_gate",
            True,
        ),
        (
            "evaluation_calibration",
            ("auroc", "auprc", "brier", "roc", "pr ", "校準", "calibration", "dca", "bootstrap", "敏感度", "特異度"),
            "metric_gate",
            True,
        ),
        (
            "modeling",
            ("模型", "model", "logistic", "xgboost", "lightgbm", "catboost", "bert", "cnn", "tabpfn", "tabicl", "stack", "svm", "random forest", "mlp", "transformer"),
            "model_coverage_gate",
            True,
        ),
        (
            "feature_engineering",
            ("特徵", "feature", "multi-hot", "ordinal", "分數", "score", "si", "gcs", "avpu", "時間區間"),
            "feature_contract_gate",
            True,
        ),
        (
            "runtime_hardware",
            ("gpu", "cpu", "vram", "ram", "cuda", "硬體", "版本", "配額", "429", "oom"),
            "runtime_manifest_gate",
            True,
        ),
        (
            "reporting_governance",
            ("報告", "checklist", "tripod", "probast", "揭露", "限制", "誠實", "虛構", "完成"),
            "manual_evidence",
            True,
        ),
    )
    for category, keywords, checker, hard_gate in rules:
        if any(keyword in folded for keyword in keywords):
            return category, checker, hard_gate
    return "methodology_contract", "manual_evidence", True


def build_requirement_matrix(project_root: Path) -> dict[str, Any]:
    requirements: list[dict[str, Any]] = []
    counts: dict[str, int] = {}
    for prompt_path in _prompt_paths(project_root):
        prompt_count = 0
        for line_number, raw_line in enumerate(
            prompt_path.read_text(encoding="utf-8").splitlines(), start=1
        ):
            if not CLAUSE_RE.match(raw_line):
                continue
            text = raw_line.strip()
            category, checker, hard_gate = _classification(text)
            prompt_count += 1
            requirements.append(
                {
                    "requirement_id": f"{_stage_for_prompt(prompt_path.name)}-L{line_number:04d}",
                    "stage": _stage_for_prompt(prompt_path.name),
                    "prompt": prompt_path.name,
                    "line": line_number,
                    "source_text_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                    "text_redacted": security_scan.mask_authorized_tokens(text).replace(
                        "AUTHORIZED_TOKEN", "[REDACTED_SECRET]"
                    ),
                    "classification": category,
                    "checker": checker,
                    "hard_gate": hard_gate,
                }
            )
        counts[prompt_path.name] = prompt_count
    unclassified = sum(not row["classification"] for row in requirements)
    return {
        "schema_version": "1.0",
        "source_prompt_count": 8,
        "source_clause_count": len(requirements),
        "classified_clause_count": len(requirements) - unclassified,
        "unclassified_clause_count": unclassified,
        "clause_count_by_prompt": counts,
        "requirements": requirements,
    }


def _artifact_spec(path: str, kind: str, schema: str | dict[str, Any]) -> dict[str, Any]:
    return {"path": path, "kind": kind, "schema": schema, "required": True}


def _p1_02_artifacts(task_family: str, model: str | None) -> list[dict[str, Any]]:
    json_object = {"type": "object"}
    if task_family == "descriptives":
        return [
            _artifact_spec("table1_long.parquet", "table1", {}),
            _artifact_spec("vital_score_correlations_long.parquet", "correlations", {}),
            _artifact_spec("hardware_v2.json", "hardware", json_object),
            *[
                _artifact_spec(f"manifests/y_{outcome}.json", "outcome_manifest", json_object)
                for outcome in OUTCOMES
            ],
            _artifact_spec("p1_02_descriptives_manifest_v2.json", "scientific_manifest", json_object),
            _artifact_spec("artifact_hashes_v2.json", "scientific_hashes", json_object),
            _artifact_spec("hashes.json", "hashes", json_object),
            _artifact_spec("task_manifest.json", "task_manifest", json_object),
            _artifact_spec("_SUCCESS.json", "success_marker", json_object),
        ]
    common = [
        _artifact_spec("predictions.parquet", "predictions", "qa_v2/schemas/prediction.schema.json"),
        _artifact_spec("metrics.parquet", "metrics", "qa_v2/schemas/metric.schema.json"),
        _artifact_spec("coverage.parquet", "coverage", {}),
        _artifact_spec("model.joblib" if task_family != "missingness_bundle" else "models.joblib", "model", {}),
        _artifact_spec("spec.json", "spec", json_object),
        _artifact_spec("canary_inputs.parquet", "canary_inputs", {}),
        _artifact_spec("canary_expected.parquet", "canary_expected", {}),
        _artifact_spec("hashes.json", "hashes", json_object),
        _artifact_spec("task_manifest.json", "task_manifest", json_object),
        _artifact_spec("_SUCCESS.json", "success_marker", json_object),
    ]
    if task_family == "stage1b_model" and model in {"logistic_l1", "xgboost", "lightgbm", "catboost"}:
        common.append(_artifact_spec("feature_importance.parquet", "feature_importance", {}))
    if task_family == "stage1b_model" and model in {"xgboost", "lightgbm", "catboost"}:
        common.extend(
            [
                _artifact_spec(
                    "optuna_trials.parquet",
                    "optuna_trials",
                    "qa_v2/schemas/optuna_trial.schema.json",
                ),
                _artifact_spec("optuna.sqlite3", "optuna_checkpoint", {}),
            ]
        )
    if task_family == "stage1b_model" and model == "xgboost":
        common.extend(
            [
                _artifact_spec("treeshap_values_2024.parquet", "treeshap_values", {}),
                _artifact_spec("treeshap_importance_2024.parquet", "treeshap_importance", {}),
            ]
        )
    return common


def _p1_02_command(
    task_id: str,
    task_family: str,
    outcome: str | None,
    model: str | None,
) -> list[str]:
    package_root = "${P1_PACKAGE_ROOT}"
    stage1a_dir = f"{package_root}/outputs/v2/stage1a"
    fold_map = f"{stage1a_dir}/fixed_group_folds_v2.parquet"
    if task_family == "descriptives":
        return [
            "python",
            f"{package_root}/scripts/build_p1_02_descriptives_v2.py",
            "--task-id",
            task_id,
            "--stage1a-dir",
            stage1a_dir,
            "--output-dir",
            "${P1_TASK_OUTPUT_DIR}",
        ]
    if task_family in {"clinical_score", "stage1b_model"}:
        return [
            "python",
            f"{package_root}/scripts/run_stage1b_v2_task.py",
            "--outcome",
            str(outcome),
            "--model",
            str(model),
            "--task-id",
            task_id,
            "--output-dir",
            "${P1_TASK_OUTPUT_DIR}",
            "--stage1a-dir",
            stage1a_dir,
            "--fold-map",
            fold_map,
            "--trials",
            "50",
            "--device",
            "auto",
        ]
    if task_family == "missingness_bundle":
        return [
            "python",
            f"{package_root}/scripts/run_missingness_v2_task.py",
            "--outcome",
            str(outcome),
            "--task-id",
            task_id,
            "--output-dir",
            "${P1_TASK_OUTPUT_DIR}",
            "--stage1a-dir",
            stage1a_dir,
            "--fold-map",
            fold_map,
            "--gbdt-model",
            "xgboost",
            "--gbdt-spec",
            f"{package_root}/locked_specs/{outcome}/spec.json",
            "--device",
            "auto",
        ]
    raise ValueError(f"unsupported P1_02 task family: {task_family}")


def _artifact(task_id: str) -> list[dict[str, Any]]:
    return [
        {
            "path": f"tasks/{task_id}/task_bundle.zip",
            "kind": "session_task_bundle",
            "schema": "schemas/task.schema.json",
            "required": True,
        }
    ]


def _wave_artifacts(
    task_id: str, *, model_task: bool = False, extra: tuple[str, ...] = ()
) -> list[dict[str, Any]]:
    files = [
        ("predictions.parquet", "prediction", "schemas/prediction.schema.json"),
        ("metrics.parquet", "metric", "schemas/metric.schema.json"),
        ("coverage.parquet", "coverage", {"contract": "stage_execution_overlay"}),
        ("spec.json", "sealed_spec", {"contract": "stage_execution_overlay"}),
        ("hashes.json", "hash_inventory", {"contract": "stage_execution_overlay"}),
        ("task_manifest.json", "task_manifest", "schemas/task.schema.json"),
        ("_SUCCESS.json", "success_marker", {"status": "PASS"}),
    ]
    if model_task:
        files.extend(
            (
                (
                    "canary_inputs.parquet",
                    "model_canary_input",
                    {"contract": "stage_execution_overlay"},
                ),
                (
                    "canary_expected.parquet",
                    "model_canary_expected",
                    {"contract": "stage_execution_overlay"},
                ),
                (
                    "sealed_model_manifest.json",
                    "sealed_model_manifest",
                    {"contract": "stage_execution_overlay"},
                ),
            )
        )
    files.extend(
        (name, "stage_specific_artifact", {"contract": "stage_execution_overlay"})
        for name in extra
    )
    return [
        {
            "path": f"tasks/{task_id}/{name}",
            "kind": kind,
            "schema": schema,
            "required": True,
        }
        for name, kind, schema in files
    ]


def build_task_registry() -> dict[str, Any]:
    tasks: list[dict[str, Any]] = []

    def add(
        task_id: str,
        stage: str,
        wave: str,
        task_family: str,
        *,
        outcome: str | None = None,
        model: str | None = None,
        compute_target: str = "local",
        privacy_class: str | None = None,
        dependencies: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        estimated_hours: float | None = None,
        ram_fraction: float | None = None,
        gpu_memory_fraction: float | None = None,
        command: list[str] | None = None,
        required_artifacts: list[dict[str, Any]] | None = None,
    ) -> None:
        task = {
                "task_id": task_id,
                "stage": stage,
                "wave": wave,
                "task_family": task_family,
                "outcome": outcome,
                "model": model,
                "status": "pending",
                "compute_target": compute_target,
                "estimated_gpu_hours": estimated_hours,
                "runtime_p80_hours": estimated_hours,
                "runtime_profile_required": compute_target.startswith("kaggle"),
                "dependencies": dependencies or [],
                "required_artifacts": required_artifacts or _artifact(task_id),
                "metadata": metadata or {},
            }
        if ram_fraction is not None:
            task["ram_fraction"] = ram_fraction
        if privacy_class is not None:
            task["privacy_class"] = privacy_class
        if wave in {"W02", "W03", "W04"}:
            task["execution_overlay_required"] = True
            task["execution_overlay_schema"] = (
                "qa_v2/schemas/wave_execution_overlay.schema.json"
            )
        if gpu_memory_fraction is not None:
            task["gpu_memory_fraction"] = gpu_memory_fraction
        if command is not None:
            task["command"] = command
        tasks.append(task)

    add("P1_01-full-dev", "P1_01", "PRE", "stage1a_full_dev")
    add("W00-kaggle-roundtrip", "W00", "W00", "kaggle_roundtrip", compute_target="kaggle_gpu", dependencies=["P1_01-full-dev"])
    add(
        "P1_02-descriptives",
        "P1_02",
        "W01A",
        "descriptives",
        compute_target="kaggle_cpu",
        dependencies=["W00-kaggle-roundtrip"],
        metadata={"table1_outcomes": 9, "correlation_methods": ["pearson", "spearman"]},
        estimated_hours=P1_02_RUNTIME_P80_HOURS["descriptives"],
        ram_fraction=P1_02_RAM_FRACTIONS["descriptives"],
        gpu_memory_fraction=0.05,
        command=_p1_02_command("P1_02-descriptives", "descriptives", None, None),
        required_artifacts=_p1_02_artifacts("descriptives", None),
    )
    for outcome in OUTCOMES:
        for score in SCORE_LABELS:
            add(
                f"P1_02-score-{outcome}-{score}",
                "P1_02",
                "W01A",
                "clinical_score",
                outcome=outcome,
                model=score,
                compute_target="kaggle_cpu",
                dependencies=["W00-kaggle-roundtrip"],
                estimated_hours=P1_02_RUNTIME_P80_HOURS["clinical_score"],
                ram_fraction=P1_02_RAM_FRACTIONS["clinical_score"],
                gpu_memory_fraction=0.05,
                command=_p1_02_command(
                    f"P1_02-score-{outcome}-{score}", "clinical_score", outcome, score
                ),
                required_artifacts=_p1_02_artifacts("clinical_score", score),
            )
        for model in STAGE1B_MODELS:
            add(
                f"P1_02-model-{outcome}-{model}",
                "P1_02",
                "W01A",
                "stage1b_model",
                outcome=outcome,
                model=model,
                compute_target="kaggle_gpu",
                dependencies=["W00-kaggle-roundtrip"],
                metadata={"optuna_trials": 50 if model in {"xgboost", "lightgbm", "catboost"} else 0},
                estimated_hours=P1_02_RUNTIME_P80_HOURS[model],
                ram_fraction=P1_02_RAM_FRACTIONS[model],
                gpu_memory_fraction=(0.35 if model in {"xgboost", "lightgbm", "catboost"} else 0.05),
                command=_p1_02_command(
                    f"P1_02-model-{outcome}-{model}", "stage1b_model", outcome, model
                ),
                required_artifacts=_p1_02_artifacts("stage1b_model", model),
            )
        add(
            f"P1_02-missingness-{outcome}",
            "P1_02",
            "W01B",
            "missingness_bundle",
            outcome=outcome,
            compute_target="kaggle_gpu",
            privacy_class="deidentified_numeric",
            dependencies=[
                f"P1_02-model-{outcome}-logistic_l2",
                f"P1_02-model-{outcome}-xgboost",
            ],
            metadata={
                "strategy_count": 10 if outcome in {"P1", "P2", "P3"} else 8,
                "model_strategy_pair_count": 19 if outcome in {"P1", "P2", "P3"} else 15,
                "locked_gbdt_family": "xgboost",
                "hpo_performed": False,
                "runtime_pilot_required": True,
            },
            estimated_hours=P1_02_RUNTIME_P80_HOURS[
                "missingness_primary" if outcome in {"P1", "P2", "P3"} else "missingness_secondary"
            ],
            ram_fraction=P1_02_RAM_FRACTIONS[
                "missingness_primary" if outcome in {"P1", "P2", "P3"} else "missingness_secondary"
            ],
            gpu_memory_fraction=0.35,
            command=_p1_02_command(
                f"P1_02-missingness-{outcome}", "missingness_bundle", outcome, None
            ),
            required_artifacts=_p1_02_artifacts("missingness_bundle", None),
        )
        add(
            f"P1_03-evaluation-{outcome}",
            "P1_03",
            "LOCAL-03",
            "evaluation_bundle",
            outcome=outcome,
            dependencies=[
                "P1_02-descriptives",
                f"P1_02-missingness-{outcome}",
                *(f"P1_02-score-{outcome}-{score}" for score in SCORE_LABELS),
                *(f"P1_02-model-{outcome}-{model}" for model in STAGE1B_MODELS),
            ],
            metadata={"evaluation_scope": "core", "final_overlay_required": True},
        )
        add(
            f"P1_04-ablation-{outcome}",
            "P1_04",
            "W02",
            "ablation_bundle",
            outcome=outcome,
            compute_target="kaggle_gpu",
            privacy_class="deidentified_numeric",
            dependencies=[f"P1_03-evaluation-{outcome}"],
            metadata={"ablation_count": 12},
            required_artifacts=_wave_artifacts(
                f"P1_04-ablation-{outcome}",
                extra=("stage2b_ablation_results.csv",),
            ),
        )
    for sensitivity in (
        "mortality_definition",
        "grouped_vs_naive_cv",
        "city_holdout",
        "age_subgroup",
        "p3_ett",
        "ed_congestion",
    ):
        add(
            f"P1_04-sensitivity-{sensitivity}",
            "P1_04",
            "W02",
            "sensitivity_bundle",
            compute_target="kaggle_gpu",
            privacy_class="deidentified_numeric",
            dependencies=[f"P1_03-evaluation-{name}" for name in OUTCOMES],
            metadata={"sensitivity": sensitivity},
            required_artifacts=_wave_artifacts(
                f"P1_04-sensitivity-{sensitivity}",
                extra=("stage2b_sensitivity_results.csv",),
            ),
        )
    for outcome in OUTCOMES:
        stage3a_models = ("frozen_embedding", "bert_finetuned", "mlp_plr", "ft_transformer")
        for model in stage3a_models:
            dependencies = [
                f"P1_04-ablation-{outcome}",
                *(f"P1_04-sensitivity-{name}" for name in (
                    "mortality_definition",
                    "grouped_vs_naive_cv",
                    "city_holdout",
                    "age_subgroup",
                    "p3_ett",
                    "ed_congestion",
                )),
            ]
            if model in {"mlp_plr", "ft_transformer"}:
                dependencies.extend(
                    (
                        f"P1_05a-{outcome}-frozen_embedding",
                        f"P1_05a-{outcome}-bert_finetuned",
                    )
                )
            add(
                f"P1_05a-{outcome}-{model}",
                "P1_05a",
                "W03",
                "stage3a_model",
                outcome=outcome,
                model=model,
                compute_target="kaggle_gpu",
                privacy_class=(
                    "deidentified_text"
                    if model in {"frozen_embedding", "bert_finetuned"}
                    else "deidentified_numeric"
                ),
                dependencies=dependencies,
                metadata={
                    "cv_folds": 5,
                    "optuna_trials": 50 if model in {"mlp_plr", "ft_transformer"} else 0,
                    "execution_phase": (
                        "W03A"
                        if model in {"frozen_embedding", "bert_finetuned"}
                        else "W03B"
                    ),
                    **(
                        {
                            "shared_embedding_model": "BAAI/bge-m3",
                            "shared_embedding_artifact_required": True,
                        }
                        if model == "frozen_embedding"
                        else {}
                    ),
                    **(
                        {"bert_model": "hfl/chinese-roberta-wwm-ext"}
                        if model == "bert_finetuned"
                        else {}
                    ),
                },
                required_artifacts=_wave_artifacts(
                    f"P1_05a-{outcome}-{model}",
                    model_task=True,
                    extra=("checkpoint_manifest.json",),
                ),
            )
        for model in (
            "cnn_1d",
            "tabpfn_standard",
            "tabpfn_finetuned",
            "tabpfn_thinking",
            "tabicl",
            "stacking",
        ):
            target = (
                "local"
                if model == "stacking"
                else "kaggle_api"
                if model in {"tabpfn_standard", "tabpfn_thinking"}
                else "kaggle_gpu"
            )
            dependencies = [f"P1_05a-{outcome}-{name}" for name in stage3a_models]
            if model == "stacking":
                dependencies.extend(
                    f"P1_05b-{outcome}-{name}"
                    for name in (
                        "cnn_1d",
                        "tabpfn_standard",
                        "tabpfn_finetuned",
                        "tabicl",
                        *(
                            ("tabpfn_thinking",)
                            if outcome in PRIMARY_OUTCOMES
                            else ()
                        ),
                    )
                )
            add(
                f"P1_05b-{outcome}-{model}",
                "P1_05b",
                "W04",
                "stage3b_model",
                outcome=outcome,
                model=model,
                compute_target=target,
                privacy_class="deidentified_numeric",
                dependencies=dependencies,
                metadata={
                    "cv_folds": (
                        0
                        if model == "tabpfn_thinking"
                        and outcome not in PRIMARY_OUTCOMES
                        else 5
                    ),
                    "execution_phase": (
                        "W04_LOCAL" if model == "stacking" else "W04_REMOTE"
                    ),
                    **(
                        {
                            "thinking_fits": 6 if outcome in PRIMARY_OUTCOMES else 1,
                            "thinking_account_role": (
                                "primary" if outcome in PRIMARY_OUTCOMES else "secondary"
                            ),
                            "thinking_api_account_alias": (
                                "T01" if outcome in PRIMARY_OUTCOMES else "T02"
                            ),
                            "final_fits": 1,
                            "stacking_eligible": outcome in PRIMARY_OUTCOMES,
                        }
                        if model == "tabpfn_thinking"
                        else {}
                    ),
                    **({"local_only": True} if model == "stacking" else {}),
                },
                required_artifacts=_wave_artifacts(
                    f"P1_05b-{outcome}-{model}",
                    model_task=True,
                    extra=(
                        ("thinking_fit_ledger.json",)
                        if model == "tabpfn_thinking"
                        else ("stacking_feature_manifest.json",)
                        if model == "stacking"
                        else ("checkpoint_manifest.json",)
                    ),
                ),
            )
        add(
            f"P1_03-final-refresh-{outcome}",
            "P1_03",
            "LOCAL-03R",
            "evaluation_refresh_bundle",
            outcome=outcome,
            dependencies=[f"P1_05b-{outcome}-stacking"],
            metadata={"evaluation_scope": "final_refresh", "fit_allowed": False},
        )
        for component in FINAL_COMPONENTS:
            add(
                f"P1_06-{outcome}-{component}",
                "P1_06",
                "FINAL",
                "frozen_evaluation",
                outcome=outcome,
                model=component,
                dependencies=[f"P1_03-final-refresh-{outcome}"],
                metadata={"fit_allowed": False},
            )
    return {
        "schema_version": "1.0",
        "registry_kind": "research_contract",
        "runtime_estimates_source": "sealed_stage_specific_type7_p90_profiles_required_before_each_wave",
        "execution_contract_policy": {
            "registry_scope": "immutable_research_task_identity",
            "future_wave_execution_overlay_required": True,
            "execution_overlay_schema": "qa_v2/schemas/wave_execution_overlay.schema.json",
            "commands_inputs_code_hashes_and_runtime_profiles_live_in_overlay": True,
            "stage_authorization_must_bind_registry_and_overlay_hashes": True,
            "pending_future_tasks_are_not_launch_authorized": True,
        },
        "tasks": tasks,
    }


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_contract(project_root: Path, output_dir: Path) -> None:
    write_json(output_dir / "prompt_lock.json", build_prompt_lock(project_root))
    write_json(output_dir / "requirement_matrix.yaml", build_requirement_matrix(project_root))
    write_json(output_dir / "task_registry.json", build_task_registry())


def check_contract(project_root: Path, output_dir: Path) -> None:
    expected = {
        "prompt_lock.json": build_prompt_lock(project_root),
        "requirement_matrix.yaml": build_requirement_matrix(project_root),
        "task_registry.json": build_task_registry(),
    }
    for filename, value in expected.items():
        path = output_dir / filename
        if not path.exists() or json.loads(path.read_text(encoding="utf-8")) != value:
            raise SystemExit(f"stale generated contract: {path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate or verify the EMT P1 v2 research contract")
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.check:
        check_contract(args.project_root.resolve(), args.output_dir.resolve())
    else:
        write_contract(args.project_root.resolve(), args.output_dir.resolve())


if __name__ == "__main__":
    main()
