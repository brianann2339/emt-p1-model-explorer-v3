from __future__ import annotations

import csv
import io
import json
import re
from pathlib import PurePosixPath
from typing import Any, Iterable, Sequence


SHA256_PATTERN = re.compile(r"^[0-9a-fA-F]{64}$")
UUID_PATTERN = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
HASH_SCALAR_FIELD_PATTERN = re.compile(
    r"(?i)(?:^|_)(?:sha256|hash|digest)$"
)
HASH_CONTAINER_ALLOWLIST = frozenset(
    {
        "artifact_hashes",
        "artifact_binding_hashes",
        "checkpoint_artifact_hashes",
        "descriptor_hashes",
        "file_hashes",
        "frozen_hashes",
        "hashes",
        "implementation_hashes",
        "locked_file_hashes",
        "locked_hashes",
        "model_hashes",
        "schema_hashes",
        "session_descriptor_hashes",
        "source_hashes",
        "task_hashes",
        "tested_file_hashes_after",
        "tested_file_hashes_before",
    }
)
PII_COLUMN_NAMES = frozenset(
    {
        "address",
        "chart_no",
        "display_name",
        "email",
        "encounter_no",
        "encounter_no.1",
        "full_name",
        "id_no",
        "id_number",
        "medical_record_number",
        "mrn",
        "name",
        "national_id",
        "op_id",
        "op_name",
        "pat_name",
        "pat_name.1",
        "patient_id",
        "patient_name",
        "phone",
        "telephone",
        "emt_出生年月日",
        "emt_患者姓名",
        "emt_案號",
        "emt_病歷號",
        "emt_發生地點",
        "emt_身分證號",
        "地址",
        "姓名",
        "完整地址",
        "患者姓名",
        "手機",
        "發生地點",
        "病患姓名",
        "病歷號",
        "身份證號",
        "身分證號",
        "電話",
    }
)
PII_COLUMN_SUBSTRINGS = (
    "patient_name",
    "patient_id",
    "pat_name",
    "chart_no",
    "encounter_no",
    "op_id",
    "op_name",
    "mrn",
    "medical_record",
    "identity_number",
    "national_id",
    "birth_date",
    "date_of_birth",
    "案號",
    "姓名",
    "身分證",
    "身份證",
    "病歷號",
    "出生年月日",
    "地址",
    "發生地點",
)
PII_DERIVED_COLUMN_ALLOWLIST = (
    "發生地點_到慈濟_開車km",
    "發生地點_到慈濟_直線km",
)
DIRECT_IDENTIFIER_SOURCE_COLUMNS = (
    "PAT_NAME",
    "PAT_NAME.1",
    "EMT_患者姓名",
    "EMT_身分證號",
    "EMT_病歷號",
    "CHART_NO",
    "ENCOUNTER_NO",
    "OP_ID",
    "OP_NAME",
    "DISPLAY_NAME",
    "EMT_發生地點",
)
STAGE1B_DIRECT_IDENTIFIER_COLUMNS = frozenset(
    {
        "PAT_NAME",
        "CHART_NO",
        "ENCOUNTER_NO",
        "EMT_患者姓名",
        "EMT_身分證號",
        "EMT_病歷號",
        "EMT_出生年月日",
        "EMT_案號",
        "EMT_發生地點",
    }
)
NAME_IDENTIFIER_SOURCE_COLUMNS = DIRECT_IDENTIFIER_SOURCE_COLUMNS[:3]
LONG_EXACT_IDENTIFIER_SOURCE_COLUMNS = frozenset(
    {"EMT_身分證號", "EMT_病歷號", "CHART_NO", "ENCOUNTER_NO"}
)
DIRECT_IDENTIFIER_CASEFOLD_COLUMNS = frozenset(
    {"pat_name", "chart_no", "encounter_no", "op_id", "op_name"}
)
EXPLORER_FORBIDDEN_PII_PAYLOAD_TOKENS = (
    '"row_hash":',
    '"anonymous_id":',
    '"patient_id":',
    "身分證",
    "病歷號",
)
DEPARTMENT_EXPORT_COLUMN_POLICY_TERMS = (
    "ENCOUNTER_NO",
    "PATIENT",
    "NAME",
    "姓名",
    "身分",
    "身份",
    "身分證",
    "病歷號",
    "電話",
    "手機",
    "地址",
    "住址",
    "free_text",
    "自由文字",
    "note",
    "NOTE",
)
HIGH_COST_EXPORT_COLUMN_POLICY_TERMS = (
    "ENCOUNTER_NO",
    "PATIENT",
    "NAME",
    "NATIONAL_ID",
    "ID_NO",
    "MRN",
    "PHONE",
    "TEL",
    "ADDRESS",
    "ADDR",
    "OP_NAME",
    "FREE_TEXT",
    "NOTE",
    "TEXT",
)
SECONDARY_NON_EXPORTABLE_IDENTIFIER_TERMS = (
    "姓名",
    "身分",
    "身份",
    "病歷",
    "電話",
    "手機",
    "地址",
    "住址",
    "phone",
    "address",
    "medicalrecord",
    "chartnumber",
    "patientname",
    "nationalid",
)
SCHEMA_FIELD_CONTAINER_NAMES = frozenset(
    {
        "columns",
        "features",
        "fields",
        "predictors",
        "properties",
        "variables",
    }
)
OPTUNA_PRUNER_NAMES = frozenset({"MedianPruner"})
STAGE3A_TABULAR_TASK_PATTERN = re.compile(
    r"P1_05a-(?:P[1-3]|S[1-6])-(?:ft_transformer|mlp_plr)"
)
SELECTION_CHECKPOINT_PATTERN = re.compile(
    r"selection_(?:final|outer_[0-4])\.json",
    re.IGNORECASE,
)
PII_PATTERNS = {
    "taiwan_national_id": re.compile(
        r"(?<![A-Za-z0-9])[A-Z][12]\d{8}(?![A-Za-z0-9])"
    ),
    "taiwan_mobile": re.compile(r"(?<!\d)09\d{8}(?!\d)"),
    "email": re.compile(
        r"(?i)\b[A-Z0-9._%+-]{1,64}@[A-Z0-9.-]{1,253}\.[A-Z]{2,63}\b"
    ),
    "chinese_name": re.compile(
        r"(?:姓名|患者姓名)\s*[:=：]\s*[\u4e00-\u9fff]{2,4}"
    ),
    "address": re.compile(
        r"(?:[^\s，。；;]{1,30}(?:路|街|巷|弄)\s*\d+"
        r"(?:之\d+)?(?:號|樓|室)?)|"
        r"(?i:\b\d{1,6}\s+[A-Z0-9.-]{1,64}(?:\s+[A-Z0-9.-]{1,64}){0,4}\s+"
        r"(?:Street|St|Road|Rd|Avenue|Ave|Lane|Ln|Boulevard|Blvd)\b)"
    ),
}
LONG_IDENTIFIER_PATTERN = re.compile(r"(?<!\d)\d{6,}(?!\d)")
PII_REDACTION_PATTERNS = {
    "chinese_name": re.compile(
        r"((?:患者姓名|姓名)\s*[:=：]\s*)([\u4e00-\u9fff]{2,4})"
    ),
    "taiwan_national_id": re.compile(
        r"(?<![A-Za-z0-9])[A-Z][12]\d{8}(?!\d)"
    ),
    "taiwan_mobile_formatted": re.compile(
        r"(?<!\d)09(?:[- ]?\d){8}(?!\d)"
    ),
    "email": re.compile(
        r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"
    ),
    "address": re.compile(
        r"[^\s，。；;]{1,30}(?:路|街|巷|弄)\s*\d+(?:之\d+)?號?"
    ),
    "address_tail": re.compile(
        r"\[ADDRESS\](?:巷|弄)\s*\d+(?:之\d+)?號?"
    ),
    "long_identifier": LONG_IDENTIFIER_PATTERN,
}


def redact_labeled_chinese_names(value: object) -> str:
    text = str(value)
    return PII_REDACTION_PATTERNS["chinese_name"].sub(
        lambda match: match.group(1) + "○" * len(match.group(2)),
        text,
    )
SECRET_ASSIGNMENT_PATTERN = re.compile(
    r"(?i)(?<![A-Za-z0-9_])[\"']?"
    r"(?:tabpfn[_-]api[_-]token(?:[_-](?:primary|secondary))?|"
    r"tabpfn[_-]token|tabpfn[_-]api[_-]key|api[_-]?token|api[_-]?key|"
    r"access[_-]?token|client[_-]?token)"
    r"[\"']?\s*[:=]\s*[\"']?([A-Za-z0-9_./+\-=!@#$%^&*]{20,})"
    r"(?=[\s,;#}\]\"']|$)"
)
SHORT_SECRET_ASSIGNMENT_PATTERN = re.compile(
    r"(?i)(?<![A-Za-z0-9_])[\"']?(?:password|secret)[\"']?"
    r"\s*[:=]\s*[\"']?([A-Za-z0-9_./+\-=!@#$%^&*]{8,})"
    r"(?=[\s,;#}\]\"']|$)"
)
RAW_SECRET_PATTERN = re.compile(
    r"(?i)(?:\btabpfn_sk_[A-Za-z0-9_-]{12,}\b|"
    r"(?<![A-Za-z0-9_])sk-[A-Za-z0-9_-]{16,}\b|"
    r"\bhf_[A-Za-z0-9]{20,}\b|"
    r"\beyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}\."
    r"[A-Za-z0-9_-]{10,}\b)"
)
BEARER_PATTERN = re.compile(r"(?i)\bbearer\s+[A-Za-z0-9_./+\-=]{20,}")
AUTHORIZED_TOKEN_PATTERN = re.compile(
    r"(?i)^(?:KGAT_[A-Za-z0-9_-]{16,}|tabpfn_sk_[A-Za-z0-9_-]{12,}|"
    r"tabicl_[A-Za-z0-9_-]{12,})$"
)
TABPFN_TOKEN_EXTRACT_PATTERN = re.compile(
    r"tabpfn_sk_[A-Za-z0-9_-]+", re.IGNORECASE
)
AUTHORIZED_TOKEN_TEXT_PATTERN = re.compile(
    r"(?i)(?<![A-Za-z0-9_])(?:KGAT_[A-Za-z0-9_-]{16,}|"
    r"tabpfn_sk_[A-Za-z0-9_-]{12,}|tabicl_[A-Za-z0-9_-]{12,})"
)
LONG_SECRET_FIELD_PATTERN = re.compile(
    r"(?i)^(?:tabpfn[_-]api[_-]token(?:[_-](?:primary|secondary))?|"
    r"tabpfn[_-]token|tabpfn[_-]api[_-]key|api[_-]?token|api[_-]?key|"
    r"access[_-]?token|client[_-]?token)$"
)
SHORT_SECRET_FIELD_PATTERN = re.compile(r"(?i)^(?:password|secret)$")
STRUCTURED_SECRET_VALUE_PATTERN = re.compile(r"^[A-Za-z0-9_./+\-=!@#$%^&*]+$")
HASH_ASSIGNMENT_PATTERN = re.compile(
    r"(?im)(?P<prefix>(?<![A-Za-z0-9_])[\"']?"
    r"(?P<key>[A-Za-z0-9_.-]+)[\"']?\s*[:=][\"']?)"
    r"(?P<value>[0-9a-fA-F]{64})"
    r"(?P<suffix>[\"']?(?:[,}]|$))"
)
TEXT_SUFFIXES = frozenset(
    {
        ".cfg",
        ".csv",
        ".env",
        ".ini",
        ".ipynb",
        ".json",
        ".jsonl",
        ".log",
        ".md",
        ".py",
        ".rst",
        ".toml",
        ".tsv",
        ".txt",
        ".yaml",
        ".yml",
    }
)
SECRET_PATTERN_CLASSES = {
    "tabpfn_token": re.compile(
        rb"tabpfn_sk_[A-Za-z0-9_-]{12,}", re.IGNORECASE
    ),
    "tabpfn_assignment": re.compile(
        rb"(?i)\btabpfn_(?:api_token(?:_primary|_secondary)?|token|api_key)\b"
        rb"\s*[:=]\s*[\"']?[A-Za-z0-9_./+\-=]{20,}"
    ),
    "tabicl_token": re.compile(
        rb"tabicl_sk_[A-Za-z0-9_-]{12,}", re.IGNORECASE
    ),
    "tabicl_assignment": re.compile(
        rb"(?i)\btabicl_(?:api_token(?:_primary|_secondary)?|token|api_key)\b"
        rb"\s*[:=]\s*[\"']?[A-Za-z0-9_./+\-=]{20,}"
    ),
    "kaggle_api_token": re.compile(
        rb"(?<![A-Za-z0-9])KGAT_[A-Za-z0-9_-]{20,}"
    ),
    "huggingface_token": re.compile(
        rb"(?<![A-Za-z0-9])hf_[A-Za-z0-9]{20,}"
    ),
    "openai_token": re.compile(
        rb"(?<![A-Za-z0-9])sk-[A-Za-z0-9_-]{20,}"
    ),
    "private_key": re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "kaggle_json_key": re.compile(
        rb"(?is)[\"']username[\"']\s*:\s*[\"'][^\"']+[\"'].{0,200}"
        rb"[\"']key[\"']\s*:\s*[\"'][A-Za-z0-9_-]{20,}"
    ),
    "assigned_api_token": re.compile(
        rb"(?i)(?<![A-Za-z0-9_])[\"']?"
        rb"(?:api[_-]?(?:key|token)|access[_-]?token|client[_-]?token|token)"
        rb"[\"']?\s*[:=]\s*[\"']?[A-Za-z0-9_./+\-=!@#$%^&*]{20,}"
    ),
    "assigned_password_secret": re.compile(
        rb"(?i)(?<![A-Za-z0-9_])[\"']?(?:password|secret)[\"']?"
        rb"\s*[:=]\s*[\"']?[A-Za-z0-9_./+\-=!@#$%^&*]{8,}"
        rb"(?=[\s,;#}\]\"']|$)"
    ),
}
AUTHORIZED_SECRET_CLASS_NAMES = frozenset(
    {
        "assigned_api_token",
        "kaggle_api_token",
        "kaggle_json_key",
        "tabicl_assignment",
        "tabicl_token",
        "tabpfn_assignment",
        "tabpfn_token",
    }
)
BLOCKING_SECRET_CLASS_NAMES = frozenset(SECRET_PATTERN_CLASSES) - (
    AUTHORIZED_SECRET_CLASS_NAMES
)
AUTHORIZED_TOKEN_BYTES_PATTERN = re.compile(
    rb"(?:"
    rb"(?<![A-Za-z0-9_])(?:kaggle[_-]api[_-]token|"
    rb"tabpfn(?:[_-]api)?[_-](?:token|key)(?:[_-](?:primary|secondary))?|"
    rb"tabicl(?:[_-]api)?[_-](?:token|key)(?:[_-](?:primary|secondary))?)"
    rb"(?![A-Za-z0-9_])\s*[:=]\s*[\"']?[A-Za-z0-9_./+\-=!@#$%^&*]{12,}|"
    rb"(?<![A-Za-z0-9_])KGAT_[A-Za-z0-9_-]{20,}|"
    rb"(?<![A-Za-z0-9_])tabpfn_sk_[A-Za-z0-9_-]{12,}|"
    rb"(?<![A-Za-z0-9_])tabicl_sk_[A-Za-z0-9_-]{12,}"
    rb")",
    re.IGNORECASE,
)
BLOCKING_SECRET_BYTES_PATTERN = re.compile(
    rb"(?:"
    rb"(?<![A-Za-z0-9_])(?!(?:kaggle[_-]api[_-]token|"
    rb"tabpfn(?:[_-]api)?[_-](?:token|key)(?:[_-](?:primary|secondary))?|"
    rb"tabicl(?:[_-]api)?[_-](?:token|key)(?:[_-](?:primary|secondary))?)"
    rb"(?![A-Za-z0-9_]))(?:"
    rb"api[_-]?(?:key|token)|access[_-]?token|client[_-]?token|token)"
    rb"(?![A-Za-z0-9_])\s*[:=]\s*[\"']?[A-Za-z0-9_./+\-=!@#$%^&*]{20,}|"
    rb"(?<![A-Za-z0-9_])(?:password|secret)(?![A-Za-z0-9_])"
    rb"\s*[:=]\s*[\"']?[A-Za-z0-9_./+\-=!@#$%^&*]{8,}|"
    rb"\bbearer\s+[A-Za-z0-9_./+\-=]{20,}|"
    rb"\bsk-[A-Za-z0-9_-]{16,}\b|"
    rb"\bhf_[A-Za-z0-9]{20,}\b|"
    rb"\beyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}\."
    rb"[A-Za-z0-9_-]{10,}\b"
    rb")",
    re.IGNORECASE,
)


def is_hash_scalar_field(value: object) -> bool:
    return bool(HASH_SCALAR_FIELD_PATTERN.search(str(value).strip()))


def is_hash_container_field(value: object) -> bool:
    name = str(value).strip().casefold()
    return name in HASH_CONTAINER_ALLOWLIST


def hash_context(path: Sequence[object] = (), field: object | None = None) -> bool:
    names = [str(value).strip() for value in path if not str(value).startswith("[")]
    if field is not None:
        names.append(str(field).strip())
    return bool(
        names
        and (
            is_hash_scalar_field(names[-1])
            or any(is_hash_container_field(name) for name in names)
        )
    )


def phone_hash_exception(
    value: object,
    *,
    path: Sequence[object] = (),
    field: object | None = None,
) -> bool:
    return isinstance(value, str) and bool(
        SHA256_PATTERN.fullmatch(value) and hash_context(path, field)
    )


def pii_column_hits(columns: Iterable[object]) -> list[str]:
    hits = []
    for value in columns:
        name = str(value).strip()
        folded = name.casefold()
        if any(allowed in name for allowed in PII_DERIVED_COLUMN_ALLOWLIST):
            continue
        if folded in PII_COLUMN_NAMES or any(
            token.casefold() in folded for token in PII_COLUMN_SUBSTRINGS
        ):
            hits.append(name)
    return sorted(set(hits))


def _schema_field_name_context(path: Sequence[object]) -> bool:
    return any(
        str(segment).strip().casefold() in SCHEMA_FIELD_CONTAINER_NAMES
        for segment in path
        if not str(segment).startswith("[")
    )


def _w01b_package_name_context(path: Sequence[object]) -> bool:
    segments = [
        str(segment).strip().replace("\\", "/").casefold()
        for segment in path
        if not str(segment).startswith("[")
    ]
    return (
        len(segments) >= 2
        and segments[-1] == "package"
        and segments[0].rsplit("/", 1)[-1]
        == "w01b_authorization_input_plan.json"
    )


def _kaggle_dataset_license_name_context(path: Sequence[object]) -> bool:
    segments = [str(segment).strip().replace("\\", "/") for segment in path]
    return (
        len(segments) >= 3
        and segments[0].rsplit("/", 1)[-1].casefold()
        == "dataset-metadata.json"
        and segments[-2].casefold() == "licenses"
        and re.fullmatch(r"\[\d+\]", segments[-1]) is not None
        and all(
            re.fullmatch(r"\[\d+\]", segment) is not None
            for segment in segments[1:-2]
        )
    )


def _hardware_cuda_device_name_context(path: Sequence[object]) -> bool:
    segments = [str(segment).strip().replace("\\", "/") for segment in path]
    return (
        len(segments) >= 4
        and segments[0].rsplit("/", 1)[-1].casefold() == "hardware.json"
        and segments[-2].casefold() == "cuda_devices"
        and re.fullmatch(r"\[\d+\]", segments[-1]) is not None
        and all(
            re.fullmatch(r"\[\d+\]", segment) is not None
            for segment in segments[1:-2]
        )
    )


def _stage3a_tabular_task_member(
    member: PurePosixPath, *, checkpoint: bool
) -> bool:
    parts = member.parts
    suffix_size = 4 if checkpoint else 3
    if len(parts) < suffix_size:
        return False
    task_offset = -3 if checkpoint else -2
    tasks_offset = -4 if checkpoint else -3
    return (
        parts[tasks_offset].casefold() == "tasks"
        and STAGE3A_TABULAR_TASK_PATTERN.fullmatch(parts[task_offset]) is not None
        and (not checkpoint or parts[-2].casefold() == "checkpoints")
    )


def _optuna_pruner_name_context(
    path: Sequence[object], value: object
) -> bool:
    segments = [str(segment).strip().replace("\\", "/") for segment in path]
    if not isinstance(value, str) or value not in OPTUNA_PRUNER_NAMES or not segments:
        return False
    member = PurePosixPath(segments[0])
    selection_checkpoint = (
        len(segments) == 3
        and segments[1] == "[0]"
        and segments[2].casefold() == "pruner"
        and SELECTION_CHECKPOINT_PATTERN.fullmatch(member.name) is not None
        and _stage3a_tabular_task_member(member, checkpoint=True)
    )
    hpo_contract = (
        len(segments) == 4
        and segments[1] == "[0]"
        and segments[2].casefold() == "hpo"
        and segments[3].casefold() == "pruner"
        and member.name.casefold() in {"runner_contract.json", "spec.json"}
        and _stage3a_tabular_task_member(member, checkpoint=False)
    )
    return selection_checkpoint or hpo_contract


def _stage3a_runtime_member(member: PurePosixPath) -> tuple[str, ...] | None:
    parts = member.parts
    if (
        len(parts) < 3
        or parts[0].casefold() != "stage3a_runtime"
        or re.fullmatch(r"W03B_TABULAR-A\d{2}-S[12]", parts[1]) is None
    ):
        return None
    return parts


def _object_store_path_phone_context(
    value: object,
    *,
    path: Sequence[object],
) -> bool:
    if not isinstance(value, str) or not path:
        return False
    segments = [str(segment).strip().replace("\\", "/") for segment in path]
    member = PurePosixPath(segments[0])
    member_parts = _stage3a_runtime_member(member)
    if member_parts is None:
        return False
    accepted_manifest = (
        member.name.casefold() == "accepted_manifest.json"
        and len(member_parts) >= 8
        and tuple(part.casefold() for part in member_parts[2:4])
        == ("authorization_root", "support")
        and len(segments) == 5
        and segments[1] == "[0]"
        and segments[2].casefold() == "artifact_bindings"
        and segments[4].casefold() == "path"
    )
    portable_catalog = (
        len(member_parts) == 3
        and member.name.casefold() == "portable_rebind_catalog.json"
        and len(segments) == 5
        and segments[1] == "[0]"
        and segments[2].casefold() == "source_objects"
        and segments[4].casefold() == "portable_path"
    )
    if not accepted_manifest and not portable_catalog:
        return False
    object_path = PurePosixPath(value)
    object_parts = object_path.parts
    if accepted_manifest:
        if (
            len(object_parts) != 8
            or object_parts[0] != "/"
            or tuple(part.casefold() for part in object_parts[1:4])
            != ("kaggle", "working", "stage3a_runtime")
            or object_parts[4] != member_parts[1]
            or object_parts[5].casefold() != "objects"
            or SHA256_PATTERN.fullmatch(object_parts[6]) is None
            or PurePosixPath(segments[3]).name != object_parts[7]
        ):
            return False
    elif (
        len(object_parts) != 3
        or object_parts[0].casefold() != "objects"
        or SHA256_PATTERN.fullmatch(object_parts[1]) is None
        or segments[3] != value
    ):
        return False
    return True


def _bert_tokenizer_vocab_context(
    path: Sequence[object], value: object
) -> bool:
    if len(path) != 4:
        return False
    member = PurePosixPath(str(path[0]).strip().replace("\\", "/"))
    parts = member.parts
    integer_token_id = isinstance(value, int) and not isinstance(value, bool) and value >= 0
    semantic_snapshot = (
        len(parts) == 5
        and parts[0].casefold() == "tasks"
        and re.fullmatch(
            r"P1_05a-(?:P[1-3]|S[1-6])-bert_finetuned",
            parts[1],
        )
        is not None
        and tuple(part.casefold() for part in parts[2:])
        == ("models", "bert_local_snapshot", "tokenizer.json")
        and str(path[1]) == "[0]"
        and str(path[2]).casefold() == "model"
        and str(path[3]).casefold() == "vocab"
    )
    object_snapshot = (
        len(parts) == 5
        and parts[0].casefold() == "stage3a_runtime"
        and re.fullmatch(r"W03B_TABULAR-A\d{2}-S[12]", parts[1]) is not None
        and parts[2].casefold() == "objects"
        and SHA256_PATTERN.fullmatch(parts[3]) is not None
        and parts[4].casefold() == "tokenizer.json"
        and str(path[1]) == "[0]"
        and str(path[2]).casefold() == "model"
        and str(path[3]).casefold() == "vocab"
    )
    return integer_token_id and (semantic_snapshot or object_snapshot)


def _mask_phone_safe_hash_assignments(text: str) -> str:
    def replace(match: re.Match[str]) -> str:
        if not (
            is_hash_scalar_field(match.group("key"))
            or is_hash_container_field(match.group("key"))
        ):
            return match.group(0)
        return (
            match.group("prefix")
            + (" " * len(match.group("value")))
            + match.group("suffix")
        )

    return HASH_ASSIGNMENT_PATTERN.sub(replace, text)


def pii_pattern_hits(
    value: object,
    *,
    path: Sequence[object] = (),
    field: object | None = None,
    include_long_identifier: bool = False,
    parse_hash_assignments: bool = False,
) -> list[str]:
    if value is None:
        return []
    raw_text = str(value)
    text = raw_text.strip()
    if not text or UUID_PATTERN.fullmatch(text):
        return []
    findings: list[str] = []
    if any(character.isdigit() for character in text) and PII_PATTERNS[
        "taiwan_national_id"
    ].search(text):
        findings.append("taiwan_national_id")
    if "@" in text and PII_PATTERNS["email"].search(text):
        findings.append("email")
    if any(token in text for token in ("姓名", "患者姓名")) and PII_PATTERNS[
        "chinese_name"
    ].search(text):
        findings.append("chinese_name")
    address_markers = (
        "縣",
        "市",
        "區",
        "鄉",
        "鎮",
        "村",
        "里",
        "路",
        "街",
        "巷",
        "弄",
        "Street",
        "street",
        " Road",
        " road",
        " Avenue",
        " avenue",
        " Lane",
        " lane",
        " Boulevard",
        " boulevard",
    )
    if any(token in text for token in address_markers) and PII_PATTERNS[
        "address"
    ].search(text):
        findings.append("address")
    phone_text = (
        _mask_phone_safe_hash_assignments(text)
        if parse_hash_assignments
        else text
    )
    hash_phone_safe = phone_hash_exception(raw_text, path=path, field=field)
    object_path_phone_safe = _object_store_path_phone_context(
        raw_text,
        path=path,
    )
    if (
        "09" in phone_text
        and not hash_phone_safe
        and not object_path_phone_safe
        and PII_PATTERNS["taiwan_mobile"].search(phone_text)
    ):
        findings.append("taiwan_mobile")
    if include_long_identifier:
        identifier_matches = list(LONG_IDENTIFIER_PATTERN.finditer(text))
        if any(
            not (
                hash_phone_safe
                and PII_PATTERNS["taiwan_mobile"].fullmatch(match.group())
            )
            for match in identifier_matches
        ):
            findings.append("long_identifier")
    return sorted(set(findings))


def first_pii_pattern_hit(
    value: object,
    *,
    path: Sequence[object] = (),
    field: object | None = None,
    include_long_identifier: bool = False,
    parse_hash_assignments: bool = False,
) -> str | None:
    findings = pii_pattern_hits(
        value,
        path=path,
        field=field,
        include_long_identifier=include_long_identifier,
        parse_hash_assignments=parse_hash_assignments,
    )
    return findings[0] if findings else None


def contains_secret_text(text: str) -> bool:
    return bool(
        SECRET_ASSIGNMENT_PATTERN.search(text)
        or SHORT_SECRET_ASSIGNMENT_PATTERN.search(text)
        or RAW_SECRET_PATTERN.search(text)
        or BEARER_PATTERN.search(text)
    )


def contains_secret(payload: bytes) -> bool:
    return bool(secret_pattern_classes(payload)) or contains_secret_text(
        payload.decode("utf-8", errors="ignore")
    )


def secret_pattern_classes(payload: bytes) -> list[str]:
    return [
        name
        for name, pattern in SECRET_PATTERN_CLASSES.items()
        if pattern.search(payload)
    ]


def authorized_token_findings(payload: bytes) -> int:
    return sum(
        len(SECRET_PATTERN_CLASSES[name].findall(payload))
        for name in AUTHORIZED_SECRET_CLASS_NAMES
    )


def mask_authorized_tokens(text: str) -> str:
    return AUTHORIZED_TOKEN_TEXT_PATTERN.sub("AUTHORIZED_TOKEN", text)


def contains_unauthorized_secret(payload: bytes) -> bool:
    masked = mask_authorized_tokens(
        payload.decode("utf-8", errors="ignore")
    ).encode("utf-8")
    return contains_secret_text(masked.decode("utf-8", errors="ignore")) or any(
        SECRET_PATTERN_CLASSES[name].search(masked)
        for name in BLOCKING_SECRET_CLASS_NAMES
    )


def secret_field_value_hit(field: object | None, value: str) -> bool:
    text = value.strip()
    if AUTHORIZED_TOKEN_PATTERN.fullmatch(text):
        return False
    if contains_unauthorized_secret(text.encode("utf-8")):
        return True
    if field is None or not STRUCTURED_SECRET_VALUE_PATTERN.fullmatch(text):
        return False
    name = str(field).strip()
    if LONG_SECRET_FIELD_PATTERN.fullmatch(name):
        return len(text) >= 20
    if SHORT_SECRET_FIELD_PATTERN.fullmatch(name):
        return len(text) >= 8
    return False


def scan_json_value(
    value: object,
    *,
    path: tuple[str, ...] = (),
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    if isinstance(value, dict):
        for key, nested in value.items():
            name = str(key)
            child_path = (*path, name)
            schema_name_key = (
                name.casefold() == "name" and _schema_field_name_context(path)
            )
            package_name_key = (
                name.casefold() == "name" and _w01b_package_name_context(path)
            )
            dataset_license_name_key = (
                name.casefold() == "name"
                and _kaggle_dataset_license_name_context(path)
            )
            hardware_device_name_key = (
                name.casefold() == "name"
                and _hardware_cuda_device_name_context(path)
            )
            optuna_pruner_name_key = (
                name.casefold() == "name"
                and _optuna_pruner_name_context(path, nested)
            )
            bert_tokenizer_vocab_key = _bert_tokenizer_vocab_context(path, nested)
            if bert_tokenizer_vocab_key:
                findings.extend(
                    {
                        "kind": "pii_value",
                        "rule": rule,
                        "path": list(child_path),
                    }
                    for rule in pii_pattern_hits(name, path=child_path)
                )
            elif schema_name_key and isinstance(nested, str) and pii_column_hits(
                [nested]
            ):
                findings.append(
                    {
                        "kind": "pii_key",
                        "rule": "pii_declared_column",
                        "path": list(child_path),
                    }
                )
            elif (
                not schema_name_key
                and not package_name_key
                and not dataset_license_name_key
                and not hardware_device_name_key
                and not optuna_pruner_name_key
                and pii_column_hits([name])
            ):
                findings.append(
                    {"kind": "pii_key", "rule": "pii_column", "path": list(child_path)}
                )
            if contains_unauthorized_secret(name.encode("utf-8")):
                findings.append(
                    {"kind": "secret_key", "rule": "unauthorized_secret", "path": list(child_path)}
                )
            findings.extend(scan_json_value(nested, path=child_path))
    elif isinstance(value, list):
        for index, nested in enumerate(value):
            findings.extend(scan_json_value(nested, path=(*path, f"[{index}]")))
    elif isinstance(value, str):
        field = next(
            (segment for segment in reversed(path) if not segment.startswith("[")),
            None,
        )
        if secret_field_value_hit(field, value):
            findings.append(
                {"kind": "secret_value", "rule": "unauthorized_secret", "path": list(path)}
            )
        for rule in pii_pattern_hits(value, path=path, field=field):
            findings.append({"kind": "pii_value", "rule": rule, "path": list(path)})
    return findings


def scan_table_values(
    columns: Sequence[object],
    rows: Iterable[Sequence[object]],
) -> list[dict[str, Any]]:
    names = [str(value) for value in columns]
    findings = [
        {"kind": "pii_column", "rule": "pii_column", "path": [name]}
        for name in pii_column_hits(names)
    ]
    for row_index, row in enumerate(rows):
        for name, value in zip(names, row, strict=False):
            if not isinstance(value, str):
                continue
            path = (name, f"[{row_index}]")
            if secret_field_value_hit(name, value):
                findings.append(
                    {"kind": "secret_value", "rule": "unauthorized_secret", "path": list(path)}
                )
            for rule in pii_pattern_hits(value, path=path, field=name):
                findings.append({"kind": "pii_value", "rule": rule, "path": list(path)})
    return findings


def _embedded_json_values(text: str) -> list[tuple[int, int, object]]:
    values: list[tuple[int, int, object]] = []
    stack: list[str] = []
    start: int | None = None
    in_string = False
    escaped = False
    pairs = {"}": "{", "]": "["}
    for index, character in enumerate(text):
        if in_string:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == '"':
                in_string = False
            continue
        if character == '"':
            in_string = True
        elif character in "{[":
            if not stack:
                start = index
            stack.append(character)
        elif character in "}]" and stack:
            if stack[-1] != pairs[character]:
                stack.clear()
                start = None
                continue
            stack.pop()
            if not stack and start is not None:
                end = index + 1
                try:
                    value = json.loads(text[start:end])
                except json.JSONDecodeError:
                    start = None
                    continue
                if isinstance(value, (dict, list)):
                    values.append((start, end, value))
                start = None
    return values


def scan_payload(relative: str, payload: bytes) -> list[dict[str, Any]]:
    member = PurePosixPath(relative)
    suffix = member.suffix.casefold()
    if suffix in {".json", ".jsonl"} or member.name in {
        "_BUNDLE_SUCCESS",
        "_BUNDLE_PARTIAL",
    }:
        try:
            text = payload.decode("utf-8")
            values = (
                [json.loads(text)]
                if suffix != ".jsonl"
                else [json.loads(line) for line in text.splitlines() if line.strip()]
            )
        except (UnicodeDecodeError, json.JSONDecodeError):
            return [
                {
                    "kind": "invalid_structured_payload",
                    "rule": "invalid_json",
                    "path": [relative],
                }
            ]
        findings = []
        for index, value in enumerate(values):
            findings.extend(scan_json_value(value, path=(relative, f"[{index}]")))
        return findings
    if suffix in {".csv", ".tsv"}:
        try:
            text = payload.decode("utf-8-sig")
            rows = list(
                csv.reader(
                    io.StringIO(text),
                    delimiter="\t" if suffix == ".tsv" else ",",
                )
            )
        except (UnicodeDecodeError, csv.Error):
            return [
                {
                    "kind": "invalid_structured_payload",
                    "rule": "invalid_table",
                    "path": [relative],
                }
            ]
        return scan_table_values(rows[0] if rows else [], rows[1:])
    if suffix == ".parquet":
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq

            table = pq.read_table(io.BytesIO(payload))
        except (ImportError, OSError, ValueError):
            return [
                {
                    "kind": "invalid_structured_payload",
                    "rule": "invalid_parquet",
                    "path": [relative],
                }
            ]
        names = [str(value) for value in table.column_names]
        findings = [
            {"kind": "pii_column", "rule": "pii_column", "path": [name]}
            for name in pii_column_hits(names)
        ]
        for index, name in enumerate(names):
            data_type = table.schema.field(index).type
            if pa.types.is_dictionary(data_type):
                data_type = data_type.value_type
            if not (pa.types.is_string(data_type) or pa.types.is_large_string(data_type)):
                continue
            values = table.column(index).to_pylist()
            findings.extend(
                scan_table_values([name], ([value] for value in values if value is not None))
            )
        return findings
    if suffix in TEXT_SUFFIXES:
        text = payload.decode("utf-8", errors="ignore")
        fragments = _embedded_json_values(text)
        outside = list(text)
        findings: list[dict[str, Any]] = []
        for index, (start, end, value) in enumerate(fragments):
            outside[start:end] = " " * (end - start)
            findings.extend(
                scan_json_value(value, path=(relative, f"json_fragment[{index}]"))
            )
        findings.extend(
            {
                "kind": "pii_value",
                "rule": rule,
                "path": [relative],
            }
            for rule in pii_pattern_hits(
                "".join(outside),
                parse_hash_assignments=True,
            )
        )
        if contains_unauthorized_secret(payload):
            findings.append(
                {"kind": "secret_value", "rule": "unauthorized_secret", "path": [relative]}
            )
        return findings
    return []


def blocking_findings(findings: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    return list(findings)
