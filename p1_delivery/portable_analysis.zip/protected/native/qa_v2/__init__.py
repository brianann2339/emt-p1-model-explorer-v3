"""Research-contract and launch-gate utilities for the EMT P1 v2 pipeline."""
