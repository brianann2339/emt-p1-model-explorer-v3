from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import re
import stat
import sys
import zipfile
from datetime import datetime, timezone
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from jsonschema import Draft202012Validator, FormatChecker

from . import contextual_security_scan as security_scan
from scripts import p1_v2_w00b_runtime_contract as w00b_contract
from scripts.p1_v2_score_recompute import (
    MODEL_OUTPUT_EXCLUDED_SCORE_ALIASES,
    PASSIVE_SCORE_VALUE_COLUMNS,
    SCORE_BASE_COMPONENT_COLUMNS,
    compute_score_values_v2,
    passive_score_recompute_contract,
)
from scripts.p1_v2_wave_contract import (
    WAVE_CONTRACT_SHA256,
    validate_w04_thinking_fit_plan,
    validate_wave_task_placement,
)

from .contract import (
    build_prompt_lock,
    build_requirement_matrix,
    build_task_registry,
    sha256_file,
)


SECRET_PATTERNS = security_scan.SECRET_PATTERN_CLASSES
PII_VALUE_PATTERNS = {
    "taiwan_id": security_scan.PII_PATTERNS["taiwan_national_id"],
    "mobile_phone": security_scan.PII_PATTERNS["taiwan_mobile"],
    "email": security_scan.PII_PATTERNS["email"],
    "long_identifier": security_scan.LONG_IDENTIFIER_PATTERN,
    "street_address": security_scan.PII_PATTERNS["address"],
}
PII_COLUMN_NAMES = security_scan.PII_COLUMN_NAMES
PII_COLUMN_SUBSTRINGS = security_scan.PII_COLUMN_SUBSTRINGS
PII_DERIVED_COLUMN_ALLOWLIST = security_scan.PII_DERIVED_COLUMN_ALLOWLIST
TEXT_EXTENSIONS = {
    ".cfg",
    ".csv",
    ".env",
    ".ini",
    ".ipynb",
    ".json",
    ".jsonl",
    ".log",
    ".md",
    ".py",
    ".rst",
    ".toml",
    ".tsv",
    ".txt",
    ".yaml",
    ".yml",
}
SECRET_SCAN_CHUNK_BYTES = 1024 * 1024
SECRET_SCAN_OVERLAP_BYTES = 64 * 1024
OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
MISSINGNESS_REASON_STATES = (
    "observed",
    "explicit_none",
    "not_applicable",
    "not_measured",
    "unmeasurable",
    "invalid_out_of_range",
    "structural_source_missing",
    "unknown_not_recorded",
)
SCORE_LABEL_TO_VALUE = {
    "NEWS2": "NEWS2",
    "rSIG": "rSIG",
    "rSIG_Age": "rSIG_Age",
    "SIA_G": "SIA_G",
    "SI_G": "SI_G",
    "SI": "SI",
    "mSI": "mSI",
    "aSI": "aSI",
    "rSI": "rSI",
    "rSI_sMS": "rSI_sMS",
    "rSI_GCSM": "rSI_GCSM",
    "SIAVPU": "SIAVPU",
    "sMS": "sMS",
    "qSOFA": "qSOFA",
    "MEWS": "MEWS",
    "REMS": "REMS",
    "RTS": "RTS",
    "rSI_GCS_alias": "rSIG",
}


def load_document(path: Path) -> Any:
    text = path.read_text(encoding="utf-8")
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        try:
            import yaml
        except ImportError as exc:
            raise ValueError(f"{path} is not JSON and PyYAML is unavailable") from exc
        return yaml.safe_load(text)


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"JSONL row is not an object: {path}")
            rows.append(value)
    return rows


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _sha256_value(value: object) -> str:
    if pd.isna(value):
        return ""
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def _resolved(project_root: Path, value: str) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (project_root / path).resolve()


def _check(name: str, callback: Callable[[], dict[str, Any]]) -> dict[str, Any]:
    try:
        details = callback()
        return {"name": name, "status": "PASS", "details": details}
    except Exception as exc:
        return {
            "name": name,
            "status": "FAIL",
            "details": {"error_type": type(exc).__name__, "error": str(exc)},
        }


def _prompt_contract_check(project_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    lock_path = _resolved(project_root, config["prompt_lock"])
    matrix_path = _resolved(project_root, config["requirement_matrix"])
    locked = load_document(lock_path)
    matrix = load_document(matrix_path)
    expected_lock = build_prompt_lock(project_root)
    expected_matrix = build_requirement_matrix(project_root)
    if locked != expected_lock:
        raise ValueError("prompt_lock.json is stale or does not describe exactly the eight approved prompts")
    if matrix != expected_matrix:
        raise ValueError("requirement_matrix.yaml is stale relative to the approved prompts")
    if matrix.get("unclassified_clause_count") != 0:
        raise ValueError(f"unclassified clauses={matrix.get('unclassified_clause_count')}")
    requirements = matrix.get("requirements", [])
    if len(requirements) != matrix.get("source_clause_count"):
        raise ValueError("requirement matrix clause count does not match its requirements list")
    return {
        "prompt_count": len(locked["prompts"]),
        "clause_count": len(requirements),
        "unclassified": 0,
        "prompt_lock_sha256": sha256_file(lock_path),
        "requirement_matrix_sha256": sha256_file(matrix_path),
    }


def _schema_check(project_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    required = {
        "canonical_missingness_coverage",
        "canonical_missingness_reference",
        "canonical_reference_hashes",
        "complete_case_flow",
        "stage",
        "task",
        "prediction",
        "metric",
        "fold",
        "missingness",
        "missingness_reason_long",
        "missingness_structural_rules",
        "optuna_trial",
        "p1_06_companion_explorer_manifest",
        "p1_06_accepted_artifacts",
        "p1_06_frozen_evaluation_authorization",
        "p1_06_acceptance_anchor",
        "p1_06_browser_qa_receipt",
        "kaggle_owner_identity_challenge",
        "kaggle_owner_identity_evidence",
        "coordinator_multi_account_auth",
        "w01b_runtime_profile",
        "w00b_runtime_profile_acceptance",
        "w00b_runtime_profile_scanner_rebind_receipt",
        "w00b_runtime_profile_derived_marker",
        "w01b_launch_receipt",
        "wave_runtime_profile",
        "wave_execution_overlay",
        "task_registry_rebind_receipt",
        "w01a_builder_rebind_receipt",
        "score_coverage_long",
        "launch_authorization",
        "w01_session_authorization",
    }
    configured = config.get("schemas", {})
    if set(configured) != required:
        raise ValueError(f"schema set mismatch; expected={sorted(required)} got={sorted(configured)}")
    hashes = {}
    for name, relative in configured.items():
        path = _resolved(project_root, relative)
        schema = load_document(path)
        if schema.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
            raise ValueError(f"{name} schema does not use JSON Schema draft 2020-12")
        if schema.get("type") != "object" or not schema.get("required"):
            raise ValueError(f"{name} schema lacks object type or required fields")
        hashes[name] = sha256_file(path)
    return {"schema_count": len(hashes), "sha256": hashes}


def _raw_data_check(project_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    raw = config["raw_data"]
    path = _resolved(project_root, raw["path"])
    actual_sha = sha256_file(path)
    if actual_sha.casefold() != raw["sha256"].casefold():
        raise ValueError(f"raw SHA256 mismatch: expected={raw['sha256']} actual={actual_sha}")
    parquet = pq.ParquetFile(path)
    shape = [parquet.metadata.num_rows, len(parquet.schema_arrow.names)]
    if shape != list(raw["shape"]):
        raise ValueError(f"raw shape mismatch: expected={raw['shape']} actual={shape}")
    missing = sorted(set(raw["required_columns"]) - set(parquet.schema_arrow.names))
    if missing:
        raise ValueError(f"raw data missing required columns: {missing}")

    cohort = config["cohort"]
    columns = [
        cohort["date_column"],
        cohort["has_emt_column"],
        cohort["age_column"],
        cohort["encounter_column"],
    ]
    development_path = _resolved(project_root, config["source_seal"]["path"])
    frame = pd.read_parquet(development_path, columns=columns)
    age = pd.to_numeric(frame[cohort["age_column"]], errors="coerce")
    mask = frame[cohort["has_emt_column"]].eq(True) & age.ge(cohort["minimum_age"])
    filtered = frame.loc[mask].copy()
    filtered["__year"] = pd.to_datetime(filtered[cohort["date_column"]], errors="coerce").dt.year
    if filtered["__year"].isna().any() or int(filtered["__year"].max()) > 2024:
        raise ValueError("development source used for cohort recompute is not sealed at 2024")
    deduplicated = filtered.drop_duplicates(subset=[cohort["encounter_column"]], keep="first")
    actual_counts = {
        str(int(year)): int(count)
        for year, count in deduplicated["__year"].value_counts(dropna=False).items()
        if not pd.isna(year)
    }
    attestation_path = _resolved(
        project_root, config["patient_group_independence"]["attestation"]
    )
    attestation = load_document(attestation_path)
    attested_counts = attestation.get("eligible_rows_by_year_after_dedup", {})
    attested_before_dedup = attestation.get("eligible_rows_by_year_before_dedup", {})
    expected_years = {"2020", "2021", "2022", "2023", "2024", "2025"}
    if set(attested_counts) != expected_years or set(attested_before_dedup) != expected_years:
        raise ValueError("2025 group attestation lacks all-year eligible cohort counts")
    if any(actual_counts.get(year) != int(attested_counts[year]) for year in actual_counts):
        raise ValueError("development cohort recompute differs from the aggregate-only attestation")
    actual_counts["2025"] = int(attested_counts["2025"])
    actual_counts = dict(sorted(actual_counts.items()))
    expected_counts = {str(year): int(count) for year, count in cohort["expected_counts_by_year"].items()}
    if actual_counts != dict(sorted(expected_counts.items())):
        raise ValueError(f"cohort year counts mismatch: expected={expected_counts} actual={actual_counts}")
    dev_years = {str(year) for year in cohort["development_years"]}
    dev_rows = sum(count for year, count in actual_counts.items() if year in dev_years)
    if dev_rows != cohort["expected_development_rows"]:
        raise ValueError(
            f"development cohort mismatch: expected={cohort['expected_development_rows']} actual={dev_rows}"
        )
    return {
        "path": str(path),
        "sha256": actual_sha,
        "shape": shape,
        "row_level_scan_maximum_year": 2024,
        "sealed_2025_counts_source": str(attestation_path),
        "filtered_rows_before_dedup": int(len(filtered))
        + int(attested_before_dedup["2025"]),
        "cohort_rows_after_dedup": int(len(deduplicated)) + int(attested_counts["2025"]),
        "counts_by_year": actual_counts,
        "development_rows": dev_rows,
    }


def _patient_disjoint_temporal_check(
    project_root: Path,
    config: dict[str, Any],
) -> dict[str, Any]:
    cohort = config["cohort"]
    contract = cohort["patient_disjoint_temporal_split"]
    if (
        contract.get("strategy")
        != "preserve_all_2024_validation_purge_prior_patient_history"
        or contract.get("outcome_independent") is not True
    ):
        raise ValueError("patient-disjoint temporal split policy differs from the locked contract")
    independence = config["patient_group_independence"]
    attestation_path = _resolved(project_root, independence["attestation"])
    attestation_ledger_path = _resolved(project_root, independence["attestation_ledger"])
    attestation_code_path = _resolved(project_root, independence["attestation_code"])
    partition = independence["filtered_development"]
    partition_path = _resolved(project_root, partition["path"])
    partition_manifest_path = _resolved(project_root, partition["manifest"])
    partition_ledger_path = _resolved(project_root, partition["ledger"])
    partition_code_path = _resolved(project_root, partition["code"])
    for path in (
        attestation_path,
        attestation_ledger_path,
        attestation_code_path,
        partition_path,
        partition_manifest_path,
        partition_ledger_path,
        partition_code_path,
    ):
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(path)

    actual_hashes = {
        "attestation": sha256_file(attestation_path),
        "attestation_ledger": sha256_file(attestation_ledger_path),
        "attestation_code": sha256_file(attestation_code_path),
        "filtered_development": sha256_file(partition_path),
        "filtered_development_manifest": sha256_file(partition_manifest_path),
        "filtered_development_ledger": sha256_file(partition_ledger_path),
        "filtered_development_code": sha256_file(partition_code_path),
    }
    expected_hashes = {
        "attestation": independence["attestation_sha256"],
        "attestation_ledger": independence["attestation_ledger_sha256"],
        "attestation_code": independence["attestation_code_sha256"],
        "filtered_development": partition["sha256"],
        "filtered_development_manifest": partition["manifest_sha256"],
        "filtered_development_ledger": partition["ledger_sha256"],
        "filtered_development_code": partition["code_sha256"],
    }
    if {name: value.casefold() for name, value in actual_hashes.items()} != {
        name: str(value).casefold() for name, value in expected_hashes.items()
    }:
        raise ValueError(
            f"patient-group evidence hash mismatch: expected={expected_hashes} actual={actual_hashes}"
        )

    attestation = load_document(attestation_path)
    intersection = int(attestation.get("overlap", {}).get("intersection_group_count", -1))
    expected_intersection = int(independence["expected_intersection_group_count"])
    expected_status = "BLOCKED_OVERLAP" if expected_intersection else "PASS_ZERO_OVERLAP"
    if (
        attestation.get("contract_version")
        != "p1-v2-sealed-2025-group-independence-attestation/1"
        or attestation.get("status") != expected_status
        or intersection != expected_intersection
        or attestation.get("independent_recompute", {}).get("status") != "PASS"
        or attestation.get("locked_stage1a_contract_verified") is not True
        or attestation.get("no_group_or_row_members_emitted") is not True
        or str(attestation.get("code_sha256", "")).casefold()
        != actual_hashes["attestation_code"].casefold()
    ):
        raise ValueError("2025 patient-group attestation is not a completed independently verified contract")
    access_scope = attestation.get("access_scope", {})
    forbidden_access = (
        "outcome_columns_accessed",
        "text_columns_accessed",
        "vital_columns_accessed",
        "prediction_columns_accessed",
        "metric_columns_accessed",
    )
    if any(access_scope.get(name) != [] for name in forbidden_access) or access_scope.get(
        "outcomes_summarized"
    ) is not False:
        raise ValueError("2025 patient-group attestation accessed forbidden clinical content")
    if str(attestation.get("source", {}).get("sha256", "")).casefold() != str(
        config["raw_data"]["sha256"]
    ).casefold():
        raise ValueError("2025 patient-group attestation is not anchored to the locked raw source")

    attestation_rows = [
        row
        for row in load_jsonl(attestation_ledger_path)
        if row.get("attempt_id") == attestation.get("attempt_id")
    ]
    if {row.get("event") for row in attestation_rows} != {"ATTEMPT_STARTED", "ATTEMPT_FINISHED"}:
        raise ValueError("2025 patient-group attestation ledger lacks a complete start/finish pair")
    finished_attestation = next(row for row in attestation_rows if row.get("event") == "ATTEMPT_FINISHED")
    if (
        str(finished_attestation.get("attestation_sha256", "")).casefold()
        != actual_hashes["attestation"].casefold()
        or finished_attestation.get("independent_recompute_status") != "PASS"
        or int(finished_attestation.get("intersection_group_count", -1)) != expected_intersection
    ):
        raise ValueError("2025 patient-group attestation ledger does not bind the completed attestation")

    partition_manifest = load_document(partition_manifest_path)
    verification = partition_manifest.get("verification", {})
    partition_access = partition_manifest.get("access_scope", {})
    if (
        partition_manifest.get("contract_version")
        != "p1-v2-patient-disjoint-development-partition/1"
        or partition_manifest.get("status") != "SUCCESS"
        or partition_manifest.get("upload_forbidden") is not True
        or partition_manifest.get("sealed_2025_artifact_created") is not False
        or partition_manifest.get("no_group_or_member_list_emitted") is not True
        or verification.get("eligible_development_vs_2025_group_overlap") != 0
        or verification.get("independent_readback_recompute") != "PASS"
        or verification.get("output_max_year_le_2024") is not True
        or partition_access.get("sealed_2025_outcomes_accessed") is not False
        or str(partition_manifest.get("code_sha256", "")).casefold()
        != actual_hashes["filtered_development_code"].casefold()
    ):
        raise ValueError("filtered development partition does not certify zero 2025 group overlap")
    if (
        str(partition_manifest.get("source", {}).get("sha256", "")).casefold()
        != str(config["raw_data"]["sha256"]).casefold()
        or str(partition_manifest.get("development_input", {}).get("sha256", "")).casefold()
        != str(config["source_seal"]["sha256"]).casefold()
        or any(
            partition_access.get(name) != []
            for name in (
                "source_outcome_columns_accessed",
                "source_text_columns_accessed",
                "source_vital_columns_accessed",
            )
        )
    ):
        raise ValueError("filtered development partition accessed or used an unlocked source")
    binding = partition_manifest.get("blocking_attestation", {})
    if (
        str(binding.get("sha256", "")).casefold() != actual_hashes["attestation"].casefold()
        or binding.get("attempt_id") != attestation.get("attempt_id")
        or binding.get("status") != attestation.get("status")
        or int(binding.get("intersection_group_count", -1)) != expected_intersection
    ):
        raise ValueError("filtered development partition is not bound to the locked 2025 attestation")
    development_output = partition_manifest.get("development_output", {})
    parquet = pq.ParquetFile(partition_path)
    shape = [parquet.metadata.num_rows, len(parquet.schema_arrow.names)]
    if (
        shape != list(partition["shape"])
        or int(development_output.get("rows", -1)) != shape[0]
        or int(development_output.get("columns", -1)) != shape[1]
        or str(development_output.get("sha256", "")).casefold()
        != actual_hashes["filtered_development"].casefold()
    ):
        raise ValueError("filtered development partition shape/hash differs from its manifest")
    years = pd.to_datetime(
        pd.read_parquet(partition_path, columns=[partition["date_column"]])[
            partition["date_column"]
        ],
        errors="coerce",
    ).dt.year
    if years.isna().any() or int(years.max()) > int(partition["maximum_year"]):
        raise ValueError("filtered development partition contains an invalid or forbidden year")

    expected_post_stage1a = independence["expected_post_stage1a"]
    if partition_manifest.get("expected_post_stage1a") != expected_post_stage1a:
        raise ValueError("filtered development partition expected counts/events differ from the lock")
    statistics = {
        "pre_purge_split_counts": expected_post_stage1a["pre_purge_split_counts"],
        "post_purge_split_counts": expected_post_stage1a["post_purge_split_counts"],
        "pre_purge_total_rows": int(sum(expected_post_stage1a["pre_purge_split_counts"].values())),
        "post_purge_total_rows": int(sum(expected_post_stage1a["post_purge_split_counts"].values())),
        "purged_train_rows": int(expected_post_stage1a["purged_train_rows"]),
        "overlap_groups_before_purge": int(expected_post_stage1a["overlap_groups_before_purge"]),
        "overlap_groups_after_purge": int(expected_post_stage1a["overlap_groups_after_purge"]),
    }
    expected_statistics = {name: contract[name] for name in statistics}
    if statistics != expected_statistics:
        raise ValueError(
            f"patient-disjoint temporal lock differs from filtered partition: expected={expected_statistics} actual={statistics}"
        )

    partition_rows = [
        row
        for row in load_jsonl(partition_ledger_path)
        if row.get("attempt_id") == partition_manifest.get("attempt_id")
    ]
    if {row.get("event") for row in partition_rows} != {"ATTEMPT_STARTED", "ATTEMPT_FINISHED"}:
        raise ValueError("filtered development ledger lacks a complete start/finish pair")
    finished_partition = next(row for row in partition_rows if row.get("event") == "ATTEMPT_FINISHED")
    if (
        finished_partition.get("status") != "SUCCESS"
        or str(finished_partition.get("manifest_sha256", "")).casefold()
        != actual_hashes["filtered_development_manifest"].casefold()
        or str(finished_partition.get("output_sha256", "")).casefold()
        != actual_hashes["filtered_development"].casefold()
    ):
        raise ValueError("filtered development ledger does not bind the completed partition")

    features_path = _resolved(project_root, config["fold_map"]["features_path"])
    feature_columns = [
        "row_hash",
        "group_hash",
        "split_year",
        "split",
        *(f"y_{outcome}" for outcome in OUTCOMES),
    ]
    features = pd.read_parquet(features_path, columns=feature_columns)
    if features["row_hash"].duplicated().any():
        raise ValueError("Stage1a patient-disjoint output contains duplicate row_hash")
    actual_train_groups = set(
        features.loc[features["split"].eq("train_2020_2023"), "group_hash"].astype(str)
    )
    actual_validation_groups = set(
        features.loc[features["split"].eq("validation_2024"), "group_hash"].astype(str)
    )
    actual_overlap = actual_train_groups & actual_validation_groups
    if actual_overlap:
        raise ValueError(
            f"temporal patient group overlap remains across train and validation: {len(actual_overlap)}"
        )
    actual_counts = features.groupby("split", observed=True).size().astype(int).to_dict()
    if actual_counts != expected_post_stage1a["post_purge_split_counts"]:
        raise ValueError(
            f"Stage1a split counts differ from filtered partition: expected={expected_post_stage1a['post_purge_split_counts']} actual={actual_counts}"
        )
    split_year = pd.to_numeric(features["split_year"], errors="coerce")
    if (
        split_year.isna().any()
        or not split_year[features["split"].eq("train_2020_2023")].between(2020, 2023).all()
        or not split_year[features["split"].eq("validation_2024")].eq(2024).all()
    ):
        raise ValueError("Stage1a split years differ from the locked temporal boundary")
    actual_events = {
        split: {
            outcome: int(pd.to_numeric(group[f"y_{outcome}"], errors="raise").sum())
            for outcome in OUTCOMES
        }
        for split, group in features.groupby("split", observed=True)
    }
    if actual_events != expected_post_stage1a["event_counts"]:
        raise ValueError(
            f"Stage1a event counts differ from filtered partition: expected={expected_post_stage1a['event_counts']} actual={actual_events}"
        )

    stage1a_manifest_path = _resolved(
        project_root, config["passive_score_contract"]["stage1a_manifest"]
    )
    stage1a_manifest = load_document(stage1a_manifest_path)
    provenance = stage1a_manifest.get("patient_disjoint_partition", {})
    expected_provenance = {
        "partition_manifest_sha256": actual_hashes["filtered_development_manifest"].upper(),
        "development_output_sha256": actual_hashes["filtered_development"].upper(),
        "blocking_attestation_sha256": actual_hashes["attestation"].upper(),
        "eligible_development_vs_2025_group_overlap": 0,
        "expected_post_stage1a": expected_post_stage1a,
    }
    if provenance != expected_provenance:
        raise ValueError("Stage1a manifest is not bound to the filtered zero-overlap partition")
    return {
        **statistics,
        "strategy": contract["strategy"],
        "group_source_column": contract["group_source_column"],
        "outcome_independent": True,
        "development_vs_2025_group_overlap": 0,
        "temporal_patient_group_overlap": 0,
        "stage1a_event_counts": actual_events,
        "evidence_hashes": actual_hashes,
    }


def _passive_score_contract_check(
    project_root: Path,
    config: dict[str, Any],
) -> dict[str, Any]:
    score_config = config["passive_score_contract"]
    feature_path = _resolved(project_root, score_config["stage1a_features"])
    schema_path = _resolved(project_root, score_config["stage1a_schema"])
    manifest_path = _resolved(project_root, score_config["stage1a_manifest"])
    for path in (feature_path, schema_path, manifest_path):
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(path)

    expected_count = int(score_config["expected_value_count"])
    if (
        expected_count != 19
        or len(PASSIVE_SCORE_VALUE_COLUMNS) != expected_count
        or len(set(PASSIVE_SCORE_VALUE_COLUMNS)) != expected_count
    ):
        raise ValueError("passive score contract does not contain exactly 19 unique values")
    expected_aliases = score_config["model_output_excluded_score_aliases"]
    if MODEL_OUTPUT_EXCLUDED_SCORE_ALIASES != expected_aliases or expected_aliases != {
        "rSI_GCS": "rSIG"
    }:
        raise ValueError("rSI_GCS duplicate alias is not locked to rSIG")

    current_contract = passive_score_recompute_contract()
    required_flags = {
        "enabled": True,
        "all_19_passive_score_values_required": True,
        "all_19_passive_score_values_recomputed_and_attested": True,
        "direct_score_value_imputation": False,
        "direct_score_imputation_for_missing_components": False,
        "original_missingness_availability_counts_preserved": True,
    }
    wrong_flags = {
        key: current_contract.get(key)
        for key, expected in required_flags.items()
        if current_contract.get(key) is not expected
    }
    if wrong_flags:
        raise ValueError(f"passive score component-first contract flags differ: {wrong_flags}")
    if (
        current_contract.get("passive_score_value_columns")
        != list(PASSIVE_SCORE_VALUE_COLUMNS)
        or current_contract.get("model_output_excluded_score_aliases") != expected_aliases
    ):
        raise ValueError("passive score value order or alias exclusion differs from the lock")

    schema = load_document(schema_path)
    manifest = load_document(manifest_path)
    if schema.get("passive_score_recompute") != current_contract:
        raise ValueError("Stage1a schema passive score contract is stale")
    if manifest.get("passive_score_recompute") != current_contract:
        raise ValueError("Stage1a manifest passive score contract is stale")
    artifact_hashes = manifest.get("artifact_sha256", {})
    for path in (feature_path, schema_path):
        if str(artifact_hashes.get(path.name, "")).casefold() != sha256_file(path).casefold():
            raise ValueError(f"Stage1a passive score input hash differs from manifest: {path.name}")
    feature_specs = schema.get("features", [])
    feature_model_flags = {
        str(row.get("name")): bool(row.get("model_feature", True)) for row in feature_specs
    }
    if feature_model_flags.get("rSI_GCS") is not False or feature_model_flags.get("rSIG") is not True:
        raise ValueError("Stage1a schema does not exclude only the rSI_GCS duplicate from ML inputs")

    required_columns = [*SCORE_BASE_COMPONENT_COLUMNS, *PASSIVE_SCORE_VALUE_COLUMNS]
    parquet_columns = set(pq.ParquetFile(feature_path).schema_arrow.names)
    missing = sorted(set(required_columns) - parquet_columns)
    if missing:
        raise ValueError(f"Stage1a lacks passive score components/values: {missing}")
    frame = pd.read_parquet(feature_path, columns=required_columns)
    recomputed = compute_score_values_v2(frame)
    mismatches = {}
    for score in PASSIVE_SCORE_VALUE_COLUMNS:
        stored = pd.to_numeric(frame[score], errors="coerce").to_numpy(dtype="float64")
        expected = pd.to_numeric(recomputed[score], errors="coerce").to_numpy(dtype="float64")
        equal = np.isclose(
            stored,
            expected,
            rtol=float(score_config["formula_rtol"]),
            atol=float(score_config["formula_atol"]),
            equal_nan=True,
        )
        if not bool(equal.all()):
            mismatches[score] = int((~equal).sum())
    if mismatches:
        raise ValueError(f"Stage1a passive score formula equivalence failed: {mismatches}")
    return {
        "value_count": len(PASSIVE_SCORE_VALUE_COLUMNS),
        "formula_sha256": current_contract["formula_sha256"],
        "formula_equivalence_mismatches": 0,
        "direct_score_value_imputation": False,
        "component_first_recompute": True,
        "model_output_excluded_score_aliases": expected_aliases,
        "artifact_hashes": {
            "stage1a_features": sha256_file(feature_path),
            "stage1a_schema": sha256_file(schema_path),
            "stage1a_manifest": sha256_file(manifest_path),
        },
    }


def _missingness_disclosure_check(
    project_root: Path,
    config: dict[str, Any],
) -> dict[str, Any]:
    disclosure = config["missingness_disclosure"]
    manifest_path = _resolved(project_root, disclosure["manifest"])
    rules_path = _resolved(project_root, disclosure["structural_rules"])
    artifact_paths = {
        name: _resolved(project_root, relative)
        for name, relative in disclosure["artifacts"].items()
    }
    schema_paths = {
        name: _resolved(project_root, config["schemas"][name])
        for name in (
            "missingness_reason_long",
            "score_coverage_long",
            "complete_case_flow",
            "missingness_structural_rules",
        )
    }
    for path in (manifest_path, rules_path, *artifact_paths.values(), *schema_paths.values()):
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(path)

    manifest = load_document(manifest_path)
    if (
        manifest.get("contract_version") != "p1-v2-missingness-disclosure/1"
        or manifest.get("deterministic") is not True
        or manifest.get("strict_no_arrival_leakage") is not True
        or manifest.get("2025_access_count") != 0
        or manifest.get("source_seal_access_count") != 0
        or manifest.get("raw_data_access_count") != 0
        or manifest.get("statistical_imputation_performed") is not False
    ):
        raise ValueError("missingness disclosure manifest does not satisfy the sealed deterministic contract")
    formula = manifest.get("formula", {})
    current_score_contract = passive_score_recompute_contract()
    if (
        formula.get("version") != current_score_contract["formula_version"]
        or formula.get("function_sha256") != current_score_contract["formula_sha256"]
        or formula.get("stored_values_recomputed_and_verified") is not True
    ):
        raise ValueError("missingness disclosure formula evidence differs from the passive score lock")

    stage1a_inputs = {
        "stage1a_features": _resolved(
            project_root, config["passive_score_contract"]["stage1a_features"]
        ),
        "stage1a_schema": _resolved(
            project_root, config["passive_score_contract"]["stage1a_schema"]
        ),
        "stage1a_manifest": _resolved(
            project_root, config["passive_score_contract"]["stage1a_manifest"]
        ),
        "structural_rules": rules_path,
    }
    expected_input_hashes = {name: sha256_file(path) for name, path in stage1a_inputs.items()}
    if manifest.get("input_hashes") != expected_input_hashes:
        raise ValueError("missingness disclosure input hashes are stale against Stage1a/rules")

    coverage = manifest.get("coverage", {})
    if (
        coverage.get("missingness_reason_taxonomy") != list(MISSINGNESS_REASON_STATES)
        or int(coverage.get("score_value_entities", -1)) != 19
        or int(coverage.get("score_label_entities", -1)) != 18
        or set(coverage.get("groupings", [])) != {"split", "year", "city", "outcome"}
    ):
        raise ValueError("missingness disclosure does not lock 8 states, 19 values, and 18 labels")
    invariants = manifest.get("invariants", {})
    if (
        invariants.get("reason_counts_exhaustive") is not True
        or invariants.get("reason_states_mutually_exclusive") is not True
        or invariants.get("score_component_patterns_exhaustive") is not True
        or invariants.get("duplicate_rows") != 0
    ):
        raise ValueError("missingness disclosure invariants are not PASS")

    rules = load_document(rules_path)
    if set(rules) != {"schema_version", "structurally_unusable_features", "rules"}:
        raise ValueError("missingness structural rules do not match the locked root schema")
    rule_ids = [str(row.get("rule_id", "")) for row in rules["rules"]]
    if any(not value for value in rule_ids) or len(rule_ids) != len(set(rule_ids)):
        raise ValueError("missingness structural rule IDs are empty or duplicated")
    structural = manifest.get("structural_rules", {})
    if (
        structural.get("provided") is not True
        or str(structural.get("sha256", "")).casefold() != sha256_file(rules_path).casefold()
        or int(structural.get("rule_count", -1)) != len(rules["rules"])
    ):
        raise ValueError("missingness disclosure is missing the explicit structural-rules artifact")

    expected_schema_hashes = {
        str(path.relative_to(project_root)).replace("\\", "/"): sha256_file(path)
        for path in schema_paths.values()
    }
    if manifest.get("schema_sha256") != expected_schema_hashes:
        raise ValueError("missingness disclosure schema hashes differ from the locked schemas")
    artifact_hashes = manifest.get("artifact_sha256", {})
    expected_artifact_hashes = {
        path.name: sha256_file(path) for path in artifact_paths.values()
    }
    if artifact_hashes != expected_artifact_hashes:
        raise ValueError("missingness disclosure artifact hashes differ from its manifest")
    if manifest.get("artifacts") != {
        name: path.name for name, path in artifact_paths.items()
    }:
        raise ValueError("missingness disclosure artifact roles differ from the locked contract")

    tables = {name: pd.read_parquet(path) for name, path in artifact_paths.items()}
    for name, frame in tables.items():
        schema = load_document(schema_paths[name])
        if frame.columns.tolist() != schema["required"]:
            raise ValueError(f"{name} columns/order differ from the locked schema")

    reasons = tables["missingness_reason_long"]
    if not set(reasons["missing_reason"].astype(str)).issubset(MISSINGNESS_REASON_STATES):
        raise ValueError("missingness disclosure contains a reason outside the 8-state taxonomy")
    reason_group_columns = [
        "feature",
        "semantic_type",
        "source_columns_json",
        "grouping",
        "split",
        "split_year",
        "city",
        "outcome",
        "outcome_value",
    ]
    for _, group in reasons.groupby(reason_group_columns, dropna=False, observed=True):
        denominators = pd.to_numeric(group["denominator_n"], errors="raise").unique()
        if len(denominators) != 1 or int(pd.to_numeric(group["n"], errors="raise").sum()) != int(
            denominators[0]
        ):
            raise ValueError("missingness reason counts are not exhaustive within a stratum")

    scores = tables["score_coverage_long"]
    value_names = set(
        scores.loc[scores["entity_type"].eq("score_value"), "entity_name"].astype(str)
    )
    label_names = set(
        scores.loc[scores["entity_type"].eq("score_label"), "entity_name"].astype(str)
    )
    if value_names != set(PASSIVE_SCORE_VALUE_COLUMNS) or label_names != set(SCORE_LABEL_TO_VALUE):
        raise ValueError("score coverage artifacts do not exactly cover 19 values and 18 labels")
    alias = scores.loc[
        scores["entity_type"].eq("score_label")
        & scores["entity_name"].eq("rSI_GCS_alias")
    ]
    duplicate = scores.loc[
        scores["entity_type"].eq("score_value") & scores["entity_name"].eq("rSI_GCS")
    ]
    if (
        alias.empty
        or not alias["is_alias"].eq(True).all()
        or set(alias["score_value_column"].astype(str)) != {"rSIG"}
        or duplicate.empty
        or not duplicate["is_formula_duplicate"].eq(True).all()
        or set(duplicate["duplicate_of"].dropna().astype(str)) != {"rSIG"}
    ):
        raise ValueError("score coverage does not deduplicate the rSI_GCS/rSIG formula alias")

    flow = tables["complete_case_flow"]
    expected_flow_keys = {
        (split, outcome, step)
        for split in ("train_2020_2023", "validation_2024")
        for outcome in OUTCOMES
        for step in (
            "eligible_development_cohort",
            "core_vitals_complete",
            "full_model_complete_case",
        )
    }
    actual_flow_keys = set(
        flow[["split", "outcome", "step"]].astype(str).itertuples(index=False, name=None)
    )
    if actual_flow_keys != expected_flow_keys or flow.duplicated(
        ["split", "outcome", "step"]
    ).any():
        raise ValueError("complete-case flow does not exactly cover both splits, nine outcomes, and three steps")

    return {
        "reason_state_count": len(MISSINGNESS_REASON_STATES),
        "score_value_count": len(value_names),
        "score_label_count": len(label_names),
        "structural_rule_count": len(rules["rules"]),
        "artifact_hashes": expected_artifact_hashes,
        "manifest_sha256": sha256_file(manifest_path),
        "structural_rules_sha256": sha256_file(rules_path),
        "schema_hashes": expected_schema_hashes,
    }


def _source_seal_check(project_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    seal = config["source_seal"]
    path = _resolved(project_root, seal["path"])
    manifest_path = _resolved(project_root, seal["manifest"])
    manifest = load_document(manifest_path)
    actual_sha = sha256_file(path)
    if actual_sha.casefold() != seal["sha256"].casefold():
        raise ValueError(f"source seal SHA256 mismatch: expected={seal['sha256']} actual={actual_sha}")
    if manifest.get("development_sha256", "").casefold() != actual_sha.casefold():
        raise ValueError("source seal manifest development hash mismatch")
    parquet = pq.ParquetFile(path)
    shape = [parquet.metadata.num_rows, len(parquet.schema_arrow.names)]
    if shape != list(seal["shape"]):
        raise ValueError(f"source seal shape mismatch: expected={seal['shape']} actual={shape}")
    years = pd.to_datetime(pd.read_parquet(path, columns=[seal["date_column"]])[seal["date_column"]], errors="coerce").dt.year
    if years.isna().any():
        raise ValueError(f"source seal contains {int(years.isna().sum())} unparseable dates")
    if int(years.max()) > int(seal["maximum_year"]):
        raise ValueError(f"source seal contains forbidden year {int(years.max())}")
    if manifest.get("source_sha256", "").casefold() != config["raw_data"]["sha256"].casefold():
        raise ValueError("source seal manifest does not point to the locked raw data")
    required_flags = {
        "sealed_2025_artifact_created": False,
        "outcomes_summarized": False,
        "historical_2025_exposure": True,
        "contains_raw_pii": True,
        "upload_forbidden": True,
    }
    wrong_flags = {key: manifest.get(key) for key, expected in required_flags.items() if manifest.get(key) is not expected}
    if wrong_flags:
        raise ValueError(f"source seal governance flags mismatch: {wrong_flags}")
    excluded = int(config["raw_data"]["shape"][0]) - int(shape[0])
    if manifest.get("excluded_2025_rows") != excluded:
        raise ValueError("source seal excluded-row audit mismatch")
    return {
        "path": str(path),
        "sha256": actual_sha,
        "manifest_sha256": sha256_file(manifest_path),
        "shape": shape,
        "minimum_year": int(years.min()),
        "maximum_year": int(years.max()),
        "excluded_2025_rows": excluded,
        "upload_forbidden": True,
    }


def _expand_scan_files(project_root: Path, entries: list[str]) -> list[Path]:
    files: set[Path] = set()
    for entry in entries:
        if any(character in entry for character in "*?[]"):
            candidates = project_root.glob(entry)
        else:
            candidates = [_resolved(project_root, entry)]
        for candidate in candidates:
            if candidate.is_dir():
                files.update(path.resolve() for path in candidate.rglob("*") if path.is_file())
            elif candidate.is_file():
                files.add(candidate.resolve())
    return sorted(files)


def _scan_payload(payload: bytes) -> list[str]:
    return security_scan.secret_pattern_classes(payload)


def _scan_secret_stream(stream: Any) -> list[str]:
    findings: set[str] = set()
    tail = b""
    while True:
        chunk = stream.read(SECRET_SCAN_CHUNK_BYTES)
        if not chunk:
            break
        window = tail + chunk
        findings.update(_scan_payload(window))
        tail = window[-SECRET_SCAN_OVERLAP_BYTES:]
    return sorted(findings)


def _secret_scan(project_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    files = _expand_scan_files(project_root, config["secret_scan_paths"])
    contract = load_document(_resolved(project_root, config["secret_safety_contract"]))
    authorized_patterns = set(contract.get("authorized_token_pattern_classes", []))
    blocking_patterns = set(contract.get("blocking_secret_pattern_classes", []))
    if authorized_patterns & blocking_patterns or authorized_patterns | blocking_patterns != set(
        SECRET_PATTERNS
    ):
        raise ValueError("secret safety pattern classes do not partition the scanner patterns")
    if contract.get("secret_scan_mode") != "audit_authorized_tokens_block_unauthorized_secrets":
        raise ValueError("secret scan mode differs from the approved contract")
    findings: list[dict[str, str]] = []
    scanned = 0
    for path in files:
        suffix = path.suffix.casefold()
        if suffix in TEXT_EXTENSIONS:
            scanned += 1
            with path.open("rb") as stream:
                hits = _scan_secret_stream(stream)
            findings.extend({"path": str(path), "pattern": hit} for hit in hits)
        elif suffix == ".zip":
            scanned += 1
            with zipfile.ZipFile(path) as archive:
                for info in archive.infolist():
                    member_suffix = Path(info.filename).suffix.casefold()
                    if info.is_dir() or member_suffix not in TEXT_EXTENSIONS:
                        continue
                    with archive.open(info) as stream:
                        hits = _scan_secret_stream(stream)
                    findings.extend(
                        {"path": f"{path}!{info.filename}", "pattern": hit} for hit in hits
                    )
    blocking = [row for row in findings if row["pattern"] in blocking_patterns]
    audit_only = [row for row in findings if row["pattern"] in authorized_patterns]
    if blocking:
        raise ValueError(
            f"unauthorized secret findings={len(blocking)} locations={blocking[:10]}"
        )
    return {
        "candidate_files": len(files),
        "scanned_text_or_zip_files": scanned,
        "findings": len(findings),
        "authorized_token_findings": len(audit_only),
        "blocking_secret_findings": 0,
        "policy": "audit_only_nonblocking",
        "finding_locations": audit_only[:100],
    }


def _pii_column_hits(columns: list[str]) -> list[str]:
    return security_scan.pii_column_hits(columns)


def _pii_value_hits(frame: pd.DataFrame, path: Path) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for column in frame.select_dtypes(include=["object", "string"]).columns:
        values = frame[column].dropna().astype(str)
        counts: dict[str, int] = {}
        for value in values:
            for pattern_name in security_scan.pii_pattern_hits(
                value,
                field=column,
            ):
                counts[pattern_name] = counts.get(pattern_name, 0) + 1
        for pattern_name, count in sorted(counts.items()):
            if count:
                findings.append({"path": str(path), "column": str(column), "pattern": pattern_name, "count": count})
    return findings


def _exact_identifier_value_check(source_path: Path, text_path: Path) -> dict[str, Any]:
    source_columns = set(pq.ParquetFile(source_path).schema_arrow.names)
    identifier_columns = [
        column
        for column in security_scan.DIRECT_IDENTIFIER_SOURCE_COLUMNS
        if column in source_columns
    ]
    if "ENCOUNTER_NO" not in source_columns or not identifier_columns:
        return {"rows_checked": 0, "identifier_columns_checked": identifier_columns, "findings": 0}
    text = pd.read_parquet(text_path, columns=["row_hash", "emt_text_sanitized"])
    source = pd.read_parquet(source_path, columns=["ENCOUNTER_NO", *[c for c in identifier_columns if c != "ENCOUNTER_NO"]])
    encounter = source["ENCOUNTER_NO"].fillna("").astype(str).str.strip()
    source["row_hash"] = encounter.map(
        lambda value: hashlib.sha256(value.encode("utf-8")).hexdigest() if value else ""
    )
    source = source.loc[source["row_hash"].ne("")]
    joined = source.merge(text, how="inner", on="row_hash", validate="many_to_one")
    sanitized = joined["emt_text_sanitized"].fillna("").astype(str)
    finding_counts: dict[str, int] = {}
    for column in identifier_columns:
        identifiers = joined[column].fillna("").astype(str).str.strip()
        minimum_length = (
            6
            if column in security_scan.LONG_EXACT_IDENTIFIER_SOURCE_COLUMNS
            else 2
        )
        matches = [
            len(identifier) >= minimum_length and identifier in text_value
            for identifier, text_value in zip(identifiers, sanitized)
        ]
        count = int(sum(matches))
        if count:
            finding_counts[column] = count
    if finding_counts:
        raise ValueError(f"exact row-linked identifier values remain in sanitized text: {finding_counts}")
    return {
        "rows_checked": int(len(joined)),
        "identifier_columns_checked": identifier_columns,
        "findings": 0,
    }


def _development_bundle_check(project_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    bundles = config.get("development_bundles", [])
    if not bundles:
        raise ValueError("development_bundles must contain at least one sealed <=2024 artifact")
    lock_path = _resolved(project_root, config["artifact_hash_lock"])
    artifact_lock = load_document(lock_path)
    locked = artifact_lock.get("artifacts", {})
    summaries = []
    bundle_paths: dict[str, Path] = {}
    for bundle in bundles:
        name = bundle["name"]
        path = _resolved(project_root, bundle["path"])
        if "2025" in path.name.casefold():
            raise ValueError(f"development bundle name contains 2025: {path.name}")
        if name not in locked:
            raise ValueError(f"development bundle has no independent hash lock: {name}")
        actual_sha = sha256_file(path)
        lock_entry = locked[name]
        if lock_entry.get("path") != bundle["path"]:
            raise ValueError(f"artifact lock path mismatch for {name}")
        if actual_sha.casefold() != lock_entry.get("sha256", "").casefold():
            raise ValueError(f"artifact SHA256 mismatch for {name}")
        parquet = pq.ParquetFile(path)
        columns = parquet.schema_arrow.names
        column_hits = _pii_column_hits(columns)
        if column_hits:
            raise ValueError(f"PII columns in {name}: {column_hits}")
        if bundle["year_column"] not in columns:
            raise ValueError(f"{name} lacks year column {bundle['year_column']}")
        read_columns = [bundle["year_column"]]
        string_columns = [field.name for field in parquet.schema_arrow if str(field.type) in {"string", "large_string"}]
        read_columns.extend(column for column in string_columns if column not in read_columns)
        frame = pd.read_parquet(path, columns=read_columns)
        year_values = frame[bundle["year_column"]]
        if bundle.get("year_is_date", False):
            years = pd.to_datetime(year_values, errors="coerce").dt.year
        else:
            years = pd.to_numeric(year_values, errors="coerce")
        if years.isna().any():
            raise ValueError(f"{name} has {int(years.isna().sum())} unparseable development years")
        max_year = int(years.max())
        if max_year > int(config["maximum_development_year"]):
            raise ValueError(f"{name} contains forbidden year {max_year}")
        if len(frame) != int(bundle["expected_rows"]):
            raise ValueError(f"{name} row mismatch: expected={bundle['expected_rows']} actual={len(frame)}")
        value_hits = _pii_value_hits(frame, path)
        if value_hits:
            raise ValueError(f"PII values in {name}: {value_hits[:10]}")
        summaries.append(
            {
                "name": name,
                "path": str(path),
                "sha256": actual_sha,
                "rows": len(frame),
                "minimum_year": int(years.min()),
                "maximum_year": max_year,
                "pii_findings": 0,
            }
        )
        bundle_paths[name] = path
    text_path = bundle_paths.get("stage1a_text_le2024")
    if text_path is None:
        raise ValueError("stage1a_text_le2024 is required for exact identifier leakage validation")
    exact_identifier_check = _exact_identifier_value_check(
        _resolved(project_root, config["source_seal"]["path"]),
        text_path,
    )
    return {
        "artifact_hash_lock_sha256": sha256_file(lock_path),
        "bundles": summaries,
        "exact_identifier_check": exact_identifier_check,
    }


def _task_registry_check(project_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    registry_path = _resolved(project_root, config["task_registry"])
    registry = load_document(registry_path)
    if registry != build_task_registry():
        raise ValueError("task registry is stale or differs from the generated research contract")
    tasks = registry.get("tasks", [])
    if not tasks:
        raise ValueError("task registry is empty")
    task_ids = [task.get("task_id") for task in tasks]
    duplicate_ids = sorted({task_id for task_id in task_ids if task_ids.count(task_id) > 1})
    if duplicate_ids:
        raise ValueError(f"duplicate task IDs: {duplicate_ids[:20]}")
    valid_statuses = {"pending", "ready", "completed", "blocked"}
    required_fields = {
        "task_id",
        "stage",
        "wave",
        "task_family",
        "status",
        "estimated_gpu_hours",
        "required_artifacts",
    }
    for task in tasks:
        missing = required_fields - set(task)
        if missing:
            raise ValueError(f"task {task.get('task_id')} missing fields: {sorted(missing)}")
        if task["status"] not in valid_statuses:
            raise ValueError(f"task {task['task_id']} has invalid status {task['status']}")
        if not isinstance(task["required_artifacts"], list) or not task["required_artifacts"]:
            raise ValueError(f"task {task['task_id']} has no required artifacts")
        if task.get("stage") == "P1_02":
            if task.get("wave") not in {"W01A", "W01B"}:
                raise ValueError(f"P1_02 task {task['task_id']} has invalid subwave")
            estimate = task.get("runtime_p80_hours")
            if not isinstance(estimate, (int, float)) or not 0 < float(estimate) <= 9.25:
                raise ValueError(f"P1_02 task {task['task_id']} lacks a valid P80 runtime")
            command = task.get("command")
            if not isinstance(command, list) or not command or "${P1_PACKAGE_ROOT}" not in " ".join(map(str, command)):
                raise ValueError(f"P1_02 task {task['task_id']} lacks a portable executable command")
            artifact_paths = {str(row.get("path", "")) for row in task["required_artifacts"]}
            if any(path.endswith("task_bundle.zip") for path in artifact_paths):
                raise ValueError(f"P1_02 task {task['task_id']} still uses placeholder task_bundle.zip")
            if not {"hashes.json", "task_manifest.json", "_SUCCESS.json"}.issubset(artifact_paths):
                raise ValueError(f"P1_02 task {task['task_id']} lacks canonical hash/manifest/success artifacts")

    wave_placement: dict[str, dict[str, list[str]]] = {}
    for wave in ("W02", "W03", "W04"):
        wave_tasks = [task for task in tasks if task.get("wave") == wave]
        if any("privacy_class" not in task for task in wave_tasks):
            raise ValueError(f"{wave} task privacy class is not explicit")
        wave_placement[wave] = validate_wave_task_placement(wave, wave_tasks)
    thinking_tasks = [
        task
        for task in tasks
        if task.get("wave") == "W04" and task.get("model") == "tabpfn_thinking"
    ]
    thinking_plan = validate_w04_thinking_fit_plan(
        [
            {
            "outcome": task["outcome"],
            "account_alias": task["metadata"].get("thinking_api_account_alias"),
            "fits": task["metadata"].get("thinking_fits"),
            }
            for task in thinking_tasks
        ],
        bound_fits_by_outcome={
            str(task["outcome"]): task["metadata"].get("thinking_fits")
            for task in thinking_tasks
        },
        enforce_account_capacity=False,
    )

    coverage = load_document(_resolved(project_root, config["coverage_targets"]))
    promotion = coverage.get("promotion_invariants", {})
    if (
        promotion.get("w01b_formal_batch_id") != "full"
        or promotion.get("w01b_formal_session_ids")
        != ["A01-S1", "A01-S2", "A02-S1"]
        or promotion.get("w01b_formal_distinct_owners") != 2
        or promotion.get("credential_sharing_allowed") is not True
        or promotion.get("coordinator_operated_multi_account_auth") is not True
        or promotion.get("owner_person_challenge_required") is not False
        or promotion.get("plaintext_tokens_allowed_in_all_research_execution_files")
        is not True
        or promotion.get("w02_w04_dynamic_owner_selection_required") is not True
        or promotion.get("maximum_sessions_per_owner") != 2
        or promotion.get("required_distinct_owner_formula")
        != "ceil(session_count/2)"
        or promotion.get("baseline_expected_development_rows") != 38214
        or promotion.get("baseline_within_development_purge_rows") != 3179
        or promotion.get("baseline_after_within_development_purge_rows") != 35035
        or promotion.get("sealed_2025_group_excluded_eligible_rows") != 2747
        or promotion.get("accepted_current_pre_purge_rows") != 34249
        or promotion.get("accepted_current_temporal_purge_rows") != 1961
        or promotion.get("accepted_patient_disjoint_modeling_rows") != 32288
    ):
        raise ValueError("Kaggle multi-owner or cohort-reconciliation coverage targets differ")
    assertion_results = []
    for assertion in coverage["registry_assertions"]:
        matching = [
            task
            for task in tasks
            if all(task.get(field) == value for field, value in assertion["filter"].items())
        ]
        if len(matching) != assertion["expected"]:
            raise ValueError(
                f"registry coverage {assertion['name']} expected={assertion['expected']} actual={len(matching)}"
            )
        assertion_results.append({"name": assertion["name"], "count": len(matching)})
    for assertion in coverage.get("metadata_sum_assertions", []):
        matching = [
            task
            for task in tasks
            if all(task.get(field) == value for field, value in assertion["filter"].items())
        ]
        actual = sum(int(task.get("metadata", {}).get(assertion["metadata_field"], 0)) for task in matching)
        if actual != assertion["expected"]:
            raise ValueError(
                f"registry metadata sum {assertion['name']} expected={assertion['expected']} actual={actual}"
            )
        assertion_results.append({"name": assertion["name"], "count": actual})
    return {
        "task_count": len(tasks),
        "unique_task_ids": len(set(task_ids)),
        "coverage_assertions": assertion_results,
        "task_registry_sha256": sha256_file(registry_path),
        "coverage_targets_sha256": sha256_file(_resolved(project_root, config["coverage_targets"])),
        "wave_contract_sha256": WAVE_CONTRACT_SHA256,
        "wave_kaggle_task_counts": {
            wave: len(placement["kaggle_task_ids"])
            for wave, placement in wave_placement.items()
        },
        "w04_local_task_count": len(wave_placement["W04"]["local_task_ids"]),
        "w04_thinking_fit_total": thinking_plan["total_fits"],
    }


def _canonical_reference_check(project_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    reference_config = config["canonical_references"]
    labels_path = _resolved(project_root, reference_config["labels"])
    prediction_path = _resolved(project_root, reference_config["prediction_reference"])
    missingness_path = _resolved(project_root, reference_config["missingness_reference"])
    missingness_coverage_path = _resolved(
        project_root, reference_config["missingness_coverage"]
    )
    manifest_path = _resolved(project_root, reference_config["manifest"])
    hash_inventory_path = _resolved(project_root, reference_config["hash_inventory"])
    for path in (
        labels_path,
        prediction_path,
        missingness_path,
        missingness_coverage_path,
        manifest_path,
        hash_inventory_path,
    ):
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(path)
    manifest = load_document(manifest_path)
    expected_rows = int(
        config["cohort"]["patient_disjoint_temporal_split"]["post_purge_total_rows"]
    )
    expected_outcomes = set(config["fold_map"]["outcomes"])
    if manifest.get("maximum_year") != 2024 or manifest.get("2025_access_count") != 0:
        raise ValueError("canonical reference manifest does not enforce the <=2024 boundary")
    if manifest.get("row_count") != expected_rows or manifest.get("label_rows") != expected_rows * len(expected_outcomes):
        raise ValueError("canonical reference manifest row counts differ from the locked cohort")
    expected_inputs = {
        name: sha256_file(_resolved(project_root, relative))
        for name, relative in reference_config["input_paths"].items()
    }
    if manifest.get("input_hashes") != expected_inputs:
        raise ValueError("canonical reference manifest is stale against inputs or task registry")
    expected_artifacts = {
        labels_path.name: sha256_file(labels_path),
        prediction_path.name: sha256_file(prediction_path),
        missingness_path.name: sha256_file(missingness_path),
        missingness_coverage_path.name: sha256_file(missingness_coverage_path),
    }
    if manifest.get("artifacts") != expected_artifacts:
        raise ValueError("canonical reference artifact hashes differ from manifest")
    labels = pd.read_parquet(labels_path)
    if labels.columns.tolist() != ["row_hash", "outcome", "y_true"]:
        raise ValueError("canonical labels do not have the exact long schema")
    if len(labels) != expected_rows * len(expected_outcomes) or labels.duplicated(["row_hash", "outcome"]).any():
        raise ValueError("canonical label key coverage is incomplete or duplicated")
    if set(labels["outcome"].astype(str)) != expected_outcomes:
        raise ValueError("canonical labels do not cover the nine outcomes")
    y_true = pd.to_numeric(labels["y_true"], errors="coerce")
    if y_true.isna().any() or not y_true.isin([0, 1]).all():
        raise ValueError("canonical labels are not complete binary 0/1")
    if _pii_column_hits(labels.columns.astype(str).tolist()):
        raise ValueError("canonical labels contain direct PII columns")
    feature_path = _resolved(
        project_root, reference_config["input_paths"]["stage1a_features"]
    )
    features = pd.read_parquet(feature_path)
    feature_row_hashes = features["row_hash"].astype(str)
    if (
        features["row_hash"].isna().any()
        or feature_row_hashes.duplicated().any()
        or not feature_row_hashes.str.fullmatch(r"[a-fA-F0-9]{64}").all()
    ):
        raise ValueError("locked Stage1a row_hash values are not unique 64-hex keys")
    if not labels["row_hash"].astype(str).str.fullmatch(r"[a-fA-F0-9]{64}").all():
        raise ValueError("canonical labels contain invalid row_hash values")
    feature_key_set = set(feature_row_hashes)
    for outcome, group in labels.groupby("outcome", observed=True):
        if set(group["row_hash"].astype(str)) != feature_key_set:
            raise ValueError(f"canonical labels do not exactly cover Stage1a rows for {outcome}")
    reference = load_document(prediction_path)
    if reference.get("maximum_year") != 2024 or reference.get("2025_access_count") != 0:
        raise ValueError("canonical prediction reference does not enforce the <=2024 boundary")
    registry = load_document(_resolved(project_root, config["task_registry"]))
    expected_ids = {
        task["task_id"]
        for task in registry["tasks"]
        if task.get("stage") == "P1_02" and task.get("wave") == "W01A"
    }
    references = reference.get("tasks", {})
    if reference.get("input_hashes") != manifest.get("input_hashes"):
        raise ValueError("canonical prediction reference input hashes differ from manifest")
    missingness_reference = load_document(missingness_path)
    missingness_coverage = pd.read_parquet(missingness_coverage_path)
    hash_inventory = load_document(hash_inventory_path)
    missingness_schema = load_document(
        _resolved(
            project_root,
            config["schemas"]["canonical_missingness_reference"],
        )
    )
    coverage_schema = load_document(
        _resolved(
            project_root,
            config["schemas"]["canonical_missingness_coverage"],
        )
    )
    inventory_schema = load_document(
        _resolved(
            project_root,
            config["schemas"]["canonical_reference_hashes"],
        )
    )
    if not set(missingness_schema["required"]).issubset(missingness_reference):
        raise ValueError("canonical missingness reference lacks schema-required fields")
    if missingness_coverage.columns.tolist() != coverage_schema["required"]:
        raise ValueError("canonical missingness coverage columns differ from schema")
    if not set(inventory_schema["required"]).issubset(hash_inventory):
        raise ValueError("canonical reference hash inventory lacks schema-required fields")
    if missingness_reference.get("input_hashes") != expected_inputs:
        raise ValueError("canonical missingness reference input hashes differ")
    coverage_artifact = missingness_reference.get("coverage_artifact", {})
    if (
        coverage_artifact.get("path") != missingness_coverage_path.name
        or int(coverage_artifact.get("rows", -1)) != len(missingness_coverage)
        or coverage_artifact.get("sha256") != expected_artifacts[missingness_coverage_path.name]
    ):
        raise ValueError("canonical missingness coverage hash or row count differs")
    inventory_artifacts = {
        **expected_artifacts,
        manifest_path.name: sha256_file(manifest_path),
    }
    if hash_inventory.get("artifacts") != inventory_artifacts:
        raise ValueError("canonical reference hash inventory differs from local artifacts")
    if manifest.get("hash_inventory") != hash_inventory_path.name:
        raise ValueError("canonical reference manifest hash inventory path differs")
    if reference.get("w01b", {}).get("reference_sha256") != expected_artifacts[
        missingness_path.name
    ] or reference.get("w01b", {}).get("coverage_sha256") != expected_artifacts[
        missingness_coverage_path.name
    ]:
        raise ValueError("canonical prediction reference W01B hashes differ")
    prerequisite_status = missingness_reference.get("prerequisite_status")
    if prerequisite_status not in {"PASS", "BLOCKED_MISSING_LOCKED_SPEC"}:
        raise ValueError("canonical missingness prerequisite status is invalid")
    if (
        manifest.get("w01b_prerequisite_status") != prerequisite_status
        or reference.get("w01b", {}).get("prerequisite_status") != prerequisite_status
    ):
        raise ValueError("canonical W01B prerequisite status differs across references")
    w01b_registry = {
        str(task["task_id"]): task
        for task in registry["tasks"]
        if task.get("stage") == "P1_02" and task.get("wave") == "W01B"
    }
    missingness_tasks = missingness_reference.get("tasks", {})
    if set(missingness_tasks) != set(w01b_registry) or len(w01b_registry) != 9:
        raise ValueError("canonical missingness reference does not cover exact W01B tasks")
    coverage_keys = ["task_id", "pair_id", "split", "scope", "fold"]
    if missingness_coverage.duplicated(coverage_keys).any():
        raise ValueError("canonical missingness coverage contains duplicate keys")
    for task_id, task in w01b_registry.items():
        task_reference = missingness_tasks[task_id]
        expected_pair_count = int(task.get("metadata", {}).get("model_strategy_pair_count", 0))
        pair_ids = list(task_reference.get("pair_ids", []))
        pair_rows = task_reference.get("pairs", {})
        if (
            task_reference.get("outcome") != task.get("outcome")
            or int(task_reference.get("expected_pair_count", -1)) != expected_pair_count
            or len(pair_ids) != expected_pair_count
            or pair_ids != list(pair_rows)
            or task_reference.get("pair_set_sha256")
            != canonical_sha256(sorted(pair_ids))
        ):
            raise ValueError(f"canonical W01B pair contract differs for {task_id}")
        task_coverage = missingness_coverage.loc[
            missingness_coverage["task_id"].astype(str).eq(task_id)
        ]
        if set(task_coverage["pair_id"].astype(str)) != set(pair_ids):
            raise ValueError(f"canonical W01B coverage pair set differs for {task_id}")
        for pair_id in pair_ids:
            pair = pair_rows[pair_id]
            rows = task_coverage.loc[
                task_coverage["pair_id"].astype(str).eq(pair_id)
            ]
            split_rows = rows.loc[rows["scope"].astype(str).eq("split")]
            fold_rows = rows.loc[rows["scope"].astype(str).eq("fold")]
            if (
                len(rows) != 7
                or set(split_rows["split"].astype(str))
                != {"oof_2020_2023", "validation_2024"}
                or set(pd.to_numeric(fold_rows["fold"]).astype(int))
                != {0, 1, 2, 3, 4}
            ):
                raise ValueError(f"canonical W01B split/fold coverage differs for {task_id}/{pair_id}")
            if not rows["strategy"].astype(str).eq(str(pair["strategy"])).all() or not rows[
                "model"
            ].astype(str).eq(str(pair["model"])).all():
                raise ValueError(f"canonical W01B pair identity differs for {task_id}/{pair_id}")
            for split, split_reference in pair["eligible_splits"].items():
                row = split_rows.loc[split_rows["split"].astype(str).eq(split)].iloc[0]
                if any(
                    row[column] != split_reference[column]
                    for column in (
                        "eligible_rows",
                        "events",
                        "class_count",
                        "eligible_key_sha256",
                        "evaluation_status",
                    )
                ) or row["training_status"] != pair["training_status"]:
                    raise ValueError(
                        f"canonical W01B split estimability differs for {task_id}/{pair_id}/{split}"
                    )
            for fold in range(5):
                row = fold_rows.loc[pd.to_numeric(fold_rows["fold"]).eq(fold)].iloc[0]
                fold_reference = pair["folds"][str(fold)]
                comparisons = {
                    "eligible_rows": "eligible_rows",
                    "events": "events",
                    "class_count": "class_count",
                    "eligible_key_sha256": "eligible_key_sha256",
                    "fit_rows": "fit_rows",
                    "fit_events": "fit_events",
                    "fit_class_count": "fit_class_count",
                    "fit_key_sha256": "fit_key_sha256",
                    "training_status": "fit_status",
                    "evaluation_status": "evaluation_status",
                }
                if any(row[left] != fold_reference[right] for left, right in comparisons.items()):
                    raise ValueError(
                        f"canonical W01B fold estimability differs for {task_id}/{pair_id}/{fold}"
                    )
        locked_spec = task_reference.get("locked_gbdt_spec", {})
        if prerequisite_status == "PASS":
            if (
                locked_spec.get("status") != "PASS"
                or not re.fullmatch(
                    r"[a-f0-9]{64}",
                    str(locked_spec.get("locked_gbdt_spec_sha256", "")),
                )
            ):
                raise ValueError(f"canonical W01B locked spec provenance differs for {task_id}")
        elif locked_spec.get("status") not in {"PASS", "BLOCKED_MISSING_LOCKED_SPEC"}:
            raise ValueError(f"canonical W01B blocked provenance differs for {task_id}")
    if set(references) != expected_ids or reference.get("task_count") != len(expected_ids):
        raise ValueError("canonical prediction reference does not exactly cover W01A tasks")
    for task_id, value in references.items():
        digest = str(value.get("expected_prediction_key_sha256", ""))
        if not re.fullmatch(r"[a-f0-9]{64}", digest):
            raise ValueError(f"canonical prediction key hash is invalid for {task_id}")
        rows = int(value.get("expected_prediction_rows", -1))
        splits = value.get("expected_splits", {})
        if rows < 0 or sum(int(count) for count in splits.values()) != rows:
            raise ValueError(f"canonical prediction split counts differ for {task_id}")
    split_map = {
        "train_2020_2023": "oof_2020_2023",
        "validation_2024": "validation_2024",
    }
    if "split" not in features or features["split"].astype(str).map(split_map).isna().any():
        raise ValueError("locked Stage1a split values cannot build canonical prediction keys")
    task_by_id = {task["task_id"]: task for task in registry["tasks"]}
    for task_id in sorted(expected_ids):
        task = task_by_id[task_id]
        value = references[task_id]
        family = task["task_family"]
        if family == "descriptives":
            keys = pd.DataFrame(
                columns=["task_id", "row_hash", "outcome", "model", "split"]
            )
        else:
            outcome = str(task["outcome"])
            requested_model = str(task["model"])
            eligible = pd.Series(True, index=features.index)
            output_model = requested_model
            if family == "clinical_score":
                source = "rSIG" if requested_model == "rSI_GCS_alias" else requested_model
                if source not in features:
                    raise ValueError(f"locked Stage1a score source is absent: {source}")
                eligible = pd.to_numeric(features[source], errors="coerce").notna()
                available = f"{source}_available"
                if available in features:
                    eligible &= pd.to_numeric(features[available], errors="coerce").eq(1)
                output_model = f"score_{requested_model}"
            keys = pd.DataFrame(
                {
                    "task_id": task_id,
                    "row_hash": features.loc[eligible, "row_hash"].astype(str),
                    "outcome": outcome,
                    "model": output_model,
                    "split": features.loc[eligible, "split"].astype(str).map(split_map),
                }
            )
        key_columns = ["task_id", "row_hash", "outcome", "model", "split"]
        ordered = keys[key_columns].astype(str).sort_values(key_columns, kind="mergesort")
        actual_hash = canonical_sha256(ordered.values.tolist())
        actual_splits = keys.groupby("split", observed=True).size().astype(int).to_dict()
        if (
            len(keys) != int(value["expected_prediction_rows"])
            or actual_splits != value["expected_splits"]
            or actual_hash != value["expected_prediction_key_sha256"]
        ):
            raise ValueError(f"canonical prediction reference differs from independent recompute: {task_id}")
    return {
        "labels_sha256": expected_artifacts[labels_path.name],
        "prediction_reference_sha256": expected_artifacts[prediction_path.name],
        "missingness_reference_sha256": expected_artifacts[missingness_path.name],
        "missingness_coverage_sha256": expected_artifacts[
            missingness_coverage_path.name
        ],
        "manifest_sha256": sha256_file(manifest_path),
        "hash_inventory_sha256": sha256_file(hash_inventory_path),
        "fold_map_sha256": expected_inputs["fold_map"],
        "fold_manifest_sha256": expected_inputs["fold_manifest"],
        "w01b_prerequisite_status": prerequisite_status,
        "w01b_authorized": prerequisite_status == "PASS",
        "label_rows": len(labels),
        "w01a_task_count": len(expected_ids),
        "w01b_task_count": len(w01b_registry),
        "w01b_pair_count": int(missingness_reference["pair_count"]),
    }


def _fold_map_check(project_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    fold_config = config["fold_map"]
    path = _resolved(project_root, fold_config["path"])
    manifest_path = _resolved(project_root, fold_config["manifest"])
    features_path = _resolved(project_root, fold_config["features_path"])
    manifest = load_document(manifest_path)
    if manifest.get("features_sha256") != sha256_file(features_path):
        raise ValueError("fold manifest was not built from the locked Stage1a feature artifact")
    if manifest.get("fold_map_sha256") != sha256_file(path):
        raise ValueError("fold map hash does not match its manifest")
    if manifest.get("n_splits") != fold_config["n_splits"] or manifest.get("seed") != fold_config["seed"]:
        raise ValueError("fold algorithm parameters differ from the locked contract")
    frame = pd.read_parquet(path)
    required = {"row_hash", "group_hash", "outcome", "fold", "split_year"}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"fold map missing columns: {missing}")
    expected_outcomes = set(fold_config["outcomes"])
    if set(frame["outcome"].unique()) != expected_outcomes:
        raise ValueError("fold map outcome coverage mismatch")
    expected_rows = int(fold_config["expected_training_rows"])
    counts = frame.groupby("outcome").size().to_dict()
    if any(counts.get(outcome) != expected_rows for outcome in expected_outcomes):
        raise ValueError(f"fold map row coverage mismatch: {counts}")
    if frame.duplicated(["row_hash", "outcome"]).any():
        raise ValueError("fold map contains duplicate row/outcome assignments")
    expected_folds = set(range(int(fold_config["n_splits"])))
    for outcome, group in frame.groupby("outcome"):
        if set(pd.to_numeric(group["fold"], errors="raise").astype(int).unique()) != expected_folds:
            raise ValueError(f"{outcome} does not contain every required fold")
        if group.groupby("group_hash")["fold"].nunique().max() != 1:
            raise ValueError(f"{outcome} has patient groups spanning folds")
    years = pd.to_numeric(frame["split_year"], errors="coerce")
    if years.isna().any() or int(years.max()) > 2023 or int(years.min()) < 2020:
        raise ValueError("fold map must contain training years 2020-2023 only")
    source_columns = ["row_hash", "group_hash", "split_year", *(f"y_{outcome}" for outcome in expected_outcomes)]
    source = pd.read_parquet(features_path, columns=source_columns)
    source_year = pd.to_numeric(source["split_year"], errors="coerce")
    source = source.loc[source_year.between(2020, 2023)].copy()
    source["row_hash"] = source["row_hash"].astype(str)
    source_group = source["group_hash"].astype("string")
    source["effective_group_hash"] = source_group.mask(
        source_group.isna() | source_group.str.strip().eq(""), source["row_hash"]
    ).astype(str)
    expected_keys = set(source["row_hash"])
    for outcome, group in frame.groupby("outcome"):
        if set(group["row_hash"].astype(str)) != expected_keys:
            raise ValueError(f"{outcome} fold keys do not match Stage1a training keys")
        joined = group.merge(
            source[["row_hash", "effective_group_hash", f"y_{outcome}"]],
            on="row_hash",
            validate="one_to_one",
        )
        if not joined["group_hash"].astype(str).eq(joined["effective_group_hash"]).all():
            raise ValueError(f"{outcome} fold group hashes do not match Stage1a")
        for fold, fold_rows in joined.groupby("fold"):
            events = int(pd.to_numeric(fold_rows[f"y_{outcome}"], errors="raise").sum())
            if events == 0 or events == len(fold_rows):
                raise ValueError(f"{outcome} fold {fold} lacks one outcome class")
    return {
        "path": str(path),
        "sha256": sha256_file(path),
        "manifest_sha256": sha256_file(manifest_path),
        "rows": int(len(frame)),
        "outcomes": len(expected_outcomes),
        "n_splits": len(expected_folds),
        "patient_groups_spanning_folds": 0,
    }


def _p1_06_companion_explorer_contract_check(
    project_root: Path, config: dict[str, Any], contract_path: Path
) -> dict[str, str]:
    contract = load_document(contract_path)
    if contract.get("schema_version") != "p1-v2-companion-explorer-governance/1":
        raise ValueError("P1_06 companion explorer contract version mismatch")
    if contract.get("status") != "LOCKED_PENDING_P1_06" or contract.get("hard_gate") is not True:
        raise ValueError("P1_06 companion explorer contract is not a locked hard gate")
    if contract.get("activation") != {
        "stage": "P1_06",
        "prerequisite": "all_upstream_frozen_artifacts_accepted",
        "final_artifact_manifest_status": "PASS",
    }:
        raise ValueError("P1_06 companion explorer activation is not post-frozen acceptance")

    golden = contract.get("golden_reference", {})
    if golden.get("immutable") is not True or golden.get("redesign_forbidden") is not True:
        raise ValueError("P1_06 golden explorer must remain immutable and redesign-forbidden")
    expected_golden_paths = {
        "builder": "scripts/build_interactive_model_explorer_v3.py",
        "html": "outputs/report/EMT_P1_interactive_model_explorer.html",
    }
    golden_hashes: dict[str, str] = {}
    for name, expected_relative in expected_golden_paths.items():
        record = golden.get(name, {})
        if record.get("path") != expected_relative:
            raise ValueError(f"P1_06 golden {name} path mismatch")
        path = _resolved(project_root, expected_relative)
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(path)
        digest = sha256_file(path)
        if record.get("sha256") != digest:
            raise ValueError(f"P1_06 golden {name} SHA256 mismatch")
        if record.get("size") != path.stat().st_size:
            raise ValueError(f"P1_06 golden {name} size mismatch")
        golden_hashes[f"p1_06_golden_{name}"] = digest
    expected_dependencies = {"scripts/build_interactive_model_explorer_v2.py"}
    dependencies = golden.get("dependencies", [])
    if {record.get("path") for record in dependencies} != expected_dependencies:
        raise ValueError("P1_06 golden builder dependency set mismatch")
    dependency_hashes: dict[str, str] = {}
    for record in dependencies:
        path = _resolved(project_root, record["path"])
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(path)
        digest = sha256_file(path)
        if record.get("sha256") != digest or record.get("size") != path.stat().st_size:
            raise ValueError("P1_06 golden builder dependency hash or size mismatch")
        dependency_hashes[record["path"]] = digest
        golden_hashes["p1_06_golden_dependency_v2"] = digest
    builder_record = golden["builder"]
    if builder_record.get("callable") != "build_html":
        raise ValueError("P1_06 golden builder callable must be build_html")
    builder_tree = ast.parse(
        _resolved(project_root, builder_record["path"]).read_text(encoding="utf-8")
    )
    build_functions = [
        node for node in builder_tree.body if isinstance(node, ast.FunctionDef) and node.name == "build_html"
    ]
    if len(build_functions) != 1:
        raise ValueError("P1_06 golden builder must define exactly one top-level build_html")
    arguments = build_functions[0].args
    if (
        [argument.arg for argument in arguments.args] != ["bundle"]
        or arguments.posonlyargs
        or arguments.kwonlyargs
        or arguments.vararg is not None
        or arguments.kwarg is not None
    ):
        raise ValueError("P1_06 golden build_html signature must remain build_html(bundle)")

    adapter = contract.get("adapter", {})
    required_adapter = {
        "required_path": "scripts/build_p1_v2_interactive_model_explorer_adapter.py",
        "import_mode": "ast_isolated_function_extraction_without_module_execution",
        "builder_callable": "build_html",
        "builder_invocation": "build_html(bundle)",
        "execute_builder_main": False,
        "template_mutation_forbidden": True,
        "input_generation": "v2",
        "accepted_artifacts_only": True,
        "legacy_metrics_forbidden": True,
        "output_path": "outputs/report/EMT_P1_v2_companion_model_explorer.html",
        "manifest_path": "outputs/report/EMT_P1_v2_companion_model_explorer.manifest.json",
        "manifest_schema": "qa_v2/schemas/p1_06_companion_explorer_manifest.schema.json",
        "runtime_manifest_gate": "qa_v2.p1_06_explorer.validate_companion_explorer_manifest_file",
        "runtime_manifest_gate_arguments": [
            "manifest_path",
            "schema_path",
            "project_root",
            "task_registry_path",
            "contract_path",
            "expected_acceptance_anchor_sha256",
        ],
        "validator_path": "scripts/validate_p1_v2_companion_explorer.py",
        "validator_test_path": "tests/test_p1_v2_companion_explorer.py",
        "golden_and_companion_coexist": True,
        "historical_2025_exposure": True,
        "strict_no_arrival_leakage": True,
        "required_hash_inventories": ["data_hashes", "model_hashes", "artifact_hashes"],
        "source_policy": {
            "explicit_pass_acceptance_manifest_only": True,
            "required_path_prefix": "outputs/v2/",
            "forbidden_path_prefixes": ["outputs/report/", "outputs/final/", "outputs/stage"],
            "reject_symlinks_reparse_points_and_outside_root": True,
            "missing_source_fallback_forbidden": True,
            "legacy_subgroups_without_accepted_v2_artifact_forbidden": True,
            "upstream_inventory_must_exactly_match_p1_06_acceptance": True,
            "generated_adapter_inventory_exact_filenames": [
                "bundle.json",
                "metric_source_displayed.parquet",
                "metric_independent_recompute.parquet",
                "bundle_numeric_records.parquet",
                "curve_source.parquet",
                "curve_independent_recompute.parquet",
            ],
            "self_declared_extra_receipts_forbidden": True,
            "metric_and_curve_paths_locked_to_adapter_outputs": True,
        },
        "trust_anchor": {
            "two_phase_required": True,
            "pre_run_authorization_path": (
                "outputs/v2/p1_06/authorization/"
                "p1_06_frozen_evaluation_authorization.json"
            ),
            "post_run_acceptance_anchor_path": (
                "outputs/v2/p1_06/acceptance/p1_06_acceptance_anchor.json"
            ),
            "canonical_accepted_manifest_path": (
                "outputs/v2/accepted/p1_06/final_artifact_manifest.json"
            ),
            "accepted_manifest_schema": (
                "qa_v2/schemas/p1_06_accepted_artifacts.schema.json"
            ),
            "pre_run_authorization_schema": (
                "qa_v2/schemas/p1_06_frozen_evaluation_authorization.schema.json"
            ),
            "post_run_acceptance_anchor_schema": (
                "qa_v2/schemas/p1_06_acceptance_anchor.schema.json"
            ),
            "pre_run_authorizer": (
                "scripts/create_p1_v2_p1_06_frozen_evaluation_authorization.py"
            ),
            "acceptance_finalizer": "scripts/finalize_p1_v2_p1_06_acceptance.py",
            "external_anchor_sha256_argument_required": True,
            "candidate_pending_or_final_must_not_supply_expected_sha256": True,
            "exclusive_create_no_overwrite": True,
            "workspace_external_retention_required": True,
            "authorization_contract_version": (
                "p1-v2-p1-06-frozen-evaluation-authorization/2"
            ),
            "evaluation_run_id_bound_to_authorization_receipts_and_manifest": True,
            "exact_108_task_model_spec_crosswalk_required": True,
            "required_core_binding_names": ['validation_2024_data', 'sealed_2025_data', 'feature_schema', 'fold_map', 'evaluation_code', 'package_lock', 'parent_launch_authorization', 'w01b_final_union', 'p1_03_acceptance', 'p1_04_acceptance', 'p1_05a_acceptance', 'p1_05b_acceptance', 'pre_unseal_independent_review', 'hardware_profile', 'environment_lock', 'prompt_code_data_hash_lock'],
            "authorized_outcome_labels_must_match_predictions": True,
            "missing_extra_or_duplicate_binding_forbidden": True,
            "finalizer_scientific_source_gate_required": True,
            "scientific_coverage_receipt_in_anchor_required": True,
        },
        "publication_policy": {
            "formal_html_assets_and_pending_seal_no_clobber": True,
            "partial_asset_publication_must_be_safely_cleaned": True,
            "changed_or_raced_targets_must_never_be_deleted": True,
        },
        "bundle_contract": {
            "outcomes": ["P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6"],
            "splits": ["validation_2024", "test_2025"],
            "fallback_groups": ["overall"],
            "validation_and_test_require_same_model_and_sealed_spec_hash": True,
        },
    }
    if adapter != required_adapter:
        raise ValueError("P1_06 companion adapter contract mismatch")
    if adapter["output_path"] == golden["html"]["path"]:
        raise ValueError("P1_06 companion output would overwrite the golden HTML")
    configured_schema = config.get("schemas", {}).get("p1_06_companion_explorer_manifest")
    if configured_schema != adapter["manifest_schema"]:
        raise ValueError("P1_06 companion manifest schema is not configured")

    browser_runtime = contract.get("browser_qa_runtime")
    required_browser_runtime = {
        "runner_path": "scripts/run_p1_v2_companion_browser_qa.py",
        "runner_test_path": "tests/test_p1_v2_companion_browser_qa.py",
        "receipt_schema": "qa_v2/schemas/p1_06_browser_qa_receipt.schema.json",
        "python_playwright_version": "1.61.0",
        "system_browser_required": True,
        "localhost_http_required": True,
        "file_url_forbidden": True,
        "synthetic_pass_forbidden": True,
        "immutable_no_clobber_evidence": True,
    }
    if browser_runtime != required_browser_runtime:
        raise ValueError("P1_06 real-browser runtime contract mismatch")
    if config.get("schemas", {}).get("p1_06_browser_qa_receipt") != browser_runtime[
        "receipt_schema"
    ]:
        raise ValueError("P1_06 browser receipt schema is not configured")
    browser_runtime_hashes: dict[str, str] = {}
    for label, relative in {
        "runner": browser_runtime["runner_path"],
        "runner_test": browser_runtime["runner_test_path"],
        "receipt_schema": browser_runtime["receipt_schema"],
    }.items():
        path = _resolved(project_root, relative)
        if not path.is_file() or path.is_symlink():
            raise FileNotFoundError(path)
        browser_runtime_hashes[f"p1_06_browser_{label}"] = sha256_file(path)
    try:
        installed_playwright = version("playwright")
    except PackageNotFoundError as exc:
        raise ValueError("P1_06 browser QA requires Python Playwright") from exc
    if installed_playwright != browser_runtime["python_playwright_version"]:
        raise ValueError("P1_06 browser QA Playwright version differs from the lock")

    acceptance = contract.get("acceptance", {})
    coverage = load_document(_resolved(project_root, config["coverage_targets"]))
    coverage_gate = coverage.get("promotion_invariants", {}).get(
        "P1_06_companion_explorer", {}
    )
    if coverage_gate.get("golden_builder_sha256") != golden["builder"]["sha256"]:
        raise ValueError("P1_06 golden builder hash differs from coverage targets")
    if coverage_gate.get("golden_html_sha256") != golden["html"]["sha256"]:
        raise ValueError("P1_06 golden HTML hash differs from coverage targets")
    if coverage_gate.get("golden_dependency_hashes") != dependency_hashes:
        raise ValueError("P1_06 golden dependency hashes differ from coverage targets")
    if coverage_gate.get("accepted_v2_artifacts_only") is not adapter["accepted_artifacts_only"]:
        raise ValueError("P1_06 accepted-v2-only coverage target mismatch")
    if coverage_gate.get("historical_2025_exposure") is not True:
        raise ValueError("P1_06 companion must disclose historical_2025_exposure")
    if coverage_gate.get("strict_no_arrival_leakage") is not adapter["strict_no_arrival_leakage"]:
        raise ValueError("P1_06 companion strict no-arrival coverage target mismatch")
    if coverage_gate.get("required_hash_inventories") != adapter["required_hash_inventories"]:
        raise ValueError("P1_06 companion hash inventory coverage mismatch")
    if (
        coverage_gate.get("browser_runner_path") != browser_runtime["runner_path"]
        or coverage_gate.get("browser_receipt_schema")
        != browser_runtime["receipt_schema"]
        or coverage_gate.get("python_playwright_version")
        != browser_runtime["python_playwright_version"]
        or coverage_gate.get("synthetic_browser_pass_allowed") is not False
    ):
        raise ValueError("P1_06 browser runtime coverage target mismatch")
    trust_anchor = adapter["trust_anchor"]
    if (
        coverage_gate.get("two_phase_trust_anchor_required")
        is not trust_anchor["two_phase_required"]
        or coverage_gate.get("external_anchor_sha256_required")
        is not trust_anchor["external_anchor_sha256_argument_required"]
        or coverage_gate.get("canonical_acceptance_anchor_path")
        != trust_anchor["post_run_acceptance_anchor_path"]
        or coverage_gate.get("evaluation_run_id_end_to_end_bound")
        is not trust_anchor[
            "evaluation_run_id_bound_to_authorization_receipts_and_manifest"
        ]
        or coverage_gate.get("exact_108_task_model_spec_crosswalk_required")
        is not trust_anchor["exact_108_task_model_spec_crosswalk_required"]
        or coverage_gate.get(
            "authorized_validation_and_test_labels_must_match_predictions"
        )
        is not trust_anchor["authorized_outcome_labels_must_match_predictions"]
        or coverage_gate.get("finalizer_scientific_source_gate_required")
        is not trust_anchor["finalizer_scientific_source_gate_required"]
        or coverage_gate.get("scientific_coverage_receipt_in_anchor_required")
        is not trust_anchor["scientific_coverage_receipt_in_anchor_required"]
    ):
        raise ValueError("P1_06 companion external trust-anchor coverage mismatch")
    acceptance_keys = {
        "desktop_viewport",
        "mobile_viewport",
        "horizontal_overflow_max_px",
        "controls_failed",
        "controls_discovered_must_equal_tested",
        "shap_complete_must_equal_discovered",
        "shap_natural_width_positive_must_equal_discovered",
        "minimum_shap_natural_width",
        "http_404_count",
        "console_error_count",
        "page_error_count",
        "http_error_response_count",
        "legacy_metric_source_hits",
        "strict_no_arrival_leakage",
        "frozen_evaluation_count",
        "mandatory_component_outcome_count",
        "golden_post_build_hash_and_size_match",
        "shap_asset_root",
        "metric_recompute_absolute_tolerance",
        "source_to_recompute_mismatch_count",
        "bundle_to_recompute_mismatch_count",
        "dom_to_bundle_mismatch_count",
        "mandatory_binding_count",
        "displayed_numeric_key_count",
        "minimum_curve_point_count",
        "browser_viewport_receipt_count",
        "exact_control_case_count_per_viewport",
        "embedded_bundle_must_equal_accepted_bundle",
        "all_runtime_files_rehashed_and_toctou_free",
    }
    if set(acceptance) != acceptance_keys or any(
        acceptance[key] != coverage_gate.get(key) for key in acceptance_keys
    ):
        raise ValueError("P1_06 companion browser or source-recompute coverage mismatch")
    return {
        "p1_06_companion_explorer_contract": sha256_file(contract_path),
        **golden_hashes,
        **browser_runtime_hashes,
        **_p1_06_explorer_implementation_check(project_root, adapter),
    }


def _p1_06_explorer_implementation_check(
    project_root: Path, adapter_contract: dict[str, Any]
) -> dict[str, str]:
    configured = {
        "p1_06_companion_adapter": adapter_contract["required_path"],
        "p1_06_companion_validator": adapter_contract["validator_path"],
        "p1_06_companion_validator_test": adapter_contract["validator_test_path"],
        "p1_06_companion_runtime_gate": "qa_v2/p1_06_explorer.py",
        "p1_06_frozen_evaluation_authorizer": adapter_contract["trust_anchor"][
            "pre_run_authorizer"
        ],
        "p1_06_acceptance_finalizer": adapter_contract["trust_anchor"][
            "acceptance_finalizer"
        ],
        "p1_06_acceptance_anchor_test": "tests/test_p1_06_acceptance_anchor.py",
    }
    paths: dict[str, Path] = {}
    root = project_root.resolve()
    reparse_flag = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    for name, relative in configured.items():
        path = _resolved(project_root, relative)
        try:
            path.resolve(strict=True).relative_to(root)
        except ValueError as exc:
            raise ValueError(f"{name} resolves outside the project root") from exc
        current = root
        for part in path.relative_to(root).parts:
            current /= part
            value = os.lstat(current)
            is_junction = getattr(current, "is_junction", None)
            if (
                current.is_symlink()
                or (callable(is_junction) and is_junction())
                or getattr(value, "st_file_attributes", 0) & reparse_flag
            ):
                raise ValueError(f"{name} contains a symlink, junction, or reparse point")
        value = os.lstat(path)
        if not stat.S_ISREG(value.st_mode):
            raise ValueError(f"{name} is not a regular file")
        paths[name] = path

    adapter_tree = ast.parse(paths["p1_06_companion_adapter"].read_text(encoding="utf-8"))
    imported_modules = {
        alias.name
        for node in adapter_tree.body
        if isinstance(node, ast.Import)
        for alias in node.names
    }
    if any(name == "importlib" or name.startswith("importlib.") for name in imported_modules):
        raise ValueError("P1_06 adapter must not module-import or execute the golden builder")
    ast_function_values: tuple[str, ...] | None = None
    for node in adapter_tree.body:
        if not isinstance(node, ast.Assign) or len(node.targets) != 1:
            continue
        target = node.targets[0]
        if isinstance(target, ast.Name) and target.id == "AST_FUNCTIONS":
            value = ast.literal_eval(node.value)
            ast_function_values = tuple(value)
    if ast_function_values != ("to_jsonable", "json_script", "build_html"):
        raise ValueError("P1_06 adapter AST extraction must exclude golden main and all other code")
    exact_calls = [
        node
        for node in ast.walk(adapter_tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "build_html"
        and len(node.args) == 1
        and isinstance(node.args[0], ast.Name)
        and node.args[0].id == "bundle"
        and not node.keywords
    ]
    if len(exact_calls) != 1:
        raise ValueError("P1_06 adapter must contain exactly one build_html(bundle) invocation")
    adapter_signatures = {
        node.name: (
            [argument.arg for argument in node.args.args],
            len(node.args.defaults),
        )
        for node in adapter_tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name
        in {
            "load_acceptance_anchor",
            "load_anchored_accepted_context",
            "prepare_candidate",
        }
    }
    if adapter_signatures != {
        "load_acceptance_anchor": (
            ["project_root", "expected_acceptance_anchor_sha256"],
            0,
        ),
        "load_anchored_accepted_context": (
            ["project_root", "expected_acceptance_anchor_sha256"],
            0,
        ),
        "prepare_candidate": (
            [
                "project_root",
                "accepted_manifest_path",
                "candidate_dir",
                "expected_acceptance_anchor_sha256",
            ],
            0,
        ),
    }:
        raise ValueError(
            "P1_06 adapter must require the external acceptance-anchor SHA"
        )
    adapter_literals = {
        node.value
        for node in ast.walk(adapter_tree)
        if isinstance(node, ast.Constant) and isinstance(node.value, str)
    }
    if "--expected-p1-06-acceptance-anchor-sha256" not in adapter_literals:
        raise ValueError("P1_06 adapter CLI lacks the external anchor SHA argument")

    validator_tree = ast.parse(
        paths["p1_06_companion_validator"].read_text(encoding="utf-8")
    )
    file_gate_calls = [
        node
        for node in ast.walk(validator_tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "validate_companion_explorer_manifest_file"
    ]
    logical_gate_calls = [
        node
        for node in ast.walk(validator_tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "validate_companion_explorer_manifest"
    ]
    if len(file_gate_calls) != 1 or logical_gate_calls:
        raise ValueError("P1_06 production validator must call only the root-aware file gate exactly once")
    validator_signatures = {
        node.name: (
            [argument.arg for argument in node.args.args],
            len(node.args.defaults),
        )
        for node in validator_tree.body
        if isinstance(node, ast.FunctionDef)
        and node.name in {"stage_for_browser", "finalize_after_browser", "rollback_pending"}
    }
    if validator_signatures != {
        "stage_for_browser": (
            [
                "project_root",
                "candidate_manifest_path",
                "pending_seal_path",
                "expected_acceptance_anchor_sha256",
            ],
            0,
        ),
        "finalize_after_browser": (
            [
                "project_root",
                "pending_seal_path",
                "desktop_receipt_path",
                "mobile_receipt_path",
                "expected_acceptance_anchor_sha256",
            ],
            0,
        ),
        "rollback_pending": (
            [
                "project_root",
                "pending_seal_path",
                "expected_acceptance_anchor_sha256",
            ],
            0,
        ),
    }:
        raise ValueError(
            "P1_06 browser stage/finalize/rollback must require the external anchor SHA"
        )
    validator_literals = {
        node.value
        for node in ast.walk(validator_tree)
        if isinstance(node, ast.Constant) and isinstance(node.value, str)
    }
    if "--expected-p1-06-acceptance-anchor-sha256" not in validator_literals:
        raise ValueError("P1_06 validator CLI lacks the external anchor SHA argument")
    file_gate_call = file_gate_calls[0]
    if len(file_gate_call.args) + len(file_gate_call.keywords) != 6:
        raise ValueError("P1_06 production validator must pass all six root-aware gate arguments")
    if (
        len(file_gate_call.args) != 6
        or not isinstance(file_gate_call.args[-1], ast.Name)
        or file_gate_call.args[-1].id != "expected_acceptance_anchor_sha256"
    ):
        raise ValueError(
            "P1_06 production validator must receive the external anchor SHA from its caller"
        )
    return {name: sha256_file(path) for name, path in paths.items()}


def _transport_targeted_file(
    project_root: Path, relative: object, label: str
) -> Path:
    if project_root.resolve(strict=True) != w00b_contract.ROOT.resolve(strict=True):
        raise ValueError("transport targeted policy project root differs")
    if (
        not isinstance(relative, str)
        or not relative
        or Path(relative).is_absolute()
    ):
        raise ValueError(f"{label} path differs")
    try:
        return w00b_contract.project_path(
            relative, label, must_exist=True, file_only=True
        )
    except (OSError, w00b_contract.W00BRuntimeError) as exc:
        raise ValueError(f"{label} is unavailable") from exc


def _transport_targeted_document(
    project_root: Path, relative: object, label: str
) -> tuple[Path, dict[str, Any]]:
    path = _transport_targeted_file(project_root, relative, label)
    try:
        return path, w00b_contract.read_json(path, label)
    except w00b_contract.W00BRuntimeError as exc:
        raise ValueError(f"{label} differs") from exc


def _transport_targeted_bound_stream(
    project_root: Path, value: dict[str, Any], name: str, label: str
) -> str:
    bound = value.get(name)
    if not isinstance(bound, dict) or set(bound) != {"path", "sha256", "size"}:
        raise ValueError(f"{label} {name} binding differs")
    path = _transport_targeted_file(
        project_root, bound.get("path"), f"{label} {name}"
    )
    size = bound.get("size")
    observed = sha256_file(path)
    if (
        not isinstance(size, int)
        or isinstance(size, bool)
        or size != path.stat().st_size
        or bound.get("sha256") != observed
    ):
        raise ValueError(f"{label} {name} binding differs")
    return observed


def _transport_scanner_rebind_overlay(
    project_root: Path,
    config: dict[str, Any],
    live_hashes: dict[str, str],
    baseline_hashes: dict[str, str],
) -> dict[str, Any]:
    settings = config.get("scanner_rebind_overlay")
    if (
        not isinstance(settings, dict)
        or set(settings)
        != {"evidence", "baseline_source", "baseline_source_sha256"}
        or settings.get("baseline_source")
        != w00b_contract.SCANNER_REBIND_BASELINE_SOURCE
        or settings.get("baseline_source_sha256")
        != w00b_contract.SCANNER_REBIND_BASELINE_SOURCE_SHA256
        or not isinstance(settings.get("evidence"), str)
    ):
        raise ValueError("scanner rebind overlay configuration differs")
    evidence_path, evidence = _transport_targeted_document(
        project_root,
        settings["evidence"],
        "scanner rebind evidence",
    )
    evidence_sha = sha256_file(evidence_path)
    inventory_binding = evidence.get("inventory")
    canary_binding = evidence.get("canary")
    baseline_overlay = evidence.get("baseline_overlay")
    transport_overlay = evidence.get("transport_overlay")
    targeted_tests = evidence.get("targeted_tests")
    if (
        evidence.get("schema_version")
        != "p1-v2-scanner-shared-gate-evidence/1"
        or evidence.get("status") != "PASS"
        or evidence.get("launch_blocker_cleared") is not True
        or not isinstance(inventory_binding, dict)
        or not isinstance(canary_binding, dict)
        or not isinstance(baseline_overlay, dict)
        or not isinstance(transport_overlay, dict)
        or not isinstance(targeted_tests, list)
        or not targeted_tests
        or any(
            not isinstance(row, dict)
            or row.get("exit_code") != 0
            or not isinstance(row.get("tests_run"), int)
            or isinstance(row.get("tests_run"), bool)
            or row["tests_run"] < 1
            or row.get("failures") != 0
            for row in targeted_tests
        )
    ):
        raise ValueError("scanner rebind evidence differs")

    inventory_path, inventory = _transport_targeted_document(
        project_root,
        inventory_binding.get("path"),
        "scanner callsite inventory",
    )
    inventory_sha = sha256_file(inventory_path)
    coverage = inventory.get("coverage")
    if (
        inventory_binding.get("sha256") != inventory_sha
        or inventory.get("schema_version")
        != "p1-v2-scanner-callsite-inventory/1"
        or inventory.get("status") != "PASS"
        or not isinstance(coverage, dict)
        or coverage.get("coverage_percent") != 100.0
        or coverage.get("expected_callsites_valid") is not True
        or coverage.get("expected_callsite_count_exact") is not True
        or coverage.get("expected_callsite_list_exact") is not True
        or coverage.get("residual_independent_scanner_count") != 0
        or inventory.get("independent_scanner_definitions") != []
    ):
        raise ValueError("scanner callsite inventory differs")

    canary_path, canary = _transport_targeted_document(
        project_root,
        canary_binding.get("path"),
        "scanner no-mutation canary",
    )
    canary_sha = sha256_file(canary_path)
    matrix = canary.get("true_positive_and_hash_context_matrix")
    no_mutation = canary.get("no_mutation")
    if (
        canary_binding.get("sha256") != canary_sha
        or canary.get("schema_version")
        != "p1-v2-scanner-no-mutation-canary/1"
        or canary.get("status") != "PASS"
        or canary.get("inventory")
        != {
            **inventory_binding,
            "callsite_count": inventory_binding.get("callsite_count"),
            "entrypoint_count": inventory_binding.get("entrypoint_count"),
            "coverage_percent": inventory_binding.get("coverage_percent"),
            "independent_scanner_definitions": inventory_binding.get(
                "independent_scanner_definitions"
            ),
        }
        or not isinstance(matrix, dict)
        or matrix.get("failures") != []
        or not isinstance(no_mutation, dict)
        or no_mutation.get("identical") is not True
        or no_mutation.get("before") != no_mutation.get("after")
    ):
        raise ValueError("scanner no-mutation canary differs")

    source_binding = baseline_overlay.get("source_report")
    changes = baseline_overlay.get("changed_hash_targets")
    source_path, source = _transport_targeted_document(
        project_root,
        source_binding.get("path") if isinstance(source_binding, dict) else None,
        "scanner rebind baseline source report",
    )
    source_sha = sha256_file(source_path)
    source_checks = source.get("checks")
    hash_check = next(
        (
            row
            for row in source_checks
            if isinstance(row, dict) and row.get("name") == "hash_targets"
        ),
        None,
    ) if isinstance(source_checks, list) else None
    hash_details = hash_check.get("details") if isinstance(hash_check, dict) else None
    source_hashes = hash_details.get("files") if isinstance(hash_details, dict) else None
    expected_paths = set(w00b_contract.SCANNER_REBIND_BASELINE_PATHS)
    if (
        source_sha != w00b_contract.SCANNER_REBIND_BASELINE_SOURCE_SHA256
        or source_binding
        != {
            "path": w00b_contract.SCANNER_REBIND_BASELINE_SOURCE,
            "sha256": source_sha,
            "check_status": "PASS",
            "aggregate_sha256": (
                hash_details.get("aggregate_sha256")
                if isinstance(hash_details, dict)
                else None
            ),
        }
        or not isinstance(hash_check, dict)
        or hash_check.get("status") != "PASS"
        or not isinstance(source_hashes, dict)
        or not isinstance(changes, dict)
        or set(changes) != expected_paths
        or len(w00b_contract.SCANNER_REBIND_BASELINE_PATHS)
        != len(expected_paths)
        or not expected_paths.issubset(live_hashes)
    ):
        raise ValueError("scanner rebind baseline source differs")
    old_hashes: dict[str, str] = {}
    current_hashes: dict[str, str] = {}
    for relative in sorted(expected_paths):
        binding = changes.get(relative)
        old_sha = source_hashes.get(relative)
        current_sha = live_hashes.get(relative)
        if (
            not isinstance(binding, dict)
            or set(binding) != {"baseline_sha256", "current_sha256"}
            or binding.get("baseline_sha256") != old_sha
            or binding.get("current_sha256") != current_sha
            or not isinstance(old_sha, str)
            or w00b_contract.HASH_RE.fullmatch(old_sha) is None
            or not isinstance(current_sha, str)
            or w00b_contract.HASH_RE.fullmatch(current_sha) is None
            or old_sha == current_sha
            or (
                relative in baseline_hashes
                and baseline_hashes[relative] != old_sha
            )
        ):
            raise ValueError("scanner rebind baseline hash binding differs")
        old_hashes[relative] = old_sha
        current_hashes[relative] = current_sha

    base_binding = transport_overlay.get("base_evidence")
    transport_changes = transport_overlay.get("changed_hash_targets")
    base_path, base_evidence = _transport_targeted_document(
        project_root,
        base_binding.get("path") if isinstance(base_binding, dict) else None,
        "scanner rebind base transport evidence",
    )
    base_sha = sha256_file(base_path)
    tested_hashes = base_evidence.get("tested_file_hashes_after")
    transport_live = {
        relative: sha256_file(
            _transport_targeted_file(project_root, relative, relative)
        )
        for relative in w00b_contract.TRANSPORT_TARGETED_HASH_PATHS
    }
    changed_transport_paths = {
        relative
        for relative, digest in transport_live.items()
        if isinstance(tested_hashes, dict) and tested_hashes.get(relative) != digest
    }
    if (
        base_binding
        != {
            "path": w00b_contract.TRANSPORT_TARGETED_EVIDENCE,
            "sha256": base_sha,
        }
        or base_evidence.get("schema_version")
        != "p1-v2-transport-targeted-test-evidence/1"
        or base_evidence.get("status") != "PASS"
        or base_evidence.get("exit_code") != 0
        or base_evidence.get("failures") != 0
        or base_evidence.get("errors") != 0
        or not isinstance(tested_hashes, dict)
        or set(tested_hashes) != set(w00b_contract.TRANSPORT_TARGETED_HASH_PATHS)
        or base_evidence.get("tested_file_hashes_before") != tested_hashes
        or base_evidence.get("tested_file_hashes_unchanged") is not True
        or not isinstance(transport_changes, dict)
        or set(transport_changes) != changed_transport_paths
    ):
        raise ValueError("scanner rebind transport overlay differs")
    for relative in sorted(changed_transport_paths):
        binding = transport_changes.get(relative)
        if (
            not isinstance(binding, dict)
            or set(binding) != {"tested_sha256", "current_sha256"}
            or binding.get("tested_sha256") != tested_hashes.get(relative)
            or binding.get("current_sha256") != transport_live.get(relative)
        ):
            raise ValueError("scanner rebind transport hash binding differs")

    return {
        "baseline_source": {
            "path": w00b_contract.SCANNER_REBIND_BASELINE_SOURCE,
            "sha256": source_sha,
        },
        "evidence": {
            "path": settings["evidence"],
            "sha256": evidence_sha,
        },
        "inventory": {
            "path": inventory_binding["path"],
            "sha256": inventory_sha,
        },
        "canary": {
            "path": canary_binding["path"],
            "sha256": canary_sha,
        },
        "baseline_hashes": old_hashes,
        "current_hashes": current_hashes,
        "transport_overlay": {
            "base_evidence": base_binding,
            "changed_hash_targets": transport_changes,
        },
    }


def _transport_targeted_baseline_scope(
    project_root: Path,
    config: dict[str, Any],
    full_suite: dict[str, Any],
    full_suite_sha: str,
) -> dict[str, Any]:
    anchor_path, anchor = _transport_targeted_document(
        project_root,
        w00b_contract.TRANSPORT_TARGETED_BASELINE_ANCHOR,
        "transport targeted baseline anchor",
    )
    anchor_sha = sha256_file(anchor_path)
    anchor_self_sha = anchor.get("preflight_sha256")
    anchor_payload = dict(anchor)
    anchor_payload.pop("preflight_sha256", None)
    anchor_full_suite = anchor.get("full_suite")
    locked_hashes = anchor.get("locked_hashes")
    if (
        anchor_sha
        != w00b_contract.TRANSPORT_TARGETED_BASELINE_ANCHOR_SHA256
        or anchor.get("contract_version")
        != "p1-v2-w00b-runtime-pilot-preflight/1"
        or anchor.get("status") != "PASS"
        or not isinstance(anchor_self_sha, str)
        or canonical_sha256(anchor_payload) != anchor_self_sha
        or not isinstance(anchor_full_suite, dict)
        or anchor_full_suite.get("path") != w00b_contract.FULL_SUITE
        or anchor_full_suite.get("sha256") != full_suite_sha
        or anchor_full_suite.get("tests_run") != full_suite.get("tests_run")
        or anchor_full_suite.get("exit_code") != 0
        or anchor_full_suite.get("hash_targets_unchanged") is not True
        or anchor_full_suite.get("golden_unchanged") is not True
        or anchor_full_suite.get("kaggle_launch_observed") is not False
        or not isinstance(locked_hashes, dict)
        or locked_hashes.get(w00b_contract.FULL_SUITE) != full_suite_sha
        or any(
            not isinstance(relative, str)
            or not isinstance(digest, str)
            or w00b_contract.HASH_RE.fullmatch(digest) is None
            for relative, digest in locked_hashes.items()
        )
    ):
        raise ValueError("transport targeted baseline anchor differs")

    extension_path, extension = _transport_targeted_document(
        project_root,
        w00b_contract.TRANSPORT_TARGETED_BASELINE_EXTENSION,
        "transport targeted derived baseline extension",
    )
    extension_sha = sha256_file(extension_path)
    extension_self_sha = extension.get("extension_self_sha256")
    extension_payload = dict(extension)
    extension_payload.pop("extension_self_sha256", None)
    source_anchor = extension.get("source_anchor")
    source_report_binding = extension.get("source_hash_targets_report")
    extension_full_suite = extension.get("full_suite")
    extension_hashes = extension.get("added_pre_edit_hashes")
    reconstruction = extension.get("reconstruction")
    expected_extension_paths = set(
        w00b_contract.TRANSPORT_TARGETED_BASELINE_EXTENSION_PATHS
    )
    if (
        extension_sha
        != w00b_contract.TRANSPORT_TARGETED_BASELINE_EXTENSION_SHA256
        or set(extension)
        != {
            "schema_version",
            "status",
            "derived",
            "created_at_utc",
            "source_anchor",
            "source_hash_targets_report",
            "full_suite",
            "baseline_tested_hash_targets_aggregate",
            "added_pre_edit_hashes",
            "reconstruction",
            "extension_self_sha256",
        }
        or extension.get("schema_version")
        != "p1-v2-transport-baseline-extension/1"
        or extension.get("status") != "PASS"
        or extension.get("derived") is not True
        or not isinstance(extension_self_sha, str)
        or canonical_sha256(extension_payload) != extension_self_sha
        or source_anchor
        != {
            "path": w00b_contract.TRANSPORT_TARGETED_BASELINE_ANCHOR,
            "sha256": anchor_sha,
        }
        or extension_full_suite
        != {"path": w00b_contract.FULL_SUITE, "sha256": full_suite_sha}
        or extension.get("baseline_tested_hash_targets_aggregate")
        != w00b_contract.TRANSPORT_TARGETED_BASELINE_AGGREGATE
        or not isinstance(extension_hashes, dict)
        or set(extension_hashes) != expected_extension_paths
        or len(w00b_contract.TRANSPORT_TARGETED_BASELINE_EXTENSION_PATHS)
        != len(expected_extension_paths)
        or not expected_extension_paths.issubset(
            w00b_contract.TRANSPORT_TARGETED_HASH_PATHS
        )
        or set(extension_hashes).intersection(locked_hashes)
        or any(
            not isinstance(digest, str)
            or w00b_contract.HASH_RE.fullmatch(digest) is None
            for digest in extension_hashes.values()
        )
        or not isinstance(reconstruction, dict)
        or reconstruction.get("status") != "PASS"
        or reconstruction.get(
            "reconstructed_baseline_tested_hash_targets_aggregate"
        )
        != w00b_contract.TRANSPORT_TARGETED_BASELINE_AGGREGATE
    ):
        raise ValueError("transport targeted derived baseline extension differs")

    if not isinstance(source_report_binding, dict):
        raise ValueError("transport targeted derived baseline extension differs")
    source_report_path, source_report = _transport_targeted_document(
        project_root,
        source_report_binding.get("path"),
        "transport targeted baseline extension source report",
    )
    source_checks = source_report.get("checks")
    source_hash_check = None
    if isinstance(source_checks, list):
        source_hash_check = next(
            (
                row
                for row in source_checks
                if isinstance(row, dict) and row.get("name") == "hash_targets"
            ),
            None,
        )
    source_details = (
        source_hash_check.get("details", {})
        if isinstance(source_hash_check, dict)
        else {}
    )
    source_files = source_details.get("files")
    if (
        source_report_binding
        != {
            "path": w00b_contract.TRANSPORT_TARGETED_BASELINE_EXTENSION_SOURCE,
            "sha256": (
                w00b_contract.TRANSPORT_TARGETED_BASELINE_EXTENSION_SOURCE_SHA256
            ),
            "check_status": "PASS",
            "aggregate_sha256": source_details.get("aggregate_sha256"),
        }
        or sha256_file(source_report_path)
        != w00b_contract.TRANSPORT_TARGETED_BASELINE_EXTENSION_SOURCE_SHA256
        or not isinstance(source_hash_check, dict)
        or source_hash_check.get("status") != "PASS"
        or not isinstance(source_files, dict)
        or {
            relative: source_files.get(relative)
            for relative in w00b_contract.TRANSPORT_TARGETED_BASELINE_EXTENSION_PATHS
        }
        != extension_hashes
    ):
        raise ValueError("transport targeted derived baseline extension differs")

    live_hashes = _hash_target_files(project_root, config)
    w01_evidence = str(config["w01_gate_test_evidence"]).replace("\\", "/")
    if w01_evidence not in live_hashes:
        raise ValueError("W01 gate evidence is not included in hash targets")
    del live_hashes[w01_evidence]
    baseline_hashes = dict(locked_hashes)
    baseline_hashes.update(extension_hashes)
    scanner_overlay = _transport_scanner_rebind_overlay(
        project_root,
        config,
        live_hashes,
        baseline_hashes,
    )
    baseline_hashes.update(scanner_overlay["baseline_hashes"])
    common_paths = set(live_hashes).intersection(baseline_hashes)
    if not common_paths:
        raise ValueError("transport targeted baseline anchor has no live hash targets")
    reconstructed = dict(live_hashes)
    reconstructed.update(
        {relative: baseline_hashes[relative] for relative in common_paths}
    )
    reconstructed_aggregate = canonical_sha256(reconstructed)
    expected_aggregate = w00b_contract.TRANSPORT_TARGETED_BASELINE_AGGREGATE
    if (
        reconstructed_aggregate != expected_aggregate
        or reconstruction.get("hash_target_count") != len(reconstructed)
        or full_suite.get("tested_hash_targets_aggregate_before")
        != expected_aggregate
        or full_suite.get("tested_hash_targets_aggregate_after")
        != expected_aggregate
    ):
        raise ValueError("transport targeted reconstructed baseline differs")
    changed_paths = sorted(
        relative
        for relative, digest in live_hashes.items()
        if reconstructed[relative] != digest
    )
    allowed_paths = list(w00b_contract.TRANSPORT_TARGETED_HASH_PATHS)
    if len(allowed_paths) != len(set(allowed_paths)):
        raise ValueError("transport targeted hash path set contains duplicates")
    scanner_allowed_paths = list(w00b_contract.SCANNER_REBIND_BASELINE_PATHS)
    if len(scanner_allowed_paths) != len(set(scanner_allowed_paths)):
        raise ValueError("scanner rebind baseline path set contains duplicates")
    disallowed = sorted(
        set(changed_paths).difference(allowed_paths, scanner_allowed_paths)
    )
    if disallowed:
        raise ValueError(
            f"non-transport hash targets changed since baseline: {disallowed}"
        )
    return {
        "baseline_anchor": {
            "path": w00b_contract.TRANSPORT_TARGETED_BASELINE_ANCHOR,
            "sha256": anchor_sha,
        },
        "baseline_extension": {
            "path": w00b_contract.TRANSPORT_TARGETED_BASELINE_EXTENSION,
            "sha256": extension_sha,
        },
        "scanner_rebind_baseline_source": scanner_overlay["baseline_source"],
        "scanner_rebind_evidence": scanner_overlay["evidence"],
        "scanner_rebind_inventory": scanner_overlay["inventory"],
        "scanner_rebind_canary": scanner_overlay["canary"],
        "scanner_rebind_transport_overlay": scanner_overlay[
            "transport_overlay"
        ],
        "reconstructed_baseline_tested_hash_targets_aggregate": (
            reconstructed_aggregate
        ),
        "current_tested_hash_targets_aggregate": canonical_sha256(live_hashes),
        "baseline_to_current_changed_paths": changed_paths,
        "transport_targeted_allowed_paths": allowed_paths,
        "scanner_rebind_allowed_paths": scanner_allowed_paths,
    }


def _transport_targeted_policy_check(
    project_root: Path,
    config: dict[str, Any],
    baseline_aggregate: object,
    current_aggregate: str,
) -> dict[str, str]:
    full_suite_path, full_suite = _transport_targeted_document(
        project_root, w00b_contract.FULL_SUITE, "baseline full-suite gate"
    )
    tests_run = full_suite.get("tests_run")
    command = full_suite.get("command")
    expected_command = [
        "-B",
        "-X",
        "utf8",
        "-m",
        "unittest",
        "discover",
        "-s",
        "tests",
        "-v",
    ]
    if (
        full_suite.get("schema_version") != "p1-v2-full-suite-evidence/1"
        or full_suite.get("status") != "PASS"
        or full_suite.get("exit_code") != 0
        or not isinstance(tests_run, int)
        or isinstance(tests_run, bool)
        or tests_run < 672
        or not isinstance(command, list)
        or len(command) != len(expected_command) + 1
        or command[1:] != expected_command
        or full_suite.get("tested_hash_targets_aggregate_unchanged") is not True
        or full_suite.get("tested_hash_targets_aggregate_before") != baseline_aggregate
        or full_suite.get("tested_hash_targets_aggregate_after") != baseline_aggregate
        or full_suite.get("golden_sha256_unchanged") is not True
        or full_suite.get("golden_sha256_before")
        != full_suite.get("golden_sha256_after")
        or full_suite.get("streaming_logs") is not True
        or full_suite.get("forced_utf8_environment") is not True
        or full_suite.get("kaggle_launch_observed") is not False
    ):
        raise ValueError("baseline full-suite gate differs")
    full_stdout_sha = _transport_targeted_bound_stream(
        project_root, full_suite, "stdout", "baseline full-suite gate"
    )
    full_stderr_sha = _transport_targeted_bound_stream(
        project_root, full_suite, "stderr", "baseline full-suite gate"
    )
    full_suite_sha = sha256_file(full_suite_path)
    baseline_scope = _transport_targeted_baseline_scope(
        project_root, config, full_suite, full_suite_sha
    )
    if (
        baseline_aggregate
        != baseline_scope[
            "reconstructed_baseline_tested_hash_targets_aggregate"
        ]
        or current_aggregate
        != baseline_scope["current_tested_hash_targets_aggregate"]
    ):
        raise ValueError("transport targeted aggregate binding differs")

    decision_path, decision = _transport_targeted_document(
        project_root,
        w00b_contract.TRANSPORT_TARGETED_DECISION,
        "transport targeted decision",
    )
    completed = decision.get("completed_full_suite")
    if not isinstance(completed, dict):
        completed = {}
    if (
        decision.get("schema_version") != "p1-v2-execution-policy-decision/1"
        or decision.get("decision") != "transport_only_targeted_retest"
        or completed.get("path") != w00b_contract.FULL_SUITE
        or completed.get("sha256") != full_suite_sha
        or completed.get("status") != full_suite["status"]
        or completed.get("tests_run") != full_suite["tests_run"]
        or completed.get("failures") != 0
        or completed.get("errors") != 0
        or "full repository suite"
        not in decision.get("prohibited_retests_for_transport_only_change", [])
    ):
        raise ValueError(
            "transport targeted decision does not bind the baseline full suite"
        )

    evidence_path, evidence = _transport_targeted_document(
        project_root,
        w00b_contract.TRANSPORT_TARGETED_EVIDENCE,
        "transport targeted evidence",
    )
    if len(w00b_contract.TRANSPORT_TARGETED_HASH_PATHS) != len(
        set(w00b_contract.TRANSPORT_TARGETED_HASH_PATHS)
    ):
        raise ValueError("transport targeted hash path set contains duplicates")
    live_hashes = {
        relative: sha256_file(
            _transport_targeted_file(project_root, relative, relative)
        )
        for relative in w00b_contract.TRANSPORT_TARGETED_HASH_PATHS
    }
    targeted_tests_run = evidence.get("tests_run")
    targeted_command = evidence.get("command")
    expected_targeted_command = [
        "-B",
        "-X",
        "utf8",
        "-m",
        "unittest",
        *w00b_contract.TRANSPORT_TARGETED_MODULES,
    ]
    evidence_full_suite = evidence.get("full_suite")
    evidence_decision = evidence.get("decision")
    golden_path = _transport_targeted_file(
        project_root,
        "outputs/report/EMT_P1_interactive_model_explorer.html",
        "golden explorer",
    )
    golden_sha = sha256_file(golden_path)
    evidence_changed_paths = evidence.get("baseline_to_current_changed_paths")
    strict_live_binding = (
        evidence_changed_paths == baseline_scope["baseline_to_current_changed_paths"]
        and evidence.get("current_tested_hash_targets_aggregate_before")
        == current_aggregate
        and evidence.get("current_tested_hash_targets_aggregate_after")
        == current_aggregate
        and evidence.get("tested_file_hashes_before") == live_hashes
        and evidence.get("tested_file_hashes_after") == live_hashes
        and evidence.get("tested_file_hashes_unchanged") is True
    )
    scanner_transport_overlay = baseline_scope[
        "scanner_rebind_transport_overlay"
    ]
    overlay_base = scanner_transport_overlay["base_evidence"]
    overlay_changes = scanner_transport_overlay["changed_hash_targets"]
    evidence_tested_hashes = evidence.get("tested_file_hashes_after")
    observed_overlay_paths = {
        relative
        for relative, digest in live_hashes.items()
        if isinstance(evidence_tested_hashes, dict)
        and evidence_tested_hashes.get(relative) != digest
    }
    overlay_live_binding = (
        overlay_base
        == {
            "path": w00b_contract.TRANSPORT_TARGETED_EVIDENCE,
            "sha256": sha256_file(evidence_path),
        }
        and isinstance(evidence_changed_paths, list)
        and evidence_changed_paths == sorted(set(evidence_changed_paths))
        and set(evidence_changed_paths).issubset(
            baseline_scope["transport_targeted_allowed_paths"]
        )
        and isinstance(evidence.get("current_tested_hash_targets_aggregate_before"), str)
        and w00b_contract.HASH_RE.fullmatch(
            evidence["current_tested_hash_targets_aggregate_before"]
        )
        is not None
        and evidence.get("current_tested_hash_targets_aggregate_before")
        == evidence.get("current_tested_hash_targets_aggregate_after")
        and isinstance(evidence_tested_hashes, dict)
        and set(evidence_tested_hashes)
        == set(w00b_contract.TRANSPORT_TARGETED_HASH_PATHS)
        and evidence.get("tested_file_hashes_before") == evidence_tested_hashes
        and evidence.get("tested_file_hashes_unchanged") is True
        and observed_overlay_paths == set(overlay_changes)
        and all(
            overlay_changes.get(relative)
            == {
                "tested_sha256": evidence_tested_hashes.get(relative),
                "current_sha256": live_hashes.get(relative),
            }
            for relative in observed_overlay_paths
        )
    )
    if (
        evidence.get("schema_version")
        != "p1-v2-transport-targeted-test-evidence/1"
        or evidence.get("status") != "PASS"
        or evidence.get("exit_code") != 0
        or not isinstance(targeted_tests_run, int)
        or isinstance(targeted_tests_run, bool)
        or targeted_tests_run < 87
        or evidence.get("failures") != 0
        or evidence.get("errors") != 0
        or evidence.get("modules")
        != list(w00b_contract.TRANSPORT_TARGETED_MODULES)
        or not isinstance(targeted_command, list)
        or len(targeted_command) != len(expected_targeted_command) + 1
        or targeted_command[1:] != expected_targeted_command
        or evidence_full_suite
        != {"path": w00b_contract.FULL_SUITE, "sha256": full_suite_sha}
        or evidence_decision
        != {
            "path": w00b_contract.TRANSPORT_TARGETED_DECISION,
            "sha256": sha256_file(decision_path),
        }
        or evidence.get("baseline_tested_hash_targets_aggregate")
        != baseline_aggregate
        or evidence.get("baseline_anchor")
        != baseline_scope["baseline_anchor"]
        or evidence.get("baseline_extension")
        != baseline_scope["baseline_extension"]
        or evidence.get(
            "reconstructed_baseline_tested_hash_targets_aggregate"
        )
        != baseline_scope[
            "reconstructed_baseline_tested_hash_targets_aggregate"
        ]
        or evidence.get("transport_targeted_allowed_paths")
        != baseline_scope["transport_targeted_allowed_paths"]
        or not (strict_live_binding or overlay_live_binding)
        or evidence.get("golden_sha256_before") != golden_sha
        or evidence.get("golden_sha256_after") != golden_sha
        or evidence.get("golden_sha256_unchanged") is not True
        or golden_sha != full_suite["golden_sha256_after"]
        or evidence.get("forced_utf8_environment") is not True
        or evidence.get("bytecode_disabled") is not True
        or evidence.get("kaggle_launch_observed") is not False
    ):
        raise ValueError("transport targeted evidence differs")
    targeted_stdout_sha = _transport_targeted_bound_stream(
        project_root, evidence, "stdout", "transport targeted evidence"
    )
    targeted_stderr_sha = _transport_targeted_bound_stream(
        project_root, evidence, "stderr", "transport targeted evidence"
    )
    return {
        "transport_targeted_baseline_anchor": baseline_scope[
            "baseline_anchor"
        ]["sha256"],
        "transport_targeted_baseline_extension": baseline_scope[
            "baseline_extension"
        ]["sha256"],
        "transport_scanner_rebind_baseline_source": baseline_scope[
            "scanner_rebind_baseline_source"
        ]["sha256"],
        "transport_scanner_rebind_evidence": baseline_scope[
            "scanner_rebind_evidence"
        ]["sha256"],
        "transport_scanner_rebind_inventory": baseline_scope[
            "scanner_rebind_inventory"
        ]["sha256"],
        "transport_scanner_rebind_canary": baseline_scope[
            "scanner_rebind_canary"
        ]["sha256"],
        "transport_targeted_baseline_full_suite": full_suite_sha,
        "transport_targeted_decision": sha256_file(decision_path),
        "transport_targeted_evidence": sha256_file(evidence_path),
        "transport_targeted_full_suite_stdout": full_stdout_sha,
        "transport_targeted_full_suite_stderr": full_stderr_sha,
        "transport_targeted_stdout": targeted_stdout_sha,
        "transport_targeted_stderr": targeted_stderr_sha,
    }


def _governance_check(project_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    paths = {
        "conflict_resolutions": _resolved(project_root, config["conflict_resolutions"]),
        "pipeline_dag": _resolved(project_root, config["pipeline_dag"]),
        "p1_06_companion_explorer_contract": _resolved(
            project_root, config["p1_06_companion_explorer_contract"]
        ),
        "secret_safety_contract": _resolved(project_root, config["secret_safety_contract"]),
        "coordinator_multi_account_auth": _resolved(
            project_root, config["coordinator_auth"]["path"]
        ),
        "w00_gate_test_evidence": _resolved(project_root, config["w00_gate_test_evidence"]),
        "w01_gate_test_evidence": _resolved(project_root, config["w01_gate_test_evidence"]),
    }
    conflicts = load_document(paths["conflict_resolutions"])
    if conflicts.get("historical_2025_exposure") is not True:
        raise ValueError("historical_2025_exposure must be true")
    required_conflicts = {
        "P1_04-COUNT",
        "P3-PREHOSPITAL-TREATMENT",
        "P1_05B-2025",
        "COMPUTE-LOCATION",
        "P1_01-PATIENT-TEMPORAL-DISJOINTNESS",
        "P1_01-PASSIVE-SCORE-RECOMPUTATION",
        "P1_01-SCORE-ALIAS-DEDUPLICATION",
        "P1_01-PREHOSPITAL-OXYGEN-AND-DBP",
        "P1_02-HPO-HASH-BINDING",
        "KAGGLE-MULTI-OWNER-SCHEDULING",
        "P1_06-GOLDEN-COMPANION-EXPLORER",
    }
    actual_conflicts = {row.get("conflict_id") for row in conflicts.get("resolutions", [])}
    if actual_conflicts != required_conflicts or not all(
        row.get("hard_gate") is True for row in conflicts.get("resolutions", [])
    ):
        raise ValueError("conflict_resolutions do not exactly contain the eleven approved hard gates")
    dag = load_document(paths["pipeline_dag"])
    nodes = {node["id"] for node in dag.get("nodes", [])}
    required_nodes = {
        "CONTRACT",
        "GROUP_ATTESTATION",
        "DEV_PARTITION",
        "P1_01",
        "W00",
        "P1_02",
        "P1_03",
        "P1_04",
        "P1_05a",
        "P1_05b",
        "P1_06_AUTHORIZATION",
        "P1_06",
        "P1_06_ACCEPTANCE",
        "P1_06_COMPANION_EXPLORER",
    }
    if not required_nodes.issubset(nodes):
        raise ValueError(f"pipeline DAG missing nodes: {sorted(required_nodes - nodes)}")
    edges = {(edge["from"], edge["to"]) for edge in dag.get("edges", [])}
    ordered = (
        "CONTRACT",
        "GROUP_ATTESTATION",
        "DEV_PARTITION",
        "P1_01",
        "W00",
        "P1_02",
        "P1_03",
        "P1_04",
        "P1_05a",
        "P1_05b",
        "P1_06_AUTHORIZATION",
        "P1_06",
        "P1_06_ACCEPTANCE",
        "P1_06_COMPANION_EXPLORER",
    )
    missing_edges = [(left, right) for left, right in zip(ordered, ordered[1:]) if (left, right) not in edges]
    if missing_edges:
        raise ValueError(f"pipeline DAG missing strict-order edges: {missing_edges}")
    secret_contract = load_document(paths["secret_safety_contract"])
    if (
        secret_contract.get("plaintext_secret_policy")
        != "user_authorized_kaggle_tabpfn_tabicl_tokens_any_research_execution_file"
    ):
        raise ValueError("plaintext token policy does not match the user's latest authorization")
    if secret_contract.get("authorized_plaintext_scopes") != [
        "code",
        "prompt",
        "log",
        "artifact",
        "zip",
        "report",
        "kaggle_output",
    ]:
        raise ValueError("plaintext token scopes differ from the approved contract")
    if secret_contract.get("authorized_token_findings_blocking") is not False:
        raise ValueError("authorized token findings must be audit-only and nonblocking")
    if secret_contract.get("credential_sharing_permitted") is not True:
        raise ValueError("coordinator credential sharing authorization is missing")
    coordinator_policy = secret_contract.get("coordinator_auth", {})
    if coordinator_policy != {
        "authorization_mode": "coordinator_operated",
        "owner_person_challenge_required": False,
        "owner_person_availability_required": False,
        "owner_person_launch_required": False,
        "one_isolated_process_per_selected_account": True,
        "clear_inherited_kaggle_auth": True,
        "inject_selected_account_only": True,
    }:
        raise ValueError("coordinator authentication policy differs")
    if secret_contract.get("w00", {}).get("api_token_required") is not False:
        raise ValueError("W00 must not require an API token")
    stage5b_secret = secret_contract.get("p1_05b", {})
    if stage5b_secret.get("launch_blocked_until_rotation_attested") is not False:
        raise ValueError("P1_05b must not require token-rotation attestation after the owner override")
    if stage5b_secret.get("plaintext_token_allowed_in_all_research_execution_files") is not True:
        raise ValueError("P1_05b plaintext token authorization is missing")
    if stage5b_secret.get("token_logging_forbidden") is not False:
        raise ValueError("P1_05b token logging restriction was not revoked")
    if stage5b_secret.get("authorized_token_findings_block_package_launch_import_release") is not False:
        raise ValueError("authorized token findings must not block the workflow")
    coordinator_config_path = paths["coordinator_multi_account_auth"]
    configured_sha256 = config["coordinator_auth"].get("sha256")
    actual_coordinator_sha256 = sha256_file(coordinator_config_path)
    if configured_sha256 != actual_coordinator_sha256:
        raise ValueError("coordinator multi-account auth config hash mismatch")
    coordinator_config = load_document(coordinator_config_path)
    coordinator_schema_path = _resolved(
        project_root, config["schemas"]["coordinator_multi_account_auth"]
    )
    coordinator_schema = load_document(coordinator_schema_path)
    Draft202012Validator.check_schema(coordinator_schema)
    if list(
        Draft202012Validator(
            coordinator_schema, format_checker=FormatChecker()
        ).iter_errors(coordinator_config)
    ):
        raise ValueError("coordinator multi-account auth config does not match its schema")
    if (
        coordinator_config.get("authorization_mode") != "coordinator_operated"
        or coordinator_config.get("credential_sharing_permitted") is not True
        or coordinator_config.get("plaintext_tokens_permitted") is not True
        or coordinator_config.get("isolation_policy")
        != {
            "one_process_per_account": True,
            "clear_inherited_kaggle_auth": True,
            "isolated_home_per_process": True,
            "inject_selected_account_only": True,
        }
    ):
        raise ValueError("coordinator multi-account auth config policy differs")
    gate_evidence = load_document(paths["w00_gate_test_evidence"])
    if gate_evidence.get("status") != "PASS":
        raise ValueError("W00 gate test evidence is not PASS")
    if int(gate_evidence.get("tests_run", 0)) < 72:
        raise ValueError("W00 gate test evidence is incomplete")
    if gate_evidence.get("failures") != 0 or gate_evidence.get("errors") != 0:
        raise ValueError("W00 gate test evidence records failures or errors")
    w01_gate_evidence = load_document(paths["w01_gate_test_evidence"])
    if w01_gate_evidence.get("status") != "PASS":
        raise ValueError("W01 gate test evidence is not PASS")
    if int(w01_gate_evidence.get("tests_run", 0)) < 99:
        raise ValueError("W01 gate test evidence is incomplete")
    if w01_gate_evidence.get("failures") != 0 or w01_gate_evidence.get("errors") != 0:
        raise ValueError("W01 gate test evidence records failures or errors")
    required_w01_gates = (
        "real_task_roundtrip",
        "independent_reference_recompute",
        "partial_resume_path_tested",
        "patient_disjoint_temporal_recompute",
        "patient_group_2025_attestation_tested",
        "filtered_development_zero_overlap_tested",
        "passive_score_component_first_tested",
        "passive_score_formula_equivalence_tested",
        "passive_score_no_direct_imputation_tested",
        "passive_score_alias_dedup_tested",
        "optuna_binding_tested",
        "missingness_disclosure_contract_tested",
        "external_contract_binding_tested",
        "canonical_scientific_projection_tested",
        "resume_external_root_anchor_tested",
        "optuna_gap_resume_to_final_import_tested",
        "multi_generation_resume_lineage_tested",
        "transport_recovery_contract_tested",
    )
    missing_w01_gates = [name for name in required_w01_gates if w01_gate_evidence.get(name) is not True]
    if missing_w01_gates:
        raise ValueError(f"W01 gate test evidence missing required coverage: {missing_w01_gates}")
    tested_aggregate = w01_gate_evidence.get("tested_hash_targets_aggregate_sha256")
    current_aggregate = _tested_hash_target_aggregate(project_root, config)
    transport_targeted_hashes: dict[str, str] = {}
    if tested_aggregate != current_aggregate:
        transport_targeted_hashes = _transport_targeted_policy_check(
            project_root,
            config,
            tested_aggregate,
            current_aggregate,
        )
    explorer_hashes = _p1_06_companion_explorer_contract_check(
        project_root, config, paths["p1_06_companion_explorer_contract"]
    )
    return (
        {name: sha256_file(path) for name, path in paths.items()}
        | explorer_hashes
        | transport_targeted_hashes
    )


def _hash_target_files(project_root: Path, config: dict[str, Any]) -> dict[str, str]:
    hashes: dict[str, str] = {}
    for relative in config.get("hash_targets", []):
        candidates = sorted(project_root.glob(relative)) if any(char in relative for char in "*?[]") else [_resolved(project_root, relative)]
        candidates = [path for path in candidates if path.is_file()]
        if not candidates:
            raise ValueError(f"hash target missing: {relative}")
        for path in candidates:
            hashes[str(path.relative_to(project_root)).replace("\\", "/")] = sha256_file(path)
    return hashes


def _tested_hash_target_aggregate(project_root: Path, config: dict[str, Any]) -> str:
    hashes = _hash_target_files(project_root, config)
    evidence_relative = str(config["w01_gate_test_evidence"]).replace("\\", "/")
    if evidence_relative not in hashes:
        raise ValueError("W01 gate evidence is not included in hash targets")
    del hashes[evidence_relative]
    return canonical_sha256(hashes)


def _hash_target_check(project_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    hashes = _hash_target_files(project_root, config)
    for group in config.get("hash_target_groups", []):
        candidates = sorted(path for path in project_root.glob(group["pattern"]) if path.is_file())
        if len(candidates) != int(group["expected_count"]):
            raise ValueError(
                f"hash target group {group['pattern']} expected={group['expected_count']} actual={len(candidates)}"
            )
    return {"files": hashes, "aggregate_sha256": canonical_sha256(hashes)}


def _w01b_runtime_profile_check(
    project_root: Path, config: dict[str, Any]
) -> dict[str, Any]:
    settings = config.get("w01b_runtime_profile")
    if not isinstance(settings, dict):
        raise ValueError("W01B runtime profile preflight configuration is missing")
    promotions = sorted(
        path.resolve()
        for path in project_root.glob(str(settings.get("promotion_glob", "")))
        if path.is_dir() and not path.is_symlink()
    )
    required = settings.get("required") is True
    if not promotions and not required:
        return {
            "status": "NOT_YET_AVAILABLE",
            "required": False,
            "accepted_profile_count": 0,
        }
    from scripts import build_p1_v2_w01_package as package_builder

    if len(promotions) != 1:
        raise ValueError(
            f"accepted W01B runtime profile count differs: {len(promotions)}"
        )
    promotion = promotions[0]
    profile_path = promotion / str(settings.get("profile_name", ""))
    acceptance_path = promotion / str(settings.get("acceptance_name", ""))
    marker_path = promotion / str(settings.get("marker_name", ""))
    if (
        not marker_path.is_file()
        or marker_path.is_symlink()
        or not profile_path.is_file()
        or profile_path.is_symlink()
        or not acceptance_path.is_file()
        or acceptance_path.is_symlink()
    ):
        raise ValueError("accepted W01B runtime profile promotion is incomplete")
    try:
        profile, _, binding = package_builder._validate_w01b_runtime_profile(
            project_root,
            profile_path,
            acceptance_path,
            registry_path=project_root / "qa_v2/task_registry.json",
            stage1a_paths={
                "features": project_root
                / "outputs/v2/stage1a/stage1a_features_le2024.parquet",
                "schema": project_root
                / "outputs/v2/stage1a/stage1a_schema_v2.json",
                "manifest": project_root
                / "outputs/v2/stage1a/stage1a_feature_manifest_v2.json",
            },
            fold_map_path=project_root / "qa_v2/fixed_group_folds_v2.parquet",
            missingness_reference_path=project_root
            / "qa_v2/canonical_references/canonical_missingness_reference_v2.json",
            materialization_manifest_path=project_root
            / "outputs/v2/w01b_locked_specs/materialization_manifest.json",
        )
    except package_builder.PackageError as exc:
        raise ValueError(f"accepted W01B runtime profile differs: {exc}") from exc
    privacy = profile.get("privacy", {})
    expected_privacy = {
        "maximum_data_year": 2024,
        "future_holdout_access_count": 0,
        "pii_findings": 0,
        "raw_text_included": False,
        "scientific_artifact": False,
    }
    if (
        not isinstance(privacy, dict)
        or any(privacy.get(key) != value for key, value in expected_privacy.items())
        or set(privacy) != set(expected_privacy) | {"secret_findings"}
        or not isinstance(privacy.get("secret_findings"), int)
        or isinstance(privacy.get("secret_findings"), bool)
        or privacy["secret_findings"] < 0
    ):
        raise ValueError("accepted W01B runtime profile privacy contract differs")
    return {
        **binding,
        "status": "PASS",
        "required": required,
        "accepted_profile_count": 1,
        "promotion_path": promotion.relative_to(project_root).as_posix(),
        "marker_sha256": sha256_file(marker_path),
    }


def run_preflight(config_path: Path) -> dict[str, Any]:
    config_path = config_path.resolve()
    config = load_document(config_path)
    project_root = _resolved(config_path.parent, config["project_root"])
    checks = [
        _check("prompt_contract", lambda: _prompt_contract_check(project_root, config)),
        _check("schemas", lambda: _schema_check(project_root, config)),
        _check("raw_data_and_cohort", lambda: _raw_data_check(project_root, config)),
        _check("source_seal", lambda: _source_seal_check(project_root, config)),
        _check("secret_scan", lambda: _secret_scan(project_root, config)),
        _check("development_bundles", lambda: _development_bundle_check(project_root, config)),
        _check(
            "patient_disjoint_temporal_split",
            lambda: _patient_disjoint_temporal_check(project_root, config),
        ),
        _check(
            "passive_score_component_first",
            lambda: _passive_score_contract_check(project_root, config),
        ),
        _check(
            "missingness_disclosure",
            lambda: _missingness_disclosure_check(project_root, config),
        ),
        _check("fold_map", lambda: _fold_map_check(project_root, config)),
        _check("task_registry", lambda: _task_registry_check(project_root, config)),
        _check("canonical_references", lambda: _canonical_reference_check(project_root, config)),
        _check(
            "w01b_runtime_profile",
            lambda: _w01b_runtime_profile_check(project_root, config),
        ),
        _check("governance", lambda: _governance_check(project_root, config)),
        _check("hash_targets", lambda: _hash_target_check(project_root, config)),
    ]
    status = "PASS" if all(check["status"] == "PASS" for check in checks) else "FAIL"
    return {
        "schema_version": "1.0",
        "status": status,
        "project_root": str(project_root),
        "config_sha256": sha256_file(config_path),
        "checks": checks,
        "failed_checks": [check["name"] for check in checks if check["status"] == "FAIL"],
    }


def _atomic_json_write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _authorization_schema_hashes(project_root: Path) -> dict[str, str]:
    return {
        path.relative_to(project_root).as_posix(): sha256_file(path)
        for path in sorted((project_root / "qa_v2/schemas").glob("*.json"))
    }


def create_launch_authorization(config_path: Path, output_path: Path) -> dict[str, Any]:
    report = run_preflight(config_path)
    if report["status"] != "PASS":
        raise RuntimeError(f"launch authorization denied; failed checks={report['failed_checks']}")
    check_details = {check["name"]: check["details"] for check in report["checks"]}
    project_root = Path(report["project_root"])
    authorization = {
        "schema_version": "1.0",
        "authorization_status": "AUTHORIZED",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "historical_2025_exposure": True,
        "maximum_development_year": 2024,
        "preflight_report_sha256": canonical_sha256(report),
        "prompt_lock_sha256": check_details["prompt_contract"]["prompt_lock_sha256"],
        "requirement_matrix_sha256": check_details["prompt_contract"]["requirement_matrix_sha256"],
        "raw_data_sha256": check_details["raw_data_and_cohort"]["sha256"],
        "source_seal_sha256": check_details["source_seal"]["sha256"],
        "source_seal_manifest_sha256": check_details["source_seal"]["manifest_sha256"],
        "artifact_hash_lock_sha256": check_details["development_bundles"]["artifact_hash_lock_sha256"],
        "fold_map_sha256": check_details["fold_map"]["sha256"],
        "fold_manifest_sha256": check_details["fold_map"]["manifest_sha256"],
        "task_registry_sha256": check_details["task_registry"]["task_registry_sha256"],
        "coverage_targets_sha256": check_details["task_registry"]["coverage_targets_sha256"],
        "canonical_reference_hashes": check_details["canonical_references"],
        "schema_hashes": check_details["schemas"]["sha256"],
        "governance_hashes": check_details["governance"],
        "locked_file_hashes": {
            **check_details["hash_targets"]["files"],
            **{
                relative: sha256_file(project_root / relative)
                for relative in (
                    "qa_v2/__init__.py",
                    "qa_v2/contextual_security_scan.py",
                )
            },
            **_authorization_schema_hashes(project_root),
        },
        "development_bundle_hashes": {
            bundle["name"]: bundle["sha256"] for bundle in check_details["development_bundles"]["bundles"]
        },
        "patient_group_independence_hashes": check_details["patient_disjoint_temporal_split"][
            "evidence_hashes"
        ],
        "passive_score_contract": {
            **check_details["passive_score_component_first"],
            "gate_test_evidence": {
                "passive_score_component_first_tested": True,
                "passive_score_formula_equivalence_tested": True,
                "passive_score_no_direct_imputation_tested": True,
                "passive_score_alias_dedup_tested": True,
                "optuna_binding_tested": True,
                "w01_gate_test_evidence_sha256": check_details["governance"][
                    "w01_gate_test_evidence"
                ],
            },
        },
        "missingness_disclosure_hashes": check_details["missingness_disclosure"],
        "w01b_runtime_profile": check_details["w01b_runtime_profile"],
    }
    _atomic_json_write(output_path.resolve(), authorization)
    return authorization


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the EMT P1 v2 preflight gate")
    parser.add_argument("--config", type=Path, default=Path(__file__).resolve().parent / "preflight_config.yaml")
    parser.add_argument("--report", type=Path)
    parser.add_argument("--authorize", type=Path)
    args = parser.parse_args()
    report = run_preflight(args.config)
    if args.report:
        _atomic_json_write(args.report.resolve(), report)
    if args.authorize:
        try:
            create_launch_authorization(args.config, args.authorize)
        except RuntimeError as exc:
            print(str(exc), file=sys.stderr)
            raise SystemExit(2) from exc
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
