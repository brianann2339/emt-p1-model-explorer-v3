from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import hashlib
import importlib.metadata
import json
import os
import platform
import sys
import time
from dataclasses import dataclass
from pathlib import Path, PureWindowsPath
from typing import Any, Callable

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegressionCV
from sklearn.model_selection import PredefinedSplit
from sklearn.preprocessing import StandardScaler

try:
    from scripts.p1_v2_wave_contract import get_task_variant
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from scripts.p1_v2_wave_contract import get_task_variant

from qa_v2 import contextual_security_scan as security_scan


OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
ROOT = Path(__file__).resolve().parents[1]
DEFAULT_TASK_REGISTRY = ROOT / "qa_v2" / "task_registry.json"
PRIMARY_OUTCOMES = ("P1", "P2", "P3")
MODELS = (
    "cnn_1d",
    "tabpfn_standard",
    "tabpfn_finetuned",
    "tabpfn_thinking",
    "tabicl",
    "stacking",
)
COMPUTE_TARGETS = {
    "cnn_1d": "kaggle_gpu",
    "tabpfn_standard": "kaggle_api",
    "tabpfn_finetuned": "kaggle_gpu",
    "tabpfn_thinking": "kaggle_api",
    "tabicl": "kaggle_gpu",
    "stacking": "local",
}
CHECKPOINT_MODELS = {
    "cnn_1d",
    "tabpfn_standard",
    "tabpfn_finetuned",
    "tabicl",
}
P1_05A_MODELS = (
    "frozen_embedding",
    "bert_finetuned",
    "mlp_plr",
    "ft_transformer",
)
REMOTE_MODELS = (
    "cnn_1d",
    "tabpfn_standard",
    "tabpfn_finetuned",
    "tabicl",
    "tabpfn_thinking",
)
STACKING_REQUIRED_MODEL_NAMES = (
    "logistic_l2",
    "catboost",
    "xgboost",
    "lightgbm",
    "balanced_random_forest",
    "bert_finetuned",
    "mlp_plr",
    "ft_transformer",
    "cnn_1d",
    "tabpfn_standard",
    "tabicl",
)
STACKING_SOURCE_TASK_TEMPLATES = {
    "logistic_l2": "P1_02-model-{outcome}-logistic_l2",
    "catboost": "P1_02-model-{outcome}-catboost",
    "xgboost": "P1_02-model-{outcome}-xgboost",
    "lightgbm": "P1_02-model-{outcome}-lightgbm",
    "balanced_random_forest": "P1_02-model-{outcome}-balanced_random_forest",
    "bert_finetuned": "P1_05a-{outcome}-bert_finetuned",
    "mlp_plr": "P1_05a-{outcome}-mlp_plr",
    "ft_transformer": "P1_05a-{outcome}-ft_transformer",
    "cnn_1d": "P1_05b-{outcome}-cnn_1d",
    "tabpfn_standard": "P1_05b-{outcome}-tabpfn_standard",
    "tabpfn_finetuned": "P1_05b-{outcome}-tabpfn_finetuned",
    "tabpfn_thinking": "P1_05b-{outcome}-tabpfn_thinking",
    "tabicl": "P1_05b-{outcome}-tabicl",
}
PREDICTION_COLUMNS = [
    "task_id",
    "row_hash",
    "outcome",
    "model",
    "split",
    "fold",
    "y_true",
    "prediction",
]
METRIC_COLUMNS = [
    "task_id",
    "outcome",
    "model",
    "split",
    "metric",
    "value",
    "status",
    "n",
    "events",
    "lower_ci",
    "upper_ci",
]
COVERAGE_COLUMNS = ["row_hash", "outcome", "model", "split", "eligible"]
CANARY_EXPECTED_COLUMNS = ["row_hash", "outcome", "model", "prediction"]
# TabPFN Thinking answers every predict with a fresh time-bounded remote search, so two calls on one
# fitted model disagree by far more than the 1e-5 reload canary allows. The deltas below were
# measured on P1_05b-P1-tabpfn_thinking (2026-08-05) and are recorded in the canary receipt so the
# artifact states what it can and cannot guarantee. See CANARY_REDEFINITION_AUTHORIZATION.
NONDETERMINISTIC_REMOTE_MODELS = frozenset({"tabpfn_thinking"})
NONDETERMINISM_WITHIN_RUN_DELTA = 0.005300581455230713
NONDETERMINISM_RELOAD_DELTA = 0.0097090601921
CANARY_REDEFINITION_AUTHORIZATION = {
    "decision": "reload canary is a local consistency check for remote stochastic backends",
    "approved_by": "project user, in discussion with Claude",
    "approved_on_utc": "2026-08-05",
    "scope": "tabpfn_thinking only; every other backend keeps the 1e-5 numerical reload canary",
    "evidence": (
        "canary_expected.parquet and predictions.parquet describe the same 100 validation_2024 "
        "rows from the same fitted model in the same run, and already differ by max 0.00530 / "
        "mean 0.00020; the post-reload comparison measured 0.00971 against a 1e-5 tolerance"
    ),
    "rationale": (
        "no tolerance choice can make bit-level reload reproducibility true for a stochastic "
        "remote search, and each re-prediction bills a full training context for 100 rows"
    ),
    "status": "SETTLED — do not revert or re-test at provider cost without new user approval",
}
SHA256_PATTERN_LENGTH = 64
STAGE3B_LINEAGE_CONTRACT = "p1-v2-stage3b-lineage/1"
FINETUNE_VALIDATION_MONITOR_POLICY = "fixed_group_fold_development_only"
FINETUNE_BASELINE_GATE_SPLIT = "oof_2020_2023"
CNN_CONFIGURATION_SELECTION_POLICY = "three_point_fixed_group_development_only"
STAGE3B_SESSION_HARD_LIMIT_HOURS = 12.0
STAGE3B_STOP_NEW_FIT_HOURS = 10.5
PACKAGE_PROVENANCE_KEYS = {
    "requirements",
    "package_lock",
    "package_manifest",
    "registry_rebind_receipt",
}
ARRIVAL_FORBIDDEN_TOKENS = (
    "arrival",
    "到院",
    "送達醫院",
    "檢傷",
    "交接",
    "離開醫院",
    "返隊",
)
ARRIVAL_EXACT_ALLOWLIST = {
    "運送時間",
    "總到院前時間",
    "MISS_運送時間",
    "MISS_總到院前時間",
}
AUTHORIZATION_CONTRACT = "p1-v2-stage3b-formal-authorization/2"
AUTHORIZATION_KEYS = {
    "contract_version",
    "status",
    "formal_training_authorized",
    "task_id",
    "authorization_sha256",
    "runner_sha256",
    "prelaunch_task_manifest_sha256",
    "task_registry_sha256",
    "registry_task_sha256",
    "maximum_year",
    "2025_access_count",
    "strict_no_arrival_leakage",
    "research_contracts",
    "accepted_dependency_tasks",
    "input_artifacts",
    "package_provenance",
    "execution_spec",
}
EXECUTION_SPEC_KEYS = {
    "feature_order",
    "feature_order_sha256",
    "seed",
    "hyperparameters",
    "hpo_allowed",
    "bootstrap_replicates",
    "stacking_sources",
    "model_policy",
}
MODEL_POLICY_KEYS = {
    "cnn_1d": {"backend", "optimizer", "scheduler"},
    "tabpfn_standard": {
        "backend",
        "token",
        "token_env",
        "get_model_limits_required",
        "bag_count",
        "bagging_seed",
        "max_train_rows",
    },
    "tabpfn_finetuned": {
        "baseline_predictions",
        "baseline_model",
        "baseline_spec",
        "baseline_task_manifest",
        "max_train_rows",
        "validation_monitor",
        "baseline_gate_split",
    },
    "tabpfn_thinking": {
        "accounts",
        "max_fits_per_account",
        "fallback_standard",
        "get_model_limits_required",
        "quota_reservation",
    },
    "tabicl": {
        "bag_count",
        "max_train_rows",
        "bag_fraction",
        "weight_version",
        "backend_package",
        "backend_package_version",
        "model_identifier",
        "checkpoint_identifier",
        "expected_weight_sha256",
    },
    "stacking": {"meta_learner", "inner_cv_contract", "inner_cv_splits"},
}

THINKING_GLOBAL_PLAN_CONTRACT = "p1-v2-stage3b-thinking-global-plan/4"
THINKING_RESERVATION_CONTRACT = "p1-v2-stage3b-thinking-reservation/2"
THINKING_SCHEDULER_CLAIM_CONTRACT = "p1-v2-stage3b-thinking-scheduler-claim/2"
THINKING_QUOTA_RESERVATION_KEYS = {
    "contract_version",
    "wave",
    "quota_month",
    "task_id",
    "outcome",
    "global_plan",
    "task_plan_sha256",
    "planned_fits",
    "quota_branch",
    "quota_probe_sha256",
    "artifact_classification",
    "scheduler_claim",
}
THINKING_PLANNED_FIT_KEYS = {
    "fit_index",
    "fit_name",
    "preferred_account_alias",
    "preferred_slot",
    "alternate_account_alias",
    "alternate_slot",
    "historical_completed",
}
THINKING_GLOBAL_PLAN_KEYS = {
    "contract_version",
    "wave",
    "quota_month",
    "quota_branch",
    "allocation_policy",
    "quota_probe",
    "max_fits_per_account",
    "fit_limits_by_account",
    "account_aliases",
    "planned_fit_count",
    "fresh_planned_fit_count",
    "historical_completed_fit_keys",
    "reservations",
    "global_plan_payload_sha256",
}
THINKING_GLOBAL_TASK_RESERVATION_KEYS = {
    "task_id",
    "outcome",
    "planned_fits",
    "artifact_classification",
    "task_plan_sha256",
}
THINKING_ARTIFACT_CLASSIFICATION_KEYS = {
    "quota_branch",
    "quota_limited_supplemental",
    "not_equivalent_to_full_oof",
    "full_oof",
    "stacking_eligible",
    "planned_fit_count",
    "completed_thinking_fit_count",
    "standard_fallback_count",
    "quota_probe_sha256",
    "global_plan_sha256",
}
STACKING_SOURCE_KEYS = {
    "outcome",
    "model",
    "split",
    "path",
    "sha256",
    "artifact_sha256",
    "source_task_id",
    "source_task_manifest_sha256",
    "acceptance_receipt_path",
    "acceptance_receipt_sha256",
    "lineage_id",
}


class Stage3bContractError(RuntimeError):
    pass


class Stage3bCheckpointBoundary(RuntimeError):
    def __init__(self, payload: dict[str, Any]):
        super().__init__("Stage3b stopped at the checkpoint boundary")
        self.payload = payload


@dataclass(frozen=True)
class TaskContract:
    task_id: str
    outcome: str
    model: str
    compute_target: str
    dependencies: tuple[str, ...]
    required_artifacts: tuple[str, ...]
    metadata: dict[str, Any]
    formal_training_authorized: bool
    task_registry_sha256: str | None = None
    registry_task_sha256: str | None = None

    @property
    def expected_prediction_splits(self) -> tuple[str, ...]:
        if self.model == "tabpfn_thinking" and not self.metadata.get(
            "full_oof_required",
            self.outcome in PRIMARY_OUTCOMES,
        ):
            return ("validation_2024",)
        return ("oof_2020_2023", "validation_2024")

    @property
    def stacking_eligible(self) -> bool:
        if self.model == "tabpfn_thinking":
            return bool(
                self.metadata.get(
                    "stacking_eligible",
                    self.outcome in PRIMARY_OUTCOMES,
                )
            )
        return True

    @property
    def thinking_fit_count(self) -> int:
        if self.model != "tabpfn_thinking":
            return 0
        return int(
            self.metadata.get(
                "thinking_fits",
                6 if self.outcome in PRIMARY_OUTCOMES else 1,
            )
        )


def thinking_fit_names(contract: TaskContract) -> tuple[str, ...]:
    if contract.model != "tabpfn_thinking":
        raise Stage3bContractError("thinking fit names require a thinking task")
    if contract.thinking_fit_count == 6:
        return tuple(f"oof_fold_{fold}" for fold in range(5)) + (
            "final_2020_2023",
        )
    if contract.thinking_fit_count == 1:
        return ("final_2020_2023",)
    raise Stage3bContractError("thinking fit count must equal one or six")


@dataclass(frozen=True)
class DevicePlan:
    requested: str
    execution_device: str
    preprocessing_device: str
    cuda_visible_devices: str | None
    gpu_required_for_formal: bool


@dataclass
class PreparedTaskResult:
    predictions: pd.DataFrame
    coverage: pd.DataFrame
    canary_inputs: pd.DataFrame
    canary_expected: pd.DataFrame
    model_state: Any
    feature_order: list[str]
    input_hashes: dict[str, str]
    model_provenance: dict[str, Any]
    stacking_sources: list[dict[str, Any]] | None = None
    thinking_fit_ledger: dict[str, Any] | None = None
    training_log: dict[str, Any] | None = None
    runtime_provenance: dict[str, Any] | None = None


class SyntheticProbabilityModel:
    def __init__(self, feature_order: list[str], coefficients: np.ndarray, intercept: float):
        self.feature_order = list(feature_order)
        self.coefficients = np.asarray(coefficients, dtype="float64")
        self.intercept = float(intercept)

    def predict_proba(self, values: pd.DataFrame | np.ndarray) -> np.ndarray:
        if isinstance(values, pd.DataFrame):
            matrix = values.loc[:, self.feature_order].to_numpy(dtype="float64")
        else:
            matrix = np.asarray(values, dtype="float64")
        score = np.clip(matrix @ self.coefficients + self.intercept, -30, 30)
        probability = 1.0 / (1.0 + np.exp(-score))
        return np.column_stack([1.0 - probability, probability])


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise Stage3bContractError(f"JSON root must be an object: {path}")
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_lines(values: list[str]) -> str:
    return hashlib.sha256(("\n".join(values) + "\n").encode("utf-8")).hexdigest()


def canonical_sha256(value: Any) -> str:
    encoded = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def stage3b_lineage_id(
    *,
    effective_registry_sha256: str,
    registry_rebind_receipt_sha256: str,
    package_manifest_sha256: str,
    package_lock_sha256: str,
) -> str:
    values = {
        "contract_version": STAGE3B_LINEAGE_CONTRACT,
        "effective_registry_sha256": effective_registry_sha256,
        "registry_rebind_receipt_sha256": registry_rebind_receipt_sha256,
        "package_manifest_sha256": package_manifest_sha256,
        "package_lock_sha256": package_lock_sha256,
    }
    if any(not _is_sha256(value) for key, value in values.items() if key != "contract_version"):
        raise Stage3bContractError("Stage3b lineage inputs must be SHA256 values")
    return canonical_sha256(values)


def _is_sha256(value: Any) -> bool:
    text = str(value)
    return len(text) == SHA256_PATTERN_LENGTH and all(
        character in "0123456789abcdefABCDEF" for character in text
    )


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def atomic_parquet(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp.parquet")
    frame.to_parquet(temporary, index=False)
    temporary.replace(path)


def atomic_joblib(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    joblib.dump(value, temporary)
    temporary.replace(path)


def _expected_dependencies(
    outcome: str,
    model: str,
    *,
    require_finetuned_baseline_dependency: bool = False,
    include_thinking_in_stacking: bool = False,
) -> tuple[str, ...]:
    stage3a = tuple(f"P1_05a-{outcome}-{name}" for name in P1_05A_MODELS)
    if model != "stacking":
        if model == "tabpfn_finetuned" and require_finetuned_baseline_dependency:
            return stage3a + (f"P1_05b-{outcome}-tabpfn_standard",)
        return stage3a
    remote_models = (
        REMOTE_MODELS
        if outcome in PRIMARY_OUTCOMES or include_thinking_in_stacking
        else tuple(name for name in REMOTE_MODELS if name != "tabpfn_thinking")
    )
    remote = tuple(f"P1_05b-{outcome}-{name}" for name in remote_models)
    return stage3a + remote


def _required_artifact_names(payload: dict[str, Any]) -> tuple[str, ...]:
    records = payload.get("required_artifacts")
    if not isinstance(records, list) or not records:
        raise Stage3bContractError("required_artifacts must be a non-empty list")
    names = []
    for record in records:
        if not isinstance(record, dict) or record.get("required") is not True:
            raise Stage3bContractError("every Stage3b artifact must be a required object")
        path = str(record.get("path", ""))
        if not path:
            raise Stage3bContractError("required artifact path is empty")
        names.append(Path(path).name)
    if len(names) != len(set(names)):
        raise Stage3bContractError("duplicate required artifact names")
    return tuple(names)


def validate_task_manifest(
    payload: dict[str, Any],
    *,
    require_preparation_state: bool = True,
    registry_task: dict[str, Any] | None = None,
    task_registry_sha256: str | None = None,
    require_finetuned_baseline_dependency: bool = False,
) -> TaskContract:
    prelaunch = payload.get("contract_version") == "p1-v2-prelaunch-task-manifest/1"
    if payload.get("stage") != "P1_05b" or payload.get("wave") != "W04":
        raise Stage3bContractError("task must be a P1_05b/W04 task")
    if payload.get("task_family") != "stage3b_model":
        raise Stage3bContractError("task_family must be stage3b_model")
    outcome = str(payload.get("outcome", ""))
    model = str(payload.get("model", ""))
    if outcome not in OUTCOMES or model not in MODELS:
        raise Stage3bContractError(f"unsupported outcome/model: {outcome}/{model}")
    task_id = str(payload.get("task_id", ""))
    expected_task_id = f"P1_05b-{outcome}-{model}"
    if task_id != expected_task_id:
        raise Stage3bContractError(
            f"task_id must equal outcome/model identity: expected {expected_task_id}"
        )
    compute_target = str(payload.get("compute_target", ""))
    if compute_target != COMPUTE_TARGETS[model]:
        raise Stage3bContractError(
            f"{model} compute_target must be {COMPUTE_TARGETS[model]}"
        )
    if prelaunch:
        inputs = payload.get("input_artifacts")
        if not isinstance(inputs, list) or not inputs:
            raise Stage3bContractError("prelaunch manifest lacks its numeric input binding")
        if any(record.get("deidentified") is not True for record in inputs):
            raise Stage3bContractError("Stage3b prelaunch inputs must be deidentified")
        if payload.get("scientific_artifact") is not True:
            raise Stage3bContractError("formal Stage3b tasks must target scientific artifacts")
    else:
        if payload.get("privacy_class") != "deidentified_numeric":
            raise Stage3bContractError("Stage3b accepts deidentified numeric inputs only")
        if payload.get("execution_overlay_required") is not True:
            raise Stage3bContractError("wave execution overlay is required")

    dependencies = tuple(payload.get("dependencies", ()))
    include_thinking_in_stacking = (
        model == "stacking"
        and f"P1_05b-{outcome}-tabpfn_thinking" in dependencies
    )
    if dependencies != _expected_dependencies(
        outcome,
        model,
        require_finetuned_baseline_dependency=require_finetuned_baseline_dependency,
        include_thinking_in_stacking=include_thinking_in_stacking,
    ):
        raise Stage3bContractError(
            f"{task_id} dependencies differ from the frozen outcome-family contract"
        )

    actual_artifacts = _required_artifact_names(payload)
    expected_artifacts = get_task_variant(
        "W04", "stage3b_model", model
    ).canonical_expected_artifacts
    if actual_artifacts != expected_artifacts:
        raise Stage3bContractError(
            f"{task_id} artifact contract differs: "
            f"expected={expected_artifacts} actual={actual_artifacts}"
        )

    maximum_year = payload.get("maximum_year")
    if maximum_year not in (None, 2024):
        raise Stage3bContractError("maximum_year must be 2024")
    access_count = payload.get("2025_access_count")
    if access_count not in (None, 0):
        raise Stage3bContractError("2025_access_count must be zero")
    leakage = payload.get("strict_no_arrival_leakage")
    if leakage not in (None, True):
        raise Stage3bContractError("strict_no_arrival_leakage must be true")
    formal_authorized = payload.get("formal_training_authorized") is True
    if require_preparation_state and formal_authorized:
        raise Stage3bContractError("preparation manifests cannot authorize formal training")

    metadata = dict(payload.get("metadata") or {})
    registry_task_sha256: str | None = None
    if prelaunch:
        if registry_task is None or task_registry_sha256 is None:
            raise Stage3bContractError(
                "prelaunch task manifest must be bound to its frozen registry task/hash"
            )
        registry_contract = validate_task_manifest(
            registry_task,
            require_finetuned_baseline_dependency=require_finetuned_baseline_dependency,
        )
        compared = (
            "task_id",
            "outcome",
            "model",
            "compute_target",
            "dependencies",
            "required_artifacts",
        )
        current_values = {
            "task_id": task_id,
            "outcome": outcome,
            "model": model,
            "compute_target": compute_target,
            "dependencies": dependencies,
            "required_artifacts": actual_artifacts,
        }
        for field in compared:
            if current_values[field] != getattr(registry_contract, field):
                raise Stage3bContractError(
                    f"prelaunch manifest differs from frozen registry field: {field}"
                )
        source_registry_hash = str(payload.get("source_hashes", {}).get("task_registry", ""))
        if source_registry_hash != task_registry_sha256:
            raise Stage3bContractError("prelaunch manifest task-registry hash differs")
        metadata = dict(registry_contract.metadata)
        registry_task_sha256 = canonical_sha256(registry_task)
    expected_phase = "W04_LOCAL" if model == "stacking" else "W04_REMOTE"
    expected_cv_folds = 5
    if model == "tabpfn_thinking":
        expected_cv_folds = int(
            metadata.get(
                "cv_folds",
                5 if outcome in PRIMARY_OUTCOMES else 0,
            )
        )
        if expected_cv_folds not in {0, 5}:
            raise Stage3bContractError("thinking cv_folds must be zero or five")
    if metadata.get("cv_folds") != expected_cv_folds:
        raise Stage3bContractError(
            f"Stage3b metadata must lock {expected_cv_folds} CV folds"
        )
    if metadata.get("execution_phase") != expected_phase:
        raise Stage3bContractError(f"{model} execution phase must be {expected_phase}")
    if model == "tabpfn_thinking":
        branch = metadata.get("thinking_quota_branch")
        if branch is None:
            branch = (
                "quota_limited_supplemental"
                if outcome not in PRIMARY_OUTCOMES
                else "legacy_primary_full_oof"
            )
        full_oof = expected_cv_folds == 5
        supplemental = branch == "quota_limited_supplemental" and not full_oof
        expected_fits = 6 if full_oof else 1
        if metadata and metadata.get("thinking_fits") != expected_fits:
            raise Stage3bContractError(
                f"{task_id} thinking_fits must equal {expected_fits}"
            )
        if metadata and metadata.get("final_fits") != 1:
            raise Stage3bContractError("thinking final_fits must equal one")
        if metadata and metadata.get("stacking_eligible") is not full_oof:
            raise Stage3bContractError("thinking stacking eligibility is not canonical")
        if "thinking_quota_branch" in metadata:
            expected_classification = {
                "quota_limited_supplemental": supplemental,
                "not_equivalent_to_full_oof": supplemental,
                "full_oof_required": full_oof,
            }
            if branch not in {"full_9_outcome_oof", "quota_limited_supplemental"}:
                raise Stage3bContractError("thinking quota branch is not canonical")
            if any(metadata.get(key) is not value for key, value in expected_classification.items()):
                raise Stage3bContractError("thinking artifact classification metadata differs")
            for key in ("thinking_task_plan_sha256", "thinking_quota_probe_sha256"):
                if not _is_sha256(metadata.get(key)):
                    raise Stage3bContractError("thinking quota metadata hash differs")
        metadata = {
            **metadata,
            "thinking_fits": expected_fits,
            "final_fits": 1,
            "stacking_eligible": full_oof,
            "full_oof_required": full_oof,
            "quota_limited_supplemental": supplemental,
            "not_equivalent_to_full_oof": supplemental,
        }
    if model == "stacking" and metadata and metadata.get("local_only") is not True:
        raise Stage3bContractError("stacking must be marked local_only")
    if model == "stacking":
        metadata = {**metadata, "local_only": True}

    return TaskContract(
        task_id=task_id,
        outcome=outcome,
        model=model,
        compute_target=compute_target,
        dependencies=dependencies,
        required_artifacts=actual_artifacts,
        metadata=metadata,
        formal_training_authorized=formal_authorized,
        task_registry_sha256=task_registry_sha256,
        registry_task_sha256=registry_task_sha256,
    )


def load_bound_task_contract(
    task_manifest_path: Path,
    task_registry_path: Path,
    registry_rebind_receipt_path: Path | None = None,
) -> tuple[TaskContract, dict[str, Any]]:
    rebind_receipt = None
    if registry_rebind_receipt_path is not None:
        from scripts.build_p1_v2_stage3_effective_registry import validate_rebind_bundle

        rebind_root = registry_rebind_receipt_path.resolve().parent
        expected_effective = rebind_root / "task_registry.json"
        if task_registry_path.resolve() != expected_effective.resolve():
            raise Stage3bContractError("formal task registry is not the validated effective registry")
        try:
            rebind_receipt = validate_rebind_bundle(
                base_registry_path=rebind_root / "base_task_registry.json",
                effective_registry_path=expected_effective,
                extension_path=rebind_root / "stage3_registry_extension.json",
                receipt_path=registry_rebind_receipt_path,
            )
        except Exception as error:
            raise Stage3bContractError("Stage3 effective-registry rebind is invalid") from error
    manifest = read_json(task_manifest_path)
    registry = read_json(task_registry_path)
    registry_hash = sha256_file(task_registry_path)
    matches = [
        task
        for task in registry.get("tasks", [])
        if isinstance(task, dict) and task.get("task_id") == manifest.get("task_id")
    ]
    if len(matches) != 1:
        raise Stage3bContractError("prelaunch task does not have one frozen registry record")
    if rebind_receipt is not None:
        source_hashes = manifest.get("source_hashes", {})
        required_source_hashes = {
            "base_task_registry_sha256": rebind_receipt["base_registry_sha256"],
            "stage3_effective_registry_sha256": rebind_receipt[
                "effective_registry_sha256"
            ],
            "stage3_registry_extension_sha256": rebind_receipt["extension_sha256"],
            "stage3_registry_rebind_receipt_sha256": sha256_file(
                registry_rebind_receipt_path
            ),
        }
        if any(source_hashes.get(key) != value for key, value in required_source_hashes.items()):
            raise Stage3bContractError("prelaunch manifest lacks the exact Stage3 registry rebind")
    return (
        validate_task_manifest(
            manifest,
            registry_task=matches[0],
            task_registry_sha256=registry_hash,
            require_finetuned_baseline_dependency=rebind_receipt is not None,
        ),
        manifest,
    )


def validate_registry_cross_product(registry: dict[str, Any]) -> list[TaskContract]:
    tasks = [
        task
        for task in registry.get("tasks", [])
        if isinstance(task, dict) and task.get("stage") == "P1_05b"
    ]
    contracts = [validate_task_manifest(task) for task in tasks]
    identities = [(contract.outcome, contract.model) for contract in contracts]
    expected = [(outcome, model) for outcome in OUTCOMES for model in MODELS]
    if len(contracts) != 54 or sorted(identities) != sorted(expected):
        raise Stage3bContractError("P1_05b registry must contain the exact 9x6 cross-product")
    return sorted(contracts, key=lambda value: value.task_id)


def resolve_device_plan(
    contract: TaskContract,
    requested: str,
    *,
    formal: bool,
    cuda_available: bool | None = None,
) -> DevicePlan:
    if requested not in {"auto", "cpu", "cuda"}:
        raise Stage3bContractError(f"unsupported device request: {requested}")
    visible = os.environ.get("CUDA_VISIBLE_DEVICES")
    if contract.compute_target == "kaggle_api":
        return DevicePlan(requested, "api", "cpu", visible, False)
    if contract.model == "stacking":
        if requested == "cuda":
            raise Stage3bContractError("local stacking is a CPU execution unit")
        return DevicePlan(requested, "cpu", "cpu", visible, False)
    if cuda_available is None:
        try:
            import torch

            cuda_available = bool(torch.cuda.is_available())
        except ImportError:
            cuda_available = False
    execution_device = "cuda" if requested in {"auto", "cuda"} and cuda_available else "cpu"
    if requested == "cuda" and not cuda_available:
        raise Stage3bContractError("CUDA was requested but is unavailable")
    if formal and execution_device != "cuda":
        raise Stage3bContractError(f"formal {contract.model} execution requires a GPU")
    return DevicePlan(requested, execution_device, "cpu", visible, True)


def validate_no_future_data(frame: pd.DataFrame) -> None:
    if "split_year" in frame:
        year = pd.to_numeric(frame["split_year"], errors="coerce")
        if year.isna().any() or year.gt(2024).any():
            raise Stage3bContractError("Stage3b refuses rows later than 2024")
    if "split" in frame:
        allowed = {"train_2020_2023", "validation_2024", "oof_2020_2023"}
        observed = set(frame["split"].dropna().astype(str))
        if not observed <= allowed:
            raise Stage3bContractError(f"Stage3b refuses split values: {sorted(observed - allowed)}")
    future_columns = [column for column in frame if "2025" in str(column).casefold()]
    if future_columns:
        raise Stage3bContractError(f"Stage3b refuses future-holdout columns: {future_columns}")


def _validated_thinking_plan(
    plan_path: Path,
    *,
    expected_month: str,
) -> dict[str, Any]:
    from scripts import build_stage3b_thinking_quota_plan as thinking_quota

    plan = read_json(plan_path)
    try:
        return thinking_quota.validate_plan(
            plan,
            plan_path=plan_path,
            expected_month=expected_month,
            require_fresh=True,
        )
    except Exception as error:
        raise Stage3bContractError("thinking official quota plan is invalid") from error


def _validate_thinking_scheduler_claim(
    contract: TaskContract,
    reservation: dict[str, Any],
    workspace_root: Path,
) -> dict[str, Any]:
    claim_path = _bound_file(
        reservation["scheduler_claim"],
        workspace_root,
        label="thinking scheduler claim",
    )
    claim = read_json(claim_path)
    required = {
        "contract_version",
        "status",
        "wave",
        "quota_month",
        "quota_branch",
        "quota_probe_sha256",
        "artifact_classification",
        "task_id",
        "outcome",
        "task_plan_sha256",
        "claim_id",
        "owner_alias",
        "launch_receipt",
        "duplicate_launch_count",
        "same_owner_resume_only",
        "claim_payload_sha256",
    }
    if not required <= set(claim):
        raise Stage3bContractError("thinking scheduler claim schema differs")
    unhashed = dict(claim)
    claimed_hash = unhashed.pop("claim_payload_sha256", None)
    if (
        claim.get("contract_version") != THINKING_SCHEDULER_CLAIM_CONTRACT
        or claim.get("status") != "CLAIMED"
        or claim.get("wave") != "W04"
        or claim.get("quota_month") != reservation.get("quota_month")
        or claim.get("quota_branch") != reservation.get("quota_branch")
        or claim.get("quota_probe_sha256")
        != reservation.get("quota_probe_sha256")
        or claim.get("artifact_classification")
        != reservation.get("artifact_classification")
        or claim.get("task_id") != contract.task_id
        or claim.get("outcome") != contract.outcome
        or claim.get("task_plan_sha256") != reservation.get("task_plan_sha256")
        or not isinstance(claim.get("claim_id"), str)
        or not claim["claim_id"]
        or not isinstance(claim.get("owner_alias"), str)
        or not claim["owner_alias"]
        or claim.get("duplicate_launch_count") != 0
        or claim.get("same_owner_resume_only") is not True
        or not _is_sha256(claimed_hash)
        or claimed_hash != canonical_sha256(unhashed)
    ):
        raise Stage3bContractError("thinking scheduler claim identity/self-hash differs")
    launch_path = _bound_file(
        claim["launch_receipt"],
        workspace_root,
        label="thinking scheduler launch receipt",
    )
    launch = read_json(launch_path)
    if (
        launch.get("status") not in {"LAUNCHED", "RESUME"}
        or launch.get("task_id") != contract.task_id
        or launch.get("outcome") != contract.outcome
        or launch.get("claim_id") != claim["claim_id"]
        or launch.get("owner_alias") != claim["owner_alias"]
        or launch.get("launch_count") != 1
        or launch.get("quota_branch") != reservation.get("quota_branch")
        or launch.get("quota_probe_sha256")
        != reservation.get("quota_probe_sha256")
        or launch.get("artifact_classification")
        != reservation.get("artifact_classification")
    ):
        raise Stage3bContractError("thinking scheduler launch receipt differs")
    return {
        "claim_id": claim["claim_id"],
        "owner_alias": claim["owner_alias"],
        "status": launch["status"],
        "quota_branch": claim["quota_branch"],
        "quota_probe_sha256": claim["quota_probe_sha256"],
        "artifact_classification": claim["artifact_classification"],
        "claim_receipt_sha256": sha256_file(claim_path),
        "launch_receipt_sha256": sha256_file(launch_path),
    }


def _validate_thinking_quota_reservation(
    contract: TaskContract,
    policy: dict[str, Any],
    workspace_root: Path,
) -> dict[str, Any]:
    reservation = policy.get("quota_reservation")
    if (
        not isinstance(reservation, dict)
        or set(reservation) != THINKING_QUOTA_RESERVATION_KEYS
    ):
        raise Stage3bContractError("thinking quota reservation schema differs")
    current_month = dt.datetime.now(dt.UTC).strftime("%Y-%m")
    if (
        reservation.get("contract_version") != THINKING_RESERVATION_CONTRACT
        or reservation.get("wave") != "W04"
        or reservation.get("quota_month") != current_month
        or reservation.get("task_id") != contract.task_id
        or reservation.get("outcome") != contract.outcome
    ):
        raise Stage3bContractError("thinking quota reservation identity/month differs")
    scheduler_claim = _validate_thinking_scheduler_claim(
        contract, reservation, workspace_root
    )
    plan_path = _bound_file(
        reservation["global_plan"], workspace_root, label="thinking global quota plan"
    )
    plan = _validated_thinking_plan(plan_path, expected_month=current_month)
    if set(plan) != THINKING_GLOBAL_PLAN_KEYS:
        raise Stage3bContractError("thinking global quota plan schema differs")
    if (
        plan.get("contract_version") != THINKING_GLOBAL_PLAN_CONTRACT
        or plan.get("max_fits_per_account") != policy.get("max_fits_per_account")
    ):
        raise Stage3bContractError("thinking global quota plan identity differs")
    aliases = plan.get("account_aliases")
    policy_aliases = [record.get("account_alias") for record in policy.get("accounts", [])]
    if aliases != policy_aliases:
        raise Stage3bContractError("thinking global quota plan account order differs")
    expected = plan["reservations"]
    if any(
        set(task_slice) != THINKING_GLOBAL_TASK_RESERVATION_KEYS
        or any(
            not isinstance(fit, dict) or set(fit) != THINKING_PLANNED_FIT_KEYS
            for fit in task_slice.get("planned_fits", [])
        )
        for task_slice in plan["reservations"].values()
    ):
        raise Stage3bContractError("thinking global quota task-slice schema differs")
    occupied: set[tuple[str, int]] = set()
    historical_observed: set[str] = set()
    probe_path = plan_path.parent / str(plan["quota_probe"]["path"])
    probe = read_json(probe_path)
    probe_accounts = {record["account_alias"]: record for record in probe["accounts"]}
    counters = {
        str(record["account_alias"]): int(record["counter_before"])
        for record in policy["accounts"]
    }
    limits = {
        str(record["account_alias"]): int(record["quota_limit"])
        for record in policy["accounts"]
    }
    if any(
        alias not in probe_accounts
        or counters[alias] != int(probe_accounts[alias]["fits_used"])
        or limits[alias] != int(probe_accounts[alias]["quota_limit"])
        for alias in counters
    ) or limits != plan.get("fit_limits_by_account"):
        raise Stage3bContractError("thinking policy counters differ from official quota probe")
    for task_slice in expected.values():
        for fit in task_slice["planned_fits"]:
            fit_key = f"{task_slice['task_id']}::{fit['fit_name']}"
            if fit["historical_completed"]:
                if any(
                    fit[name] is not None
                    for name in (
                        "preferred_account_alias",
                        "preferred_slot",
                        "alternate_account_alias",
                        "alternate_slot",
                    )
                ):
                    raise Stage3bContractError(
                        "historical thinking fit must not consume a fresh quota slot"
                    )
                historical_observed.add(fit_key)
                continue
            for prefix in ("preferred", "alternate"):
                alias = fit[f"{prefix}_account_alias"]
                slot = fit[f"{prefix}_slot"]
                if alias is None and slot is None:
                    continue
                if alias not in counters or not isinstance(slot, int) or slot < 0:
                    raise Stage3bContractError("thinking quota plan contains an invalid slot")
                key = (alias, slot)
                if key in occupied:
                    raise Stage3bContractError("thinking quota plan reuses an account slot")
                occupied.add(key)
                if slot >= int(probe_accounts[alias]["fits_remaining"]):
                    raise Stage3bContractError("thinking quota reservation exceeds account capacity")
    if historical_observed != set(plan["historical_completed_fit_keys"]):
        raise Stage3bContractError("historical thinking fit lineage differs")
    # historical_observed spans the whole plan, but the scheduler claim is issued per task. Pairing
    # them directly makes every non-P1 outcome unsatisfiable once P1's folds are marked historical:
    # the plan demands RESUME while execute_formal_task demands LAUNCHED for a task with nothing to
    # resume. The guard's intent is that a task reusing historical fits must run as a resume.
    task_historical = {
        key for key in historical_observed if key.startswith(f"{contract.task_id}::")
    }
    if task_historical and scheduler_claim.get("status") != "RESUME":
        raise Stage3bContractError("historical thinking fits require a resume claim")
    if len(occupied) != plan["fresh_planned_fit_count"]:
        raise Stage3bContractError("fresh thinking reservation count differs")
    task_slice = expected[contract.task_id]
    classification = task_slice["artifact_classification"]
    if (
        reservation.get("planned_fits") != task_slice["planned_fits"]
        or reservation.get("task_plan_sha256") != task_slice["task_plan_sha256"]
        or reservation.get("quota_branch") != plan["quota_branch"]
        or reservation.get("quota_probe_sha256") != plan["quota_probe"]["sha256"]
        or reservation.get("artifact_classification") != classification
        or classification.get("planned_fit_count") != contract.thinking_fit_count
        or classification.get("stacking_eligible") is not contract.stacking_eligible
        or classification.get("quota_limited_supplemental")
        is not bool(contract.metadata.get("quota_limited_supplemental", False))
        or classification.get("not_equivalent_to_full_oof")
        is not bool(contract.metadata.get("not_equivalent_to_full_oof", False))
    ):
        raise Stage3bContractError("thinking task reservation differs from the global plan")
    return reservation


def _validate_model_policy(
    contract: TaskContract,
    policy: Any,
    parameters: dict[str, Any],
    workspace_root: Path,
) -> dict[str, Any]:
    if not isinstance(policy, dict) or set(policy) != MODEL_POLICY_KEYS[contract.model]:
        raise Stage3bContractError(
            f"{contract.model} model_policy keys differ from the frozen schema"
        )
    if contract.model == "cnn_1d":
        if policy != {
            "backend": "torch",
            "optimizer": "AdamW",
            "scheduler": "OneCycleLR",
        }:
            raise Stage3bContractError("CNN policy must lock torch/AdamW/OneCycleLR")
        if (
            parameters.get("proj_dim") not in {1024, 2048, 4096}
            or parameters.get("channels") not in {128, 256, 512}
            or parameters.get("n_conv") not in {2, 3, 4}
            or parameters.get("kernel") not in {3, 5, 7}
        ):
            raise Stage3bContractError("CNN hyperparameters leave the prompt search space")
        epochs = parameters.get("epochs", 20)
        batch_size = parameters.get("batch_size", 256)
        patience = parameters.get("early_stopping_patience", 5)
        minimum_epochs = parameters.get("minimum_epochs")
        if minimum_epochs is None and isinstance(epochs, int) and not isinstance(epochs, bool):
            minimum_epochs = min(5, epochs)
        if (
            isinstance(epochs, bool)
            or not isinstance(epochs, int)
            or epochs < 1
            or isinstance(batch_size, bool)
            or not isinstance(batch_size, int)
            or batch_size < 1
            or isinstance(patience, bool)
            or not isinstance(patience, int)
            or patience < 1
            or isinstance(minimum_epochs, bool)
            or not isinstance(minimum_epochs, int)
            or not 1 <= minimum_epochs <= epochs
        ):
            raise Stage3bContractError("CNN convergence controls are invalid")
    elif contract.model == "tabpfn_standard":
        if policy.get("backend") not in {"cloud", "local"}:
            raise Stage3bContractError("TabPFN standard backend must be cloud/local")
        if policy.get("token") is not None and not isinstance(policy.get("token"), str):
            raise Stage3bContractError("TabPFN standard token must be text/null")
        if policy.get("token_env") is not None and not isinstance(
            policy.get("token_env"), str
        ):
            raise Stage3bContractError("TabPFN standard token_env must be text/null")
        if policy.get("backend") == "cloud" and not (
            policy.get("token") or policy.get("token_env")
        ):
            raise Stage3bContractError("cloud TabPFN requires token or token_env")
        if policy.get("get_model_limits_required") is not (
            policy.get("backend") == "cloud"
        ):
            raise Stage3bContractError("cloud TabPFN must call get_model_limits")
        if not isinstance(policy.get("bag_count"), int) or policy["bag_count"] < 2:
            raise Stage3bContractError("TabPFN bag_count must be at least two")
        if not isinstance(policy.get("bagging_seed"), int):
            raise Stage3bContractError("TabPFN bagging seed must be an integer")
        maximum = policy.get("max_train_rows")
        if maximum is not None and (not isinstance(maximum, int) or maximum < 2):
            raise Stage3bContractError("TabPFN max_train_rows is invalid")
        if parameters.get("n_estimators", 8) > 8:
            raise Stage3bContractError("cloud TabPFN n_estimators must not exceed eight")
    elif contract.model == "tabpfn_finetuned":
        for name in (
            "baseline_predictions",
            "baseline_model",
            "baseline_spec",
            "baseline_task_manifest",
        ):
            _bound_file(policy[name], workspace_root, label=f"fine-tune {name}")
        if (
            policy.get("validation_monitor")
            != FINETUNE_VALIDATION_MONITOR_POLICY
            or policy.get("baseline_gate_split") != FINETUNE_BASELINE_GATE_SPLIT
            or not isinstance(policy.get("max_train_rows"), int)
            or policy["max_train_rows"] < 2
        ):
            raise Stage3bContractError("fine-tune validation/subsampling policy differs")
        epochs = parameters.get("epochs")
        learning_rate = parameters.get("learning_rate")
        if (
            not isinstance(epochs, int)
            or not 10 <= epochs <= 100
            or not isinstance(learning_rate, (int, float))
            or not 1e-6 <= float(learning_rate) <= 1e-3
        ):
            raise Stage3bContractError("fine-tune epochs/learning rate are invalid")
    elif contract.model == "tabpfn_thinking":
        maximum = policy.get("max_fits_per_account")
        if isinstance(maximum, bool) or not isinstance(maximum, int) or maximum < 1:
            raise Stage3bContractError("thinking account quota is invalid")
        if policy.get("get_model_limits_required") is not True:
            raise Stage3bContractError("thinking must call get_model_limits")
        accounts = policy.get("accounts")
        if not isinstance(accounts, list) or not accounts:
            raise Stage3bContractError("thinking requires live-probed account records")
        account_keys = {
            "account_alias",
            "token_env",
            "token",
            "counter_before",
            "quota_limit",
        }
        aliases = []
        tokens = []
        for account in accounts:
            if not isinstance(account, dict) or set(account) != account_keys:
                raise Stage3bContractError("thinking account schema differs")
            if (
                not isinstance(account.get("account_alias"), str)
                or not account["account_alias"]
                or not isinstance(account.get("token_env"), str)
                or not isinstance(account.get("counter_before"), int)
                or not isinstance(account.get("quota_limit"), int)
                or not 1 <= account["quota_limit"] <= maximum
                or not 0 <= account["counter_before"] <= account["quota_limit"]
            ):
                raise Stage3bContractError("thinking account record is invalid")
            token = account.get("token") or os.environ.get(account["token_env"])
            if not isinstance(token, str) or not token:
                raise Stage3bContractError("thinking account token is unavailable")
            aliases.append(account["account_alias"])
            tokens.append(token)
        if len(set(aliases)) != len(accounts) or len(set(tokens)) != len(accounts):
            raise Stage3bContractError("thinking accounts/tokens must be distinct")
        fallback = policy.get("fallback_standard")
        if not isinstance(fallback, dict) or set(fallback) != {"backend", "token_env", "token"}:
            raise Stage3bContractError("thinking fallback-standard schema differs")
        if fallback.get("backend") != "cloud":
            raise Stage3bContractError("thinking fallback must use standard cloud TabPFN")
        _validate_thinking_quota_reservation(contract, policy, workspace_root)
        if parameters.get("thinking_mode") is not True:
            raise Stage3bContractError("thinking mode must be explicitly enabled")
        if parameters.get("thinking_metric") != "roc_auc":
            raise Stage3bContractError("thinking metric must equal roc_auc")
        if parameters.get("thinking_effort") not in {"medium", "high"}:
            raise Stage3bContractError("thinking effort must be medium/high")
        if parameters.get("n_estimators", 8) > 8:
            raise Stage3bContractError("thinking n_estimators must not exceed eight")
    elif contract.model == "tabicl":
        if (
            not isinstance(policy.get("bag_count"), int)
            or policy["bag_count"] < 2
            or not isinstance(policy.get("max_train_rows"), int)
            or policy["max_train_rows"] < 2
            or not isinstance(policy.get("bag_fraction"), (int, float))
            or not 0 < float(policy["bag_fraction"]) < 1
            or not isinstance(policy.get("weight_version"), str)
            or not policy["weight_version"]
            or policy.get("backend_package") != "tabicl"
            or not isinstance(policy.get("backend_package_version"), str)
            or not policy["backend_package_version"]
            or policy.get("model_identifier") != "TabICLClassifier"
            or not isinstance(policy.get("checkpoint_identifier"), str)
            or not policy["checkpoint_identifier"]
            or policy["weight_version"] != policy["checkpoint_identifier"]
            or not _is_sha256(policy.get("expected_weight_sha256"))
        ):
            raise Stage3bContractError("TabICL stratified-bagging policy differs")
    elif (
        policy.get("meta_learner") != "LogisticRegressionCV"
        or policy.get("inner_cv_contract") != "group_fold_predefined_v1"
        or policy.get("inner_cv_splits") != {"outer_fit": 4, "final_fit": 5}
    ):
        raise Stage3bContractError("stacking meta-learner/fixed-fold policy differs")
    return policy


def _model_feature_order_from_schema(schema: dict[str, Any]) -> list[str]:
    records = schema.get("features")
    if not isinstance(records, list) or not records:
        raise Stage3bContractError("feature schema lacks ordered feature records")
    excluded_value = schema.get("model_output_excluded_features", {})
    if isinstance(excluded_value, dict):
        excluded = set(excluded_value)
    elif isinstance(excluded_value, list):
        excluded = set(excluded_value)
    else:
        raise Stage3bContractError("feature schema model-output exclusions differ")
    structural = schema.get("structurally_unusable_features", [])
    if not isinstance(structural, list):
        raise Stage3bContractError("feature schema structural exclusions differ")
    structural_set = set(structural)
    order = []
    seen = set()
    for record in records:
        if not isinstance(record, dict) or not isinstance(record.get("name"), str):
            raise Stage3bContractError("feature schema record is invalid")
        name = record["name"]
        if name in seen:
            raise Stage3bContractError("feature schema contains duplicate names")
        seen.add(name)
        if (
            record.get("model_feature") is True
            and record.get("structurally_unusable") is not True
            and name not in structural_set
            and name not in excluded
        ):
            order.append(name)
    if schema.get("model_feature_count") != len(order):
        raise Stage3bContractError("feature schema model_feature_count differs")
    return order


def _validate_finetune_baseline_bindings(
    contract: TaskContract,
    policy: dict[str, Any],
    feature_order: list[str],
    workspace_root: Path,
) -> None:
    paths = {
        name: _bound_file(policy[name], workspace_root, label=f"fine-tune {name}")
        for name in (
            "baseline_predictions",
            "baseline_model",
            "baseline_spec",
            "baseline_task_manifest",
        )
    }
    manifest = read_json(paths["baseline_task_manifest"])
    spec = read_json(paths["baseline_spec"])
    task_id = f"P1_05b-{contract.outcome}-tabpfn_standard"
    hashes = manifest.get("artifact_hashes", {})
    if (
        manifest.get("task_id") != task_id
        or manifest.get("model") != "tabpfn_standard"
        or manifest.get("status") != "PASS"
        or manifest.get("scientific_artifact") is not True
        or manifest.get("maximum_year") != 2024
        or manifest.get("2025_access_count") != 0
        or any(
            hashes.get(path.name) != sha256_file(path)
            for name, path in paths.items()
            if name != "baseline_task_manifest"
        )
        or spec.get("task_id") != task_id
        or spec.get("model") != "tabpfn_standard"
        or spec.get("feature_order") != feature_order
        or spec.get("feature_order_sha256") != sha256_lines(feature_order)
    ):
        raise Stage3bContractError("fine-tune baseline bindings are not accepted/locked")
    predictions = pd.read_parquet(paths["baseline_predictions"])
    if (
        predictions.columns.tolist() != PREDICTION_COLUMNS
        or set(predictions["outcome"].astype(str)) != {contract.outcome}
        or set(predictions["model"].astype(str)) != {"tabpfn_standard"}
        or set(predictions["split"].astype(str))
        != {"oof_2020_2023", "validation_2024"}
        or predictions.duplicated(["row_hash", "split"]).any()
    ):
        raise Stage3bContractError("fine-tune baseline predictions differ")


def validate_authorization(
    contract: TaskContract,
    authorization: dict[str, Any],
    *,
    task_manifest_sha256: str,
    workspace_root: Path = ROOT,
) -> dict[str, Any]:
    if set(authorization) != AUTHORIZATION_KEYS:
        raise Stage3bContractError("formal authorization keys differ from the exact schema")
    if authorization.get("contract_version") != AUTHORIZATION_CONTRACT:
        raise Stage3bContractError("formal authorization contract version differs")
    unhashed = dict(authorization)
    claimed_authorization_hash = unhashed.pop("authorization_sha256", None)
    if not _is_sha256(claimed_authorization_hash) or claimed_authorization_hash != canonical_sha256(
        unhashed
    ):
        raise Stage3bContractError("formal authorization self hash differs")
    if authorization.get("runner_sha256") != sha256_file(Path(__file__).resolve()):
        raise Stage3bContractError("formal authorization runner hash differs")
    if authorization.get("status") != "PASS":
        raise Stage3bContractError("formal authorization status must be PASS")
    if authorization.get("formal_training_authorized") is not True:
        raise Stage3bContractError("formal training has not been authorized")
    if authorization.get("task_id") != contract.task_id:
        raise Stage3bContractError("authorization belongs to another task")
    if authorization.get("prelaunch_task_manifest_sha256") != task_manifest_sha256:
        raise Stage3bContractError("authorization task-manifest hash mismatch")
    if authorization.get("maximum_year") != 2024:
        raise Stage3bContractError("authorization does not lock the maximum year to 2024")
    if authorization.get("2025_access_count") != 0:
        raise Stage3bContractError("authorization does not certify zero future access")
    if authorization.get("strict_no_arrival_leakage") is not True:
        raise Stage3bContractError("authorization does not certify no-arrival leakage")
    if authorization.get("task_registry_sha256") != contract.task_registry_sha256:
        raise Stage3bContractError("authorization task-registry hash mismatch")
    if authorization.get("registry_task_sha256") != contract.registry_task_sha256:
        raise Stage3bContractError("authorization registry-task hash mismatch")
    research_contracts = authorization.get("research_contracts")
    if not isinstance(research_contracts, dict) or set(research_contracts) != {
        "prompt",
        "prompt_lock",
    }:
        raise Stage3bContractError("authorization research-contract bindings differ")
    prompt_path = _bound_file(
        research_contracts["prompt"], workspace_root, label="P1_05b prompt"
    )
    prompt_lock_path = _bound_file(
        research_contracts["prompt_lock"], workspace_root, label="prompt lock"
    )
    if prompt_path.name != "P1_05b_Stage3b_CNN與TabPFN.md":
        raise Stage3bContractError("authorization binds another research prompt")
    prompt_lock = read_json(prompt_lock_path)
    if not any(
        record.get("sha256") == sha256_file(prompt_path)
        for record in prompt_lock.get("prompts", [])
        if isinstance(record, dict)
    ):
        raise Stage3bContractError("prompt lock does not contain the bound P1_05b prompt")
    accepted = authorization.get("accepted_dependency_tasks")
    if not isinstance(accepted, dict) or set(accepted) != set(contract.dependencies):
        raise Stage3bContractError("authorization does not bind every dependency exactly")
    workspace_root = workspace_root.resolve()
    for dependency, binding in accepted.items():
        if not isinstance(binding, dict) or binding.get("status") != "PASS":
            raise Stage3bContractError(f"accepted dependency is not PASS: {dependency}")
        receipt_path = _bound_file(
            binding,
            workspace_root,
            label=f"accepted dependency {dependency}",
        )
        receipt = read_json(receipt_path)
        if receipt.get("task_id") != dependency:
            raise Stage3bContractError(
                f"dependency receipt belongs to another task: {dependency}"
            )
        if receipt.get("status") != "PASS":
            raise Stage3bContractError(f"dependency receipt is not accepted: {dependency}")
        if receipt.get("scientific_artifact") is not True:
            raise Stage3bContractError(
                f"dependency receipt is not a scientific artifact: {dependency}"
            )
        if receipt.get("maximum_year") != 2024 or receipt.get("2025_access_count") != 0:
            raise Stage3bContractError(
                f"dependency receipt violates the temporal contract: {dependency}"
            )
        if receipt.get("strict_no_arrival_leakage") is not True:
            raise Stage3bContractError(
                f"dependency receipt violates the leakage contract: {dependency}"
            )
    input_artifacts = authorization.get("input_artifacts")
    if not isinstance(input_artifacts, dict):
        raise Stage3bContractError("authorization lacks formal input artifacts")
    required_inputs = {"features", "fold_map", "feature_schema"}
    if set(input_artifacts) != required_inputs:
        raise Stage3bContractError("formal input artifacts must be exact features/fold_map")
    resolved_inputs = {
        name: _bound_file(binding, workspace_root, label=f"formal input {name}")
        for name, binding in input_artifacts.items()
    }
    package_provenance = authorization.get("package_provenance")
    if (
        not isinstance(package_provenance, dict)
        or set(package_provenance) != PACKAGE_PROVENANCE_KEYS
    ):
        raise Stage3bContractError("authorization package provenance differs")
    for name, binding in package_provenance.items():
        _bound_file(binding, workspace_root, label=f"package provenance {name}")
    execution_spec = authorization.get("execution_spec")
    if not isinstance(execution_spec, dict) or set(execution_spec) != EXECUTION_SPEC_KEYS:
        raise Stage3bContractError("authorization execution spec keys differ")
    features = execution_spec.get("feature_order")
    if not isinstance(features, list) or not features or len(features) != len(set(features)):
        raise Stage3bContractError("execution spec feature order is empty or duplicated")
    if execution_spec.get("feature_order_sha256") != sha256_lines(features):
        raise Stage3bContractError("execution spec feature-order hash differs")
    schema_feature_order = _model_feature_order_from_schema(
        read_json(resolved_inputs["feature_schema"])
    )
    if contract.model != "stacking" and features != schema_feature_order:
        raise Stage3bContractError("execution feature order differs from frozen feature schema")
    seed = execution_spec.get("seed")
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise Stage3bContractError("execution spec seed must be an integer")
    parameters = execution_spec.get("hyperparameters")
    if not isinstance(parameters, dict):
        raise Stage3bContractError("execution spec hyperparameters must be locked")
    expected_hpo_allowed = contract.model == "cnn_1d"
    if execution_spec.get("hpo_allowed") is not expected_hpo_allowed:
        raise Stage3bContractError(
            "formal Stage3b HPO permission differs from the model contract"
        )
    bootstrap_replicates = execution_spec.get("bootstrap_replicates")
    if (
        not isinstance(bootstrap_replicates, int)
        or bootstrap_replicates < 2000
    ):
        raise Stage3bContractError("formal metrics require at least 2,000 bootstrap replicates")
    stacking_sources = execution_spec.get("stacking_sources")
    if not isinstance(stacking_sources, list):
        raise Stage3bContractError("stacking_sources must always be an array")
    if contract.model == "stacking":
        validate_stacking_sources(
            contract, stacking_sources, workspace_root=workspace_root
        )
        if tuple(features) != stacking_feature_models(
            contract.outcome,
            contract.dependencies,
        ):
            raise Stage3bContractError("stacking feature order differs from accepted OOF sources")
    elif stacking_sources:
        raise Stage3bContractError("non-stacking tasks must not bind stacking sources")
    model_policy = _validate_model_policy(
        contract,
        execution_spec.get("model_policy"),
        parameters,
        workspace_root,
    )
    if contract.model == "tabpfn_finetuned":
        _validate_finetune_baseline_bindings(
            contract, model_policy, features, workspace_root
        )
    return authorization


def _is_windows_drive_absolute(path: PureWindowsPath) -> bool:
    return (
        path.is_absolute()
        and len(path.drive) == 2
        and path.drive[0].isalpha()
        and path.drive[1] == ":"
    )


def _windows_project_relative_path(
    value: str,
    frozen_project_root: str,
) -> Path:
    source = PureWindowsPath(value)
    frozen_root = PureWindowsPath(frozen_project_root)
    if (
        not _is_windows_drive_absolute(source)
        or not _is_windows_drive_absolute(frozen_root)
    ):
        raise Stage3bContractError("Windows binding/project root must be drive-absolute")
    try:
        relative = source.relative_to(frozen_root)
    except ValueError as error:
        raise Stage3bContractError(
            "Windows binding is outside the frozen project root"
        ) from error
    if not relative.parts or any(part in {"", ".", ".."} for part in relative.parts):
        raise Stage3bContractError("Windows binding escapes the frozen project root")
    return Path(*relative.parts)


def _resolve_bound_path(relative: str, workspace_root: Path) -> Path:
    path = Path(relative)
    windows_path = PureWindowsPath(relative)
    frozen_project_root = os.environ.get("P1_FROZEN_PROJECT_ROOT", "")
    if _is_windows_drive_absolute(windows_path) and frozen_project_root:
        path = workspace_root / _windows_project_relative_path(
            relative,
            frozen_project_root,
        )
    elif path.is_absolute():
        return path.resolve()
    elif _is_windows_drive_absolute(windows_path):
        raise Stage3bContractError(
            "Windows binding requires the explicit frozen project root"
        )
    elif windows_path.drive or windows_path.root:
        raise Stage3bContractError("unsupported Windows binding path")
    else:
        path = workspace_root / path
    resolved_workspace = workspace_root.resolve()
    path = path.resolve()
    try:
        path.relative_to(resolved_workspace)
    except ValueError as error:
        raise Stage3bContractError("relative binding escapes the workspace root") from error
    return path


def _bound_file(binding: Any, workspace_root: Path, *, label: str) -> Path:
    if not isinstance(binding, dict):
        raise Stage3bContractError(f"{label} binding must be an object")
    relative = str(binding.get("path", ""))
    expected_hash = str(binding.get("sha256", ""))
    if not relative or len(expected_hash) != SHA256_PATTERN_LENGTH:
        raise Stage3bContractError(f"{label} lacks path/SHA256")
    if "2025" in relative.casefold():
        raise Stage3bContractError(f"{label} path refers to the future holdout")
    path = _resolve_bound_path(relative, workspace_root)
    if not path.is_file() or sha256_file(path) != expected_hash:
        raise Stage3bContractError(f"{label} file/hash mismatch")
    return path


def stacking_feature_models(
    outcome: str,
    dependencies: tuple[str, ...],
) -> tuple[str, ...]:
    optional = ("tabpfn_finetuned",)
    thinking_task_id = STACKING_SOURCE_TASK_TEMPLATES["tabpfn_thinking"].format(
        outcome=outcome
    )
    if thinking_task_id in dependencies:
        optional += ("tabpfn_thinking",)
    return STACKING_REQUIRED_MODEL_NAMES + optional


def stacking_acceptance_dependencies(
    thinking_tasks: list[dict[str, Any]],
) -> dict[str, dict[str, str]]:
    by_outcome = {
        str(task.get("outcome", "")): task
        for task in thinking_tasks
        if task.get("model") == "tabpfn_thinking"
    }
    if len(thinking_tasks) != len(OUTCOMES) or set(by_outcome) != set(OUTCOMES):
        raise Stage3bContractError("thinking task set does not cover all nine outcomes")
    result = {}
    for outcome in OUTCOMES:
        metadata = by_outcome[outcome].get("metadata", {})
        stacking_eligible = metadata.get("stacking_eligible")
        fit_count = metadata.get("thinking_fits")
        if (
            not isinstance(stacking_eligible, bool)
            or fit_count not in {1, 6}
            or stacking_eligible is not (fit_count == 6)
        ):
            raise Stage3bContractError(
                f"{outcome} thinking stacking classification differs"
            )
        result[outcome] = {
            model: template.format(outcome=outcome)
            for model, template in STACKING_SOURCE_TASK_TEMPLATES.items()
            if model != "tabpfn_thinking" or stacking_eligible
        }
    return result


def validate_thinking_stacking_classification(value: Any) -> dict[str, Any]:
    if (
        not isinstance(value, dict)
        or value.get("quota_limited_supplemental") is not False
        or value.get("not_equivalent_to_full_oof") is not False
        or value.get("full_oof") is not True
        or value.get("stacking_eligible") is not True
        or value.get("planned_fit_count") != 6
        or value.get("completed_thinking_fit_count") != 6
        or value.get("standard_fallback_count") != 0
    ):
        raise Stage3bContractError(
            "quota-limited thinking artifact cannot enter stacking"
        )
    return value


def validate_stacking_sources(
    contract: TaskContract,
    sources: list[dict[str, Any]],
    *,
    workspace_root: Path | None = None,
) -> None:
    if contract.model != "stacking":
        raise Stage3bContractError("stacking source validation is only valid for stacking")
    if not isinstance(sources, list) or not sources:
        raise Stage3bContractError("stacking requires accepted OOF source records")
    models = []
    for source in sources:
        if not isinstance(source, dict) or set(source) != STACKING_SOURCE_KEYS:
            raise Stage3bContractError("stacking source schema differs")
        if source.get("outcome") != contract.outcome:
            raise Stage3bContractError("stacking source belongs to a different outcome")
        if source.get("split") != "oof_2020_2023":
            raise Stage3bContractError("stacking training may use OOF predictions only")
        model_name = str(source.get("model", ""))
        template = STACKING_SOURCE_TASK_TEMPLATES.get(model_name)
        if template is None or source.get("source_task_id") != template.format(
            outcome=contract.outcome
        ):
            raise Stage3bContractError("stacking source task identity is not canonical")
        artifact_hash = str(source.get("artifact_sha256", ""))
        if not _is_sha256(artifact_hash):
            raise Stage3bContractError("stacking source lacks an artifact SHA256")
        if (
            source.get("sha256") != artifact_hash
            or not source.get("path")
            or not _is_sha256(source.get("source_task_manifest_sha256"))
            or not _is_sha256(source.get("acceptance_receipt_sha256"))
            or not isinstance(source.get("source_task_id"), str)
            or not source["source_task_id"]
            or not isinstance(source.get("lineage_id"), str)
            or not source["lineage_id"]
        ):
            raise Stage3bContractError("stacking source path/hash binding differs")
        if workspace_root is not None:
            artifact_path = _bound_file(
                {"path": source["path"], "sha256": source["sha256"]},
                workspace_root,
                label=f"stacking source {source['model']}",
            )
            receipt_path = _bound_file(
                {
                    "path": source["acceptance_receipt_path"],
                    "sha256": source["acceptance_receipt_sha256"],
                },
                workspace_root,
                label=f"stacking acceptance receipt {source['model']}",
            )
            receipt = read_json(receipt_path)
            manifest_binding = receipt.get("task_manifest")
            if isinstance(manifest_binding, dict):
                manifest_path = _bound_file(
                    manifest_binding,
                    workspace_root,
                    label=f"stacking source manifest {source['model']}",
                )
            else:
                manifest_path = artifact_path.parent / "task_manifest.json"
                if not manifest_path.is_file():
                    raise Stage3bContractError("stacking source task manifest is unavailable")
            if sha256_file(manifest_path) != source["source_task_manifest_sha256"]:
                raise Stage3bContractError("stacking source task-manifest hash differs")
            manifest = read_json(manifest_path)
            receipt_artifact_hash = receipt.get("artifact_sha256")
            if not _is_sha256(receipt_artifact_hash):
                receipt_artifact_hash = (receipt.get("artifact_hashes") or {}).get(
                    "predictions.parquet"
                )
            if (
                receipt.get("status") != "PASS"
                or receipt.get("accepted") is not True
                or receipt.get("task_id") != source["source_task_id"]
                or receipt.get("outcome") != contract.outcome
                or receipt.get("model") != source["model"]
                or receipt.get("scientific_artifact") is not True
                or receipt.get("maximum_year") != 2024
                or receipt.get("2025_access_count") != 0
                or receipt.get("strict_no_arrival_leakage") is not True
                or receipt.get("lineage_id") != source["lineage_id"]
                or receipt.get("task_manifest_sha256")
                != source["source_task_manifest_sha256"]
                or receipt_artifact_hash != artifact_hash
            ):
                raise Stage3bContractError("stacking source acceptance receipt differs")
            if (
                manifest.get("task_id") != source["source_task_id"]
                or manifest.get("outcome") != contract.outcome
                or manifest.get("model") != source["model"]
                or manifest.get("status") != "PASS"
                or manifest.get("scientific_artifact") is not True
                or manifest.get("maximum_year") != 2024
                or manifest.get("2025_access_count") != 0
                or manifest.get("strict_no_arrival_leakage") is not True
                or manifest.get("lineage_id") != source["lineage_id"]
                or (manifest.get("artifact_hashes") or {}).get("predictions.parquet")
                != artifact_hash
            ):
                raise Stage3bContractError("stacking source lineage manifest differs")
        models.append(model_name)
    required = set(stacking_feature_models(contract.outcome, contract.dependencies))
    if set(models) != required or len(models) != len(set(models)):
        raise Stage3bContractError(
            f"stacking source models must be exact: expected={sorted(required)}"
        )


class FormalProbabilityPipeline:
    def __init__(self, estimator: Any):
        self.imputer = SimpleImputer(strategy="median")
        self.scaler = StandardScaler()
        self.estimator = estimator

    def fit(
        self,
        values: pd.DataFrame,
        target: np.ndarray,
        *,
        validation_values: pd.DataFrame | None = None,
        validation_target: np.ndarray | None = None,
    ) -> FormalProbabilityPipeline:
        matrix = self.imputer.fit_transform(values)
        matrix = self.scaler.fit_transform(matrix).astype("float32")
        if getattr(self.estimator, "requires_validation_data", False):
            if validation_values is None or validation_target is None:
                raise Stage3bContractError(
                    "validation-monitored fit requires explicit development data"
                )
            validation_matrix = self.imputer.transform(validation_values)
            validation_matrix = self.scaler.transform(validation_matrix).astype("float32")
            self.estimator.fit(
                matrix,
                np.asarray(target, dtype="int8"),
                X_val=validation_matrix,
                y_val=np.asarray(validation_target, dtype="int8"),
            )
        else:
            self.estimator.fit(matrix, np.asarray(target, dtype="int8"))
        return self

    def predict_proba(self, values: pd.DataFrame | np.ndarray) -> np.ndarray:
        matrix = self.imputer.transform(values)
        matrix = self.scaler.transform(matrix).astype("float32")
        return np.asarray(self.estimator.predict_proba(matrix), dtype="float64")


def _stratified_sample(target: np.ndarray, size: int, seed: int) -> np.ndarray:
    labels = np.asarray(target, dtype="int8")
    if size >= len(labels):
        return np.arange(len(labels))
    if size < 2 or len(np.unique(labels)) != 2:
        raise Stage3bContractError("stratified sampling requires two classes and size >= 2")
    positive = np.flatnonzero(labels == 1)
    negative = np.flatnonzero(labels == 0)
    positive_size = max(1, min(len(positive), round(size * len(positive) / len(labels))))
    negative_size = size - positive_size
    if negative_size < 1:
        negative_size = 1
        positive_size = size - 1
    rng = np.random.default_rng(seed)
    selected = np.concatenate(
        [
            rng.choice(positive, positive_size, replace=len(positive) < positive_size),
            rng.choice(negative, negative_size, replace=len(negative) < negative_size),
        ]
    )
    rng.shuffle(selected)
    return selected


class StratifiedBaggingEstimator:
    def __init__(
        self,
        estimator_factory: Callable[[int], Any],
        *,
        max_train_rows: int | None,
        bag_count: int,
        seed: int,
        bag_fraction: float = 1.0,
        always_bag: bool = False,
        model_limits: dict[str, Any] | None = None,
    ):
        self.estimator_factory = estimator_factory
        self.max_train_rows = max_train_rows
        self.bag_count = int(bag_count)
        self.seed = int(seed)
        self.bag_fraction = float(bag_fraction)
        self.always_bag = bool(always_bag)
        self.model_limits = dict(model_limits or {})
        self.estimators: list[Any] = []
        self.bagging_log: dict[str, Any] = {}

    def fit(self, values: np.ndarray, target: np.ndarray) -> StratifiedBaggingEstimator:
        matrix = np.asarray(values, dtype="float32")
        labels = np.asarray(target, dtype="int8")
        maximum_features = self.model_limits.get("max_features")
        if isinstance(maximum_features, int) and matrix.shape[1] > maximum_features:
            raise Stage3bContractError("feature count exceeds the queried model limit")
        requested = max(2, int(np.floor(len(labels) * self.bag_fraction)))
        sample_size = min(len(labels), requested)
        if self.max_train_rows is not None:
            sample_size = min(sample_size, int(self.max_train_rows))
        use_bagging = self.always_bag or sample_size < len(labels)
        count = self.bag_count if use_bagging else 1
        self.estimators = []
        sample_hashes = []
        for bag in range(count):
            indices = _stratified_sample(labels, sample_size, self.seed + bag)
            estimator = self.estimator_factory(self.seed + bag)
            estimator.fit(matrix[indices], labels[indices])
            self.estimators.append(estimator)
            sample_hashes.append(
                hashlib.sha256(np.asarray(indices, dtype="int64").tobytes()).hexdigest()
            )
        self.bagging_log = {
            "strategy": "stratified_subsample_probability_averaging",
            "training_rows": int(len(labels)),
            "sample_rows_per_bag": int(sample_size),
            "bag_count": int(count),
            "sample_index_hashes": sample_hashes,
            "model_limits": self.model_limits,
        }
        self.estimator_factory = None
        return self

    def predict_proba(self, values: np.ndarray) -> np.ndarray:
        if not self.estimators:
            raise Stage3bContractError("bagging estimator is not fitted")
        probabilities = [
            np.asarray(estimator.predict_proba(values), dtype="float64")[:, 1]
            for estimator in self.estimators
        ]
        averaged = np.mean(np.vstack(probabilities), axis=0)
        return np.column_stack([1 - averaged, averaged])


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    return repr(value)


def _tabpfn_client_get_model_limits() -> Any:
    import tabpfn_client

    get_limits = getattr(tabpfn_client, "get_model_limits", None)
    if callable(get_limits):
        return get_limits()
    try:
        from tabpfn_client.client import ServiceClient
    except ImportError as error:
        raise Stage3bContractError(
            "installed tabpfn-client has no official get_model_limits API"
        ) from error
    get_limits = getattr(ServiceClient, "get_model_limits", None)
    if not callable(get_limits):
        raise Stage3bContractError(
            "installed tabpfn-client has no official get_model_limits API"
        )
    return get_limits()


def _model_limits_json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {
            str(key): _model_limits_json_safe(item) for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [_model_limits_json_safe(item) for item in value]
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        return _model_limits_json_safe(model_dump(mode="json"))
    if hasattr(value, "__dict__"):
        return _model_limits_json_safe(vars(value))
    raise Stage3bContractError("get_model_limits returned an unsupported value")


def _normalise_model_limits(value: Any) -> dict[str, Any]:
    raw = _model_limits_json_safe(value)
    if not isinstance(raw, dict):
        raise Stage3bContractError("get_model_limits returned an unsupported value")
    preferred = raw.get("max_model_limit")
    if isinstance(preferred, dict):
        raw_candidate = preferred
    else:
        raw_candidate = raw
    maximum = None
    for key in (
        "train_set_max_rows",
        "max_num_rows",
        "max_rows",
        "maximum_rows",
        "max_training_rows",
        "n_rows",
    ):
        candidate = raw_candidate.get(key)
        if isinstance(candidate, int) and candidate >= 2:
            maximum = candidate
            break
    if maximum is None:
        for nested in raw.values():
            if isinstance(nested, dict):
                try:
                    maximum = _normalise_model_limits(nested)["max_train_rows"]
                    break
                except Stage3bContractError:
                    continue
    if maximum is None:
        raise Stage3bContractError("get_model_limits did not report a row limit")
    maximum_features = None
    for key in (
        "max_cols",
        "max_num_columns",
        "max_num_features",
        "max_columns",
        "maximum_columns",
        "max_features",
        "n_features",
    ):
        candidate = raw_candidate.get(key)
        if isinstance(candidate, int) and candidate >= 1:
            maximum_features = candidate
            break
    maximum_cells = None
    for key in ("train_set_max_cells", "max_cells"):
        candidate = raw_candidate.get(key)
        if isinstance(candidate, int) and candidate >= 2:
            maximum_cells = candidate
            break
    return {
        "max_train_rows": int(maximum),
        "max_features": maximum_features,
        "max_cells": maximum_cells,
        "raw": _json_safe(raw),
        "queried": True,
    }


def _token_from_record(token: Any, token_env: Any) -> str:
    value = token or (os.environ.get(str(token_env)) if token_env else None)
    if not isinstance(value, str) or not value:
        raise Stage3bContractError("TabPFN token is unavailable")
    return value


class FineTunedTabPFNEstimator:
    requires_validation_data = True

    def __init__(self, parameters: dict[str, Any], *, device: str, seed: int, max_train_rows: int):
        self.parameters = dict(parameters)
        self.device = device
        self.seed = int(seed)
        self.max_train_rows = int(max_train_rows)
        self.estimator: Any | None = None
        self.training_history_: list[dict[str, float | int]] = []

    def fit(
        self,
        values: np.ndarray,
        target: np.ndarray,
        *,
        X_val: np.ndarray,
        y_val: np.ndarray,
    ) -> FineTunedTabPFNEstimator:
        from tabpfn.finetuning import FinetunedTabPFNClassifier

        labels = np.asarray(target, dtype="int8")
        indices = _stratified_sample(labels, min(len(labels), self.max_train_rows), self.seed)
        self.estimator = FinetunedTabPFNClassifier(
            device=self.device,
            **self.parameters,
        )
        self.estimator.fit(
            np.asarray(values, dtype="float32")[indices],
            labels[indices],
            X_val=np.asarray(X_val, dtype="float32"),
            y_val=np.asarray(y_val, dtype="int8"),
        )
        self.training_history_ = _extract_finetune_history(
            self.estimator, int(self.parameters["epochs"])
        )
        for row in self.training_history_:
            print(
                "fine_tune_epoch "
                f"epoch={row['epoch']} train_loss={row['train_loss']:.8g} "
                f"val_loss={row['val_loss']:.8g} val_auprc={row['val_auprc']:.8g}",
                flush=True,
            )
        return self

    def predict_proba(self, values: np.ndarray) -> np.ndarray:
        if self.estimator is None:
            raise Stage3bContractError("fine-tuned TabPFN is not fitted")
        return np.asarray(self.estimator.predict_proba(values), dtype="float64")


def _extract_finetune_history(estimator: Any, expected_epochs: int) -> list[dict[str, Any]]:
    history = None
    for name in ("training_history_", "history_", "history"):
        candidate = getattr(estimator, name, None)
        if candidate is not None:
            history = candidate
            break
    rows: list[dict[str, Any]] = []
    if isinstance(history, list):
        rows = [dict(row) for row in history if isinstance(row, dict)]
    elif isinstance(history, dict):
        aliases = {
            "train_loss": ("train_loss", "training_loss", "loss"),
            "val_loss": ("val_loss", "validation_loss"),
            "val_auprc": ("val_auprc", "validation_auprc", "auprc"),
        }
        series = {}
        for canonical, names in aliases.items():
            for name in names:
                if isinstance(history.get(name), (list, tuple)):
                    series[canonical] = list(history[name])
                    break
        if len(series) == 3:
            count = min(len(values) for values in series.values())
            rows = [
                {"epoch": index + 1, **{name: values[index] for name, values in series.items()}}
                for index in range(count)
            ]
    normalised = []
    for index, row in enumerate(rows):
        mapped = {
            "epoch": int(row.get("epoch", index + 1)),
            "train_loss": row.get("train_loss", row.get("training_loss", row.get("loss"))),
            "val_loss": row.get("val_loss", row.get("validation_loss")),
            "val_auprc": row.get(
                "val_auprc", row.get("validation_auprc", row.get("auprc"))
            ),
        }
        if any(not isinstance(mapped[name], (int, float)) for name in ("train_loss", "val_loss", "val_auprc")):
            raise Stage3bContractError("fine-tune history lacks per-epoch loss/AUPRC")
        normalised.append(mapped)
    if len(normalised) != expected_epochs or [row["epoch"] for row in normalised] != list(
        range(1, expected_epochs + 1)
    ):
        raise Stage3bContractError("fine-tune history must contain every configured epoch")
    return normalised


def _is_http_429(error: BaseException) -> bool:
    return _http_status(error) == 429 or "429" in str(error)


def _http_status(error: BaseException) -> int | None:
    status = getattr(error, "status_code", None)
    response = getattr(error, "response", None)
    response_status = getattr(response, "status_code", None)
    for value in (status, response_status):
        if isinstance(value, int):
            return value
    return None


def _is_cloud_unavailable(error: BaseException) -> bool:
    status = _http_status(error)
    if status == 422:
        return False
    if status == 429 or (isinstance(status, int) and status >= 500):
        return True
    if isinstance(error, (ConnectionError, TimeoutError)):
        return True
    text = str(error).casefold()
    return any(
        token in text
        for token in (
            "connection refused",
            "connection reset",
            "connection error",
            "timed out",
            "timeout",
            "temporarily unavailable",
            "service unavailable",
        )
    )


class CloudFirstTabPFNEstimator:
    def __init__(
        self,
        parameters: dict[str, Any],
        *,
        token: str,
        max_train_rows: int | None,
        bag_count: int,
        seed: int,
    ):
        self.parameters = dict(parameters)
        self.token = token
        self.max_train_rows = max_train_rows
        self.bag_count = int(bag_count)
        self.seed = int(seed)
        self.estimator: StratifiedBaggingEstimator | None = None
        self.bagging_log: dict[str, Any] = {}
        self.backend_provenance_: dict[str, Any] = {
            "requested_backend": "tabpfn_client_cloud_v3",
            "selected_backend": None,
            "cloud_attempted": False,
            "local_cuda_attempted": False,
            "fallback_reason": None,
            "model_limits": None,
            "real_inference": True,
        }

    def _fit_cloud(self, values: np.ndarray, target: np.ndarray) -> None:
        from tabpfn_client import TabPFNClassifier, set_access_token

        set_access_token(self.token)
        self.backend_provenance_["cloud_attempted"] = True
        limits = _normalise_model_limits(_tabpfn_client_get_model_limits())
        parameters = dict(self.parameters)
        parameters.setdefault("thinking_mode", False)
        parameters.setdefault("n_estimators", 8)
        parameters["n_estimators"] = min(8, int(parameters["n_estimators"]))

        def factory(_: int) -> Any:
            set_access_token(self.token)
            return TabPFNClassifier(**parameters)

        maximum = int(limits["max_train_rows"])
        if self.max_train_rows is not None:
            maximum = min(maximum, int(self.max_train_rows))
        model = StratifiedBaggingEstimator(
            factory,
            max_train_rows=maximum,
            bag_count=self.bag_count,
            seed=self.seed,
            model_limits=limits,
        )
        model.fit(values, target)
        self.estimator = model
        self.bagging_log = model.bagging_log
        self.backend_provenance_.update(
            {
                "selected_backend": "tabpfn_client_cloud_v3",
                "model_limits": limits,
            }
        )

    def _fit_local(self, values: np.ndarray, target: np.ndarray) -> None:
        try:
            import torch
            from tabpfn import TabPFNClassifier
        except ImportError as error:
            raise Stage3bContractError(
                "TabPFN cloud was unavailable and local CUDA fallback packages are missing"
            ) from error
        self.backend_provenance_["local_cuda_attempted"] = True
        if not torch.cuda.is_available():
            raise Stage3bContractError(
                "TabPFN cloud was unavailable and local CUDA fallback is unavailable"
            )
        parameters = {
            key: value
            for key, value in self.parameters.items()
            if key
            not in {
                "thinking_mode",
                "thinking_effort",
                "thinking_metric",
                "thinking_timeout_s",
            }
        }

        def factory(_: int) -> Any:
            return TabPFNClassifier(device="cuda", **parameters)

        model = StratifiedBaggingEstimator(
            factory,
            max_train_rows=self.max_train_rows,
            bag_count=self.bag_count,
            seed=self.seed,
        )
        model.fit(values, target)
        self.estimator = model
        self.bagging_log = model.bagging_log
        try:
            package_version = importlib.metadata.version("tabpfn")
        except importlib.metadata.PackageNotFoundError:
            package_version = None
        self.backend_provenance_.update(
            {
                "selected_backend": "tabpfn_local_cuda",
                "local_package_version": package_version,
                "local_model_identifier": "TabPFNClassifier",
            }
        )

    def fit(self, values: np.ndarray, target: np.ndarray) -> CloudFirstTabPFNEstimator:
        try:
            self._fit_cloud(values, target)
        except Exception as error:
            status = _http_status(error)
            if status == 422 or not _is_cloud_unavailable(error):
                raise
            self.backend_provenance_["fallback_reason"] = {
                "exception_type": type(error).__name__,
                "http_status": status,
                "message": str(error)[:500],
            }
            self._fit_local(values, target)
        return self

    def predict_proba(self, values: np.ndarray) -> np.ndarray:
        if self.estimator is None:
            raise Stage3bContractError("cloud/local TabPFN estimator is not fitted")
        return np.asarray(self.estimator.predict_proba(values), dtype="float64")


class ProvenancedTabICLEstimator:
    def __init__(
        self,
        parameters: dict[str, Any],
        *,
        policy: dict[str, Any],
        device: str,
        seed: int,
    ):
        self.parameters = dict(parameters)
        self.policy = dict(policy)
        self.device = device
        self.seed = int(seed)
        self.estimator: StratifiedBaggingEstimator | None = None
        self.bagging_log: dict[str, Any] = {}
        self.backend_provenance_: dict[str, Any] | None = None

    def fit(self, values: np.ndarray, target: np.ndarray) -> ProvenancedTabICLEstimator:
        from tabicl import TabICLClassifier

        parameters = dict(self.parameters)
        configured_checkpoint = parameters.get("checkpoint_version")
        if configured_checkpoint not in (None, self.policy["checkpoint_identifier"]):
            raise Stage3bContractError("TabICL parameter checkpoint differs from policy")
        parameters["checkpoint_version"] = self.policy["checkpoint_identifier"]

        def factory(bag_seed: int) -> Any:
            return TabICLClassifier(
                device=self.device,
                random_state=bag_seed,
                **parameters,
            )

        model = StratifiedBaggingEstimator(
            factory,
            max_train_rows=int(self.policy["max_train_rows"]),
            bag_count=int(self.policy["bag_count"]),
            seed=self.seed,
            bag_fraction=float(self.policy["bag_fraction"]),
            always_bag=True,
            model_limits={"weight_version": self.policy["weight_version"]},
        )
        model.fit(values, target)
        package_names = {type(item).__module__.split(".", 1)[0] for item in model.estimators}
        model_identifiers = {type(item).__name__ for item in model.estimators}
        checkpoint_identifiers = {
            str(getattr(item, "checkpoint_version", "")) for item in model.estimators
        }
        if (
            package_names != {self.policy["backend_package"]}
            or model_identifiers != {self.policy["model_identifier"]}
            or checkpoint_identifiers != {self.policy["checkpoint_identifier"]}
        ):
            raise Stage3bContractError("TabICL actual backend/model/checkpoint differs")
        weight_files = []
        for item in model.estimators:
            value = getattr(item, "model_path_", None)
            if value is None:
                continue
            path = Path(value).resolve()
            if path.is_file():
                weight_files.append(
                    {"path": str(path), "sha256": sha256_file(path)}
                )
        weight_hashes = sorted({record["sha256"] for record in weight_files})
        if len(weight_hashes) > 1:
            raise Stage3bContractError("TabICL bags loaded different checkpoint weights")
        actual_weight_hash = weight_hashes[0] if weight_hashes else None
        expected_weight_hash = self.policy.get("expected_weight_sha256")
        if actual_weight_hash != expected_weight_hash:
            raise Stage3bContractError("TabICL checkpoint weight hash differs from policy")
        try:
            package_version = importlib.metadata.version(self.policy["backend_package"])
        except importlib.metadata.PackageNotFoundError:
            package_version = None
        if package_version != self.policy["backend_package_version"]:
            raise Stage3bContractError("TabICL backend package version differs from policy")
        self.estimator = model
        self.bagging_log = model.bagging_log
        self.backend_provenance_ = {
            "backend_package": self.policy["backend_package"],
            "backend_package_version": package_version,
            "backend_module": type(model.estimators[0]).__module__,
            "model_identifier": self.policy["model_identifier"],
            "checkpoint_identifier": self.policy["checkpoint_identifier"],
            "weight_version": self.policy["weight_version"],
            "expected_weight_sha256": expected_weight_hash,
            "actual_weight_sha256": actual_weight_hash,
            "weight_file_available": bool(weight_files),
            "weight_files": weight_files,
            "locked_expectations_match": True,
            "real_inference": True,
        }
        return self

    def predict_proba(self, values: np.ndarray) -> np.ndarray:
        if self.estimator is None or self.backend_provenance_ is None:
            raise Stage3bContractError("provenanced TabICL estimator is not fitted")
        return np.asarray(self.estimator.predict_proba(values), dtype="float64")


class ThinkingQuotaManager:
    def __init__(
        self,
        policy: dict[str, Any],
        parameters: dict[str, Any],
        *,
        outcome: str,
        scheduler_claim: dict[str, Any] | None = None,
    ):
        self.policy = dict(policy)
        self.parameters = dict(parameters)
        self.outcome = outcome
        self.scheduler_claim = dict(scheduler_claim or {})
        self.maximum = int(policy["max_fits_per_account"])
        self.reservation = dict(policy["quota_reservation"])
        self.planned_fits = list(self.reservation["planned_fits"])
        self.accounts = []
        for record in policy["accounts"]:
            self.accounts.append(
                {
                    "account_alias": record["account_alias"],
                    "token": _token_from_record(record.get("token"), record["token_env"]),
                    "token_env": record["token_env"],
                    "counter_before": int(record["counter_before"]),
                    "counter": int(record["counter_before"]),
                    "quota_limit": int(record["quota_limit"]),
                    "successful_fits": 0,
                    "http_429_events": 0,
                    "used_slots": [],
                }
            )
        self.accounts_by_alias = {
            account["account_alias"]: account for account in self.accounts
        }
        fallback = policy["fallback_standard"]
        self.fallback_token = _token_from_record(
            fallback.get("token"), fallback.get("token_env")
        )
        self.events: list[dict[str, Any]] = []
        self.model_limits_by_account: dict[str, dict[str, Any]] = {}
        self.next_fit_index = 0

    def restore_ledger(self, ledger: dict[str, Any]) -> None:
        if (
            ledger.get("task_plan_sha256") != self.reservation["task_plan_sha256"]
            or ledger.get("quota_month") != self.reservation["quota_month"]
            or ledger.get("planned_fits") != self.planned_fits
            or ledger.get("quota_branch") != self.reservation["quota_branch"]
            or ledger.get("quota_probe_sha256")
            != self.reservation["quota_probe_sha256"]
            or ledger.get("global_plan_sha256")
            != self.reservation["global_plan"]["sha256"]
            or ledger.get("artifact_classification")
            != self.reservation["artifact_classification"]
        ):
            raise Stage3bContractError("thinking resume reservation binding differs")
        prior_claim = ledger.get("scheduler_claim")
        if self.scheduler_claim and (
            not isinstance(prior_claim, dict)
            or prior_claim.get("claim_id") != self.scheduler_claim.get("claim_id")
            or prior_claim.get("owner_alias") != self.scheduler_claim.get("owner_alias")
            or self.scheduler_claim.get("status") != "RESUME"
        ):
            raise Stage3bContractError("thinking resume scheduler claim differs")
        records = ledger.get("accounts")
        if not isinstance(records, list) or len(records) != len(self.accounts):
            raise Stage3bContractError("thinking resume ledger account set differs")
        by_alias = {record.get("account_alias"): record for record in records}
        for account in self.accounts:
            record = by_alias.get(account["account_alias"])
            if (
                not isinstance(record, dict)
                or record.get("counter_before") != account["counter_before"]
                or record.get("quota_limit") != account["quota_limit"]
                or not isinstance(record.get("counter_after"), int)
                or not account["counter_before"]
                <= record["counter_after"]
                <= account["quota_limit"]
                or not isinstance(record.get("used_slots"), list)
            ):
                raise Stage3bContractError("thinking resume ledger counter differs")
            account["counter"] = int(record["counter_after"])
            account["successful_fits"] = int(record.get("successful_fits", 0))
            account["http_429_events"] = int(record.get("http_429_events", 0))
            account["used_slots"] = list(record["used_slots"])
        events = ledger.get("events")
        if not isinstance(events, list):
            raise Stage3bContractError("thinking resume ledger events differ")
        self.events = [dict(event) for event in events]
        limits = ledger.get("model_limits_by_account")
        if not isinstance(limits, dict):
            raise Stage3bContractError("thinking resume model limits differ")
        self.model_limits_by_account = dict(limits)
        completed = [
            event
            for event in self.events
            if event.get("event") in {"thinking_fit", "standard_fallback"}
        ]
        if [event.get("fit_index") for event in completed] != list(range(len(completed))):
            raise Stage3bContractError("thinking resume fit sequence differs")
        self.next_fit_index = len(completed)

    def _account_limits(self, account: dict[str, Any]) -> dict[str, Any]:
        alias = str(account["account_alias"])
        if alias not in self.model_limits_by_account:
            from tabpfn_client import set_access_token

            set_access_token(account["token"])
            self.model_limits_by_account[alias] = _normalise_model_limits(
                _tabpfn_client_get_model_limits()
            )
        return self.model_limits_by_account[alias]

    def fit(
        self,
        values: np.ndarray,
        target: np.ndarray,
        *,
        seed: int,
        fit_name: str,
    ) -> tuple[Any, dict[str, Any]]:
        from tabpfn_client import TabPFNClassifier, set_access_token

        if self.next_fit_index >= len(self.planned_fits):
            raise Stage3bContractError("thinking execution exceeds its global reservation")
        plan = self.planned_fits[self.next_fit_index]
        if plan.get("fit_index") != self.next_fit_index or plan.get("fit_name") != fit_name:
            raise Stage3bContractError("thinking execution order differs from its reservation")
        if plan.get("historical_completed") is True:
            raise Stage3bContractError(
                "historical thinking fit requires checkpoint resume and cannot be recomputed"
            )
        candidates = [
            (plan["preferred_account_alias"], plan["preferred_slot"], "preferred")
        ]
        if plan["alternate_account_alias"] is not None:
            candidates.append(
                (plan["alternate_account_alias"], plan["alternate_slot"], "alternate")
            )
        for alias, slot, role in candidates:
            account = self.accounts_by_alias[str(alias)]
            try:
                limits = self._account_limits(account)
            except Exception as error:
                if not _is_cloud_unavailable(error):
                    raise
                account["http_429_events"] += int(_is_http_429(error))
                self.events.append(
                    {
                        "event": "cloud_account_unavailable",
                        "phase": "get_model_limits",
                        "fit_index": self.next_fit_index,
                        "fit_name": fit_name,
                        "account_alias": alias,
                        "reserved_slot": slot,
                        "reservation_role": role,
                        "http_status": _http_status(error),
                        "error": str(error)[:500],
                    }
                )
                if _is_http_429(error):
                    raise
                continue
            maximum_features = limits.get("max_features")
            if isinstance(maximum_features, int) and values.shape[1] > maximum_features:
                raise Stage3bContractError("feature count exceeds the thinking model limit")
            if len(target) > int(limits["max_train_rows"]):
                model = self._fit_standard_fallback(
                    values,
                    target,
                    seed=seed,
                    fit_name=fit_name,
                    reason="thinking_model_limit",
                )
                self.next_fit_index += 1
                return model, self.events[-1]
            set_access_token(account["token"])
            estimator = TabPFNClassifier(**self.parameters)
            try:
                estimator.fit(values, target)
            except Exception as error:
                if not _is_cloud_unavailable(error):
                    raise
                account["http_429_events"] += int(_is_http_429(error))
                self.events.append(
                    {
                        "event": "cloud_account_unavailable",
                        "phase": "thinking_fit",
                        "fit_index": self.next_fit_index,
                        "fit_name": fit_name,
                        "account_alias": alias,
                        "reserved_slot": slot,
                        "reservation_role": role,
                        "http_status": _http_status(error),
                        "error": str(error)[:500],
                    }
                )
                if _is_http_429(error):
                    raise
                continue
            account["counter"] = max(
                account["counter"], account["counter_before"] + int(slot) + 1
            )
            account["successful_fits"] += 1
            account["used_slots"].append(int(slot))
            event = {
                "event": "thinking_fit",
                "fit_index": self.next_fit_index,
                "fit_name": fit_name,
                "account_alias": alias,
                "reserved_slot": int(slot),
                "reservation_role": role,
                "counter_after": account["counter"],
                "seed": int(seed),
                "training_rows": int(len(target)),
            }
            self.events.append(event)
            self.next_fit_index += 1
            return estimator, event
        model = self._fit_standard_fallback(
            values,
            target,
            seed=seed,
            fit_name=fit_name,
            reason="reserved_accounts_unavailable",
        )
        self.next_fit_index += 1
        return model, self.events[-1]

    def _fit_standard_fallback(
        self,
        values: np.ndarray,
        target: np.ndarray,
        *,
        seed: int,
        fit_name: str,
        reason: str,
    ) -> Any:
        parameters = {
            key: value
            for key, value in self.parameters.items()
            if key
            not in {
                "thinking_mode",
                "thinking_effort",
                "thinking_metric",
                "thinking_timeout_s",
            }
        }
        parameters["thinking_mode"] = False
        parameters["n_estimators"] = min(8, int(parameters.get("n_estimators", 8)))
        model = CloudFirstTabPFNEstimator(
            parameters,
            token=self.fallback_token,
            max_train_rows=None,
            bag_count=2,
            seed=seed,
        )
        model.fit(values, target)
        self.events.append(
            {
                "event": "standard_fallback",
                "fit_index": self.next_fit_index,
                "fit_name": fit_name,
                "reason": reason,
                "seed": int(seed),
                "training_rows": int(len(target)),
                "backend_provenance": model.backend_provenance_,
                "bagging": model.bagging_log,
            }
        )
        return model

    def ledger(self) -> dict[str, Any]:
        accounts = [
            {
                "account_alias": account["account_alias"],
                "token_env": account["token_env"],
                "quota_limit": account["quota_limit"],
                "counter_before": account["counter_before"],
                "counter_after": account["counter"],
                "successful_fits": account["successful_fits"],
                "http_429_events": account["http_429_events"],
                "used_slots": list(account["used_slots"]),
            }
            for account in self.accounts
        ]
        return {
            "quota_month": self.reservation["quota_month"],
            "quota_branch": self.reservation["quota_branch"],
            "quota_probe_sha256": self.reservation["quota_probe_sha256"],
            "global_plan_sha256": self.reservation["global_plan"]["sha256"],
            "task_plan_sha256": self.reservation["task_plan_sha256"],
            "planned_fits": self.planned_fits,
            "artifact_classification": self.reservation["artifact_classification"],
            "scheduler_claim": self.scheduler_claim,
            "accounts": accounts,
            "events": list(self.events),
            "scientific_fit_count": int(sum(row["successful_fits"] for row in accounts)),
            "standard_fallback_count": int(
                sum(event["event"] == "standard_fallback" for event in self.events)
            ),
            "synthetic_fit_count": 0,
            "api_called": True,
            "quota_consumed": any(row["successful_fits"] for row in accounts),
            "model_limits_by_account": self.model_limits_by_account,
        }


class ThinkingTabPFNEstimator:
    def __init__(self, manager: ThinkingQuotaManager, *, seed: int, fit_name: str):
        self.manager = manager
        self.seed = int(seed)
        self.fit_name = fit_name
        self.estimator: Any | None = None
        self.fit_event: dict[str, Any] | None = None

    def fit(self, values: np.ndarray, target: np.ndarray) -> ThinkingTabPFNEstimator:
        self.estimator, self.fit_event = self.manager.fit(
            values, target, seed=self.seed, fit_name=self.fit_name
        )
        return self

    def predict_proba(self, values: np.ndarray) -> np.ndarray:
        if self.estimator is None:
            raise Stage3bContractError("thinking/fallback estimator is not fitted")
        return np.asarray(self.estimator.predict_proba(values), dtype="float64")


class TorchCnnEstimator:
    requires_validation_data = True

    def __init__(self, parameters: dict[str, Any], *, device: str, seed: int):
        self.parameters = dict(parameters)
        self.execution_envelope_ = cnn_execution_envelope(self.parameters)
        self.device = device
        self.seed = int(seed)
        self.n_features: int | None = None
        self.state_dict: dict[str, Any] | None = None
        self.training_history_: list[dict[str, float | int]] = []
        self.convergence_: dict[str, Any] | None = None

    def _model(self, n_features: int) -> Any:
        import torch

        proj_dim = int(self.parameters["proj_dim"])
        channels = int(self.parameters["channels"])
        n_conv = int(self.parameters["n_conv"])
        kernel = int(self.parameters["kernel"])
        dropout = float(self.parameters.get("dropout", 0.2))

        class ConfigurableOneDCNN(torch.nn.Module):
            def __init__(self) -> None:
                super().__init__()
                self.proj = torch.nn.Sequential(
                    torch.nn.Linear(n_features, proj_dim),
                    torch.nn.ReLU(),
                    torch.nn.Dropout(dropout),
                )
                layers: list[Any] = []
                input_channels = 1
                for _ in range(n_conv):
                    layers.extend(
                        [
                            torch.nn.Conv1d(
                                input_channels,
                                channels,
                                kernel_size=kernel,
                                padding=kernel // 2,
                            ),
                            torch.nn.BatchNorm1d(channels),
                            torch.nn.ReLU(),
                        ]
                    )
                    input_channels = channels
                layers.append(torch.nn.AdaptiveAvgPool1d(1))
                self.conv = torch.nn.Sequential(*layers)
                self.head = torch.nn.Sequential(
                    torch.nn.Flatten(),
                    torch.nn.Dropout(dropout),
                    torch.nn.Linear(channels, 1),
                )

            def forward(self, values: Any) -> Any:
                projected = self.proj(values).unsqueeze(1)
                return self.head(self.conv(projected)).squeeze(-1)

        return ConfigurableOneDCNN()

    def fit(
        self,
        values: np.ndarray,
        target: np.ndarray,
        *,
        X_val: np.ndarray,
        y_val: np.ndarray,
    ) -> TorchCnnEstimator:
        import torch
        from torch.utils.data import DataLoader, TensorDataset

        torch.manual_seed(self.seed)
        matrix = np.asarray(values, dtype="float32")
        labels = np.asarray(target, dtype="float32")
        validation_matrix = np.asarray(X_val, dtype="float32")
        validation_labels = np.asarray(y_val, dtype="float32")
        if (
            matrix.ndim != 2
            or validation_matrix.ndim != 2
            or matrix.shape[1] != validation_matrix.shape[1]
            or set(np.unique(labels)) != {0.0, 1.0}
            or set(np.unique(validation_labels)) != {0.0, 1.0}
        ):
            raise Stage3bContractError(
                "CNN training and development monitor matrices are invalid"
            )
        self.n_features = int(matrix.shape[1])
        model = self._model(self.n_features).to(torch.device(self.device))
        positives = max(1.0, float(labels.sum()))
        negatives = max(1.0, float(len(labels) - labels.sum()))
        loss = torch.nn.BCEWithLogitsLoss(
            pos_weight=torch.tensor([negatives / positives], device=self.device)
        )
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=float(self.parameters.get("learning_rate", 1e-3)),
            weight_decay=float(self.parameters.get("weight_decay", 1e-4)),
        )
        loader = DataLoader(
            TensorDataset(torch.from_numpy(matrix), torch.from_numpy(labels)),
            batch_size=self.execution_envelope_["micro_batch_size"],
            shuffle=True,
        )
        epochs = int(self.parameters.get("epochs", 20))
        optimizer_steps_per_epoch = cnn_optimizer_steps_per_epoch(
            len(loader), self.execution_envelope_["gradient_accumulation_steps"]
        )
        scheduler = torch.optim.lr_scheduler.OneCycleLR(
            optimizer,
            max_lr=float(self.parameters.get("max_lr", self.parameters.get("learning_rate", 1e-3))),
            epochs=epochs,
            steps_per_epoch=optimizer_steps_per_epoch,
            pct_start=float(self.parameters.get("one_cycle_pct_start", 0.3)),
        )
        model.train()
        self.training_history_ = []
        patience = int(self.parameters.get("early_stopping_patience", 5))
        minimum_epochs = int(self.parameters.get("minimum_epochs", min(5, epochs)))
        minimum_delta = float(self.parameters.get("early_stopping_min_delta", 1e-4))
        best_auprc = -np.inf
        best_validation_loss = np.inf
        best_epoch = 0
        best_state: dict[str, Any] | None = None
        stale_epochs = 0
        for epoch in range(epochs):
            losses = []
            optimizer.zero_grad(set_to_none=True)
            accumulation_steps = self.execution_envelope_[
                "gradient_accumulation_steps"
            ]
            effective_batch_size = self.execution_envelope_["effective_batch_size"]
            for batch_index, (features, batch_target) in enumerate(loader):
                features = features.to(self.device)
                batch_target = batch_target.to(self.device)
                batch_loss = loss(model(features), batch_target)
                group_index = batch_index // accumulation_steps
                group_start = group_index * effective_batch_size
                group_rows = min(effective_batch_size, len(labels) - group_start)
                (batch_loss * (len(batch_target) / group_rows)).backward()
                group_end = (
                    (batch_index + 1) % accumulation_steps == 0
                    or batch_index + 1 == len(loader)
                )
                if group_end:
                    optimizer.step()
                    scheduler.step()
                    optimizer.zero_grad(set_to_none=True)
                losses.append(float(batch_loss.detach().cpu()))
            model.eval()
            validation_probabilities = []
            validation_logits = []
            with torch.no_grad():
                validation_batch_size = self.execution_envelope_[
                    "validation_batch_size"
                ]
                for start in range(0, len(validation_matrix), validation_batch_size):
                    features = torch.from_numpy(
                        validation_matrix[start : start + validation_batch_size]
                    ).to(self.device)
                    logits = model(features)
                    validation_logits.append(logits.cpu().numpy())
                    validation_probabilities.append(torch.sigmoid(logits).cpu().numpy())
            monitor_logits = np.concatenate(validation_logits)
            monitor_probability = np.concatenate(validation_probabilities)
            monitor_loss = float(
                loss(
                    torch.from_numpy(monitor_logits).to(self.device),
                    torch.from_numpy(validation_labels).to(self.device),
                )
                .detach()
                .cpu()
            )
            monitor_auprc = float(
                average_precision_score(validation_labels, monitor_probability)
            )
            if not (
                np.isfinite(losses).all()
                and np.isfinite(monitor_loss)
                and np.isfinite(monitor_auprc)
            ):
                raise Stage3bContractError("CNN convergence metrics are not finite")
            self.training_history_.append(
                {
                    "epoch": epoch + 1,
                    "train_loss": float(np.mean(losses)),
                    "validation_loss": monitor_loss,
                    "validation_auprc": monitor_auprc,
                    "learning_rate": float(scheduler.get_last_lr()[0]),
                }
            )
            improved = monitor_auprc > best_auprc + minimum_delta or (
                abs(monitor_auprc - best_auprc) <= minimum_delta
                and monitor_loss < best_validation_loss
            )
            if improved:
                best_auprc = monitor_auprc
                best_validation_loss = monitor_loss
                best_epoch = epoch + 1
                best_state = {
                    key: value.detach().cpu().clone()
                    for key, value in model.state_dict().items()
                }
                stale_epochs = 0
            else:
                stale_epochs += 1
            if epoch + 1 >= minimum_epochs and stale_epochs >= patience:
                break
            model.train()
        if best_state is None:
            raise Stage3bContractError("CNN training produced no finite best state")
        self.state_dict = best_state
        stopped_epoch = len(self.training_history_)
        self.convergence_ = {
            "status": "PASS",
            "converged": True,
            "best_epoch": best_epoch,
            "stopped_epoch": stopped_epoch,
            "maximum_epochs": epochs,
            "early_stopped": stopped_epoch < epochs,
            "best_validation_auprc": best_auprc,
            "best_validation_loss": best_validation_loss,
            "patience": patience,
            "minimum_epochs": minimum_epochs,
            "minimum_delta": minimum_delta,
            "monitor_source_split": "train_2020_2023",
            "monitor_maximum_year": 2023,
            "validation_2024_used": False,
            "execution_envelope": self.execution_envelope_
            | {"optimizer_steps_per_epoch": optimizer_steps_per_epoch},
        }
        return self

    def predict_proba(self, values: np.ndarray) -> np.ndarray:
        import torch

        if self.n_features is None or self.state_dict is None:
            raise Stage3bContractError("CNN estimator is not fitted")
        model = self._model(self.n_features)
        model.load_state_dict(self.state_dict)
        model = model.to(torch.device(self.device))
        model.eval()
        matrix = np.asarray(values, dtype="float32")
        predictions = []
        batch_size = self.execution_envelope_["predict_batch_size"]
        with torch.no_grad():
            for start in range(0, len(matrix), batch_size):
                features = torch.from_numpy(matrix[start : start + batch_size]).to(self.device)
                predictions.append(torch.sigmoid(model(features)).cpu().numpy())
        probability = np.concatenate(predictions)
        return np.column_stack([1 - probability, probability])


def _stacking_predefined_cv(
    frame: pd.DataFrame,
    *,
    fit_name: str,
    expected_splits: int,
) -> tuple[PredefinedSplit, dict[str, Any]]:
    if not {"row_hash", "fold"} <= set(frame.columns):
        raise Stage3bContractError("stacking fixed CV requires row_hash/fold")
    folds = pd.to_numeric(frame["fold"], errors="raise").astype(int)
    observed = sorted(folds.unique().tolist())
    if len(observed) != expected_splits or not set(observed) <= set(range(5)):
        raise Stage3bContractError("stacking fixed CV fold count differs")
    if expected_splits == 5 and observed != list(range(5)):
        raise Stage3bContractError("final stacking CV must use all five group folds")
    if expected_splits == 4:
        missing = sorted(set(range(5)) - set(observed))
        if len(missing) != 1 or fit_name != f"oof_fold_{missing[0]}":
            raise Stage3bContractError("outer stacking CV must use the remaining four folds")
    fold_to_test = {fold: index for index, fold in enumerate(observed)}
    test_fold = folds.map(fold_to_test).to_numpy(dtype="int32")
    ordered = pd.DataFrame(
        {"row_hash": frame["row_hash"].astype(str), "fold": folds}
    ).sort_values(["row_hash", "fold"], kind="mergesort")
    payload = {
        "contract_version": "p1-v2-stage3b-stacking-predefined-cv/1",
        "fit_name": fit_name,
        "original_group_folds": observed,
        "predefined_split_count": expected_splits,
        "row_count": int(len(frame)),
        "row_fold_sha256": sha256_lines(
            [f"{row.row_hash}\t{row.fold}" for row in ordered.itertuples(index=False)]
        ),
    }
    binding = {**payload, "binding_sha256": canonical_sha256(payload)}
    return PredefinedSplit(test_fold=test_fold), binding


def make_formal_estimator(
    contract: TaskContract,
    parameters: dict[str, Any],
    *,
    device_plan: DevicePlan,
    seed: int,
    runtime_context: dict[str, Any] | None = None,
) -> FormalProbabilityPipeline:
    parameters = dict(parameters)
    context = runtime_context if runtime_context is not None else {}
    policy = dict(context.get("model_policy") or {})
    if contract.model == "cnn_1d":
        estimator = TorchCnnEstimator(
            parameters, device=device_plan.execution_device, seed=seed
        )
    elif contract.model == "tabpfn_standard":
        backend = str(policy["backend"])
        if backend == "cloud":
            token = _token_from_record(policy.get("token"), policy.get("token_env"))
            parameters.setdefault("thinking_mode", False)
            parameters.setdefault("n_estimators", 8)
            parameters["n_estimators"] = min(8, int(parameters["n_estimators"]))
            estimator = CloudFirstTabPFNEstimator(
                parameters,
                token=token,
                max_train_rows=policy.get("max_train_rows"),
                bag_count=int(policy["bag_count"]),
                seed=int(policy["bagging_seed"]) + seed,
            )
        elif backend == "local":
            from tabpfn import TabPFNClassifier

            local_device = device_plan.execution_device
            if local_device == "api":
                try:
                    import torch

                    local_device = "cuda" if torch.cuda.is_available() else "cpu"
                except ImportError:
                    local_device = "cpu"
            if local_device != "cuda":
                raise Stage3bContractError("local TabPFN fallback requires CUDA")

            def standard_local_factory(_: int) -> Any:
                return TabPFNClassifier(
                    device=local_device, **parameters
                )

            estimator = StratifiedBaggingEstimator(
                standard_local_factory,
                max_train_rows=policy["max_train_rows"],
                bag_count=int(policy["bag_count"]),
                seed=int(policy["bagging_seed"]) + seed,
            )
        else:
            raise Stage3bContractError("TabPFN standard backend must be cloud/local")
    elif contract.model == "tabpfn_finetuned":
        estimator = FineTunedTabPFNEstimator(
            parameters,
            device=device_plan.execution_device,
            seed=seed,
            max_train_rows=int(policy["max_train_rows"]),
        )
    elif contract.model == "tabpfn_thinking":
        manager = context.get("thinking_manager")
        if manager is None:
            manager = ThinkingQuotaManager(
                policy,
                parameters,
                outcome=contract.outcome,
                scheduler_claim=context.get("thinking_scheduler_claim"),
            )
            prior = context.get("resume_thinking_ledger")
            if prior is not None:
                manager.restore_ledger(prior)
            context["thinking_manager"] = manager
        fit_name = context.get("fit_name")
        if not isinstance(fit_name, str) or not fit_name:
            raise Stage3bContractError("thinking estimator requires its reserved fit name")
        estimator = ThinkingTabPFNEstimator(
            manager, seed=seed, fit_name=fit_name
        )
    elif contract.model == "tabicl":
        estimator = ProvenancedTabICLEstimator(
            parameters,
            policy=policy,
            device=device_plan.execution_device,
            seed=seed,
        )
    elif contract.model == "stacking":
        cv = context.get("stacking_predefined_cv")
        cv_binding = context.get("stacking_cv_binding")
        if not isinstance(cv, PredefinedSplit) or not isinstance(cv_binding, dict):
            raise Stage3bContractError("stacking estimator lacks fixed group-fold CV binding")
        parameters.pop("cv", None)
        estimator = LogisticRegressionCV(
            Cs=parameters.pop("Cs", 10),
            cv=cv,
            scoring="average_precision",
            class_weight="balanced",
            max_iter=parameters.pop("max_iter", 2000),
            random_state=seed,
            **parameters,
        )
        estimator.stacking_cv_binding_ = cv_binding
    else:
        raise Stage3bContractError(f"unsupported formal model: {contract.model}")
    return FormalProbabilityPipeline(estimator)


def _load_stage1a_formal_frames(
    contract: TaskContract,
    authorization: dict[str, Any],
    workspace_root: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, list[str]]:
    feature_path = _bound_file(
        authorization["input_artifacts"]["features"],
        workspace_root,
        label="formal input features",
    )
    fold_path = _bound_file(
        authorization["input_artifacts"]["fold_map"],
        workspace_root,
        label="formal input fold_map",
    )
    frame = pd.read_parquet(feature_path)
    validate_no_future_data(frame)
    feature_order = list(authorization["execution_spec"]["feature_order"])
    required = {"row_hash", "split", f"y_{contract.outcome}", *feature_order}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise Stage3bContractError(f"formal Stage1a frame lacks columns: {missing[:20]}")
    train = frame.loc[frame["split"].eq("train_2020_2023")].copy()
    validation = frame.loc[frame["split"].eq("validation_2024")].copy()
    folds = pd.read_parquet(fold_path)
    validate_no_future_data(folds)
    folds = folds.loc[folds["outcome"].eq(contract.outcome)].copy()
    required_fold = {"row_hash", "fold"}
    if required_fold - set(folds.columns) or folds["row_hash"].duplicated().any():
        raise Stage3bContractError("formal fold map is missing keys or duplicated")
    if set(folds["row_hash"].astype(str)) != set(train["row_hash"].astype(str)):
        raise Stage3bContractError("formal fold keys differ from training keys")
    train["row_hash"] = train["row_hash"].astype(str)
    train = train.merge(
        folds[["row_hash", "fold"]].assign(row_hash=lambda value: value["row_hash"].astype(str)),
        on="row_hash",
        how="left",
        validate="one_to_one",
    )
    observed = sorted(pd.to_numeric(train["fold"], errors="raise").astype(int).unique())
    if observed != list(range(5)):
        raise Stage3bContractError("formal fold map must contain exact folds 0..4")
    return train, validation, feature_order


def _assert_deidentified_numeric_features(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    feature_order: list[str],
) -> dict[str, Any]:
    forbidden = []
    for column in feature_order:
        name = str(column)
        if name in ARRIVAL_EXACT_ALLOWLIST:
            continue
        lowered = name.casefold()
        if any(token.casefold() in lowered for token in ARRIVAL_FORBIDDEN_TOKENS):
            forbidden.append(name)
    if forbidden:
        raise Stage3bContractError(
            f"external-model feature names violate the no-arrival contract: {forbidden}"
        )
    scanner_findings: list[dict[str, Any]] = []
    for frame in (train, validation):
        scanner_findings.extend(
            security_scan.blocking_findings(
                security_scan.scan_table_values(
                    feature_order,
                    frame.loc[:, feature_order].itertuples(index=False, name=None),
                )
            )
        )
    if scanner_findings:
        rules = sorted({str(finding.get("rule")) for finding in scanner_findings})
        paths = sorted(
            {
                "/".join(str(part) for part in finding.get("path", []))
                for finding in scanner_findings
            }
        )
        raise Stage3bContractError(
            f"external-model PII/identifier scan failed: rules={rules} paths={paths[:20]}"
        )
    for column in feature_order:
        for frame in (train, validation):
            converted = pd.to_numeric(frame[column], errors="coerce")
            original_missing = frame[column].isna()
            if converted.isna().ne(original_missing).any():
                raise Stage3bContractError(
                    f"external-model feature is not purely numeric: {column}"
                )
    return {
        "status": "PASS",
        "deidentified_numeric_only": True,
        "raw_text_columns_sent": 0,
        "identifier_columns_sent": 0,
        "feature_count": len(feature_order),
        "shared_scanner": "qa_v2.contextual_security_scan.scan_table_values",
        "shared_scanner_blocking_findings": 0,
        "arrival_exact_allowlist": sorted(ARRIVAL_EXACT_ALLOWLIST),
    }


def _load_stacking_formal_frames(
    contract: TaskContract,
    authorization: dict[str, Any],
    workspace_root: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, list[str], list[dict[str, Any]]]:
    sources = list(authorization["execution_spec"]["stacking_sources"])
    validate_stacking_sources(contract, sources, workspace_root=workspace_root)
    train: pd.DataFrame | None = None
    validation: pd.DataFrame | None = None
    train_keys: set[str] | None = None
    validation_keys: set[str] | None = None
    for source in sources:
        path = _bound_file(source, workspace_root, label=f"stacking source {source['model']}")
        predictions = pd.read_parquet(path)
        required = {"row_hash", "outcome", "model", "split", "fold", "y_true", "prediction"}
        if required - set(predictions.columns):
            raise Stage3bContractError("stacking source prediction schema differs")
        if set(predictions["outcome"].astype(str)) != {contract.outcome}:
            raise Stage3bContractError("stacking artifact belongs to another outcome")
        model_name = str(source["model"])
        selected = predictions.loc[
            predictions["model"].astype(str).eq(model_name),
            ["row_hash", "split", "fold", "y_true", "prediction"],
        ].copy()
        selected = selected.rename(columns={"prediction": model_name})
        source_train = selected.loc[selected["split"].eq("oof_2020_2023")]
        source_validation = selected.loc[selected["split"].eq("validation_2024")]
        if source_train.empty or source_validation.empty:
            raise Stage3bContractError("stacking source lacks OOF or validation predictions")
        if selected.duplicated(["row_hash", "split"]).any():
            raise Stage3bContractError("stacking source contains duplicate prediction keys")
        observed_folds = sorted(
            pd.to_numeric(source_train["fold"], errors="raise").astype(int).unique()
        )
        if observed_folds != list(range(5)) or source_train["fold"].isna().any():
            raise Stage3bContractError("stacking source must contain exact OOF folds 0..4")
        if source_validation["fold"].notna().any():
            raise Stage3bContractError("stacking validation rows must have null folds")
        current_train_keys = set(source_train["row_hash"].astype(str))
        current_validation_keys = set(source_validation["row_hash"].astype(str))
        if train_keys is None:
            train_keys = current_train_keys
            validation_keys = current_validation_keys
        elif current_train_keys != train_keys or current_validation_keys != validation_keys:
            raise Stage3bContractError("stacking source row coverage differs")
        keys = ["row_hash", "split", "fold", "y_true"]
        train = (
            source_train
            if train is None
            else train.merge(source_train, on=keys, validate="one_to_one")
        )
        validation = (
            source_validation
            if validation is None
            else validation.merge(source_validation, on=keys, validate="one_to_one")
        )
    assert train is not None and validation is not None
    feature_order = list(stacking_feature_models(contract.outcome, contract.dependencies))
    validate_no_future_data(train)
    validate_no_future_data(validation)
    return train, validation, feature_order, sources


def _checkpoint_lock(
    contract: TaskContract,
    authorization: dict[str, Any],
    *,
    owner_alias: str,
) -> dict[str, Any]:
    return {
        "task_id": contract.task_id,
        "owner_alias": owner_alias,
        "authorization_sha256": authorization["authorization_sha256"],
        "runner_sha256": sha256_file(Path(__file__).resolve()),
        "prelaunch_task_manifest_sha256": authorization[
            "prelaunch_task_manifest_sha256"
        ],
        "task_registry_sha256": contract.task_registry_sha256,
        "registry_task_sha256": contract.registry_task_sha256,
        "feature_order_sha256": authorization["execution_spec"][
            "feature_order_sha256"
        ],
        "input_hashes": {
            name: binding["sha256"]
            for name, binding in authorization["input_artifacts"].items()
        },
    }


def _write_resume_cursor(
    output_dir: Path,
    contract: TaskContract,
    authorization: dict[str, Any],
    *,
    owner_alias: str,
    completed_folds: list[int],
    thinking_fit_ledger: dict[str, Any] | None = None,
    extra_state_paths: list[Path] | None = None,
) -> dict[str, Any]:
    expected = list(range(5))
    if completed_folds != expected[: len(completed_folds)]:
        raise Stage3bContractError("resume folds must be a contiguous prefix of 0..4")
    state_hashes = {}
    for fold in completed_folds:
        path = output_dir / f"checkpoint_fold_{fold}_predictions.parquet"
        if not path.is_file():
            raise Stage3bContractError(f"checkpoint fold shard is absent: {fold}")
        state_hashes[path.name] = sha256_file(path)
    for path in extra_state_paths or []:
        if path.parent.resolve() != output_dir.resolve() or not path.is_file():
            raise Stage3bContractError("checkpoint extra state path is invalid")
        state_hashes[path.name] = sha256_file(path)
    lock = _checkpoint_lock(contract, authorization, owner_alias=owner_alias)
    cursor = {
        "contract_version": "p1-v2-stage3b-resume-cursor/1",
        "status": "OOF_COMPLETE_FINAL_PENDING" if completed_folds == expected else "PARTIAL",
        **lock,
        "completed_folds": completed_folds,
        "next_fold": None if completed_folds == expected else len(completed_folds),
        "state_artifact_hashes": state_hashes,
        "thinking_fit_ledger": thinking_fit_ledger,
        "same_owner_resume_required": True,
        "maximum_year": 2024,
        "2025_access_count": 0,
    }
    cursor["resume_cursor_sha256"] = canonical_sha256(cursor)
    cursor_path = output_dir / "resume_cursor.json"
    atomic_json(cursor_path, cursor)
    checkpoint = {
        "contract_version": "p1-v2-stage3b-checkpoint/2",
        "status": cursor["status"],
        **lock,
        "completed_folds": completed_folds,
        "remaining_folds": [fold for fold in expected if fold not in completed_folds],
        "resume_cursor": {
            "path": cursor_path.name,
            "sha256": sha256_file(cursor_path),
        },
        "state_artifact_hashes": state_hashes,
        "same_owner_resume_required": True,
        "cross_session_parallel_resume": False,
        "maximum_year": 2024,
        "2025_access_count": 0,
    }
    checkpoint["checkpoint_payload_sha256"] = canonical_sha256(checkpoint)
    atomic_json(output_dir / "checkpoint_manifest.json", checkpoint)
    return cursor


def _load_resume_cursor(
    output_dir: Path,
    contract: TaskContract,
    authorization: dict[str, Any],
    *,
    owner_alias: str,
) -> tuple[list[int], list[pd.DataFrame], dict[str, Any]]:
    cursor_path = output_dir / "resume_cursor.json"
    checkpoint_path = output_dir / "checkpoint_manifest.json"
    if not cursor_path.is_file() or not checkpoint_path.is_file():
        raise Stage3bContractError("resume requires cursor and checkpoint manifests")
    cursor = read_json(cursor_path)
    claimed_cursor_hash = cursor.get("resume_cursor_sha256")
    unhashed_cursor = dict(cursor)
    unhashed_cursor.pop("resume_cursor_sha256", None)
    if claimed_cursor_hash != canonical_sha256(unhashed_cursor):
        raise Stage3bContractError("resume cursor self hash differs")
    checkpoint = read_json(checkpoint_path)
    claimed_checkpoint_hash = checkpoint.get("checkpoint_payload_sha256")
    unhashed_checkpoint = dict(checkpoint)
    unhashed_checkpoint.pop("checkpoint_payload_sha256", None)
    if claimed_checkpoint_hash != canonical_sha256(unhashed_checkpoint):
        raise Stage3bContractError("checkpoint manifest self hash differs")
    expected_lock = _checkpoint_lock(contract, authorization, owner_alias=owner_alias)
    for key, value in expected_lock.items():
        if cursor.get(key) != value or checkpoint.get(key) != value:
            raise Stage3bContractError(f"resume checkpoint lock differs: {key}")
    if checkpoint.get("resume_cursor", {}).get("sha256") != sha256_file(cursor_path):
        raise Stage3bContractError("checkpoint does not bind the resume cursor")
    completed = cursor.get("completed_folds")
    if not isinstance(completed, list) or completed != list(range(len(completed))):
        raise Stage3bContractError("resume folds are not a contiguous prefix")
    if checkpoint.get("completed_folds") != completed:
        raise Stage3bContractError("checkpoint/cursor fold sets differ")
    parts = []
    state_hashes = cursor.get("state_artifact_hashes")
    if not isinstance(state_hashes, dict):
        raise Stage3bContractError("resume cursor lacks state hashes")
    for fold in completed:
        name = f"checkpoint_fold_{fold}_predictions.parquet"
        path = output_dir / name
        if state_hashes.get(name) != sha256_file(path):
            raise Stage3bContractError(f"resume fold artifact hash differs: {fold}")
        part = pd.read_parquet(path)
        if set(part["fold"].astype(int)) != {fold}:
            raise Stage3bContractError(f"resume fold artifact identity differs: {fold}")
        parts.append(part)
    for name, expected_hash in state_hashes.items():
        if name.startswith("checkpoint_fold_"):
            continue
        path = output_dir / name
        if not path.is_file() or sha256_file(path) != expected_hash:
            raise Stage3bContractError(
                f"resume extra state artifact hash differs: {name}"
            )
    return completed, parts, cursor


def _fit_formal_pipeline(
    contract: TaskContract,
    estimator: FormalProbabilityPipeline,
    fit_rows: pd.DataFrame,
    *,
    feature_order: list[str],
    target_column: str,
    seed: int,
) -> None:
    if contract.model not in {"tabpfn_finetuned", "cnn_1d"}:
        estimator.fit(
            fit_rows[feature_order], fit_rows[target_column].to_numpy(dtype="int8")
        )
        return
    required = {"split", "split_year", "group_hash", "fold"}
    missing = sorted(required - set(fit_rows.columns))
    if missing:
        raise Stage3bContractError(
            f"development monitor lacks columns: {missing}"
        )
    years = pd.to_numeric(fit_rows["split_year"], errors="coerce")
    if (
        set(fit_rows["split"].astype(str)) != {"train_2020_2023"}
        or years.isna().any()
        or not years.between(2020, 2023).all()
    ):
        raise Stage3bContractError(
            "fit/monitor rows must be development years 2020-2023"
        )
    folds = pd.to_numeric(fit_rows["fold"], errors="raise").astype(int)
    observed_folds = sorted(int(value) for value in folds.unique())
    group_fold_counts = (
        fit_rows.assign(_fold=folds)
        .groupby("group_hash", observed=True)["_fold"]
        .nunique()
    )
    if (
        len(observed_folds) not in {4, 5}
        or not set(observed_folds) <= set(range(5))
        or fit_rows["group_hash"].isna().any()
        or group_fold_counts.gt(1).any()
    ):
        raise Stage3bContractError(
            "monitor requires locked patient-disjoint group folds"
        )
    monitor_fold = observed_folds[0]
    monitor_rows = fit_rows.loc[folds.eq(monitor_fold)]
    training_rows = fit_rows.loc[folds.ne(monitor_fold)]
    if (
        set(training_rows[target_column].astype(int)) != {0, 1}
        or set(monitor_rows[target_column].astype(int)) != {0, 1}
        or set(training_rows["group_hash"].astype(str))
        & set(monitor_rows["group_hash"].astype(str))
    ):
        raise Stage3bContractError(
            "development train/monitor partition is invalid"
        )
    estimator.fit(
        training_rows[feature_order],
        training_rows[target_column].to_numpy(dtype="int8"),
        validation_values=monitor_rows[feature_order],
        validation_target=monitor_rows[target_column].to_numpy(dtype="int8"),
    )
    binding = {
        "policy": (
            FINETUNE_VALIDATION_MONITOR_POLICY
            if contract.model == "tabpfn_finetuned"
            else CNN_CONFIGURATION_SELECTION_POLICY
        ),
        "source_split": "train_2020_2023",
        "maximum_year": int(years.max()),
        "monitor_fold": monitor_fold,
        "training_folds": sorted(
            int(value)
            for value in pd.to_numeric(training_rows["fold"], errors="raise")
            .astype(int)
            .unique()
        ),
        "training_rows": len(training_rows),
        "monitor_rows": len(monitor_rows),
        "seed": seed,
    }
    estimator.estimator.development_monitor_binding_ = binding
    if contract.model == "tabpfn_finetuned":
        estimator.estimator.finetune_monitor_binding_ = binding


def _pipeline_fit_log(pipeline: FormalProbabilityPipeline, *, fit_name: str) -> dict[str, Any]:
    estimator = pipeline.estimator
    log: dict[str, Any] = {
        "fit_name": fit_name,
        "backend": type(estimator).__name__,
    }
    history = getattr(estimator, "training_history_", None)
    if history is not None:
        log["epoch_metrics"] = history
    bagging = getattr(estimator, "bagging_log", None)
    if bagging is not None:
        log["bagging"] = bagging
    event = getattr(estimator, "fit_event", None)
    if event is not None:
        log["thinking_event"] = event
    backend_provenance = getattr(estimator, "backend_provenance_", None)
    if backend_provenance is not None:
        log["backend_provenance"] = backend_provenance
    cv_binding = getattr(estimator, "stacking_cv_binding_", None)
    if cv_binding is not None:
        log["stacking_cv_binding"] = cv_binding
    finetune_monitor = getattr(estimator, "finetune_monitor_binding_", None)
    if finetune_monitor is not None:
        log["finetune_monitor"] = finetune_monitor
    development_monitor = getattr(
        estimator, "development_monitor_binding_", None
    )
    if development_monitor is not None:
        log["development_monitor"] = development_monitor
    convergence = getattr(estimator, "convergence_", None)
    if convergence is not None:
        log["convergence"] = convergence
    return log


def _apply_finetune_baseline_gate(
    contract: TaskContract,
    predictions: pd.DataFrame,
    final_model: FormalProbabilityPipeline,
    policy: dict[str, Any],
    *,
    workspace_root: Path,
    feature_order: list[str],
) -> tuple[pd.DataFrame, Any, dict[str, Any]]:
    baseline_prediction_path = _bound_file(
        policy["baseline_predictions"], workspace_root, label="fine-tune baseline predictions"
    )
    baseline_model_path = _bound_file(
        policy["baseline_model"], workspace_root, label="fine-tune baseline model"
    )
    baseline_manifest_path = _bound_file(
        policy["baseline_task_manifest"], workspace_root, label="fine-tune baseline manifest"
    )
    baseline_spec_path = _bound_file(
        policy["baseline_spec"], workspace_root, label="fine-tune baseline spec"
    )
    manifest = read_json(baseline_manifest_path)
    baseline_spec = read_json(baseline_spec_path)
    expected_task = f"P1_05b-{contract.outcome}-tabpfn_standard"
    if (
        manifest.get("task_id") != expected_task
        or manifest.get("status") != "PASS"
        or manifest.get("scientific_artifact") is not True
        or manifest.get("maximum_year") != 2024
        or manifest.get("2025_access_count") != 0
        or manifest.get("artifact_hashes", {}).get("predictions.parquet")
        != sha256_file(baseline_prediction_path)
        or manifest.get("artifact_hashes", {}).get("model.joblib")
        != sha256_file(baseline_model_path)
        or manifest.get("artifact_hashes", {}).get("spec.json")
        != sha256_file(baseline_spec_path)
        or baseline_spec.get("task_id") != expected_task
        or baseline_spec.get("model") != "tabpfn_standard"
        or baseline_spec.get("feature_order") != feature_order
        or baseline_spec.get("feature_order_sha256") != sha256_lines(feature_order)
    ):
        raise Stage3bContractError("fine-tune baseline artifact is not accepted standard TabPFN")
    baseline = pd.read_parquet(baseline_prediction_path)
    if baseline.columns.tolist() != PREDICTION_COLUMNS:
        raise Stage3bContractError("fine-tune baseline predictions are not canonical")
    if (
        set(baseline["outcome"].astype(str)) != {contract.outcome}
        or set(baseline["model"].astype(str)) != {"tabpfn_standard"}
        or set(baseline["split"].astype(str))
        != {"oof_2020_2023", "validation_2024"}
    ):
        raise Stage3bContractError("fine-tune baseline prediction identity differs")
    key_columns = ["row_hash", "split", "fold", "y_true"]
    left = predictions[key_columns].sort_values(["split", "row_hash"], kind="mergesort")
    right = baseline[key_columns].sort_values(["split", "row_hash"], kind="mergesort")
    try:
        pd.testing.assert_frame_equal(
            left.reset_index(drop=True),
            right.reset_index(drop=True),
            check_dtype=False,
            check_exact=True,
        )
    except AssertionError as error:
        raise Stage3bContractError("fine-tune/baseline prediction keys differ") from error
    fine_oof = predictions.loc[predictions["split"].eq(FINETUNE_BASELINE_GATE_SPLIT)]
    baseline_oof = baseline.loc[baseline["split"].eq(FINETUNE_BASELINE_GATE_SPLIT)]
    fine_auprc = float(
        average_precision_score(fine_oof["y_true"], fine_oof["prediction"])
    )
    baseline_auprc = float(
        average_precision_score(baseline_oof["y_true"], baseline_oof["prediction"])
    )
    selected = "tabpfn_finetuned" if fine_auprc > baseline_auprc else "tabpfn_standard"
    record = {
        "split": FINETUNE_BASELINE_GATE_SPLIT,
        "metric": "AUPRC",
        "fine_tuned_value": fine_auprc,
        "standard_value": baseline_auprc,
        "selected_model": selected,
        "fine_tuned_won": selected == "tabpfn_finetuned",
        "decision": (
            "fine-tune won; adopted"
            if selected == "tabpfn_finetuned"
            else "fine-tune did not win; reverted to standard"
        ),
        "baseline_artifact_sha256": sha256_file(baseline_prediction_path),
        "validation_2024_used_for_selection": False,
    }
    print(f"fine_tune_baseline_gate {json.dumps(record, sort_keys=True)}", flush=True)
    if selected == "tabpfn_finetuned":
        return predictions, final_model, record
    fallback = baseline.copy()
    fallback["task_id"] = contract.task_id
    fallback["model"] = contract.model
    return fallback[PREDICTION_COLUMNS], joblib.load(baseline_model_path), record


def cnn_candidate_configurations(parameters: dict[str, Any]) -> list[dict[str, Any]]:
    points = (
        {"proj_dim": 1024, "channels": 128, "n_conv": 2, "kernel": 3},
        {"proj_dim": 2048, "channels": 256, "n_conv": 3, "kernel": 5},
        {"proj_dim": 4096, "channels": 512, "n_conv": 4, "kernel": 7},
    )
    configurations = []
    for point in points:
        configuration = {**parameters, **point}
        configuration.setdefault("early_stopping_patience", 5)
        configuration.setdefault(
            "minimum_epochs", min(5, int(configuration.get("epochs", 20)))
        )
        configuration.setdefault("early_stopping_min_delta", 1e-4)
        configuration["config_sha256"] = canonical_sha256(configuration)
        configurations.append(configuration)
    return configurations


def cnn_execution_envelope(parameters: dict[str, Any]) -> dict[str, Any]:
    effective_batch_size = int(parameters.get("batch_size", 256))
    micro_batch_size = int(parameters.get("micro_batch_size", effective_batch_size))
    accumulation_steps = int(parameters.get("gradient_accumulation_steps", 1))
    validation_batch_size = int(
        parameters.get("validation_batch_size", effective_batch_size * 2)
    )
    predict_batch_size = int(
        parameters.get("predict_batch_size", effective_batch_size * 2)
    )
    if (
        effective_batch_size < 1
        or micro_batch_size < 1
        or accumulation_steps < 1
        or micro_batch_size * accumulation_steps != effective_batch_size
        or validation_batch_size < 1
        or predict_batch_size < 1
    ):
        raise Stage3bContractError("CNN execution envelope is invalid")
    return {
        "contract_version": "p1-v2-stage3b-cnn-execution-envelope/1",
        "effective_batch_size": effective_batch_size,
        "micro_batch_size": micro_batch_size,
        "gradient_accumulation_steps": accumulation_steps,
        "validation_batch_size": validation_batch_size,
        "predict_batch_size": predict_batch_size,
    }


def cnn_optimizer_steps_per_epoch(
    loader_batches: int, accumulation_steps: int
) -> int:
    if loader_batches < 1 or accumulation_steps < 1:
        raise Stage3bContractError("CNN optimizer-step inputs are invalid")
    return max(1, int(np.ceil(loader_batches / accumulation_steps)))


def cnn_memory_safe_execution_parameters(
    parameters: dict[str, Any],
) -> dict[str, Any]:
    execution = dict(parameters)
    if (
        execution.get("proj_dim") == 4096
        and execution.get("channels") == 512
        and execution.get("n_conv") == 4
        and execution.get("kernel") == 7
        and execution.get("batch_size", 256) == 256
    ):
        execution.update(
            {
                "micro_batch_size": 64,
                "gradient_accumulation_steps": 4,
                "validation_batch_size": 64,
                "predict_batch_size": 64,
            }
        )
    cnn_execution_envelope(execution)
    return execution


def _stop_new_stage3b_fit(started_at: float, *, now: float | None = None) -> bool:
    observed = time.perf_counter() if now is None else now
    return observed - started_at >= STAGE3B_STOP_NEW_FIT_HOURS * 3600


def _write_stage3b_checkpoint_boundary(
    output_dir: Path,
    contract: TaskContract,
    authorization: dict[str, Any],
    *,
    owner_alias: str,
    completed_folds: list[int],
    phase: str,
    extra_state_paths: list[Path] | None = None,
) -> None:
    cursor = _write_resume_cursor(
        output_dir,
        contract,
        authorization,
        owner_alias=owner_alias,
        completed_folds=completed_folds,
        extra_state_paths=extra_state_paths,
    )
    payload = {
        "contract_version": "p1-v2-stage3b-partial-boundary/1",
        "status": "PARTIAL",
        "task_id": contract.task_id,
        "phase": phase,
        "completed_folds": completed_folds,
        "stop_new_fit_hours": STAGE3B_STOP_NEW_FIT_HOURS,
        "session_hard_limit_hours": STAGE3B_SESSION_HARD_LIMIT_HOURS,
        "checkpoint_resume_required": True,
        "same_owner_resume_required": True,
        "resume_cursor_sha256": cursor["resume_cursor_sha256"],
        "maximum_year": 2024,
        "2025_access_count": 0,
    }
    payload["partial_payload_sha256"] = canonical_sha256(payload)
    atomic_json(output_dir / "_PARTIAL.json", payload)
    raise Stage3bCheckpointBoundary(payload)


def _cnn_selection_checkpoint(
    output_dir: Path,
    contract: TaskContract,
    authorization: dict[str, Any],
    *,
    owner_alias: str,
    configurations: list[dict[str, Any]],
    results: list[dict[str, Any]],
) -> Path:
    path = output_dir / "cnn_configuration_selection.json"
    complete = len(results) == len(configurations)
    payload = {
        "contract_version": "p1-v2-stage3b-cnn-configuration-selection/1",
        "status": "COMPLETE" if complete else "PARTIAL",
        **_checkpoint_lock(contract, authorization, owner_alias=owner_alias),
        "policy": CNN_CONFIGURATION_SELECTION_POLICY,
        "candidate_config_sha256s": [
            configuration["config_sha256"] for configuration in configurations
        ],
        "results": results,
        "locked_config_sha256": (
            None
            if not complete
            else sorted(
                results,
                key=lambda row: (
                    -float(row["monitor_auprc"]),
                    float(row["monitor_brier"]),
                    str(row["config_sha256"]),
                ),
            )[0]["config_sha256"]
        ),
        "selection_split": "train_2020_2023",
        "selection_maximum_year": 2023,
        "validation_2024_used": False,
        "2025_access_count": 0,
    }
    payload["selection_payload_sha256"] = canonical_sha256(payload)
    atomic_json(path, payload)
    return path


def _select_cnn_configuration(
    contract: TaskContract,
    authorization: dict[str, Any],
    train: pd.DataFrame,
    feature_order: list[str],
    target_column: str,
    parameters: dict[str, Any],
    *,
    device_plan: DevicePlan,
    runtime_context: dict[str, Any],
    output_dir: Path,
    owner_alias: str,
    started_at: float,
    completed_folds: list[int],
) -> dict[str, Any]:
    configurations = cnn_candidate_configurations(parameters)
    selection_path = output_dir / "cnn_configuration_selection.json"
    results: list[dict[str, Any]] = []
    if selection_path.is_file():
        checkpoint = read_json(selection_path)
        claimed = checkpoint.get("selection_payload_sha256")
        unhashed = dict(checkpoint)
        unhashed.pop("selection_payload_sha256", None)
        expected_lock = _checkpoint_lock(
            contract, authorization, owner_alias=owner_alias
        )
        if (
            claimed != canonical_sha256(unhashed)
            or any(checkpoint.get(key) != value for key, value in expected_lock.items())
            or checkpoint.get("candidate_config_sha256s")
            != [configuration["config_sha256"] for configuration in configurations]
            or checkpoint.get("selection_split") != "train_2020_2023"
            or checkpoint.get("selection_maximum_year") != 2023
            or checkpoint.get("validation_2024_used") is not False
            or checkpoint.get("2025_access_count") != 0
        ):
            raise Stage3bContractError("CNN configuration selection checkpoint differs")
        results = list(checkpoint.get("results") or [])
    folds = pd.to_numeric(train["fold"], errors="raise").astype(int)
    monitor_rows = train.loc[folds.eq(0)]
    training_rows = train.loc[folds.ne(0)]
    years = pd.to_numeric(train["split_year"], errors="coerce")
    if (
        set(train["split"].astype(str)) != {"train_2020_2023"}
        or years.isna().any()
        or not years.between(2020, 2023).all()
        or set(training_rows[target_column].astype(int)) != {0, 1}
        or set(monitor_rows[target_column].astype(int)) != {0, 1}
        or set(training_rows["group_hash"].astype(str))
        & set(monitor_rows["group_hash"].astype(str))
    ):
        raise Stage3bContractError("CNN selection requires development-only group folds")
    completed_hashes = [str(row.get("config_sha256")) for row in results]
    expected_prefix = [
        configuration["config_sha256"] for configuration in configurations
    ][: len(results)]
    if completed_hashes != expected_prefix:
        raise Stage3bContractError("CNN selection results are not a candidate prefix")
    for index, configuration in enumerate(configurations[len(results) :], len(results)):
        if _stop_new_stage3b_fit(started_at):
            _write_stage3b_checkpoint_boundary(
                output_dir,
                contract,
                authorization,
                owner_alias=owner_alias,
                completed_folds=completed_folds,
                phase="cnn_configuration_selection",
                extra_state_paths=[selection_path] if selection_path.is_file() else None,
            )
        fit_context = {
            "model_policy": runtime_context["model_policy"],
            "fit_name": f"cnn_selection_{index}",
        }
        scientific_parameters = {
            key: value for key, value in configuration.items() if key != "config_sha256"
        }
        execution_parameters = cnn_memory_safe_execution_parameters(
            scientific_parameters
        )
        estimator = make_formal_estimator(
            contract,
            execution_parameters,
            device_plan=device_plan,
            seed=int(authorization["execution_spec"]["seed"]) + 10000 + index,
            runtime_context=fit_context,
        )
        estimator.fit(
            training_rows[feature_order],
            training_rows[target_column].to_numpy(dtype="int8"),
            validation_values=monitor_rows[feature_order],
            validation_target=monitor_rows[target_column].to_numpy(dtype="int8"),
        )
        probability = estimator.predict_proba(monitor_rows[feature_order])[:, 1]
        fit_log = _pipeline_fit_log(
            estimator, fit_name=f"cnn_selection_{index}"
        )
        convergence = fit_log.get("convergence")
        if not isinstance(convergence, dict) or convergence.get("converged") is not True:
            raise Stage3bContractError("CNN candidate did not produce convergence evidence")
        results.append(
            {
                "config_sha256": configuration["config_sha256"],
                "parameters": {
                    key: value
                    for key, value in configuration.items()
                    if key != "config_sha256"
                },
                "execution_envelope": cnn_execution_envelope(execution_parameters),
                "monitor_fold": 0,
                "fit_rows": len(training_rows),
                "monitor_rows": len(monitor_rows),
                "fit_maximum_year": int(
                    pd.to_numeric(training_rows["split_year"], errors="raise").max()
                ),
                "monitor_maximum_year": int(
                    pd.to_numeric(monitor_rows["split_year"], errors="raise").max()
                ),
                "monitor_auprc": float(
                    average_precision_score(
                        monitor_rows[target_column].to_numpy(dtype="int8"), probability
                    )
                ),
                "monitor_brier": float(
                    brier_score_loss(
                        monitor_rows[target_column].to_numpy(dtype="int8"), probability
                    )
                ),
                "convergence": convergence,
            }
        )
        _cnn_selection_checkpoint(
            output_dir,
            contract,
            authorization,
            owner_alias=owner_alias,
            configurations=configurations,
            results=results,
        )
        _write_resume_cursor(
            output_dir,
            contract,
            authorization,
            owner_alias=owner_alias,
            completed_folds=completed_folds,
            extra_state_paths=[selection_path],
        )
    checkpoint = read_json(selection_path)
    locked_sha256 = checkpoint.get("locked_config_sha256")
    locked = next(
        (
            configuration
            for configuration in configurations
            if configuration["config_sha256"] == locked_sha256
        ),
        None,
    )
    if checkpoint.get("status") != "COMPLETE" or locked is None:
        raise Stage3bContractError("CNN configuration selection did not lock a candidate")
    runtime_context["cnn_configuration_selection"] = checkpoint
    runtime_context["fit_logs"].extend(
        {
            "fit_name": f"cnn_selection_{index}",
            "configuration_selection": row,
        }
        for index, row in enumerate(results)
    )
    return cnn_memory_safe_execution_parameters(
        {key: value for key, value in locked.items() if key != "config_sha256"}
    )


def execute_formal_task(
    contract: TaskContract,
    authorization: dict[str, Any],
    *,
    workspace_root: Path,
    device_plan: DevicePlan,
    output_dir: Path | None = None,
    owner_alias: str = "UNSPECIFIED",
    resume: bool = False,
) -> PreparedTaskResult:
    started_at = time.perf_counter()
    if not contract.formal_training_authorized:
        raise Stage3bContractError("formal task contract has not passed authorization")
    execution_spec = authorization["execution_spec"]
    if device_plan.execution_device == "cuda":
        import torch

        torch.cuda.reset_peak_memory_stats(0)
    if contract.model == "stacking":
        train, validation, feature_order, stacking_sources = _load_stacking_formal_frames(
            contract, authorization, workspace_root
        )
        target_column = "y_true"
    else:
        train, validation, feature_order = _load_stage1a_formal_frames(
            contract, authorization, workspace_root
        )
        stacking_sources = None
        target_column = f"y_{contract.outcome}"
    validate_no_future_data(train)
    validate_no_future_data(validation)
    privacy_assertion = _assert_deidentified_numeric_features(
        train, validation, feature_order
    )
    seed = int(execution_spec["seed"])
    parameters = dict(execution_spec["hyperparameters"])
    runtime_context: dict[str, Any] = {
        "model_policy": dict(execution_spec["model_policy"]),
        "fit_logs": [],
    }
    if contract.model == "tabpfn_thinking":
        scheduler_claim = _validate_thinking_scheduler_claim(
            contract,
            execution_spec["model_policy"]["quota_reservation"],
            workspace_root,
        )
        expected_status = "RESUME" if resume else "LAUNCHED"
        if (
            scheduler_claim["owner_alias"] != owner_alias
            or scheduler_claim["status"] != expected_status
        ):
            raise Stage3bContractError(
                "thinking scheduler claim does not authorize this owner/run mode"
            )
        runtime_context["thinking_scheduler_claim"] = scheduler_claim
    prediction_parts: list[pd.DataFrame] = []
    completed_folds: list[int] = []
    checkpoint_enabled = (
        output_dir is not None
        and "oof_2020_2023" in contract.expected_prediction_splits
        and contract.model != "stacking"
    )
    if checkpoint_enabled:
        output_dir.mkdir(parents=True, exist_ok=True)
        if resume:
            completed_folds, resumed_parts, resume_cursor = _load_resume_cursor(
                output_dir,
                contract,
                authorization,
                owner_alias=owner_alias,
            )
            prediction_parts.extend(resumed_parts)
            if contract.model == "tabpfn_thinking":
                runtime_context["resume_thinking_ledger"] = resume_cursor.get(
                    "thinking_fit_ledger"
                )
        elif any(output_dir.iterdir()):
            raise Stage3bContractError("new formal Stage3b output directory must be empty")
        elif contract.model == "cnn_1d":
            _write_resume_cursor(
                output_dir,
                contract,
                authorization,
                owner_alias=owner_alias,
                completed_folds=[],
            )
    if contract.model == "cnn_1d":
        if output_dir is None:
            raise Stage3bContractError("formal CNN selection requires an output directory")
        parameters = _select_cnn_configuration(
            contract,
            authorization,
            train,
            feature_order,
            target_column,
            parameters,
            device_plan=device_plan,
            runtime_context=runtime_context,
            output_dir=output_dir,
            owner_alias=owner_alias,
            started_at=started_at,
            completed_folds=completed_folds,
        )
    checkpoint_extra_paths = (
        [output_dir / "cnn_configuration_selection.json"]
        if contract.model == "cnn_1d" and output_dir is not None
        else None
    )
    if "oof_2020_2023" in contract.expected_prediction_splits:
        for fold in range(5):
            if fold in completed_folds:
                continue
            if checkpoint_enabled and _stop_new_stage3b_fit(started_at):
                _write_stage3b_checkpoint_boundary(
                    output_dir,
                    contract,
                    authorization,
                    owner_alias=owner_alias,
                    completed_folds=completed_folds,
                    phase=f"before_oof_fold_{fold}",
                    extra_state_paths=checkpoint_extra_paths,
                )
            fit_rows = train.loc[train["fold"].ne(fold)]
            predict_rows = train.loc[train["fold"].eq(fold)]
            fit_name = f"oof_fold_{fold}"
            runtime_context["fit_name"] = fit_name
            if contract.model == "stacking":
                fixed_cv, cv_binding = _stacking_predefined_cv(
                    fit_rows, fit_name=fit_name, expected_splits=4
                )
                runtime_context["stacking_predefined_cv"] = fixed_cv
                runtime_context["stacking_cv_binding"] = cv_binding
            estimator = make_formal_estimator(
                contract,
                parameters,
                device_plan=device_plan,
                seed=seed + fold,
                runtime_context=runtime_context,
            )
            _fit_formal_pipeline(
                contract,
                estimator,
                fit_rows,
                feature_order=feature_order,
                target_column=target_column,
                seed=seed + fold,
            )
            probability = estimator.predict_proba(predict_rows[feature_order])[:, 1]
            fold_predictions = pd.DataFrame(
                {
                    "task_id": contract.task_id,
                    "row_hash": predict_rows["row_hash"].astype(str),
                    "outcome": contract.outcome,
                    "model": contract.model,
                    "split": "oof_2020_2023",
                    "fold": pd.array([fold] * len(predict_rows), dtype="Int8"),
                    "y_true": predict_rows[target_column].to_numpy(dtype="int8"),
                    "prediction": probability,
                },
                columns=PREDICTION_COLUMNS,
            )
            prediction_parts.append(fold_predictions)
            runtime_context["fit_logs"].append(
                _pipeline_fit_log(estimator, fit_name=fit_name)
            )
            if checkpoint_enabled:
                atomic_parquet(
                    output_dir / f"checkpoint_fold_{fold}_predictions.parquet",
                    fold_predictions,
                )
                completed_folds.append(fold)
                _write_resume_cursor(
                    output_dir,
                    contract,
                    authorization,
                    owner_alias=owner_alias,
                    completed_folds=completed_folds,
                    thinking_fit_ledger=(
                        runtime_context["thinking_manager"].ledger()
                        if contract.model == "tabpfn_thinking"
                        else None
                    ),
                    extra_state_paths=checkpoint_extra_paths,
                )
    if checkpoint_enabled and _stop_new_stage3b_fit(started_at):
        _write_stage3b_checkpoint_boundary(
            output_dir,
            contract,
            authorization,
            owner_alias=owner_alias,
            completed_folds=completed_folds,
            phase="before_final_2020_2023",
            extra_state_paths=checkpoint_extra_paths,
        )
    runtime_context["fit_name"] = "final_2020_2023"
    if contract.model == "stacking":
        fixed_cv, cv_binding = _stacking_predefined_cv(
            train, fit_name="final_2020_2023", expected_splits=5
        )
        runtime_context["stacking_predefined_cv"] = fixed_cv
        runtime_context["stacking_cv_binding"] = cv_binding
    final_model = make_formal_estimator(
        contract,
        parameters,
        device_plan=device_plan,
        seed=seed,
        runtime_context=runtime_context,
    )
    _fit_formal_pipeline(
        contract,
        final_model,
        train,
        feature_order=feature_order,
        target_column=target_column,
        seed=seed,
    )
    runtime_context["fit_logs"].append(
        _pipeline_fit_log(final_model, fit_name="final_2020_2023")
    )
    validation_probability = final_model.predict_proba(validation[feature_order])[:, 1]
    prediction_parts.append(
        pd.DataFrame(
            {
                "task_id": contract.task_id,
                "row_hash": validation["row_hash"].astype(str),
                "outcome": contract.outcome,
                "model": contract.model,
                "split": "validation_2024",
                "fold": pd.array([pd.NA] * len(validation), dtype="Int8"),
                "y_true": validation[target_column].to_numpy(dtype="int8"),
                "prediction": validation_probability,
            },
            columns=PREDICTION_COLUMNS,
        )
    )
    predictions = pd.concat(prediction_parts, ignore_index=True)
    baseline_gate = None
    if contract.model == "tabpfn_finetuned":
        predictions, final_model, baseline_gate = _apply_finetune_baseline_gate(
            contract,
            predictions,
            final_model,
            execution_spec["model_policy"],
            workspace_root=workspace_root,
            feature_order=feature_order,
        )
        if checkpoint_enabled and baseline_gate["fine_tuned_won"] is False:
            for fold in range(5):
                atomic_parquet(
                    output_dir / f"checkpoint_fold_{fold}_predictions.parquet",
                    predictions.loc[
                        predictions["split"].eq("oof_2020_2023")
                        & predictions["fold"].astype("Int8").eq(fold)
                    ],
                )
            _write_resume_cursor(
                output_dir,
                contract,
                authorization,
                owner_alias=owner_alias,
                completed_folds=list(range(5)),
            )
    coverage_parts = [
        pd.DataFrame(
            {
                "row_hash": train["row_hash"].astype(str),
                "outcome": contract.outcome,
                "model": contract.model,
                "split": "oof_2020_2023",
                "eligible": "oof_2020_2023" in contract.expected_prediction_splits,
            }
        ),
        pd.DataFrame(
            {
                "row_hash": validation["row_hash"].astype(str),
                "outcome": contract.outcome,
                "model": contract.model,
                "split": "validation_2024",
                "eligible": True,
            }
        ),
    ]
    coverage = pd.concat(coverage_parts, ignore_index=True)[COVERAGE_COLUMNS]
    if len(validation) < 100:
        raise Stage3bContractError("formal validation cohort has fewer than 100 canary rows")
    canary_source = validation.sort_values("row_hash", kind="mergesort").head(100)
    canary_inputs = canary_source[["row_hash", *feature_order]].reset_index(drop=True)
    # The canary rows are a slice of validation_2024, already scored above. Re-scoring them costs a
    # remote provider call that re-ships the whole training context to obtain 100 probabilities we
    # already hold; taking them from the prediction frame also makes canary_expected provably equal
    # to predictions.parquet instead of merely assumed equal.
    validation_predictions = predictions.loc[
        predictions["split"].eq("validation_2024"), ["row_hash", "prediction"]
    ]
    canary_prediction = canary_inputs[["row_hash"]].merge(
        validation_predictions, on="row_hash", how="left"
    )["prediction"]
    if canary_prediction.isna().any():
        raise Stage3bContractError("canary rows are absent from the validation prediction block")
    canary_expected = pd.DataFrame(
        {
            "row_hash": canary_inputs["row_hash"],
            "outcome": contract.outcome,
            "model": contract.model,
            "prediction": canary_prediction.to_numpy(dtype="float64"),
        },
        columns=CANARY_EXPECTED_COLUMNS,
    )
    thinking_ledger = None
    if contract.model == "tabpfn_thinking":
        manager = runtime_context.get("thinking_manager")
        if not isinstance(manager, ThinkingQuotaManager):
            raise Stage3bContractError("thinking execution lacks its quota manager")
        thinking_ledger = manager.ledger()
        expected_fits = contract.thinking_fit_count
        accounted = thinking_ledger["scientific_fit_count"] + thinking_ledger[
            "standard_fallback_count"
        ]
        if accounted != expected_fits:
            raise Stage3bContractError("thinking ledger does not account for every planned fit")
    package_versions = {}
    for package in ("numpy", "pandas", "scikit-learn", "torch", "tabpfn", "tabicl", "tabpfn-client"):
        try:
            package_versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            package_versions[package] = None
    package_provenance_hashes = {
        name: binding["sha256"]
        for name, binding in authorization["package_provenance"].items()
    }
    lineage_id = stage3b_lineage_id(
        effective_registry_sha256=authorization["task_registry_sha256"],
        registry_rebind_receipt_sha256=package_provenance_hashes[
            "registry_rebind_receipt"
        ],
        package_manifest_sha256=package_provenance_hashes["package_manifest"],
        package_lock_sha256=package_provenance_hashes["package_lock"],
    )
    final_backend_provenance = getattr(
        final_model.estimator, "backend_provenance_", None
    )
    if contract.model == "tabicl" and not isinstance(final_backend_provenance, dict):
        raise Stage3bContractError("TabICL final model lacks backend provenance")
    runtime_provenance = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "device_plan": dataclasses.asdict(device_plan),
        "package_versions": package_versions,
        "package_provenance_hashes": package_provenance_hashes,
        "elapsed_seconds": float(time.perf_counter() - started_at),
    }
    try:
        import psutil

        runtime_provenance["ram_total_bytes"] = int(psutil.virtual_memory().total)
        memory = psutil.Process(os.getpid()).memory_info()
        runtime_provenance["ram_peak_rss_bytes"] = int(
            getattr(memory, "peak_wset", memory.rss)
        )
    except ImportError:
        runtime_provenance["ram_total_bytes"] = None
        runtime_provenance["ram_peak_rss_bytes"] = None
    if device_plan.execution_device == "cuda":
        import torch

        runtime_provenance["gpu_name"] = torch.cuda.get_device_name(0)
        runtime_provenance["gpu_total_vram_bytes"] = int(
            torch.cuda.get_device_properties(0).total_memory
        )
        runtime_provenance["gpu_peak_vram_bytes"] = int(
            torch.cuda.max_memory_allocated(0)
        )
    return PreparedTaskResult(
        predictions=predictions,
        coverage=coverage,
        canary_inputs=canary_inputs,
        canary_expected=canary_expected,
        model_state=final_model,
        feature_order=feature_order,
        input_hashes={
            name: str(binding["sha256"])
            for name, binding in authorization["input_artifacts"].items()
        },
        model_provenance={
            "backend": type(final_model.estimator).__name__,
            "device": device_plan.execution_device,
            "authorization_sha256": authorization["authorization_sha256"],
            "runner_sha256": authorization["runner_sha256"],
            "lineage_id": lineage_id,
            "effective_registry_sha256": authorization["task_registry_sha256"],
            "registry_rebind_receipt_sha256": package_provenance_hashes[
                "registry_rebind_receipt"
            ],
            "package_manifest_sha256": package_provenance_hashes["package_manifest"],
            "package_lock_sha256": package_provenance_hashes["package_lock"],
            "package_provenance_hashes": package_provenance_hashes,
            "accepted_dependency_receipts": {
                dependency: binding["sha256"]
                for dependency, binding in authorization["accepted_dependency_tasks"].items()
            },
            "api_called": contract.compute_target == "kaggle_api",
            "gpu_training_launched": contract.compute_target == "kaggle_gpu",
            "hyperparameters": parameters,
            "cnn_configuration_selection": runtime_context.get(
                "cnn_configuration_selection"
            ),
            "model_policy": execution_spec["model_policy"],
            "fit_logs": runtime_context["fit_logs"],
            "fine_tune_baseline_gate": baseline_gate,
            "tabpfn_model_limits": runtime_context.get("tabpfn_model_limits"),
            "backend_provenance": final_backend_provenance,
            "stacking_cv_bindings": [
                log["stacking_cv_binding"]
                for log in runtime_context["fit_logs"]
                if "stacking_cv_binding" in log
            ],
            "bootstrap_replicates": int(execution_spec["bootstrap_replicates"]),
            "privacy_assertion": privacy_assertion,
        },
        stacking_sources=stacking_sources,
        thinking_fit_ledger=thinking_ledger,
        training_log={
            "fits": runtime_context["fit_logs"],
            "fine_tune_baseline_gate": baseline_gate,
            "cnn_configuration_selection": runtime_context.get(
                "cnn_configuration_selection"
            ),
        },
        runtime_provenance=runtime_provenance,
    )


def _bootstrap_interval(
    function: Callable[[np.ndarray, np.ndarray], float],
    y_true: np.ndarray,
    probability: np.ndarray,
    *,
    replicates: int,
    seed: int,
) -> tuple[float, float]:
    labels = np.asarray(y_true, dtype="int8")
    predictions = np.asarray(probability, dtype="float64")
    if replicates < 1 or len(labels) != len(predictions):
        raise Stage3bContractError("metric bootstrap inputs are invalid")
    cases = np.flatnonzero(labels == 1)
    controls = np.flatnonzero(labels == 0)
    if not len(cases) or not len(controls):
        raise Stage3bContractError("metric bootstrap requires cases and controls")
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(replicates):
        indices = np.concatenate(
            [
                rng.choice(cases, size=len(cases), replace=True),
                rng.choice(controls, size=len(controls), replace=True),
            ]
        )
        rng.shuffle(indices)
        value = float(function(labels[indices], predictions[indices]))
        if not np.isfinite(value):
            raise Stage3bContractError("metric bootstrap produced a non-finite replicate")
        values.append(value)
    if len(values) != replicates:
        raise Stage3bContractError("metric bootstrap did not return exact B replicates")
    lower, upper = np.quantile(np.asarray(values), [0.025, 0.975])
    return float(lower), float(upper)


def _metric_rows(
    contract: TaskContract,
    predictions: pd.DataFrame,
    *,
    bootstrap_replicates: int = 200,
) -> pd.DataFrame:
    rows = []
    functions: dict[str, Callable[[np.ndarray, np.ndarray], float]] = {
        "AUROC": roc_auc_score,
        "AUPRC": average_precision_score,
        "Brier": brier_score_loss,
    }
    for split, group in predictions.groupby("split", sort=True, observed=True):
        y_true = group["y_true"].to_numpy(dtype="int8")
        probability = group["prediction"].to_numpy(dtype="float64")
        estimable = len(y_true) > 0 and len(np.unique(y_true)) == 2
        for metric_index, (metric, function) in enumerate(functions.items()):
            value = float(function(y_true, probability)) if estimable else None
            lower_ci = None
            upper_ci = None
            if estimable:
                lower_ci, upper_ci = _bootstrap_interval(
                    function,
                    y_true,
                    probability,
                    replicates=bootstrap_replicates,
                    seed=20260714
                    + OUTCOMES.index(contract.outcome) * 100
                    + metric_index,
                )
            rows.append(
                {
                    "task_id": contract.task_id,
                    "outcome": contract.outcome,
                    "model": contract.model,
                    "split": str(split),
                    "metric": metric,
                    "value": value,
                    "status": "ESTIMATED" if estimable else "NOT_ESTIMABLE",
                    "n": int(len(y_true)),
                    "events": int(y_true.sum()),
                    "lower_ci": lower_ci,
                    "upper_ci": upper_ci,
                }
            )
    return pd.DataFrame(rows, columns=METRIC_COLUMNS)


def _validate_prepared_result(contract: TaskContract, result: PreparedTaskResult) -> None:
    if result.predictions.columns.tolist() != PREDICTION_COLUMNS:
        raise Stage3bContractError("prepared predictions are not canonical")
    if result.coverage.columns.tolist() != COVERAGE_COLUMNS:
        raise Stage3bContractError("prepared coverage is not canonical")
    if result.canary_expected.columns.tolist() != CANARY_EXPECTED_COLUMNS:
        raise Stage3bContractError("canary expected table is not canonical")
    if not result.feature_order or len(result.feature_order) != len(set(result.feature_order)):
        raise Stage3bContractError("feature order is empty or duplicated")
    if result.canary_inputs.columns.tolist() != ["row_hash", *result.feature_order]:
        raise Stage3bContractError("canary input feature order differs from the sealed order")
    if len(result.canary_inputs) != len(result.canary_expected):
        raise Stage3bContractError("canary input/expected row counts differ")
    if not 1 <= len(result.canary_inputs) <= 100:
        raise Stage3bContractError("canary must contain between one and 100 rows")
    predictions = result.predictions
    if set(predictions["task_id"].astype(str)) != {contract.task_id}:
        raise Stage3bContractError("predictions belong to another task")
    if set(predictions["outcome"].astype(str)) != {contract.outcome}:
        raise Stage3bContractError("predictions belong to another outcome")
    if set(predictions["model"].astype(str)) != {contract.model}:
        raise Stage3bContractError("predictions belong to another model")
    if tuple(sorted(predictions["split"].unique())) != tuple(
        sorted(contract.expected_prediction_splits)
    ):
        raise Stage3bContractError("prediction splits differ from the outcome-family contract")
    probability = pd.to_numeric(predictions["prediction"], errors="coerce")
    if probability.isna().any() or not probability.between(0, 1).all():
        raise Stage3bContractError("predictions contain NaN or out-of-range values")
    if predictions.duplicated(["task_id", "row_hash", "outcome", "model", "split"]).any():
        raise Stage3bContractError("duplicate prediction keys")
    oof = predictions.loc[predictions["split"].eq("oof_2020_2023")]
    if "oof_2020_2023" in contract.expected_prediction_splits:
        if oof.empty or oof["fold"].isna().any():
            raise Stage3bContractError("OOF predictions must have a fold for every row")
        observed_folds = sorted(
            pd.to_numeric(oof["fold"], errors="raise").astype(int).unique().tolist()
        )
        if observed_folds != list(range(5)):
            raise Stage3bContractError("OOF predictions must cover exact folds 0..4")
    elif not oof.empty:
        raise Stage3bContractError("non-stacking secondary thinking must not emit OOF")
    validation = predictions.loc[predictions["split"].eq("validation_2024")]
    if validation.empty or validation["fold"].notna().any():
        raise Stage3bContractError("validation predictions must exist and have null folds")
    coverage = result.coverage
    if set(coverage["outcome"].astype(str)) != {contract.outcome}:
        raise Stage3bContractError("coverage belongs to another outcome")
    if set(coverage["model"].astype(str)) != {contract.model}:
        raise Stage3bContractError("coverage belongs to another model")
    if coverage.duplicated(["row_hash", "outcome", "model", "split"]).any():
        raise Stage3bContractError("duplicate coverage keys")
    eligible_coverage = coverage.loc[coverage["eligible"].astype(bool), [
        "row_hash",
        "outcome",
        "model",
        "split",
    ]].sort_values(["split", "row_hash"], kind="mergesort").reset_index(drop=True)
    prediction_coverage = predictions.loc[:, [
        "row_hash",
        "outcome",
        "model",
        "split",
    ]].sort_values(["split", "row_hash"], kind="mergesort").reset_index(drop=True)
    try:
        pd.testing.assert_frame_equal(
            eligible_coverage, prediction_coverage, check_dtype=False, check_exact=True
        )
    except AssertionError as exc:
        raise Stage3bContractError(
            "eligible coverage keys must exactly equal prediction keys"
        ) from exc
    if contract.model == "stacking":
        validate_stacking_sources(contract, result.stacking_sources or [])
    if contract.model == "tabpfn_thinking" and result.thinking_fit_ledger is None:
        raise Stage3bContractError("thinking result lacks its fit ledger")
    if contract.model == "tabpfn_thinking" and result.thinking_fit_ledger is not None:
        ledger = result.thinking_fit_ledger
        scientific = ledger.get("scientific_fit_count")
        fallback = ledger.get("standard_fallback_count", 0)
        expected = contract.thinking_fit_count
        if (
            not isinstance(scientific, int)
            or not isinstance(fallback, int)
            or (scientific + fallback not in {0, expected})
            or ledger.get("synthetic_fit_count") != 0
        ):
            raise Stage3bContractError("thinking ledger fit accounting differs")
        accounts = ledger.get("accounts", [])
        if scientific and (
            not isinstance(accounts, list)
            or len(accounts) < 1
            or any(
                not 0
                <= int(account.get("counter_after", -1))
                <= int(account.get("quota_limit", -1))
                for account in accounts
            )
        ):
            raise Stage3bContractError("thinking ledger account counters differ")
        if scientific or fallback:
            planned_fits = ledger.get("planned_fits")
            completed = [
                event
                for event in ledger.get("events", [])
                if event.get("event") in {"thinking_fit", "standard_fallback"}
            ]
            if (
                ledger.get("quota_month")
                != dt.datetime.now(dt.UTC).strftime("%Y-%m")
                or ledger.get("quota_branch")
                != ledger.get("artifact_classification", {}).get("quota_branch")
                or not _is_sha256(ledger.get("quota_probe_sha256"))
                or not _is_sha256(ledger.get("global_plan_sha256"))
                or not _is_sha256(ledger.get("task_plan_sha256"))
                or not isinstance(planned_fits, list)
                or len(planned_fits) != expected
                or [event.get("fit_index") for event in completed]
                != list(range(expected))
            ):
                raise Stage3bContractError("thinking global reservation evidence differs")
            claim = ledger.get("scheduler_claim")
            if (
                not isinstance(claim, dict)
                or not isinstance(claim.get("claim_id"), str)
                or not claim["claim_id"]
                or not isinstance(claim.get("owner_alias"), str)
                or claim.get("status") not in {"LAUNCHED", "RESUME"}
                or not _is_sha256(claim.get("claim_receipt_sha256"))
                or not _is_sha256(claim.get("launch_receipt_sha256"))
            ):
                raise Stage3bContractError("thinking scheduler claim evidence differs")
            planned_by_index = {
                fit.get("fit_index"): fit
                for fit in planned_fits
                if isinstance(fit, dict)
            }
            if set(planned_by_index) != set(range(expected)):
                raise Stage3bContractError(
                    "thinking global reservation evidence differs"
                )
            fresh_completed = []
            for event in completed:
                planned = planned_by_index[event["fit_index"]]
                historical_completed = planned.get("historical_completed")
                if (
                    not isinstance(historical_completed, bool)
                    or event.get("fit_name") != planned.get("fit_name")
                    or event.get("historical_completed", False)
                    is not historical_completed
                    or (
                        historical_completed
                        and event.get("fresh_quota_slot_consumed") is not False
                    )
                ):
                    raise Stage3bContractError(
                        "thinking completed fit differs from its sealed reservation"
                    )
                if event.get("event") == "thinking_fit" and not historical_completed:
                    fresh_completed.append(event)
            used = [
                (event.get("account_alias"), event.get("reserved_slot"))
                for event in fresh_completed
            ]
            if len(used) != len(set(used)):
                raise Stage3bContractError("thinking ledger reuses a reserved account slot")


def thinking_artifact_classification(
    contract: TaskContract,
    ledger: dict[str, Any],
) -> dict[str, Any]:
    if contract.model != "tabpfn_thinking":
        raise Stage3bContractError("thinking classification requires a thinking task")
    planned = ledger.get("artifact_classification")
    if not isinstance(planned, dict):
        raise Stage3bContractError("thinking ledger lacks artifact classification")
    value = {
        "quota_branch": planned.get("quota_branch"),
        "quota_limited_supplemental": planned.get(
            "quota_limited_supplemental"
        ),
        "not_equivalent_to_full_oof": planned.get(
            "not_equivalent_to_full_oof"
        ),
        "full_oof": planned.get("full_oof_required"),
        "stacking_eligible": planned.get("stacking_eligible"),
        "planned_fit_count": planned.get("planned_fit_count"),
        "completed_thinking_fit_count": ledger.get("scientific_fit_count"),
        "standard_fallback_count": ledger.get("standard_fallback_count"),
        "quota_probe_sha256": ledger.get("quota_probe_sha256"),
        "global_plan_sha256": ledger.get("global_plan_sha256"),
    }
    expected = contract.thinking_fit_count
    supplemental = bool(contract.metadata.get("quota_limited_supplemental", False))
    if (
        set(value) != THINKING_ARTIFACT_CLASSIFICATION_KEYS
        or value["quota_branch"]
        not in {"full_9_outcome_oof", "quota_limited_supplemental"}
        or value["quota_limited_supplemental"] is not supplemental
        or value["not_equivalent_to_full_oof"] is not supplemental
        or value["full_oof"] is not (expected == 6)
        or value["stacking_eligible"] is not (expected == 6)
        or value["planned_fit_count"] != expected
        or value["completed_thinking_fit_count"] != expected
        or value["standard_fallback_count"] != 0
        or not _is_sha256(value["quota_probe_sha256"])
        or not _is_sha256(value["global_plan_sha256"])
    ):
        raise Stage3bContractError("thinking artifact classification differs")
    return value


def write_checkpoint_manifest(
    output_dir: Path,
    contract: TaskContract,
    *,
    completed_folds: list[int],
    state_artifacts: list[Path],
    owner_alias: str,
    complete: bool,
) -> Path:
    expected_folds = list(range(5))
    if contract.model not in CHECKPOINT_MODELS:
        raise Stage3bContractError(f"{contract.model} does not use checkpoint_manifest.json")
    if sorted(set(completed_folds)) != sorted(completed_folds):
        raise Stage3bContractError("completed checkpoint folds are duplicated or unsorted")
    if not set(completed_folds) <= set(expected_folds):
        raise Stage3bContractError("checkpoint contains a noncanonical fold")
    if complete and completed_folds != expected_folds:
        raise Stage3bContractError("COMPLETE checkpoint requires exact folds 0..4")
    path = output_dir / "checkpoint_manifest.json"
    atomic_json(
        path,
        {
            "contract_version": "p1-v2-stage3b-checkpoint/1",
            "task_id": contract.task_id,
            "status": "COMPLETE" if complete else "PARTIAL",
            "owner_alias": owner_alias,
            "same_owner_resume_required": True,
            "cross_session_parallel_resume": False,
            "completed_folds": completed_folds,
            "remaining_folds": [fold for fold in expected_folds if fold not in completed_folds],
            "state_artifact_hashes": {
                artifact.name: sha256_file(artifact) for artifact in state_artifacts
            },
            "maximum_year": 2024,
            "2025_access_count": 0,
        },
    )
    return path


def _finalize_formal_checkpoint(
    output_dir: Path,
    contract: TaskContract,
    *,
    model_path: Path,
) -> list[Path]:
    cursor_path = output_dir / "resume_cursor.json"
    checkpoint_path = output_dir / "checkpoint_manifest.json"
    cursor = read_json(cursor_path)
    checkpoint = read_json(checkpoint_path)
    if cursor.get("completed_folds") != list(range(5)):
        raise Stage3bContractError("formal checkpoint cannot complete before all five folds")
    cursor.pop("resume_cursor_sha256", None)
    cursor["status"] = "COMPLETE"
    cursor["final_model_sha256"] = sha256_file(model_path)
    cursor["resume_cursor_sha256"] = canonical_sha256(cursor)
    atomic_json(cursor_path, cursor)
    checkpoint.pop("checkpoint_payload_sha256", None)
    checkpoint["status"] = "COMPLETE"
    checkpoint["remaining_folds"] = []
    checkpoint["resume_cursor"] = {
        "path": cursor_path.name,
        "sha256": sha256_file(cursor_path),
    }
    checkpoint["final_model_sha256"] = sha256_file(model_path)
    checkpoint["checkpoint_payload_sha256"] = canonical_sha256(checkpoint)
    atomic_json(checkpoint_path, checkpoint)
    shards = [
        output_dir / f"checkpoint_fold_{fold}_predictions.parquet" for fold in range(5)
    ]
    if any(not path.is_file() for path in shards):
        raise Stage3bContractError("formal checkpoint is missing a fold prediction shard")
    return [checkpoint_path, cursor_path, *shards]


def write_canary_artifacts(
    output_dir: Path,
    contract: TaskContract,
    result: PreparedTaskResult,
) -> tuple[Path, Path, dict[str, Any]]:
    inputs_path = output_dir / "canary_inputs.parquet"
    expected_path = output_dir / "canary_expected.parquet"
    atomic_parquet(inputs_path, result.canary_inputs)
    atomic_parquet(expected_path, result.canary_expected)
    loaded = result.model_state
    if not hasattr(loaded, "predict_proba"):
        raise Stage3bContractError("sealed model cannot perform canary probability inference")
    expected = result.canary_expected["prediction"].to_numpy(dtype="float64")
    if contract.model in NONDETERMINISTIC_REMOTE_MODELS:
        if len(expected) != len(result.canary_inputs):
            raise Stage3bContractError("canary inputs and expectations are not row aligned")
        if not np.isfinite(expected).all() or expected.min() < 0.0 or expected.max() > 1.0:
            raise Stage3bContractError("canary expectations are not valid probabilities")
        return inputs_path, expected_path, {
            "status": "PASS_LOCAL_RELOAD_ONLY",
            "rows": int(len(expected)),
            "reload_numerical_fidelity_asserted": False,
            "backend_determinism": "remote_stochastic_search",
            "reloaded_estimator_type": type(loaded).__name__,
            "observed_within_run_absolute_delta": NONDETERMINISM_WITHIN_RUN_DELTA,
            "observed_reload_absolute_delta": NONDETERMINISM_RELOAD_DELTA,
            "superseded_tolerance": 1e-5,
            "authorization": CANARY_REDEFINITION_AUTHORIZATION,
            "feature_order_sha256": sha256_lines(result.feature_order),
        }
    actual = np.asarray(
        loaded.predict_proba(result.canary_inputs[result.feature_order])[:, 1],
        dtype="float64",
    )
    maximum_error = float(np.max(np.abs(actual - expected))) if len(expected) else 0.0
    if maximum_error > 1e-5:
        raise Stage3bContractError(f"model canary error exceeds 1e-5: {maximum_error}")
    return inputs_path, expected_path, {
        "status": "PASS",
        "rows": int(len(expected)),
        "maximum_absolute_error": maximum_error,
        "tolerance": 1e-5,
        "feature_order_sha256": sha256_lines(result.feature_order),
    }


def write_sealed_model_manifest(
    output_dir: Path,
    contract: TaskContract,
    *,
    model_path: Path,
    canary_paths: tuple[Path, Path],
    result: PreparedTaskResult,
    formal_authorized: bool,
) -> Path:
    path = output_dir / "sealed_model_manifest.json"
    thinking_classification = (
        thinking_artifact_classification(contract, result.thinking_fit_ledger or {})
        if formal_authorized and contract.model == "tabpfn_thinking"
        else None
    )
    lineage = {
        name: result.model_provenance.get(name)
        for name in (
            "lineage_id",
            "effective_registry_sha256",
            "registry_rebind_receipt_sha256",
            "package_manifest_sha256",
            "package_lock_sha256",
            "accepted_dependency_receipts",
        )
    }
    atomic_json(
        path,
        {
            "contract_version": "p1-v2-stage3b-sealed-model/1",
            "task_id": contract.task_id,
            "outcome": contract.outcome,
            "model": contract.model,
            "status": "SEALED_SMOKE" if not formal_authorized else "SEALED",
            "scientific_artifact": bool(formal_authorized),
            "model_artifacts": {model_path.name: sha256_file(model_path)},
            "canary_artifacts": {
                artifact.name: sha256_file(artifact) for artifact in canary_paths
            },
            "feature_order": result.feature_order,
            "feature_order_sha256": sha256_lines(result.feature_order),
            "input_hashes": result.input_hashes,
            "model_provenance": result.model_provenance,
            **lineage,
            "task_registry_sha256": contract.task_registry_sha256,
            "registry_task_sha256": contract.registry_task_sha256,
            "test_ready_for_p1_06": bool(formal_authorized),
            "strict_no_arrival_leakage": True,
            "maximum_year": 2024,
            "historical_2025_exposure": True,
            "2025_access_count": 0,
            **(
                {"thinking_artifact_classification": thinking_classification}
                if thinking_classification is not None
                else {}
            ),
        },
    )
    return path


def write_task_artifacts(
    contract: TaskContract,
    result: PreparedTaskResult,
    output_dir: Path,
    *,
    owner_alias: str = "SMOKE",
    formal_authorized: bool = False,
) -> dict[str, Any]:
    if formal_authorized and not contract.formal_training_authorized:
        raise Stage3bContractError("task contract itself is not formally authorized")
    _validate_prepared_result(contract, result)
    thinking_classification = (
        thinking_artifact_classification(contract, result.thinking_fit_ledger or {})
        if formal_authorized and contract.model == "tabpfn_thinking"
        else None
    )
    if formal_authorized and len(result.canary_inputs) != 100:
        raise Stage3bContractError("formal sealed models require an exact 100-row canary")
    output_dir.mkdir(parents=True, exist_ok=True)
    predictions_path = output_dir / "predictions.parquet"
    metrics_path = output_dir / "metrics.parquet"
    coverage_path = output_dir / "coverage.parquet"
    model_path = output_dir / "model.joblib"
    spec_path = output_dir / "spec.json"
    bootstrap_replicates = int(
        result.model_provenance.get("bootstrap_replicates", 200)
    )
    if formal_authorized and bootstrap_replicates < 2000:
        raise Stage3bContractError("formal Stage3b metrics require >=2,000 bootstraps")
    metrics = _metric_rows(
        contract,
        result.predictions,
        bootstrap_replicates=bootstrap_replicates,
    )
    atomic_parquet(predictions_path, result.predictions)
    atomic_parquet(metrics_path, metrics)
    atomic_parquet(coverage_path, result.coverage)
    atomic_joblib(model_path, result.model_state)
    reloaded = joblib.load(model_path)
    if contract.model == "tabicl" and formal_authorized:
        actual_provenance = getattr(reloaded.estimator, "backend_provenance_", None)
        if actual_provenance != result.model_provenance.get("backend_provenance"):
            raise Stage3bContractError("TabICL backend provenance changed after model reload")
    result.model_state = reloaded
    canary_input_path, canary_expected_path, canary = write_canary_artifacts(
        output_dir, contract, result
    )
    atomic_json(
        spec_path,
        {
            "contract_version": "p1-v2-stage3b-task-spec/1",
            "task_id": contract.task_id,
            "outcome": contract.outcome,
            "model": contract.model,
            "compute_target": contract.compute_target,
            "feature_order": result.feature_order,
            "feature_order_sha256": sha256_lines(result.feature_order),
            "expected_prediction_splits": list(contract.expected_prediction_splits),
            "stacking_eligible": contract.stacking_eligible,
            "model_provenance": result.model_provenance,
            "model_reload_canary": canary,
            "training_log": result.training_log,
            "runtime_provenance": result.runtime_provenance,
            "task_registry_sha256": contract.task_registry_sha256,
            "registry_task_sha256": contract.registry_task_sha256,
            "training_years": [2020, 2021, 2022, 2023],
            "validation_year": 2024,
            "uses_2025": False,
            "formal_training_authorized": bool(formal_authorized),
            **(
                {"thinking_artifact_classification": thinking_classification}
                if thinking_classification is not None
                else {}
            ),
        },
    )
    sealed_path = write_sealed_model_manifest(
        output_dir,
        contract,
        model_path=model_path,
        canary_paths=(canary_input_path, canary_expected_path),
        result=result,
        formal_authorized=formal_authorized,
    )

    extra_paths: list[Path] = []
    training_log_path = output_dir / "training_log.json"
    atomic_json(
        training_log_path,
        {
            "contract_version": "p1-v2-stage3b-training-log/1",
            "task_id": contract.task_id,
            "model": contract.model,
            "log": result.training_log,
            "maximum_year": 2024,
            "2025_access_count": 0,
        },
    )
    extra_paths.append(training_log_path)
    cnn_selection_path = output_dir / "cnn_configuration_selection.json"
    if contract.model == "cnn_1d":
        if formal_authorized and not cnn_selection_path.is_file():
            raise Stage3bContractError(
                "formal CNN artifact lacks configuration-selection evidence"
            )
        if cnn_selection_path.is_file():
            extra_paths.append(cnn_selection_path)
    stage_specific: Path
    if contract.model in CHECKPOINT_MODELS:
        if formal_authorized:
            checkpoint_paths = _finalize_formal_checkpoint(
                output_dir, contract, model_path=model_path
            )
            stage_specific = checkpoint_paths[0]
            extra_paths.extend(checkpoint_paths[1:])
        else:
            stage_specific = write_checkpoint_manifest(
                output_dir,
                contract,
                completed_folds=list(range(5)),
                state_artifacts=[model_path],
                owner_alias=owner_alias,
                complete=True,
            )
    elif contract.model == "tabpfn_thinking":
        stage_specific = output_dir / "thinking_fit_ledger.json"
        ledger = dict(result.thinking_fit_ledger or {})
        ledger.update(
            {
                "contract_version": "p1-v2-stage3b-thinking-fit-ledger/1",
                "task_id": contract.task_id,
                "expected_fits": contract.thinking_fit_count,
                "scientific_fit_count": int(ledger.get("scientific_fit_count", 0)),
                "synthetic_fit_count": int(ledger.get("synthetic_fit_count", 0)),
                "maximum_year": 2024,
                "2025_access_count": 0,
            }
        )
        atomic_json(stage_specific, ledger)
        if formal_authorized and "oof_2020_2023" in contract.expected_prediction_splits:
            extra_paths.extend(
                _finalize_formal_checkpoint(output_dir, contract, model_path=model_path)
            )
    else:
        stage_specific = output_dir / "stacking_feature_manifest.json"
        atomic_json(
            stage_specific,
            {
                "contract_version": "p1-v2-stage3b-stacking-features/1",
                "task_id": contract.task_id,
                "outcome": contract.outcome,
                "training_split": "oof_2020_2023",
                "validation_split": "validation_2024",
                "source_models": result.stacking_sources,
                "source_model_names": list(
                    stacking_feature_models(contract.outcome, contract.dependencies)
                ),
                "source_task_templates": STACKING_SOURCE_TASK_TEMPLATES,
                "stacking_cv_bindings": result.model_provenance.get(
                    "stacking_cv_bindings", []
                ),
                "stacking_cv_bindings_sha256": canonical_sha256(
                    result.model_provenance.get("stacking_cv_bindings", [])
                ),
                "no_in_sample_meta_features": True,
                "lineage_id": result.model_provenance.get("lineage_id"),
                "strict_no_arrival_leakage": True,
                "maximum_year": 2024,
                "2025_access_count": 0,
            },
        )

    core_paths = [
        predictions_path,
        metrics_path,
        coverage_path,
        model_path,
        spec_path,
        canary_input_path,
        canary_expected_path,
        sealed_path,
        stage_specific,
        *extra_paths,
    ]
    artifact_hashes = {path.name: sha256_file(path) for path in core_paths}
    hashes_path = output_dir / "hashes.json"
    atomic_json(
        hashes_path,
        {
            "contract_version": "p1-v2-stage3b-hashes/1",
            "task_id": contract.task_id,
            "input_hashes": result.input_hashes,
            "runner_sha256": sha256_file(Path(__file__).resolve()),
            "artifact_hashes": artifact_hashes,
        },
    )
    artifact_hashes[hashes_path.name] = sha256_file(hashes_path)
    task_manifest_path = output_dir / "task_manifest.json"
    task_manifest = {
        "contract_version": "p1-v2-stage3b-task-result/1",
        "task_id": contract.task_id,
        "stage": "P1_05b",
        "wave": "W04",
        "task_family": "stage3b_model",
        "outcome": contract.outcome,
        "model": contract.model,
        "status": "PASS",
        "scientific_artifact": bool(formal_authorized),
        "formal_training_authorized": bool(formal_authorized),
        "formal_training_launched": bool(formal_authorized),
        "synthetic_smoke": not formal_authorized,
        "task_registry_sha256": contract.task_registry_sha256,
        "registry_task_sha256": contract.registry_task_sha256,
        "input_hashes": result.input_hashes,
        "artifact_hashes": artifact_hashes,
        "prediction_rows": int(len(result.predictions)),
        "metric_rows": int(len(metrics)),
        "model_reload_canary": canary,
        "strict_no_arrival_leakage": True,
        "historical_2025_exposure": True,
        "maximum_year": 2024,
        "2025_access_count": 0,
        "runtime": result.runtime_provenance
        or {"python": platform.python_version(), "platform": platform.platform()},
        "lineage_id": result.model_provenance.get("lineage_id"),
        "effective_registry_sha256": result.model_provenance.get(
            "effective_registry_sha256"
        ),
        "registry_rebind_receipt_sha256": result.model_provenance.get(
            "registry_rebind_receipt_sha256"
        ),
        "package_manifest_sha256": result.model_provenance.get(
            "package_manifest_sha256"
        ),
        "package_lock_sha256": result.model_provenance.get("package_lock_sha256"),
        "accepted_dependency_receipts": result.model_provenance.get(
            "accepted_dependency_receipts", {}
        ),
        "package_provenance_hashes": result.model_provenance.get(
            "package_provenance_hashes",
            (result.runtime_provenance or {}).get("package_provenance_hashes"),
        ),
        **(
            {"thinking_artifact_classification": thinking_classification}
            if thinking_classification is not None
            else {}
        ),
    }
    atomic_json(task_manifest_path, task_manifest)
    artifact_hashes[task_manifest_path.name] = sha256_file(task_manifest_path)
    success_path = output_dir / "_SUCCESS.json"
    success = {
        "contract_version": "p1-v2-stage3b-success/1",
        "task_id": contract.task_id,
        "status": "PASS",
        "scientific_artifact": bool(formal_authorized),
        "manifest": task_manifest_path.name,
        "manifest_sha256": sha256_file(task_manifest_path),
        "artifact_hashes": artifact_hashes,
        "task_registry_sha256": contract.task_registry_sha256,
        "registry_task_sha256": contract.registry_task_sha256,
        "lineage_id": result.model_provenance.get("lineage_id"),
        "effective_registry_sha256": result.model_provenance.get(
            "effective_registry_sha256"
        ),
        "registry_rebind_receipt_sha256": result.model_provenance.get(
            "registry_rebind_receipt_sha256"
        ),
        "package_manifest_sha256": result.model_provenance.get(
            "package_manifest_sha256"
        ),
        "package_lock_sha256": result.model_provenance.get("package_lock_sha256"),
        "accepted_dependency_receipts": result.model_provenance.get(
            "accepted_dependency_receipts", {}
        ),
        "strict_no_arrival_leakage": True,
        "historical_2025_exposure": True,
        "maximum_year": 2024,
        "2025_access_count": 0,
        **(
            {"thinking_artifact_classification": thinking_classification}
            if thinking_classification is not None
            else {}
        ),
        # Carried here as well as in the task manifest so a downstream reader that opens only the
        # success marker still sees why this backend's reload canary is a local check.
        **(
            {"model_reload_canary": canary}
            if contract.model in NONDETERMINISTIC_REMOTE_MODELS
            else {}
        ),
    }
    atomic_json(success_path, success)
    return success


def synthetic_prepared_result(contract: TaskContract, seed: int = 20260714) -> PreparedTaskResult:
    rng = np.random.default_rng(seed + OUTCOMES.index(contract.outcome) * 10 + MODELS.index(contract.model))
    feature_order = [f"x{index}" for index in range(6)]
    coefficients = np.asarray([0.9, -0.4, 0.3, 0.2, -0.2, 0.5], dtype="float64")
    model = SyntheticProbabilityModel(feature_order, coefficients, -0.15)
    parts = []
    coverage_parts = []
    for split, rows in (("oof_2020_2023", 160), ("validation_2024", 100)):
        matrix = rng.normal(size=(rows, len(feature_order)))
        probability = model.predict_proba(matrix)[:, 1]
        y_true = (probability + rng.normal(scale=0.18, size=rows) > 0.5).astype("int8")
        row_hash = [
            hashlib.sha256(f"{contract.task_id}-{split}-{index}".encode()).hexdigest()
            for index in range(rows)
        ]
        coverage_parts.append(
            pd.DataFrame(
                {
                    "row_hash": row_hash,
                    "outcome": contract.outcome,
                    "model": contract.model,
                    "split": split,
                    "eligible": split in contract.expected_prediction_splits,
                }
            )
        )
        if split not in contract.expected_prediction_splits:
            continue
        folds = pd.array(np.arange(rows) % 5, dtype="Int8")
        if split == "validation_2024":
            folds = pd.array([pd.NA] * rows, dtype="Int8")
        parts.append(
            pd.DataFrame(
                {
                    "task_id": contract.task_id,
                    "row_hash": row_hash,
                    "outcome": contract.outcome,
                    "model": contract.model,
                    "split": split,
                    "fold": folds,
                    "y_true": y_true,
                    "prediction": probability,
                },
                columns=PREDICTION_COLUMNS,
            )
        )
    predictions = pd.concat(parts, ignore_index=True)
    coverage = pd.concat(coverage_parts, ignore_index=True)[COVERAGE_COLUMNS]
    canary_matrix = rng.normal(size=(100, len(feature_order)))
    canary_hashes = [
        hashlib.sha256(f"{contract.task_id}-canary-{index}".encode()).hexdigest()
        for index in range(100)
    ]
    canary_inputs = pd.DataFrame(canary_matrix, columns=feature_order)
    canary_inputs.insert(0, "row_hash", canary_hashes)
    canary_expected = pd.DataFrame(
        {
            "row_hash": canary_hashes,
            "outcome": contract.outcome,
            "model": contract.model,
            "prediction": model.predict_proba(canary_inputs[feature_order])[:, 1],
        },
        columns=CANARY_EXPECTED_COLUMNS,
    )
    stacking_sources = None
    if contract.model == "stacking":
        stacking_sources = [
            {
                "outcome": contract.outcome,
                "model": model_name,
                "split": "oof_2020_2023",
                "path": f"synthetic/{model_name}.parquet",
                "artifact_sha256": hashlib.sha256(
                    f"{contract.outcome}-{model_name}".encode()
                ).hexdigest(),
                "sha256": hashlib.sha256(
                    f"{contract.outcome}-{model_name}".encode()
                ).hexdigest(),
                "source_task_id": STACKING_SOURCE_TASK_TEMPLATES[model_name].format(
                    outcome=contract.outcome
                ),
                "source_task_manifest_sha256": hashlib.sha256(
                    f"{contract.outcome}-{model_name}-manifest".encode()
                ).hexdigest(),
                "acceptance_receipt_path": (
                    f"synthetic/{model_name}.acceptance_receipt.json"
                ),
                "acceptance_receipt_sha256": hashlib.sha256(
                    f"{contract.outcome}-{model_name}-receipt".encode()
                ).hexdigest(),
                "lineage_id": "synthetic_stage3b_v2",
            }
            for model_name in stacking_feature_models(
                contract.outcome,
                contract.dependencies,
            )
        ]
    thinking_ledger = None
    if contract.model == "tabpfn_thinking":
        thinking_ledger = {
            "scientific_fit_count": 0,
            "synthetic_fit_count": 0,
            "api_called": False,
            "quota_consumed": False,
        }
    return PreparedTaskResult(
        predictions=predictions,
        coverage=coverage,
        canary_inputs=canary_inputs,
        canary_expected=canary_expected,
        model_state=model,
        feature_order=feature_order,
        input_hashes={
            "synthetic_frame": hashlib.sha256(contract.task_id.encode()).hexdigest(),
        },
        model_provenance={
            "backend": "synthetic_probability_model",
            "api_called": False,
            "gpu_training_launched": False,
        },
        stacking_sources=stacking_sources,
        thinking_fit_ledger=thinking_ledger,
    )


def import_smoke_bundle(output_dir: Path, contract: TaskContract) -> dict[str, Any]:
    success = read_json(output_dir / "_SUCCESS.json")
    if success.get("task_id") != contract.task_id or success.get("status") != "PASS":
        raise Stage3bContractError("synthetic bundle success marker is invalid")
    if success.get("scientific_artifact") is not False:
        raise Stage3bContractError("synthetic smoke must not claim a scientific artifact")
    manifest_path = output_dir / str(success.get("manifest", ""))
    if sha256_file(manifest_path) != success.get("manifest_sha256"):
        raise Stage3bContractError("synthetic bundle manifest hash mismatch")
    for filename, expected_hash in success.get("artifact_hashes", {}).items():
        path = output_dir / filename
        if not path.is_file() or sha256_file(path) != expected_hash:
            raise Stage3bContractError(f"synthetic bundle artifact hash mismatch: {filename}")
    required = set(contract.required_artifacts)
    missing = sorted(required - {path.name for path in output_dir.iterdir() if path.is_file()})
    if missing:
        raise Stage3bContractError(f"synthetic bundle misses required artifacts: {missing}")
    predictions = pd.read_parquet(output_dir / "predictions.parquet")
    metrics = pd.read_parquet(output_dir / "metrics.parquet")
    coverage = pd.read_parquet(output_dir / "coverage.parquet")
    if predictions.columns.tolist() != PREDICTION_COLUMNS:
        raise Stage3bContractError("import smoke found noncanonical predictions")
    if metrics.columns.tolist() != METRIC_COLUMNS:
        raise Stage3bContractError("import smoke found noncanonical metrics")
    if coverage.columns.tolist() != COVERAGE_COLUMNS:
        raise Stage3bContractError("import smoke found noncanonical coverage")
    model = joblib.load(output_dir / "model.joblib")
    inputs = pd.read_parquet(output_dir / "canary_inputs.parquet")
    expected = pd.read_parquet(output_dir / "canary_expected.parquet")
    actual = model.predict_proba(inputs.drop(columns="row_hash"))[:, 1]
    maximum_error = float(
        np.max(np.abs(np.asarray(actual) - expected["prediction"].to_numpy(dtype=float)))
    )
    if maximum_error > 1e-5:
        raise Stage3bContractError("import smoke canary exceeds reload tolerance")
    return {
        "status": "PASS",
        "task_id": contract.task_id,
        "prediction_rows": int(len(predictions)),
        "metric_rows": int(len(metrics)),
        "coverage_rows": int(len(coverage)),
        "canary_rows": int(len(inputs)),
        "canary_maximum_absolute_error": maximum_error,
        "formal_training_authorized": False,
        "api_calls": 0,
        "2025_access_count": 0,
    }


def consolidate_stacking_models(task_root: Path, output_dir: Path) -> dict[str, Any]:
    models = {}
    sources = {}
    accepted_receipts = {}
    shared_lineage: dict[str, Any] | None = None
    for outcome in OUTCOMES:
        task_id = f"P1_05b-{outcome}-stacking"
        task_dir = task_root / task_id
        manifest_path = task_dir / "task_manifest.json"
        model_path = task_dir / "model.joblib"
        inputs_path = task_dir / "canary_inputs.parquet"
        expected_path = task_dir / "canary_expected.parquet"
        receipt_path = task_dir / "acceptance_receipt.json"
        if not receipt_path.is_file():
            raise Stage3bContractError(
                f"stacking acceptance receipt is missing: {task_id}"
            )
        manifest = read_json(manifest_path)
        receipt = read_json(receipt_path)
        hashes = manifest.get("artifact_hashes", {})
        required_hashes = {
            "model.joblib": model_path,
            "canary_inputs.parquet": inputs_path,
            "canary_expected.parquet": expected_path,
        }
        lineage = {
            "lineage_id": manifest.get("lineage_id"),
            "effective_registry_sha256": manifest.get("effective_registry_sha256"),
            "registry_rebind_receipt_sha256": manifest.get(
                "registry_rebind_receipt_sha256"
            ),
            "package_manifest_sha256": manifest.get("package_manifest_sha256"),
            "package_lock_sha256": manifest.get("package_lock_sha256"),
            "accepted_dependency_receipts": manifest.get(
                "accepted_dependency_receipts"
            ),
        }
        lineage_core = {
            key: lineage[key]
            for key in (
                "lineage_id",
                "effective_registry_sha256",
                "registry_rebind_receipt_sha256",
                "package_manifest_sha256",
                "package_lock_sha256",
            )
        }
        lineage_hashes = {
            key: lineage[key]
            for key in (
                "effective_registry_sha256",
                "registry_rebind_receipt_sha256",
                "package_manifest_sha256",
                "package_lock_sha256",
            )
        }
        expected_lineage_id = stage3b_lineage_id(**lineage_hashes)
        if (
            manifest.get("task_id") != task_id
            or manifest.get("model") != "stacking"
            or manifest.get("status") != "PASS"
            or manifest.get("scientific_artifact") is not True
            or manifest.get("strict_no_arrival_leakage") is not True
            or manifest.get("maximum_year") != 2024
            or manifest.get("2025_access_count") != 0
            or lineage["lineage_id"] != expected_lineage_id
            or not isinstance(lineage["accepted_dependency_receipts"], dict)
            or not lineage["accepted_dependency_receipts"]
            or any(hashes.get(name) != sha256_file(path) for name, path in required_hashes.items())
        ):
            raise Stage3bContractError(f"stacking task is not accepted: {task_id}")
        receipt_artifact_hashes = receipt.get("artifact_hashes") or {}
        if (
            receipt.get("status") != "PASS"
            or receipt.get("accepted") is not True
            or receipt.get("task_id") != task_id
            or receipt.get("outcome") != outcome
            or receipt.get("model") != "stacking"
            or receipt.get("scientific_artifact") is not True
            or receipt.get("strict_no_arrival_leakage") is not True
            or receipt.get("maximum_year") != 2024
            or receipt.get("2025_access_count") != 0
            or receipt.get("task_manifest_sha256") != sha256_file(manifest_path)
            or receipt.get("lineage_id") != expected_lineage_id
            or receipt.get("effective_registry_sha256")
            != lineage["effective_registry_sha256"]
            or receipt.get("registry_rebind_receipt_sha256")
            != lineage["registry_rebind_receipt_sha256"]
            or receipt.get("package_manifest_sha256")
            != lineage["package_manifest_sha256"]
            or receipt.get("package_lock_sha256") != lineage["package_lock_sha256"]
            or receipt.get("accepted_dependency_receipts")
            != lineage["accepted_dependency_receipts"]
            or any(
                receipt_artifact_hashes.get(name) != hashes.get(name)
                for name in required_hashes
            )
        ):
            raise Stage3bContractError(
                f"stacking acceptance receipt/lineage differs: {task_id}"
            )
        if shared_lineage is None:
            shared_lineage = lineage_core
        elif lineage_core != shared_lineage:
            raise Stage3bContractError("stacking tasks do not share one package lineage")
        model = joblib.load(model_path)
        inputs = pd.read_parquet(inputs_path)
        expected = pd.read_parquet(expected_path)
        actual = np.asarray(
            model.predict_proba(inputs.drop(columns="row_hash"))[:, 1], dtype="float64"
        )
        maximum_error = float(
            np.max(
                np.abs(actual - expected["prediction"].to_numpy(dtype="float64"))
            )
        )
        if maximum_error > 1e-5:
            raise Stage3bContractError(f"stacking reload canary differs: {task_id}")
        models[outcome] = model
        sources[outcome] = {
            "task_manifest_sha256": sha256_file(manifest_path),
            "acceptance_receipt_sha256": sha256_file(receipt_path),
            "model_sha256": sha256_file(model_path),
            "canary_maximum_absolute_error": maximum_error,
        }
        accepted_receipts[outcome] = sha256_file(receipt_path)
    if shared_lineage is None:
        raise Stage3bContractError("stacking consolidation has no accepted lineage")
    output_dir.mkdir(parents=True, exist_ok=True)
    model_output = output_dir / "stage3b_final_stacked_models.pkl"
    manifest_output = output_dir / "stage3b_final_stacked_models_manifest.json"
    atomic_joblib(
        model_output,
        {
            "contract_version": "p1-v2-stage3b-final-stacked-models/1",
            "outcomes": list(OUTCOMES),
            "models": models,
            "source_hashes": sources,
            "lineage": shared_lineage,
            "accepted_receipts": accepted_receipts,
        },
    )
    reloaded = joblib.load(model_output)
    if set(reloaded.get("models", {})) != set(OUTCOMES):
        raise Stage3bContractError("consolidated stacking model reload differs")
    manifest = {
        "contract_version": "p1-v2-stage3b-final-stacked-models-manifest/1",
        "status": "PASS",
        "scientific_artifact": True,
        "artifact": {
            "path": model_output.name,
            "sha256": sha256_file(model_output),
        },
        "outcome_count": len(OUTCOMES),
        "outcomes": list(OUTCOMES),
        "sources": sources,
        **shared_lineage,
        "accepted_receipts": accepted_receipts,
        "strict_no_arrival_leakage": True,
        "historical_2025_exposure": True,
        "maximum_year": 2024,
        "2025_access_count": 0,
    }
    manifest["manifest_payload_sha256"] = canonical_sha256(manifest)
    atomic_json(manifest_output, manifest)
    return manifest


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate, smoke, or formally run one EMT P1 Stage3b v2 task"
    )
    parser.add_argument("--task-manifest", type=Path, required=True)
    parser.add_argument("--task-registry", type=Path, default=DEFAULT_TASK_REGISTRY)
    parser.add_argument("--registry-rebind-receipt", type=Path)
    parser.add_argument("--authorization", type=Path)
    parser.add_argument("--workspace-root", type=Path, default=ROOT)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--resume", action="store_true")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--validate-only", action="store_true")
    mode.add_argument("--synthetic-smoke", action="store_true")
    mode.add_argument("--formal", action="store_true")
    parser.add_argument("--seed", type=int, default=20260714)
    args = parser.parse_args(argv)
    if (args.synthetic_smoke or args.formal) and args.output_dir is None:
        parser.error("--synthetic-smoke/--formal requires --output-dir")
    if args.formal and args.authorization is None:
        parser.error("--formal requires --authorization")
    if args.formal and args.registry_rebind_receipt is None:
        parser.error("--formal requires --registry-rebind-receipt")
    if not args.formal and args.authorization is not None:
        parser.error("--authorization is valid only with --formal")
    if not args.formal and args.registry_rebind_receipt is not None:
        parser.error("--registry-rebind-receipt is valid only with --formal")
    if args.resume and not args.formal:
        parser.error("--resume is valid only with --formal")
    return args


def main() -> int:
    args = parse_args()
    contract, _ = load_bound_task_contract(
        args.task_manifest,
        args.task_registry,
        args.registry_rebind_receipt,
    )
    if args.resume and (
        contract.model == "stacking"
        or "oof_2020_2023" not in contract.expected_prediction_splits
    ):
        raise Stage3bContractError("this Stage3b task has no fold-level resume path")
    if args.validate_only:
        device = resolve_device_plan(contract, args.device, formal=False)
        print(
            json.dumps(
                {
                    "status": "PASS",
                    "task_id": contract.task_id,
                    "device_plan": device.__dict__,
                    "formal_training_authorized": False,
                },
                ensure_ascii=False,
            )
        )
        return 0
    workspace_root = args.workspace_root.resolve()
    if args.formal:
        authorization = read_json(args.authorization)
        validate_authorization(
            contract,
            authorization,
            task_manifest_sha256=sha256_file(args.task_manifest),
            workspace_root=workspace_root,
        )
        contract = dataclasses.replace(contract, formal_training_authorized=True)
        device = resolve_device_plan(contract, args.device, formal=True)
    else:
        authorization = None
        device = resolve_device_plan(contract, args.device, formal=False)
    output_dir = args.output_dir.resolve()
    if output_dir.exists() and any(output_dir.iterdir()) and not args.resume:
        raise Stage3bContractError("Stage3b output directory must be empty")
    if args.formal:
        try:
            result = execute_formal_task(
                contract,
                authorization,
                workspace_root=workspace_root,
                device_plan=device,
                output_dir=output_dir,
                owner_alias=os.environ.get("P1_OWNER_ALIAS", "UNSPECIFIED"),
                resume=args.resume,
            )
        except Stage3bCheckpointBoundary as boundary:
            print(json.dumps(boundary.payload, ensure_ascii=False))
            return 0
        report = write_task_artifacts(
            contract,
            result,
            output_dir,
            owner_alias=os.environ.get("P1_OWNER_ALIAS", "UNSPECIFIED"),
            formal_authorized=True,
        )
        (output_dir / "_PARTIAL.json").unlink(missing_ok=True)
    else:
        result = synthetic_prepared_result(contract, seed=args.seed)
        write_task_artifacts(contract, result, output_dir, formal_authorized=False)
        report = import_smoke_bundle(output_dir, contract)
    print(json.dumps(report, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
