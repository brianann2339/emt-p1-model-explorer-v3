from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import re
import shutil
from pathlib import Path
from typing import Any


OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
PRIMARY_OUTCOMES = OUTCOMES[:3]
FULL_BRANCH = "full_9_outcome_oof"
LIMITED_BRANCH = "quota_limited_supplemental"
FULL_FIT_COUNT = 54
LIMITED_FIT_COUNT = 24
PROBE_CONTRACT = "p1-v2-stage3b-thinking-official-quota-probe/1"
PLAN_CONTRACT = "p1-v2-stage3b-thinking-global-plan/4"
BASELINE_ALLOCATION = "baseline_minimum_or_full"
CHECKPOINT_RESUME_ALLOCATION = "checkpoint_resume_consume_all"
FINAL_REPLACEMENT_RESUME_ALLOCATION = "p1_final_replacement_exact_resume"
REUSE_FIRST_P1_RESUME_REMAINING_OUTCOMES_ALLOCATION = (
    "reuse_first_p1_resume_remaining_outcomes"
)
FINAL_REPLACEMENT_HISTORICAL_FIT_KEYS = tuple(
    f"P1_05b-P1-tabpfn_thinking::oof_fold_{fold}" for fold in range(5)
)
# Used once P1, P2 and P3 are captured and only the single-fit S outcomes remain. Their eighteen
# completed fits are carried as historical so the plan reserves six fresh slots instead of nineteen.
REMAINING_OUTCOMES_ONLY_ALLOCATION = "reuse_first_remaining_outcomes_only"
REMAINING_OUTCOMES_HISTORICAL_FIT_KEYS = tuple(
    f"P1_05b-{outcome}-tabpfn_thinking::{fit_name}"
    for outcome in ("P1", "P2", "P3")
    for fit_name in (*(f"oof_fold_{fold}" for fold in range(5)), "final_2020_2023")
)
# One outcome of headroom: a network drop still bills the fit it orphaned, so the floor leaves room
# to retry the largest single fresh outcome in this plan (S outcomes are one fit each).
REMAINING_OUTCOMES_RETRY_MARGIN = 1
PROBE_FILENAME = "thinking_official_quota_probe.json"
TOP_KEYS = {
    "contract_version",
    "wave",
    "quota_month",
    "quota_branch",
    "allocation_policy",
    "quota_probe",
    "max_fits_per_account",
    "fit_limits_by_account",
    "account_aliases",
    "planned_fit_count",
    "fresh_planned_fit_count",
    "historical_completed_fit_keys",
    "reservations",
    "global_plan_payload_sha256",
}
PROBE_KEYS = {
    "contract_version",
    "status",
    "official_quota_probe",
    "provider",
    "quota_month",
    "captured_at_utc",
    "expires_at_utc",
    "accounts",
    "total_remaining_fits",
    "probe_payload_sha256",
}
PROBE_ACCOUNT_KEYS = {
    "account_alias",
    "quota_limit",
    "fits_used",
    "fits_remaining",
    "official_response_sha256",
}
RESERVATION_KEYS = {
    "task_id",
    "outcome",
    "planned_fits",
    "artifact_classification",
    "task_plan_sha256",
}
CLASSIFICATION_KEYS = {
    "quota_branch",
    "quota_limited_supplemental",
    "not_equivalent_to_full_oof",
    "full_oof_required",
    "stacking_eligible",
    "planned_fit_count",
}
FIT_KEYS = {
    "fit_index",
    "fit_name",
    "preferred_account_alias",
    "preferred_slot",
    "alternate_account_alias",
    "alternate_slot",
    "historical_completed",
}


class ThinkingQuotaPlanError(RuntimeError):
    pass


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ThinkingQuotaPlanError(f"JSON root is not an object: {path}")
    return value


def _utc(value: Any, label: str) -> dt.datetime:
    if not isinstance(value, str) or not value.endswith("Z"):
        raise ThinkingQuotaPlanError(f"{label} must be an RFC3339 UTC timestamp")
    try:
        parsed = dt.datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError as error:
        raise ThinkingQuotaPlanError(f"{label} is not a valid timestamp") from error
    if parsed.utcoffset() != dt.timedelta(0):
        raise ThinkingQuotaPlanError(f"{label} must use UTC")
    return parsed


def _now_utc(now_utc: dt.datetime | None) -> dt.datetime:
    value = now_utc or dt.datetime.now(dt.UTC)
    if value.tzinfo is None or value.utcoffset() != dt.timedelta(0):
        raise ThinkingQuotaPlanError("now_utc must be timezone-aware UTC")
    return value


def validate_probe(
    value: dict[str, Any],
    *,
    expected_month: str | None = None,
    require_fresh: bool = True,
    now_utc: dt.datetime | None = None,
    minimum_remaining_fits: int = LIMITED_FIT_COUNT,
) -> dict[str, Any]:
    if set(value) != PROBE_KEYS:
        raise ThinkingQuotaPlanError("official quota probe key set differs")
    unhashed = dict(value)
    claimed_hash = unhashed.pop("probe_payload_sha256", None)
    quota_month = str(value.get("quota_month", ""))
    captured = _utc(value.get("captured_at_utc"), "quota probe captured_at_utc")
    expires = _utc(value.get("expires_at_utc"), "quota probe expires_at_utc")
    if (
        value.get("contract_version") != PROBE_CONTRACT
        or value.get("status") != "PASS"
        or value.get("official_quota_probe") is not True
        or value.get("provider") != "PriorLabs"
        or re.fullmatch(r"[0-9]{4}-(0[1-9]|1[0-2])", quota_month) is None
        or quota_month != captured.strftime("%Y-%m")
        or (expected_month is not None and quota_month != expected_month)
        or expires <= captured
        or claimed_hash != canonical_sha256(unhashed)
    ):
        raise ThinkingQuotaPlanError("official quota probe identity, month, or self hash differs")
    if require_fresh and not (captured <= _now_utc(now_utc) <= expires):
        raise ThinkingQuotaPlanError("official quota probe is not currently valid")
    accounts = value.get("accounts")
    if not isinstance(accounts, list) or not accounts:
        raise ThinkingQuotaPlanError("official quota probe has no account records")
    aliases: list[str] = []
    limits: dict[str, int] = {}
    remaining_total = 0
    for record in accounts:
        if not isinstance(record, dict) or set(record) != PROBE_ACCOUNT_KEYS:
            raise ThinkingQuotaPlanError("official quota account schema differs")
        alias = record.get("account_alias")
        limit = record.get("quota_limit")
        used = record.get("fits_used")
        remaining = record.get("fits_remaining")
        response_hash = record.get("official_response_sha256")
        if (
            not isinstance(alias, str)
            or re.fullmatch(r"[A-Za-z0-9_.-]+", alias) is None
            or isinstance(limit, bool)
            or not isinstance(limit, int)
            or limit < 1
            or isinstance(used, bool)
            or not isinstance(used, int)
            or isinstance(remaining, bool)
            or not isinstance(remaining, int)
            or used < 0
            or remaining < 0
            or used + remaining != limit
            or not isinstance(response_hash, str)
            or re.fullmatch(r"[0-9a-f]{64}", response_hash) is None
        ):
            raise ThinkingQuotaPlanError("official quota account content differs")
        aliases.append(alias)
        limits[alias] = limit
        remaining_total += remaining
    if len(aliases) != len(set(aliases)):
        raise ThinkingQuotaPlanError("official quota account aliases are duplicated")
    if value.get("total_remaining_fits") != remaining_total:
        raise ThinkingQuotaPlanError("official quota remaining-fit total differs")
    if remaining_total < minimum_remaining_fits:
        if minimum_remaining_fits != LIMITED_FIT_COUNT:
            raise ThinkingQuotaPlanError(
                "official quota cannot satisfy the final replacement allocation"
            )
        raise ThinkingQuotaPlanError(
            "official quota cannot satisfy either formal thinking branch"
        )
    return value


def _minimum_remaining_fits(allocation_policy: str) -> int:
    if allocation_policy not in {
        BASELINE_ALLOCATION,
        CHECKPOINT_RESUME_ALLOCATION,
        FINAL_REPLACEMENT_RESUME_ALLOCATION,
        REUSE_FIRST_P1_RESUME_REMAINING_OUTCOMES_ALLOCATION,
        REMAINING_OUTCOMES_ONLY_ALLOCATION,
    }:
        raise ThinkingQuotaPlanError("thinking allocation policy differs")
    if allocation_policy == FINAL_REPLACEMENT_RESUME_ALLOCATION:
        return 1
    if allocation_policy == REMAINING_OUTCOMES_ONLY_ALLOCATION:
        return (
            LIMITED_FIT_COUNT
            - len(REMAINING_OUTCOMES_HISTORICAL_FIT_KEYS)
            + REMAINING_OUTCOMES_RETRY_MARGIN
        )
    if allocation_policy == REUSE_FIRST_P1_RESUME_REMAINING_OUTCOMES_ALLOCATION:
        return 19
    return LIMITED_FIT_COUNT


def quota_branch(probe: dict[str, Any]) -> str:
    return (
        FULL_BRANCH
        if int(probe["total_remaining_fits"]) >= FULL_FIT_COUNT
        else LIMITED_BRANCH
    )


def _fit_names(branch: str, outcome: str) -> tuple[str, ...]:
    if branch == FULL_BRANCH or outcome in PRIMARY_OUTCOMES:
        return tuple(f"oof_fold_{fold}" for fold in range(5)) + (
            "final_2020_2023",
        )
    return ("final_2020_2023",)


def task_classification(branch: str, outcome: str) -> dict[str, Any]:
    full_oof = branch == FULL_BRANCH or outcome in PRIMARY_OUTCOMES
    supplemental = branch == LIMITED_BRANCH and outcome not in PRIMARY_OUTCOMES
    return {
        "quota_branch": branch,
        "quota_limited_supplemental": supplemental,
        "not_equivalent_to_full_oof": supplemental,
        "full_oof_required": full_oof,
        "stacking_eligible": full_oof,
        "planned_fit_count": 6 if full_oof else 1,
    }


def _checkpoint_resume_priority() -> tuple[tuple[str, str], ...]:
    fits = tuple(f"oof_fold_{fold}" for fold in range(5)) + (
        "final_2020_2023",
    )
    priority = [("P1", fit_name) for fit_name in fits[1:]]
    priority.extend(
        (outcome, fit_name)
        for outcome in PRIMARY_OUTCOMES[1:]
        for fit_name in fits
    )
    priority.extend((outcome, "final_2020_2023") for outcome in OUTCOMES[3:])
    priority.extend(
        (outcome, fit_name)
        for outcome in OUTCOMES[3:]
        for fit_name in fits[:5]
    )
    return tuple(priority)


def _classification_for_selected_fits(
    branch: str,
    outcome: str,
    selected_fit_names: set[str],
) -> dict[str, Any]:
    ideal = set(_fit_names(FULL_BRANCH, outcome))
    if selected_fit_names == ideal:
        return {
            "quota_branch": branch,
            "quota_limited_supplemental": False,
            "not_equivalent_to_full_oof": False,
            "full_oof_required": True,
            "stacking_eligible": True,
            "planned_fit_count": 6,
        }
    if selected_fit_names == {"final_2020_2023"} and outcome not in PRIMARY_OUTCOMES:
        return {
            "quota_branch": branch,
            "quota_limited_supplemental": True,
            "not_equivalent_to_full_oof": True,
            "full_oof_required": False,
            "stacking_eligible": False,
            "planned_fit_count": 1,
        }
    raise ThinkingQuotaPlanError(
        f"resume-aware allocation leaves a non-executable partial task: {outcome}"
    )


def build_plan(
    probe: dict[str, Any],
    probe_binding: dict[str, str],
    *,
    require_fresh: bool = True,
    now_utc: dt.datetime | None = None,
    allocation_policy: str = BASELINE_ALLOCATION,
    historical_completed_fit_keys: tuple[str, ...] = (),
) -> dict[str, Any]:
    validate_probe(
        probe,
        require_fresh=require_fresh,
        now_utc=now_utc,
        minimum_remaining_fits=_minimum_remaining_fits(allocation_policy),
    )
    if (
        not isinstance(probe_binding, dict)
        or set(probe_binding) != {"path", "sha256"}
        or not isinstance(probe_binding.get("path"), str)
        or not probe_binding["path"]
        or not isinstance(probe_binding.get("sha256"), str)
        or re.fullmatch(r"[0-9a-f]{64}", probe_binding["sha256"]) is None
    ):
        raise ThinkingQuotaPlanError("official quota probe binding differs")
    historical = tuple(historical_completed_fit_keys)
    if len(historical) != len(set(historical)):
        raise ThinkingQuotaPlanError("historical completed fit keys are duplicated")
    if allocation_policy == BASELINE_ALLOCATION and historical:
        raise ThinkingQuotaPlanError("baseline allocation cannot contain historical fits")
    if allocation_policy == CHECKPOINT_RESUME_ALLOCATION and historical != (
        "P1_05b-P1-tabpfn_thinking::oof_fold_0",
    ):
        raise ThinkingQuotaPlanError("resume-aware allocation requires exact P1 fold-0 lineage")
    if (
        allocation_policy
        in {
            FINAL_REPLACEMENT_RESUME_ALLOCATION,
            REUSE_FIRST_P1_RESUME_REMAINING_OUTCOMES_ALLOCATION,
        }
        and historical != FINAL_REPLACEMENT_HISTORICAL_FIT_KEYS
    ):
        raise ThinkingQuotaPlanError(
            "final replacement allocation requires exact P1 OOF lineage"
        )
    if (
        allocation_policy == REMAINING_OUTCOMES_ONLY_ALLOCATION
        and historical != REMAINING_OUTCOMES_HISTORICAL_FIT_KEYS
    ):
        raise ThinkingQuotaPlanError(
            "remaining-outcomes allocation requires exact P1/P2/P3 completed lineage"
        )
    limits = {
        str(record["account_alias"]): int(record["quota_limit"])
        for record in probe["accounts"]
    }
    if allocation_policy == FINAL_REPLACEMENT_RESUME_ALLOCATION:
        if len(probe["accounts"]) != 1:
            raise ThinkingQuotaPlanError(
                "final replacement allocation requires exactly one selected owner"
            )
        selected_owner = probe["accounts"][0]
        if int(selected_owner["fits_remaining"]) < 1:
            raise ThinkingQuotaPlanError(
                "final replacement allocation requires one remaining fit"
            )
        available = [(str(selected_owner["account_alias"]), 0)]
    else:
        available = []
        for record in probe["accounts"]:
            available.extend(
                (str(record["account_alias"]), slot)
                for slot in range(int(record["fits_remaining"]))
            )
    if allocation_policy == BASELINE_ALLOCATION:
        branch = quota_branch(probe)
        fresh_needed = FULL_FIT_COUNT if branch == FULL_BRANCH else LIMITED_FIT_COUNT
        selected = [
            (outcome, fit_name)
            for outcome in OUTCOMES
            for fit_name in _fit_names(branch, outcome)
        ]
    elif allocation_policy == CHECKPOINT_RESUME_ALLOCATION:
        fresh_needed = min(len(available), FULL_FIT_COUNT - len(historical))
        selected = list(_checkpoint_resume_priority()[:fresh_needed])
        selected.append(("P1", "oof_fold_0"))
        branch = (
            FULL_BRANCH
            if len(selected) == FULL_FIT_COUNT
            else LIMITED_BRANCH
        )
    elif allocation_policy in {
        REUSE_FIRST_P1_RESUME_REMAINING_OUTCOMES_ALLOCATION,
        REMAINING_OUTCOMES_ONLY_ALLOCATION,
    }:
        fresh_needed = (
            LIMITED_FIT_COUNT - len(historical)
            if allocation_policy == REMAINING_OUTCOMES_ONLY_ALLOCATION
            else 19
        )
        selected = [
            (outcome, fit_name)
            for outcome in PRIMARY_OUTCOMES
            for fit_name in _fit_names(FULL_BRANCH, outcome)
        ]
        selected.extend(
            (outcome, "final_2020_2023") for outcome in OUTCOMES[3:]
        )
        branch = LIMITED_BRANCH
    else:
        fresh_needed = 1
        selected = [
            ("P1", fit_name) for fit_name in _fit_names(FULL_BRANCH, "P1")
        ]
        branch = LIMITED_BRANCH
    if len(available) < fresh_needed:
        raise ThinkingQuotaPlanError("official quota branch capacity differs")
    selected_set = set(selected)
    fresh_allocation = {
        (outcome, fit_name): available[index]
        for index, (outcome, fit_name) in enumerate(
            item for item in selected if f"P1_05b-{item[0]}-tabpfn_thinking::{item[1]}" not in historical
        )
    }
    reservations: dict[str, dict[str, Any]] = {}
    reservation_outcomes = (
        ("P1",)
        if allocation_policy == FINAL_REPLACEMENT_RESUME_ALLOCATION
        else OUTCOMES
    )
    for outcome in reservation_outcomes:
        fits = []
        selected_names = {
            fit_name for selected_outcome, fit_name in selected_set if selected_outcome == outcome
        }
        classification = (
            task_classification(branch, outcome)
            if allocation_policy == BASELINE_ALLOCATION
            else _classification_for_selected_fits(branch, outcome, selected_names)
        )
        ordered_names = tuple(
            fit_name
            for fit_name in _fit_names(FULL_BRANCH, outcome)
            if fit_name in selected_names
        )
        for fit_index, fit_name in enumerate(ordered_names):
            historical_key = f"P1_05b-{outcome}-tabpfn_thinking::{fit_name}"
            is_historical = historical_key in historical
            alias, slot = (None, None) if is_historical else fresh_allocation[(outcome, fit_name)]
            fits.append(
                {
                    "fit_index": fit_index,
                    "fit_name": fit_name,
                    "preferred_account_alias": alias,
                    "preferred_slot": slot,
                    "alternate_account_alias": None,
                    "alternate_slot": None,
                    "historical_completed": is_historical,
                }
            )
        task_id = f"P1_05b-{outcome}-tabpfn_thinking"
        reservation = {
            "task_id": task_id,
            "outcome": outcome,
            "planned_fits": fits,
            "artifact_classification": classification,
        }
        reservation["task_plan_sha256"] = canonical_sha256(reservation)
        reservations[task_id] = reservation
    value = {
        "contract_version": PLAN_CONTRACT,
        "wave": "W04",
        "quota_month": probe["quota_month"],
        "quota_branch": branch,
        "allocation_policy": allocation_policy,
        "quota_probe": probe_binding,
        "max_fits_per_account": max(limits.values()),
        "fit_limits_by_account": limits,
        "account_aliases": [record["account_alias"] for record in probe["accounts"]],
        "planned_fit_count": len(selected_set),
        "fresh_planned_fit_count": fresh_needed,
        "historical_completed_fit_keys": list(historical),
        "reservations": reservations,
    }
    value["global_plan_payload_sha256"] = canonical_sha256(value)
    return value


def _probe_path(plan_path: Path, binding: dict[str, Any]) -> Path:
    if not isinstance(binding, dict) or set(binding) != {"path", "sha256"}:
        raise ThinkingQuotaPlanError("official quota probe binding schema differs")
    path = Path(str(binding.get("path", "")))
    if not path.is_absolute():
        path = plan_path.resolve().parent / path
    path = path.resolve()
    try:
        path.relative_to(plan_path.resolve().parent)
    except ValueError as error:
        raise ThinkingQuotaPlanError("official quota probe escapes the plan directory") from error
    if not path.is_file() or sha256_file(path) != binding.get("sha256"):
        raise ThinkingQuotaPlanError("official quota probe path/hash differs")
    return path


def validate_plan(
    value: dict[str, Any],
    *,
    plan_path: Path,
    expected_month: str | None = None,
    require_fresh: bool = True,
    now_utc: dt.datetime | None = None,
) -> dict[str, Any]:
    if set(value) != TOP_KEYS:
        raise ThinkingQuotaPlanError("global plan key set differs")
    probe_path = _probe_path(plan_path, value.get("quota_probe", {}))
    probe = read_json(probe_path)
    validate_probe(
        probe,
        expected_month=expected_month,
        require_fresh=require_fresh,
        now_utc=now_utc,
        minimum_remaining_fits=_minimum_remaining_fits(value["allocation_policy"]),
    )
    expected = build_plan(
        probe,
        value["quota_probe"],
        require_fresh=require_fresh,
        now_utc=now_utc,
        allocation_policy=value["allocation_policy"],
        historical_completed_fit_keys=tuple(value["historical_completed_fit_keys"]),
    )
    if value != expected:
        raise ThinkingQuotaPlanError(
            "global plan differs from the official-probe deterministic branch"
        )
    if any(
        set(task) != RESERVATION_KEYS
        or set(task.get("artifact_classification", {})) != CLASSIFICATION_KEYS
        or any(set(fit) != FIT_KEYS for fit in task.get("planned_fits", []))
        for task in value["reservations"].values()
    ):
        raise ThinkingQuotaPlanError("global plan reservation schema differs")
    return value


def write_plan(
    output: Path,
    quota_probe_path: Path,
    *,
    now_utc: dt.datetime | None = None,
    allocation_policy: str = BASELINE_ALLOCATION,
    historical_completed_fit_keys: tuple[str, ...] = (),
) -> dict[str, Any]:
    if output.exists():
        raise ThinkingQuotaPlanError(f"output already exists: {output}")
    quota_probe_path = quota_probe_path.resolve()
    probe = read_json(quota_probe_path)
    validate_probe(
        probe,
        require_fresh=True,
        now_utc=now_utc,
        minimum_remaining_fits=_minimum_remaining_fits(allocation_policy),
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    copied_probe = output.parent / PROBE_FILENAME
    if copied_probe.exists():
        if sha256_file(copied_probe) != sha256_file(quota_probe_path):
            raise ThinkingQuotaPlanError("existing copied quota probe differs")
    elif copied_probe.resolve() != quota_probe_path:
        shutil.copy2(quota_probe_path, copied_probe)
    binding = {"path": PROBE_FILENAME, "sha256": sha256_file(copied_probe)}
    value = build_plan(
        probe,
        binding,
        require_fresh=True,
        now_utc=now_utc,
        allocation_policy=allocation_policy,
        historical_completed_fit_keys=historical_completed_fit_keys,
    )
    temporary = output.with_suffix(output.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(output)
    reopened = read_json(output)
    return validate_plan(
        reopened,
        plan_path=output,
        expected_month=probe["quota_month"],
        require_fresh=True,
        now_utc=now_utc,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build the W04 TabPFN thinking quota plan")
    parser.add_argument("--quota-probe", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--allocation-policy",
        choices=(
            BASELINE_ALLOCATION,
            CHECKPOINT_RESUME_ALLOCATION,
            FINAL_REPLACEMENT_RESUME_ALLOCATION,
            REUSE_FIRST_P1_RESUME_REMAINING_OUTCOMES_ALLOCATION,
            REMAINING_OUTCOMES_ONLY_ALLOCATION,
        ),
        default=BASELINE_ALLOCATION,
    )
    parser.add_argument("--historical-completed-fit-key", action="append", default=[])
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    value = write_plan(
        args.output,
        args.quota_probe,
        allocation_policy=args.allocation_policy,
        historical_completed_fit_keys=tuple(args.historical_completed_fit_key),
    )
    print(
        json.dumps(
            {
                "status": "PASS",
                "output": str(args.output),
                "quota_branch": value["quota_branch"],
                "planned_fit_count": value["planned_fit_count"],
                "global_plan_payload_sha256": value[
                    "global_plan_payload_sha256"
                ],
            },
            ensure_ascii=False,
            sort_keys=True,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
