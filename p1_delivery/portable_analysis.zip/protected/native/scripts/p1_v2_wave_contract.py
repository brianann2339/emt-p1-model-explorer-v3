# -*- coding: utf-8 -*-
from __future__ import annotations

import hashlib
import json
import math
import re
from dataclasses import asdict, dataclass
from typing import Any, Iterable


WAVES = ("W02", "W03", "W04")
OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
PRIMARY_OUTCOMES = ("P1", "P2", "P3")
SECONDARY_OUTCOMES = ("S1", "S2", "S3", "S4", "S5", "S6")
MAX_SESSIONS_PER_OWNER = 2
MAX_THINKING_FITS_PER_ACCOUNT = 20
SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")
SESSION_PATTERN = re.compile(r"^A0[1-7]-S[12]$")


class WaveContractError(RuntimeError):
    pass


@dataclass(frozen=True)
class CheckpointPolicy:
    mode: str
    same_owner_resume: bool
    cross_session_parallel_resume: bool
    partial_marker: str
    required_records: tuple[str, ...]


@dataclass(frozen=True)
class ApiQuotaPolicy:
    metric: str
    allowed_total_fits: tuple[int, ...]
    max_fits_per_account: int
    primary_outcomes: tuple[str, ...]
    secondary_outcomes: tuple[str, ...]
    full_branch_fits_per_outcome: int
    quota_limited_primary_fits_per_outcome: int
    quota_limited_secondary_fits_per_outcome: int
    distinct_affinity_accounts: bool


@dataclass(frozen=True)
class TaskVariantSpec:
    task_family: str
    model: str | None
    compute_target: str
    allowed_privacy_classes: tuple[str, ...]
    canonical_expected_artifacts: tuple[str, ...]
    api_quota_group: str | None = None

    @property
    def key(self) -> str:
        return self.task_family if self.model is None else f"{self.task_family}:{self.model}"


@dataclass(frozen=True)
class WaveSpec:
    wave: str
    stage: str
    task_variants: tuple[TaskVariantSpec, ...]
    accepted_upstream_receipt_types: tuple[str, ...]
    checkpoint_policy: CheckpointPolicy
    stage_validator_hook: str
    api_quota_policy: ApiQuotaPolicy | None
    owner_affinity: tuple[tuple[str, str], ...]

    @property
    def task_families(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(variant.task_family for variant in self.task_variants))

    @property
    def allowed_privacy_classes(self) -> tuple[str, ...]:
        return tuple(
            sorted(
                {
                    privacy_class
                    for variant in self.task_variants
                    for privacy_class in variant.allowed_privacy_classes
                }
            )
        )

    @property
    def canonical_expected_artifacts(self) -> dict[str, tuple[str, ...]]:
        return {
            variant.key: variant.canonical_expected_artifacts
            for variant in self.task_variants
        }


COMMON_TASK_ARTIFACTS = (
    "predictions.parquet",
    "metrics.parquet",
    "coverage.parquet",
    "spec.json",
    "hashes.json",
    "task_manifest.json",
    "_SUCCESS.json",
)
MODEL_TASK_ARTIFACTS = COMMON_TASK_ARTIFACTS + (
    "canary_inputs.parquet",
    "canary_expected.parquet",
    "sealed_model_manifest.json",
)


WAVE_SPECS = {
    "W02": WaveSpec(
        wave="W02",
        stage="P1_04",
        task_variants=(
            TaskVariantSpec(
                task_family="ablation_bundle",
                model=None,
                compute_target="kaggle_gpu",
                allowed_privacy_classes=("deidentified_numeric",),
                canonical_expected_artifacts=COMMON_TASK_ARTIFACTS
                + ("stage2b_ablation_results.csv",),
            ),
            TaskVariantSpec(
                task_family="sensitivity_bundle",
                model=None,
                compute_target="kaggle_gpu",
                allowed_privacy_classes=("deidentified_numeric",),
                canonical_expected_artifacts=COMMON_TASK_ARTIFACTS
                + ("stage2b_sensitivity_results.csv",),
            ),
        ),
        accepted_upstream_receipt_types=("P1_03_ACCEPTED_EVALUATION_RECEIPT",),
        checkpoint_policy=CheckpointPolicy(
            mode="outcome_or_sensitivity_bundle_same_owner_resume",
            same_owner_resume=True,
            cross_session_parallel_resume=False,
            partial_marker="_SESSION_PARTIAL",
            required_records=("checkpoint_manifest.json", "resume_cursor.json"),
        ),
        stage_validator_hook="scripts.validate_p1_v2_w02_stage:validate",
        api_quota_policy=None,
        owner_affinity=(("checkpoint_resume", "original_owner"),),
    ),
    "W03": WaveSpec(
        wave="W03",
        stage="P1_05a",
        task_variants=tuple(
            TaskVariantSpec(
                task_family="stage3a_model",
                model=model,
                compute_target="kaggle_gpu",
                allowed_privacy_classes=(
                    ("deidentified_text", "deidentified_numeric")
                    if model in {"frozen_embedding", "bert_finetuned"}
                    else ("deidentified_numeric",)
                ),
                canonical_expected_artifacts=MODEL_TASK_ARTIFACTS
                + ("checkpoint_manifest.json",),
            )
            for model in (
                "frozen_embedding",
                "bert_finetuned",
                "mlp_plr",
                "ft_transformer",
            )
        ),
        accepted_upstream_receipt_types=("P1_04_ACCEPTED_WAVE_RECEIPT",),
        checkpoint_policy=CheckpointPolicy(
            mode="outcome_model_bundle_same_owner_resume",
            same_owner_resume=True,
            cross_session_parallel_resume=False,
            partial_marker="_SESSION_PARTIAL",
            required_records=("checkpoint_manifest.json", "resume_cursor.json"),
        ),
        stage_validator_hook="scripts.validate_p1_v2_w03_stage:validate",
        api_quota_policy=None,
        owner_affinity=(
            ("checkpoint_resume", "original_owner"),
            ("optuna_study", "single_owner"),
        ),
    ),
    "W04": WaveSpec(
        wave="W04",
        stage="P1_05b",
        task_variants=tuple(
            TaskVariantSpec(
                task_family="stage3b_model",
                model=model,
                compute_target=(
                    "local"
                    if model == "stacking"
                    else "kaggle_api"
                    if model in {"tabpfn_standard", "tabpfn_thinking"}
                    else "kaggle_gpu"
                ),
                allowed_privacy_classes=("deidentified_numeric",),
                canonical_expected_artifacts=MODEL_TASK_ARTIFACTS
                + (
                    ("thinking_fit_ledger.json",)
                    if model == "tabpfn_thinking"
                    else ("stacking_feature_manifest.json",)
                    if model == "stacking"
                    else ("checkpoint_manifest.json",)
                ),
                api_quota_group=(
                    "tabpfn_thinking" if model == "tabpfn_thinking" else None
                ),
            )
            for model in (
                "cnn_1d",
                "tabpfn_standard",
                "tabpfn_finetuned",
                "tabpfn_thinking",
                "tabicl",
                "stacking",
            )
        ),
        accepted_upstream_receipt_types=("P1_05A_ACCEPTED_WAVE_RECEIPT",),
        checkpoint_policy=CheckpointPolicy(
            mode="outcome_model_same_owner_resume_with_api_fit_ledger",
            same_owner_resume=True,
            cross_session_parallel_resume=False,
            partial_marker="_SESSION_PARTIAL",
            required_records=(
                "checkpoint_manifest.json",
                "resume_cursor.json",
                "thinking_fit_ledger.json",
            ),
        ),
        stage_validator_hook="scripts.validate_p1_v2_w04_stage:validate",
        api_quota_policy=ApiQuotaPolicy(
            metric="thinking_fits",
            allowed_total_fits=(24, 54),
            max_fits_per_account=MAX_THINKING_FITS_PER_ACCOUNT,
            primary_outcomes=PRIMARY_OUTCOMES,
            secondary_outcomes=SECONDARY_OUTCOMES,
            full_branch_fits_per_outcome=6,
            quota_limited_primary_fits_per_outcome=6,
            quota_limited_secondary_fits_per_outcome=1,
            distinct_affinity_accounts=False,
        ),
        owner_affinity=(
            ("checkpoint_resume", "original_owner"),
            ("thinking_primary", "one_primary_account"),
            ("thinking_secondary", "one_distinct_secondary_account"),
            ("stacking", "local_only"),
        ),
    ),
}


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def wave_specs_payload() -> dict[str, Any]:
    return {wave: asdict(WAVE_SPECS[wave]) for wave in WAVES}


WAVE_CONTRACT_SHA256 = canonical_sha256(wave_specs_payload())


def get_wave_spec(wave: str) -> WaveSpec:
    try:
        return WAVE_SPECS[wave]
    except KeyError as exc:
        raise WaveContractError(f"unsupported wave: {wave!r}") from exc


def get_task_variant(wave: str, task_family: str, model: str | None) -> TaskVariantSpec:
    spec = get_wave_spec(wave)
    matches = [
        variant
        for variant in spec.task_variants
        if variant.task_family == task_family and variant.model == model
    ]
    if len(matches) != 1:
        raise WaveContractError(
            f"{wave} task variant is not canonical: family={task_family!r}, model={model!r}"
        )
    return matches[0]


def required_owner_count(session_count: int) -> int:
    if isinstance(session_count, bool) or not isinstance(session_count, int):
        raise WaveContractError("session_count must be an integer")
    if not 1 <= session_count <= 14:
        raise WaveContractError("session_count must be in [1, 14]")
    return math.ceil(session_count / MAX_SESSIONS_PER_OWNER)


def validate_owner_session_policy(sessions: Iterable[dict[str, Any]]) -> dict[str, Any]:
    rows = list(sessions)
    required = required_owner_count(len(rows))
    session_ids: set[str] = set()
    owner_counts: dict[str, int] = {}
    for row in rows:
        if not isinstance(row, dict):
            raise WaveContractError("session owner rows must be objects")
        session_id = str(row.get("session_id", ""))
        owner = str(row.get("account_alias", row.get("owner_alias", "")))
        if not SESSION_PATTERN.fullmatch(session_id):
            raise WaveContractError(f"invalid session_id: {session_id!r}")
        if session_id in session_ids:
            raise WaveContractError(f"duplicate session_id: {session_id}")
        if not re.fullmatch(r"A0[1-7]", owner):
            raise WaveContractError(f"invalid account alias: {owner!r}")
        if not session_id.startswith(f"{owner}-"):
            raise WaveContractError(
                f"session {session_id} is not owned by its account alias {owner}"
            )
        session_ids.add(session_id)
        owner_counts[owner] = owner_counts.get(owner, 0) + 1
    if any(count > MAX_SESSIONS_PER_OWNER for count in owner_counts.values()):
        raise WaveContractError("an owner has more than two sessions")
    if len(owner_counts) != required:
        raise WaveContractError(
            f"owner count must equal ceil(sessions/2): expected {required}, got {len(owner_counts)}"
        )
    return {
        "session_count": len(rows),
        "required_owner_count": required,
        "owner_session_counts": dict(sorted(owner_counts.items())),
    }


WAVE_BINDING_SHA256_FIELDS = (
    "package_sha256",
    "schedule_sha256",
    "wave_contract_sha256",
    "task_registry_sha256",
    "data_sha256",
    "feature_schema_sha256",
    "fold_map_sha256",
)


def validate_single_wave_binding(
    session_bindings: Iterable[dict[str, Any]],
) -> dict[str, str]:
    rows = list(session_bindings)
    if not rows:
        raise WaveContractError("wave binding requires at least one session")
    session_ids: set[str] = set()
    canonical: dict[str, str] | None = None
    fields = ("wave", "package_id", "schedule_id", *WAVE_BINDING_SHA256_FIELDS)
    for row in rows:
        if not isinstance(row, dict):
            raise WaveContractError("wave binding rows must be objects")
        session_id = str(row.get("session_id", ""))
        if not SESSION_PATTERN.fullmatch(session_id):
            raise WaveContractError(f"invalid session_id: {session_id!r}")
        if session_id in session_ids:
            raise WaveContractError(f"duplicate session binding: {session_id}")
        session_ids.add(session_id)
        value = {field: str(row.get(field, "")) for field in fields}
        get_wave_spec(value["wave"])
        if not value["package_id"] or not value["schedule_id"]:
            raise WaveContractError("package_id and schedule_id are required")
        for field in WAVE_BINDING_SHA256_FIELDS:
            if not SHA256_PATTERN.fullmatch(value[field]):
                raise WaveContractError(f"{field} must be lowercase SHA256")
        if value["wave_contract_sha256"] != WAVE_CONTRACT_SHA256:
            raise WaveContractError("wave contract SHA256 differs from canonical contract")
        if canonical is None:
            canonical = value
        elif value != canonical:
            changed = [field for field in fields if value[field] != canonical[field]]
            raise WaveContractError(
                "sessions do not share one package/schedule/hash wave: "
                + ", ".join(changed)
            )
    assert canonical is not None
    return canonical


def expected_w04_thinking_fits(quota_branch: str) -> dict[str, int]:
    if quota_branch == "full_9_outcome_oof":
        return {outcome: 6 for outcome in OUTCOMES}
    if quota_branch == "quota_limited_supplemental":
        return {
            **{outcome: 6 for outcome in PRIMARY_OUTCOMES},
            **{outcome: 1 for outcome in SECONDARY_OUTCOMES},
        }
    raise WaveContractError(f"unknown thinking quota branch: {quota_branch!r}")


def validate_w04_thinking_bound_plan(
    fits_by_outcome: dict[str, Any],
) -> dict[str, Any]:
    if not isinstance(fits_by_outcome, dict) or set(fits_by_outcome) != set(OUTCOMES):
        raise WaveContractError("bound thinking fit plan must cover all nine outcomes")
    normalized: dict[str, int] = {}
    for outcome in OUTCOMES:
        fits = fits_by_outcome[outcome]
        if isinstance(fits, bool) or not isinstance(fits, int):
            raise WaveContractError(f"bound thinking fits for {outcome} must be an integer")
        normalized[outcome] = fits
    for quota_branch in ("quota_limited_supplemental", "full_9_outcome_oof"):
        if normalized == expected_w04_thinking_fits(quota_branch):
            return {
                "quota_branch": quota_branch,
                "total_fits": sum(normalized.values()),
                "fits_by_outcome": normalized,
            }
    raise WaveContractError("bound thinking fit plan is neither exact 24-fit nor 54-fit branch")


def validate_w04_thinking_fit_plan(
    assignments: Iterable[dict[str, Any]],
    *,
    bound_fits_by_outcome: dict[str, Any],
    enforce_account_capacity: bool = True,
) -> dict[str, Any]:
    rows = list(assignments)
    bound_plan = validate_w04_thinking_bound_plan(bound_fits_by_outcome)
    expected = bound_plan["fits_by_outcome"]
    by_outcome: dict[str, tuple[str, int]] = {}
    for row in rows:
        if not isinstance(row, dict):
            raise WaveContractError("thinking fit assignments must be objects")
        outcome = str(row.get("outcome", ""))
        account = str(row.get("account_alias", ""))
        fits = row.get("fits")
        if outcome not in expected:
            raise WaveContractError(f"unknown thinking outcome: {outcome!r}")
        if outcome in by_outcome:
            raise WaveContractError(f"duplicate thinking outcome assignment: {outcome}")
        if not re.fullmatch(r"T0[1-7]", account):
            raise WaveContractError(f"invalid thinking account alias: {account!r}")
        if isinstance(fits, bool) or not isinstance(fits, int) or fits != expected[outcome]:
            raise WaveContractError(
                f"thinking fits for {outcome} must equal {expected[outcome]}"
            )
        by_outcome[outcome] = (account, fits)
    if set(by_outcome) != set(expected):
        missing = sorted(set(expected) - set(by_outcome))
        raise WaveContractError(f"thinking fit plan is incomplete: {missing}")
    account_counts: dict[str, int] = {}
    for account, fits in by_outcome.values():
        account_counts[account] = account_counts.get(account, 0) + fits
    if sum(account_counts.values()) != bound_plan["total_fits"]:
        raise WaveContractError("W04 thinking fit total differs from the bound plan")
    if enforce_account_capacity and any(
        count > MAX_THINKING_FITS_PER_ACCOUNT for count in account_counts.values()
    ):
        raise WaveContractError("W04 thinking account exceeds 20 fits")
    return {
        "quota_branch": bound_plan["quota_branch"],
        "total_fits": bound_plan["total_fits"],
        "account_fit_counts": dict(sorted(account_counts.items())),
        "fits_by_outcome": expected,
    }


def validate_wave_task_placement(
    wave: str, tasks: Iterable[dict[str, Any]]
) -> dict[str, list[str]]:
    get_wave_spec(wave)
    rows = list(tasks)
    if not rows:
        raise WaveContractError("wave task placement requires at least one task")
    kaggle_task_ids: list[str] = []
    local_task_ids: list[str] = []
    seen: set[str] = set()
    for task in rows:
        if not isinstance(task, dict):
            raise WaveContractError("wave tasks must be objects")
        task_id = str(task.get("task_id", ""))
        if not task_id or task_id in seen:
            raise WaveContractError(f"missing or duplicate task_id: {task_id!r}")
        seen.add(task_id)
        if str(task.get("wave", "")) != wave:
            raise WaveContractError(f"task {task_id} belongs to a different wave")
        family = str(task.get("task_family", ""))
        model_value = task.get("model")
        model = None if model_value is None else str(model_value)
        variant = get_task_variant(wave, family, model)
        target = str(task.get("compute_target", ""))
        if target != variant.compute_target:
            raise WaveContractError(
                f"task {task_id} compute target must be {variant.compute_target}"
            )
        privacy_class = str(task.get("privacy_class", ""))
        if privacy_class not in variant.allowed_privacy_classes:
            raise WaveContractError(
                f"task {task_id} privacy class is not allowed for {variant.key}"
            )
        if target == "local":
            local_task_ids.append(task_id)
        elif target.startswith("kaggle_"):
            kaggle_task_ids.append(task_id)
        else:
            raise WaveContractError(f"task {task_id} has unsupported compute target")
    return {
        "kaggle_task_ids": sorted(kaggle_task_ids),
        "local_task_ids": sorted(local_task_ids),
    }
