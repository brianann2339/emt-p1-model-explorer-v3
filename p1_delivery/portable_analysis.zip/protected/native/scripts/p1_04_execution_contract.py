from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
SENSITIVITIES = (
    "mortality_definition",
    "grouped_vs_naive_cv",
    "city_holdout",
    "age_subgroup",
    "p3_ett",
    "ed_congestion",
)
EXECUTABLE_TASK_IDS = tuple(
    [f"P1_04-ablation-{outcome}" for outcome in OUTCOMES]
    + [
        f"P1_04-sensitivity-{sensitivity}"
        for sensitivity in SENSITIVITIES
        if sensitivity != "p3_ett"
    ]
)
TERMINAL_TASK_ID = "P1_04-sensitivity-p3_ett"
FORMAL_AUTHORIZATION_OVERLAY = (
    "${P1_PACKAGE_ROOT}/authorization/p1_04_formal_launch_overlay.json"
)
FORMAL_AUTHORIZATION_KEYS = {
    "contract_version",
    "status",
    "formal_training_authorized",
    "formal_training_launched",
    "scientific_artifact",
    "task_id",
    "task_family",
    "outcome",
    "sensitivity",
    "lineage",
    "maximum_year",
    "2025_access_count",
    "strict_no_arrival_leakage",
    "input_hashes",
    "code_sha256",
    "scientific_hashes",
    "binding_sha256",
    "accepted_launch_receipt",
    "authorization_sha256",
}
FORMAL_RECEIPT_KEYS = {
    "contract_version",
    "status",
    "task_id",
    "binding_sha256",
    "scientific_artifact",
    "formal_training_authorized",
    "receipt_sha256",
}


class ExecutionContractError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _authorization_binding(
    *,
    task_id: str,
    task_family: str,
    outcome: str | None,
    sensitivity: str | None,
    input_hashes: dict[str, str],
    code_sha256: dict[str, str],
    scientific_hashes: dict[str, str],
) -> dict[str, Any]:
    return {
        "task_id": task_id,
        "task_family": task_family,
        "outcome": outcome,
        "sensitivity": sensitivity,
        "input_hashes": input_hashes,
        "code_sha256": code_sha256,
        "scientific_hashes": scientific_hashes,
    }


def build_formal_authorization_overlay(
    *,
    task_id: str,
    task_family: str,
    outcome: str | None,
    sensitivity: str | None,
    input_hashes: dict[str, str],
    code_sha256: dict[str, str],
    scientific_hashes: dict[str, str],
) -> dict[str, Any]:
    binding_sha256 = canonical_sha256(
        _authorization_binding(
            task_id=task_id,
            task_family=task_family,
            outcome=outcome,
            sensitivity=sensitivity,
            input_hashes=input_hashes,
            code_sha256=code_sha256,
            scientific_hashes=scientific_hashes,
        )
    )
    receipt = {
        "contract_version": "p1-v2-p1-04-accepted-launch-receipt/1",
        "status": "ACCEPTED",
        "task_id": task_id,
        "binding_sha256": binding_sha256,
        "scientific_artifact": True,
        "formal_training_authorized": True,
    }
    receipt["receipt_sha256"] = canonical_sha256(receipt)
    overlay = {
        "contract_version": "p1-v2-p1-04-formal-launch-overlay/1",
        "status": "ACCEPTED",
        "formal_training_authorized": True,
        "formal_training_launched": False,
        "scientific_artifact": True,
        "task_id": task_id,
        "task_family": task_family,
        "outcome": outcome,
        "sensitivity": sensitivity,
        "lineage": "all_comer_v2",
        "maximum_year": 2024,
        "2025_access_count": 0,
        "strict_no_arrival_leakage": True,
        "input_hashes": input_hashes,
        "code_sha256": code_sha256,
        "scientific_hashes": scientific_hashes,
        "binding_sha256": binding_sha256,
        "accepted_launch_receipt": receipt,
    }
    overlay["authorization_sha256"] = canonical_sha256(overlay)
    return overlay


def validate_formal_authorization_overlay(
    path: Path,
    *,
    task_id: str,
    task_family: str,
    outcome: str | None,
    sensitivity: str | None,
    input_hashes: dict[str, str],
    code_sha256: dict[str, str],
    scientific_hashes: dict[str, str],
) -> dict[str, Any]:
    if not path.is_file():
        raise ExecutionContractError("formal launch authorization overlay is missing")
    value = read_json(path)
    if set(value) != FORMAL_AUTHORIZATION_KEYS:
        raise ExecutionContractError("formal launch authorization overlay schema differs")
    unhashed = dict(value)
    provided = unhashed.pop("authorization_sha256")
    if provided != canonical_sha256(unhashed):
        raise ExecutionContractError("formal launch authorization overlay self hash mismatch")
    receipt = value.get("accepted_launch_receipt")
    if not isinstance(receipt, dict) or set(receipt) != FORMAL_RECEIPT_KEYS:
        raise ExecutionContractError("accepted launch receipt schema differs")
    unhashed_receipt = dict(receipt)
    receipt_sha256 = unhashed_receipt.pop("receipt_sha256")
    if receipt_sha256 != canonical_sha256(unhashed_receipt):
        raise ExecutionContractError("accepted launch receipt self hash mismatch")
    expected = build_formal_authorization_overlay(
        task_id=task_id,
        task_family=task_family,
        outcome=outcome,
        sensitivity=sensitivity,
        input_hashes=input_hashes,
        code_sha256=code_sha256,
        scientific_hashes=scientific_hashes,
    )
    if value != expected:
        raise ExecutionContractError("formal launch authorization bindings differ")
    return value


def load_extension(
    path: Path,
    *,
    registry_path: Path | None = None,
    registry: dict[str, Any] | None = None,
) -> dict[str, Any]:
    value = read_json(path)
    if value.get("contract_version") != "p1-v2-p1-04-execution-extension/1":
        raise ExecutionContractError("unexpected P1_04 execution extension contract")
    if value.get("formal_training_authorized") is not False:
        raise ExecutionContractError("P1_04 execution extension must remain unauthorized")
    if value.get("canonical_registry_mutated") is not False:
        raise ExecutionContractError("P1_04 execution extension cannot mutate the canonical registry")
    if value.get("formal_authorization_overlay") != FORMAL_AUTHORIZATION_OVERLAY:
        raise ExecutionContractError("P1_04 formal authorization overlay path differs")
    dnr = value.get("isolated_lineages", {}).get("dnr_sensitivity_v2", {})
    if (
        dnr.get("dispatcher") != "separate_dnr_runner_required"
        or dnr.get("formal_training_authorized") is not False
        or dnr.get("all_comer_artifact_write_allowed") is not False
        or dnr.get("shares_all_comer_task_ids") is not False
    ):
        raise ExecutionContractError("DNR sensitivity lineage is not isolated")
    commands = value.get("task_commands")
    terminal = value.get("terminal_tasks")
    if not isinstance(commands, dict) or set(commands) != set(EXECUTABLE_TASK_IDS):
        raise ExecutionContractError("P1_04 execution extension executable task set mismatch")
    if not isinstance(terminal, dict) or set(terminal) != {TERMINAL_TASK_ID}:
        raise ExecutionContractError("P1_04 execution extension terminal task set mismatch")
    terminal_value = terminal[TERMINAL_TASK_ID]
    if (
        terminal_value.get("status") != "NOT_ESTIMABLE"
        or terminal_value.get("scheduled") is not False
        or terminal_value.get("command") is not None
        or terminal_value.get("field_intubated_inferred_from_proxy") is not False
    ):
        raise ExecutionContractError("P3 ETT terminal disposition changed")
    for task_id, item in commands.items():
        command = item.get("command")
        if (
            not isinstance(command, list)
            or not command
            or any(not isinstance(token, str) or not token for token in command)
            or "--launch-authorization-overlay" in command
            or item.get("scientific_artifact") is not True
            or item.get("formal_training_authorized") is not False
        ):
            raise ExecutionContractError(f"invalid P1_04 command entry: {task_id}")
        expected_family = "ablation_bundle" if "-ablation-" in task_id else "sensitivity_bundle"
        if item.get("task_family") != expected_family:
            raise ExecutionContractError(f"P1_04 task family mismatch: {task_id}")
    if registry_path is not None:
        actual = sha256_file(registry_path)
        if value.get("canonical_task_registry_sha256") != actual:
            raise ExecutionContractError("P1_04 extension canonical registry hash mismatch")
        if registry is None:
            registry = read_json(registry_path)
    if registry is not None:
        tasks = [task for task in registry.get("tasks", []) if task.get("stage") == "P1_04"]
        ids = [str(task.get("task_id", "")) for task in tasks]
        expected = [*EXECUTABLE_TASK_IDS, TERMINAL_TASK_ID]
        if len(ids) != len(expected) or set(ids) != set(expected):
            raise ExecutionContractError("canonical P1_04 registry task set mismatch")
        registry_by_id = {str(task["task_id"]): task for task in tasks}
        for task_id, item in commands.items():
            task = registry_by_id[task_id]
            if task.get("task_family") != item["task_family"]:
                raise ExecutionContractError(f"registry family differs from extension: {task_id}")
            if task.get("outcome") != item.get("outcome"):
                raise ExecutionContractError(f"registry outcome differs from extension: {task_id}")
            if task.get("metadata", {}).get("sensitivity") != item.get("sensitivity"):
                raise ExecutionContractError(f"registry sensitivity differs from extension: {task_id}")
    return value


def executable_task_ids(extension: dict[str, Any]) -> list[str]:
    return sorted(extension["task_commands"])


def command_for(extension: dict[str, Any], task_id: str) -> list[str]:
    if task_id in extension["terminal_tasks"]:
        raise ExecutionContractError(f"terminal task has no command: {task_id}")
    try:
        command = list(extension["task_commands"][task_id]["command"])
        return [
            *command,
            "--launch-authorization-overlay",
            str(extension["formal_authorization_overlay"]),
        ]
    except KeyError as error:
        raise ExecutionContractError(f"task is absent from P1_04 execution extension: {task_id}") from error
