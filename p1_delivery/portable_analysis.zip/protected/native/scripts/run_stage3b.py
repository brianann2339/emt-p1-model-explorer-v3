from __future__ import annotations

import argparse
import gc
import hashlib
import json
import pickle
import warnings
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegressionCV
from sklearn.metrics import average_precision_score, brier_score_loss, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset


ROOT = Path(__file__).resolve().parents[1]
STAGE1A_DIR = ROOT / "outputs" / "stage1a"
STAGE1B_DIR = ROOT / "outputs" / "stage1b"
STAGE3A_DIR = ROOT / "outputs" / "stage3a"
OUT_DIR = ROOT / "outputs" / "stage3b"
LOG_DIR = ROOT / "outputs" / "logs"

PRIMARY_TARGETS = ["y_P1", "y_P2", "y_P3"]
FORBIDDEN_TERMS = ["到院_", "檢傷", "交接", "離開醫院", "返隊", "送達醫院名稱", "在院"]


@dataclass
class PredBlock:
    outcome: str
    model: str
    split: str
    row_hash: np.ndarray
    y_true: np.ndarray
    pred: np.ndarray
    notes: str


class OneDCNN(nn.Module):
    def __init__(self, n_features: int, proj_dim: int = 1024, channels: int = 64, dropout: float = 0.2):
        super().__init__()
        self.proj = nn.Sequential(nn.Linear(n_features, proj_dim), nn.ReLU(), nn.Dropout(dropout))
        self.conv = nn.Sequential(
            nn.Conv1d(1, channels, kernel_size=5, padding=2),
            nn.BatchNorm1d(channels),
            nn.ReLU(),
            nn.Conv1d(channels, channels, kernel_size=5, padding=2),
            nn.BatchNorm1d(channels),
            nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
        )
        self.head = nn.Sequential(nn.Flatten(), nn.Dropout(dropout), nn.Linear(channels, 1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.proj(x).unsqueeze(1)
        return self.head(self.conv(z)).squeeze(-1)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def safe_metric(func, y: np.ndarray, p: np.ndarray) -> float:
    try:
        if len(np.unique(y)) < 2:
            return float("nan")
        return float(func(y, p))
    except Exception:
        return float("nan")


def metric_row(block: PredBlock) -> dict:
    y = block.y_true.astype("int8")
    p = np.clip(block.pred.astype("float64"), 1e-6, 1 - 1e-6)
    th = float(np.quantile(p, 0.9))
    return {
        "outcome": block.outcome,
        "model": block.model,
        "split": block.split,
        "n": int(len(y)),
        "events": int(y.sum()),
        "prevalence": float(y.mean()),
        "AUROC": safe_metric(roc_auc_score, y, p),
        "AUPRC": safe_metric(average_precision_score, y, p),
        "Brier": float(brier_score_loss(y, p)),
        "F1_at_top10pct": float(f1_score(y, p >= th, zero_division=0)),
        "notes": block.notes,
    }


def validate_upstream() -> None:
    for name, path in [
        ("stage1a", STAGE1A_DIR / "stage1a_feature_manifest.json"),
        ("stage1b", STAGE1B_DIR / "stage1b_manifest.json"),
        ("stage3a", STAGE3A_DIR / "stage3a_manifest.json"),
    ]:
        m = read_json(path)
        if not m.get("strict_no_arrival_leakage"):
            raise RuntimeError(f"{name} strict no-arrival leakage gate is not true")
        if m.get("holdout_2025_rows_loaded") not in (0, None):
            raise RuntimeError(f"{name} reports 2025 rows loaded")


def load_baseline_feature_columns() -> list[str]:
    with (STAGE1B_DIR / "stage1b_models.pkl").open("rb") as f:
        models = pickle.load(f)
    try:
        cols = list(models["y_P1::xgboost"].named_steps["imputer"].feature_names_in_)
        bad = [c for c in cols if any(term in c for term in FORBIDDEN_TERMS)]
        if bad:
            raise RuntimeError(f"Forbidden feature names in baseline columns: {bad[:10]}")
        return cols
    finally:
        del models
        gc.collect()


def select_top_features(feature_cols: list[str], max_features: int) -> list[str]:
    if max_features <= 0 or len(feature_cols) <= max_features:
        return feature_cols if max_features <= 0 else feature_cols[:max_features]
    imp = pd.read_csv(STAGE1B_DIR / "stage1b_feature_importance_top100.csv")
    ordered = [c for c in imp["feature"].dropna().astype(str).tolist() if c in feature_cols]
    selected = []
    for c in ordered + feature_cols:
        if c not in selected:
            selected.append(c)
        if len(selected) >= max_features:
            break
    return selected


def stratified_sample_indices(y: np.ndarray, max_rows: int, seed: int) -> np.ndarray:
    if max_rows <= 0 or len(y) <= max_rows:
        return np.arange(len(y))
    rng = np.random.default_rng(seed)
    pos = np.flatnonzero(y == 1)
    neg = np.flatnonzero(y == 0)
    keep_pos = min(len(pos), max(1, int(max_rows * max(0.2, len(pos) / len(y)))))
    keep_neg = max_rows - keep_pos
    idx = np.concatenate([rng.choice(pos, keep_pos, replace=False), rng.choice(neg, min(keep_neg, len(neg)), replace=False)])
    rng.shuffle(idx)
    return idx


def preprocess_fit_transform(X_train: pd.DataFrame, X_other: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, dict]:
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    xt = imputer.fit_transform(X_train)
    xo = imputer.transform(X_other)
    xt = scaler.fit_transform(xt).astype("float32")
    xo = scaler.transform(xo).astype("float32")
    return xt, xo, {"imputer": imputer, "scaler": scaler}


def train_cnn_predict(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_eval: np.ndarray,
    args: argparse.Namespace,
    device: torch.device,
    seed: int,
) -> tuple[np.ndarray, OneDCNN]:
    torch.manual_seed(seed)
    model = OneDCNN(X_train.shape[1], proj_dim=args.cnn_proj_dim, channels=args.cnn_channels, dropout=args.cnn_dropout).to(device)
    y_train = y_train.astype("float32")
    pos = max(1.0, float(y_train.sum()))
    neg = max(1.0, float(len(y_train) - y_train.sum()))
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([neg / pos], device=device))
    opt = torch.optim.AdamW(model.parameters(), lr=args.cnn_lr, weight_decay=1e-4)
    loader = DataLoader(TensorDataset(torch.from_numpy(X_train.astype("float32")), torch.from_numpy(y_train)), batch_size=args.cnn_batch_size, shuffle=True)
    model.train()
    for _ in range(args.cnn_epochs):
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            opt.zero_grad(set_to_none=True)
            loss = loss_fn(model(xb), yb)
            loss.backward()
            opt.step()
    model.eval()
    preds = []
    with torch.no_grad():
        for start in range(0, len(X_eval), args.cnn_batch_size * 2):
            xb = torch.from_numpy(X_eval[start : start + args.cnn_batch_size * 2].astype("float32")).to(device)
            preds.append(torch.sigmoid(model(xb)).cpu().numpy())
    return np.concatenate(preds), model


def run_cnn(df: pd.DataFrame, feature_cols: list[str], targets: list[str], args: argparse.Namespace, device: torch.device) -> tuple[list[PredBlock], dict]:
    blocks: list[PredBlock] = []
    specs = {}
    train = df[df["split"].eq("train_2020_2023")].copy()
    val = df[df["split"].eq("validation_2024")].copy()
    groups = train["group_hash"].astype(str).to_numpy()
    for outcome_i, outcome in enumerate(targets):
        y = train[outcome].to_numpy(dtype="int8")
        pred = np.full(len(train), np.nan, dtype="float32")
        splitter = StratifiedGroupKFold(n_splits=args.oof_folds, shuffle=True, random_state=args.seed + outcome_i)
        for fold_i, (tr, te) in enumerate(splitter.split(train[feature_cols], y, groups), start=1):
            print(f"[{datetime.now().isoformat(timespec='seconds')}] stage3b cnn outcome={outcome} fold={fold_i}/{args.oof_folds}", flush=True)
            tr_sample = stratified_sample_indices(y[tr], args.cnn_max_train_rows, args.seed + fold_i + outcome_i * 100)
            X_tr_raw = train.iloc[tr].iloc[tr_sample][feature_cols].apply(pd.to_numeric, errors="coerce").astype("float32")
            y_tr = y[tr][tr_sample]
            X_te_raw = train.iloc[te][feature_cols].apply(pd.to_numeric, errors="coerce").astype("float32")
            X_tr, X_te, _ = preprocess_fit_transform(X_tr_raw, X_te_raw)
            pred[te], _ = train_cnn_predict(X_tr, y_tr, X_te, args, device, args.seed + fold_i)
        blocks.append(PredBlock(outcome, "1d_cnn", "train_2020_2023_oof", train["row_hash"].to_numpy(), y, pred, "1D-CNN OOF"))

        idx = stratified_sample_indices(y, args.cnn_max_train_rows, args.seed + 500 + outcome_i)
        X_fit_raw = train.iloc[idx][feature_cols].apply(pd.to_numeric, errors="coerce").astype("float32")
        y_fit = y[idx]
        X_val_raw = val[feature_cols].apply(pd.to_numeric, errors="coerce").astype("float32")
        X_fit, X_val, prep = preprocess_fit_transform(X_fit_raw, X_val_raw)
        p_val, model = train_cnn_predict(X_fit, y_fit, X_val, args, device, args.seed + 700 + outcome_i)
        state_path = OUT_DIR / f"stage3b_1d_cnn_{outcome}.pt"
        torch.save({"model_state_dict": model.cpu().state_dict(), "columns": feature_cols, "preprocessor": prep, "args": vars(args)}, state_path)
        blocks.append(PredBlock(outcome, "1d_cnn", "validation_2024", val["row_hash"].to_numpy(), val[outcome].to_numpy(dtype="int8"), p_val, "1D-CNN validation final"))
        specs[f"{outcome}::1d_cnn"] = {"state_path": str(state_path), "feature_count": len(feature_cols), "bounded_train_rows": int(len(y_fit))}
    return blocks, specs


def fit_prior_classifier(model_name: str, args: argparse.Namespace, seed: int):
    if model_name == "tabpfn":
        from tabpfn_client import TabPFNClassifier

        return TabPFNClassifier(n_estimators=args.tabpfn_estimators, random_state=seed, thinking_mode=False)
    if model_name == "tabicl":
        from tabicl import TabICLClassifier

        return TabICLClassifier(n_estimators=args.tabicl_estimators, device="cpu", batch_size=args.tabicl_batch_size, random_state=seed, verbose=False)
    raise ValueError(model_name)


def run_prior_model(df: pd.DataFrame, feature_cols: list[str], targets: list[str], args: argparse.Namespace, model_name: str) -> tuple[list[PredBlock], dict]:
    blocks: list[PredBlock] = []
    specs = {}
    train = df[df["split"].eq("train_2020_2023")].copy()
    val = df[df["split"].eq("validation_2024")].copy()
    groups = train["group_hash"].astype(str).to_numpy()
    for outcome_i, outcome in enumerate(targets):
        y = train[outcome].to_numpy(dtype="int8")
        pred = np.full(len(train), np.nan, dtype="float32")
        splitter = StratifiedGroupKFold(n_splits=args.oof_folds, shuffle=True, random_state=args.seed + 2000 + outcome_i)
        for fold_i, (tr, te) in enumerate(splitter.split(train[feature_cols], y, groups), start=1):
            print(f"[{datetime.now().isoformat(timespec='seconds')}] stage3b {model_name} outcome={outcome} fold={fold_i}/{args.oof_folds}", flush=True)
            tr_sample = stratified_sample_indices(y[tr], args.prior_max_train_rows, args.seed + 2100 + fold_i + outcome_i * 100)
            X_tr_raw = train.iloc[tr].iloc[tr_sample][feature_cols].apply(pd.to_numeric, errors="coerce").astype("float32")
            y_tr = y[tr][tr_sample]
            X_te_raw = train.iloc[te][feature_cols].apply(pd.to_numeric, errors="coerce").astype("float32")
            X_tr, X_te, _ = preprocess_fit_transform(X_tr_raw, X_te_raw)
            clf = fit_prior_classifier(model_name, args, args.seed + fold_i + outcome_i * 100)
            clf.fit(X_tr, y_tr)
            pred[te] = clf.predict_proba(X_te)[:, 1]
        blocks.append(PredBlock(outcome, model_name, "train_2020_2023_oof", train["row_hash"].to_numpy(), y, pred, f"{model_name} OOF bounded"))

        idx = stratified_sample_indices(y, args.prior_max_train_rows, args.seed + 2500 + outcome_i)
        X_fit_raw = train.iloc[idx][feature_cols].apply(pd.to_numeric, errors="coerce").astype("float32")
        y_fit = y[idx]
        X_val_raw = val[feature_cols].apply(pd.to_numeric, errors="coerce").astype("float32")
        X_fit, X_val, prep = preprocess_fit_transform(X_fit_raw, X_val_raw)
        clf = fit_prior_classifier(model_name, args, args.seed + 2600 + outcome_i)
        clf.fit(X_fit, y_fit)
        p_val = clf.predict_proba(X_val)[:, 1]
        model_path = OUT_DIR / f"stage3b_{model_name}_{outcome}.pkl"
        with model_path.open("wb") as f:
            pickle.dump({"model": clf, "columns": feature_cols, "preprocessor": prep, "args": vars(args)}, f)
        blocks.append(PredBlock(outcome, model_name, "validation_2024", val["row_hash"].to_numpy(), val[outcome].to_numpy(dtype="int8"), p_val, f"{model_name} validation final"))
        specs[f"{outcome}::{model_name}"] = {"model_path": str(model_path), "feature_count": len(feature_cols), "bounded_train_rows": int(len(y_fit))}
        gc.collect()
    return blocks, specs


def blocks_to_frames(blocks: list[PredBlock]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    frames = []
    metrics = []
    for b in blocks:
        frames.append(pd.DataFrame({"row_hash": b.row_hash, "outcome": b.outcome, "model": b.model, "split": b.split, "y_true": b.y_true, "pred": b.pred}))
        metrics.append(metric_row(b))
    pred = pd.concat(frames, ignore_index=True)
    return pred[pred["split"].str.contains("oof")].reset_index(drop=True), pred[pred["split"].eq("validation_2024")].reset_index(drop=True), pd.DataFrame(metrics)


def pivot_long_preds(df: pd.DataFrame, prefix: str, outcome: str) -> pd.DataFrame:
    sub = df[df["outcome"].eq(outcome)].copy()
    if "pred" in sub.columns:
        piv = sub.pivot_table(index="row_hash", columns="model", values="pred", aggfunc="first")
        piv.columns = [f"{prefix}__{c}" for c in piv.columns]
        y = sub.groupby("row_hash")["y_true"].first()
        out = piv.join(y.rename("y_true"))
        return out.reset_index()
    pred_cols = [c for c in sub.columns if c.startswith("pred__")]
    out = sub[["row_hash", "y_true", *pred_cols]].copy()
    out = out.rename(columns={c: f"{prefix}__{c.replace('pred__','')}" for c in pred_cols})
    return out


def run_stacking(stage3b_oof: pd.DataFrame, stage3b_val: pd.DataFrame, targets: list[str]) -> tuple[list[PredBlock], dict]:
    blocks: list[PredBlock] = []
    specs = {}
    s1_oof = pd.read_parquet(STAGE1B_DIR / "oof_preds.parquet")
    s1_val = pd.read_parquet(STAGE1B_DIR / "validation_preds.parquet")
    s3a_oof = pd.read_parquet(STAGE3A_DIR / "stage3a_oof_preds.parquet")
    s3a_val = pd.read_parquet(STAGE3A_DIR / "stage3a_validation_preds.parquet")
    for outcome in targets:
        train_parts = [
            pivot_long_preds(s1_oof, "stage1b", outcome),
            pivot_long_preds(s3a_oof, "stage3a", outcome),
            pivot_long_preds(stage3b_oof, "stage3b", outcome),
        ]
        val_parts = [
            pivot_long_preds(s1_val, "stage1b", outcome),
            pivot_long_preds(s3a_val, "stage3a", outcome),
            pivot_long_preds(stage3b_val, "stage3b", outcome),
        ]
        train_meta = train_parts[0]
        for part in train_parts[1:]:
            train_meta = train_meta.merge(part.drop(columns=["y_true"], errors="ignore"), on="row_hash", how="left")
        val_meta = val_parts[0]
        for part in val_parts[1:]:
            val_meta = val_meta.merge(part.drop(columns=["y_true"], errors="ignore"), on="row_hash", how="left")
        y = train_meta["y_true"].to_numpy(dtype="int8")
        y_val = val_meta["y_true"].to_numpy(dtype="int8")
        feature_cols = [c for c in train_meta.columns if c not in ["row_hash", "y_true"]]
        imputer = SimpleImputer(strategy="median")
        scaler = StandardScaler()
        X = scaler.fit_transform(imputer.fit_transform(train_meta[feature_cols])).astype("float32")
        Xv = scaler.transform(imputer.transform(val_meta[feature_cols])).astype("float32")
        print(f"[{datetime.now().isoformat(timespec='seconds')}] stage3b stacking outcome={outcome} features={len(feature_cols)}", flush=True)
        clf = LogisticRegressionCV(Cs=5, cv=3, scoring="average_precision", max_iter=1000, class_weight="balanced", solver="lbfgs")
        clf.fit(X, y)
        p_val = clf.predict_proba(Xv)[:, 1]
        blocks.append(PredBlock(outcome, "stacking_logregcv", "validation_2024", val_meta["row_hash"].to_numpy(), y_val, p_val, "Stage1b+Stage3a+Stage3b stacking"))
        specs[outcome] = {"feature_count": len(feature_cols), "meta_features": feature_cols, "C": clf.C_.tolist()}
    return blocks, specs


def run(args: argparse.Namespace) -> None:
    warnings.filterwarnings("ignore", category=UserWarning)
    warnings.filterwarnings("ignore", category=FutureWarning)
    started = datetime.now(timezone.utc)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(args.torch_threads)
    device = torch.device("cpu")
    validate_upstream()
    targets = PRIMARY_TARGETS[: args.max_targets] if args.max_targets else PRIMARY_TARGETS
    baseline_cols = load_baseline_feature_columns()
    cnn_cols = baseline_cols
    prior_cols = select_top_features(baseline_cols, args.prior_max_features)
    read_cols = ["row_hash", "group_hash", "split_year", "split", *targets, *sorted(set(cnn_cols) | set(prior_cols))]
    df = pd.read_parquet(STAGE1A_DIR / "stage1a_features_le2024.parquet", columns=read_cols)
    if (df["split_year"] >= 2025).any():
        raise RuntimeError("Stage3b loaded 2025 rows unexpectedly")

    blocks: list[PredBlock] = []
    specs: dict = {}
    cnn_blocks, cnn_specs = run_cnn(df, cnn_cols, targets, args, device)
    blocks.extend(cnn_blocks)
    specs.update(cnn_specs)
    tabpfn_blocks, tabpfn_specs = run_prior_model(df, prior_cols, targets, args, "tabpfn")
    blocks.extend(tabpfn_blocks)
    specs.update(tabpfn_specs)
    tabicl_blocks, tabicl_specs = run_prior_model(df, prior_cols, targets, args, "tabicl")
    blocks.extend(tabicl_blocks)
    specs.update(tabicl_specs)

    oof, val, metrics = blocks_to_frames(blocks)
    stack_blocks, stack_specs = run_stacking(oof, val, targets)
    stack_metrics = pd.DataFrame([metric_row(b) for b in stack_blocks])
    all_metrics = pd.concat([metrics, stack_metrics], ignore_index=True)
    stack_val = pd.concat(
        [
            pd.DataFrame({"row_hash": b.row_hash, "outcome": b.outcome, "model": b.model, "split": b.split, "y_true": b.y_true, "pred": b.pred})
            for b in stack_blocks
        ],
        ignore_index=True,
    )
    val_all = pd.concat([val, stack_val], ignore_index=True)

    oof.to_parquet(OUT_DIR / "stage3b_oof_preds.parquet", index=False)
    val_all.to_parquet(OUT_DIR / "stage3b_validation_preds.parquet", index=False)
    all_metrics.to_csv(OUT_DIR / "stage3b_metrics.csv", index=False, encoding="utf-8-sig")
    specs["stacking_logregcv"] = stack_specs
    (OUT_DIR / "stage3b_model_specs.json").write_text(json.dumps(specs, ensure_ascii=False, indent=2), encoding="utf-8")
    with (OUT_DIR / "stage3b_final_stacked_models.pkl").open("wb") as f:
        pickle.dump({"stacking_specs": stack_specs, "base_model_specs": specs}, f)

    mandatory = {"1d_cnn", "tabpfn", "tabicl"}
    have = set(all_metrics["model"].unique())
    if not mandatory <= have:
        raise RuntimeError(f"Stage3b mandatory model hard gate failed: {sorted(mandatory - have)}")
    for model in mandatory:
        sub = all_metrics[all_metrics["model"].eq(model) & all_metrics["split"].eq("validation_2024")]
        if sorted(sub["outcome"].unique().tolist()) != sorted(targets):
            raise RuntimeError(f"Stage3b validation metrics missing for {model}")

    required = [
        "stage3b_oof_preds.parquet",
        "stage3b_validation_preds.parquet",
        "stage3b_metrics.csv",
        "stage3b_model_specs.json",
        "stage3b_final_stacked_models.pkl",
    ]
    hashes = {name: sha256_file(OUT_DIR / name) for name in required}
    manifest = {
        "stage": "P1_05b_Stage3b",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS",
        "scope_outcomes": targets,
        "strict_no_arrival_leakage": True,
        "holdout_2025_rows_loaded": 0,
        "holdout_2025_predictions_computed": False,
        "device": "cpu",
        "torch_cuda_available": bool(torch.cuda.is_available()),
        "mandatory_models": sorted(mandatory),
        "oof_folds": int(args.oof_folds),
        "cnn_feature_count": len(cnn_cols),
        "prior_feature_count": len(prior_cols),
        "prior_max_train_rows": int(args.prior_max_train_rows),
        "tabpfn_mode": "tabpfn_client_baseline_no_thinking",
        "tabpfn_finetune": "not_run_bounded_cpu_api_stage",
        "tabpfn_thinking": "not_run_bounded_api_stage",
        "tabicl_mode": "local_cpu",
        "artifact_sha256": hashes,
        "runtime_seconds": round((datetime.now(timezone.utc) - started).total_seconds(), 2),
    }
    (OUT_DIR / "stage3b_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    qa = [
        "# P1_05b Stage 3b QA Record",
        "",
        "- Stage: P1_05b 1D-CNN, TabPFN, TabICL, stacking",
        "- Decision: PASS",
        "- QA mode: structured self-audit; independent subagent QA unavailable because this turn did not explicitly authorize subagents.",
        "- Strict no-arrival leakage: true",
        "- 2025 rows loaded/predicted/metriced: 0/false/false",
        "- Mandatory hard gate models present: 1D-CNN, TabPFN client baseline, TabICL local CPU",
        "- TabPFN fine-tune/thinking: not run in bounded CPU/API stage; baseline TabPFN client predictions are included for stacking.",
        f"- OOF folds: {args.oof_folds}",
        "",
        "## Artifact Integrity",
        "",
        "| artifact | sha256 |",
        "|---|---|",
    ]
    for name, digest in sorted(hashes.items()):
        qa.append(f"| `{name}` | `{digest}` |")
    (LOG_DIR / "stage3b_qa_record.md").write_text("\n".join(qa) + "\n", encoding="utf-8")
    print(json.dumps({"decision": "PASS", "manifest": str(OUT_DIR / "stage3b_manifest.json"), "qa_record": str(LOG_DIR / "stage3b_qa_record.md")}, ensure_ascii=False, indent=2), flush=True)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--max-targets", type=int, default=0)
    p.add_argument("--oof-folds", type=int, default=5)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--torch-threads", type=int, default=4)
    p.add_argument("--cnn-max-train-rows", type=int, default=16000)
    p.add_argument("--cnn-epochs", type=int, default=3)
    p.add_argument("--cnn-batch-size", type=int, default=512)
    p.add_argument("--cnn-lr", type=float, default=1e-3)
    p.add_argument("--cnn-proj-dim", type=int, default=1024)
    p.add_argument("--cnn-channels", type=int, default=64)
    p.add_argument("--cnn-dropout", type=float, default=0.2)
    p.add_argument("--prior-max-train-rows", type=int, default=2048)
    p.add_argument("--prior-max-features", type=int, default=64)
    p.add_argument("--tabpfn-estimators", type=int, default=1)
    p.add_argument("--tabicl-estimators", type=int, default=1)
    p.add_argument("--tabicl-batch-size", type=int, default=8)
    return p.parse_args()


if __name__ == "__main__":
    run(parse_args())
