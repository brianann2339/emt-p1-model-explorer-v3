from __future__ import annotations

import argparse
import copy
import hashlib
import json
import shutil
from pathlib import Path
from typing import Any

from scripts import build_stage3b_thinking_quota_plan as thinking_quota


ROOT = Path(__file__).resolve().parents[1]
BASE_REGISTRY_SHA256 = "4bcf8486c3a182fcb60da1066eb1a71fc5c2203a5be388125aca15946539f32d"
OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
BASE_ADDITIONS = tuple(
    (
        f"P1_05b-{outcome}-tabpfn_finetuned",
        f"P1_05b-{outcome}-tabpfn_standard",
    )
    for outcome in OUTCOMES
)
THINKING_PLAN_FILENAME = "thinking_global_plan.json"
THINKING_PROBE_FILENAME = thinking_quota.PROBE_FILENAME


class Stage3RegistryError(RuntimeError):
    pass


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise Stage3RegistryError(f"JSON root is not an object: {path}")
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, sort_keys=False, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _thinking_metadata_overrides(plan: dict[str, Any]) -> dict[str, dict[str, Any]]:
    result = {}
    for task_id, reservation in plan["reservations"].items():
        classification = reservation["artifact_classification"]
        result[task_id] = {
            "cv_folds": 5 if classification["full_oof_required"] else 0,
            "thinking_fits": classification["planned_fit_count"],
            "final_fits": 1,
            "stacking_eligible": classification["stacking_eligible"],
            "thinking_quota_branch": classification["quota_branch"],
            "quota_limited_supplemental": classification[
                "quota_limited_supplemental"
            ],
            "not_equivalent_to_full_oof": classification[
                "not_equivalent_to_full_oof"
            ],
            "full_oof_required": classification["full_oof_required"],
            "thinking_task_plan_sha256": reservation["task_plan_sha256"],
            "thinking_quota_probe_sha256": plan["quota_probe"]["sha256"],
        }
    return result


def _dependency_additions(
    thinking_plan: dict[str, Any] | None,
) -> tuple[tuple[str, str], ...]:
    additions = list(BASE_ADDITIONS)
    if thinking_plan is not None:
        additions.extend(
            (
                f"P1_05b-{outcome}-stacking",
                f"P1_05b-{outcome}-tabpfn_thinking",
            )
            for outcome in thinking_quota.OUTCOMES
            if outcome not in thinking_quota.PRIMARY_OUTCOMES
            and thinking_plan["reservations"][
                f"P1_05b-{outcome}-tabpfn_thinking"
            ]["artifact_classification"]["stacking_eligible"]
        )
    return tuple(additions)


def _allowed_mutation(thinking_plan: dict[str, Any] | None) -> str:
    if thinking_plan is None:
        return "append one same-outcome tabpfn_standard dependency to each tabpfn_finetuned task"
    return (
        "append same-outcome tabpfn_standard dependencies, append full-branch eligible "
        "tabpfn_thinking stacking dependencies, and apply only live-plan-bound "
        "tabpfn_thinking metadata"
    )


def build_effective_registry(
    base: dict[str, Any],
    thinking_plan: dict[str, Any] | None = None,
) -> dict[str, Any]:
    tasks = base.get("tasks")
    if not isinstance(tasks, list):
        raise Stage3RegistryError("base registry tasks are not a list")
    by_id = {str(task.get("task_id", "")): task for task in tasks}
    if len(by_id) != len(tasks) or "" in by_id:
        raise Stage3RegistryError("base registry task ids are empty or duplicated")
    effective = copy.deepcopy(base)
    effective_by_id = {str(task["task_id"]): task for task in effective["tasks"]}
    for task_id, dependency in _dependency_additions(thinking_plan):
        if task_id not in by_id or dependency not in by_id:
            raise Stage3RegistryError(f"Stage3 extension task is missing: {task_id}/{dependency}")
        base_dependencies = by_id[task_id].get("dependencies")
        if not isinstance(base_dependencies, list) or dependency in base_dependencies:
            raise Stage3RegistryError(f"Stage3 base dependency state differs: {task_id}")
        effective_by_id[task_id]["dependencies"] = [*base_dependencies, dependency]
    if thinking_plan is not None:
        for task_id, override in _thinking_metadata_overrides(thinking_plan).items():
            if task_id not in effective_by_id:
                raise Stage3RegistryError(f"thinking task is missing: {task_id}")
            effective_by_id[task_id]["metadata"] = {
                **effective_by_id[task_id]["metadata"],
                **override,
            }
    validate_effective_registry(base, effective, thinking_plan=thinking_plan)
    return effective


def validate_effective_registry(
    base: dict[str, Any],
    effective: dict[str, Any],
    *,
    thinking_plan: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if list(base) != list(effective):
        raise Stage3RegistryError("effective registry root key order/content differs")
    base_tasks = base.get("tasks")
    effective_tasks = effective.get("tasks")
    if not isinstance(base_tasks, list) or not isinstance(effective_tasks, list):
        raise Stage3RegistryError("registry tasks are not lists")
    if len(base_tasks) != len(effective_tasks):
        raise Stage3RegistryError("effective registry task count differs")
    additions = dict(_dependency_additions(thinking_plan))
    metadata_overrides = (
        _thinking_metadata_overrides(thinking_plan) if thinking_plan is not None else {}
    )
    changed: list[str] = []
    for position, (base_task, effective_task) in enumerate(zip(base_tasks, effective_tasks)):
        task_id = str(base_task.get("task_id", ""))
        if effective_task.get("task_id") != task_id:
            raise Stage3RegistryError(f"effective registry task order differs at {position}")
        if list(base_task) != list(effective_task):
            raise Stage3RegistryError(f"effective task key order/content differs: {task_id}")
        expected = copy.deepcopy(base_task)
        if task_id in additions:
            expected["dependencies"] = [*base_task["dependencies"], additions[task_id]]
        if task_id in metadata_overrides:
            expected["metadata"] = {
                **base_task["metadata"],
                **metadata_overrides[task_id],
            }
        if task_id in additions or task_id in metadata_overrides:
            changed.append(task_id)
        if effective_task != expected:
            raise Stage3RegistryError(f"effective task contains unauthorized drift: {task_id}")
    expected_changed = [
        str(task["task_id"])
        for task in base_tasks
        if task["task_id"] in additions or task["task_id"] in metadata_overrides
    ]
    if changed != expected_changed:
        raise Stage3RegistryError("effective registry changed-task order/content differs")
    audit = {
        "changed_task_ids": changed,
        "changed_task_count": len(changed),
        "unchanged_task_count": len(base_tasks) - len(changed),
        "task_count": len(base_tasks),
        "only_allowed_dependency_additions": True,
        "task_order_unchanged": True,
        "non_dependency_fields_unchanged": True,
    }
    if thinking_plan is not None:
        audit["only_plan_bound_thinking_metadata_overrides"] = True
    return audit


def validate_rebind_bundle(
    *,
    base_registry_path: Path,
    effective_registry_path: Path,
    extension_path: Path,
    receipt_path: Path,
) -> dict[str, Any]:
    if sha256_file(base_registry_path) != BASE_REGISTRY_SHA256:
        raise Stage3RegistryError("canonical base registry hash differs")
    base = read_json(base_registry_path)
    effective = read_json(effective_registry_path)
    extension = read_json(extension_path)
    receipt = read_json(receipt_path)
    extension_contract = extension.get("contract_version")
    thinking_plan = None
    if extension_contract == "p1-v2-stage3-registry-extension/2":
        plan_path = receipt_path.parent / THINKING_PLAN_FILENAME
        probe_path = receipt_path.parent / THINKING_PROBE_FILENAME
        if not plan_path.is_file() or not probe_path.is_file():
            raise Stage3RegistryError("Stage3 thinking plan/probe evidence is missing")
        thinking_plan = read_json(plan_path)
        try:
            thinking_quota.validate_plan(
                thinking_plan,
                plan_path=plan_path,
                require_fresh=False,
            )
        except Exception as error:
            raise Stage3RegistryError("Stage3 thinking plan/probe evidence differs") from error
    audit = validate_effective_registry(
        base,
        effective,
        thinking_plan=thinking_plan,
    )
    expected_extension_keys = {
        "contract_version",
        "status",
        "base_registry_sha256",
        "allowed_mutation",
        "dependency_additions",
        "extension_sha256",
    }
    if thinking_plan is not None:
        expected_extension_keys |= {
            "thinking_quota_plan_sha256",
            "thinking_quota_probe_sha256",
            "thinking_quota_branch",
            "thinking_metadata_overrides",
        }
    if set(extension) != expected_extension_keys:
        raise Stage3RegistryError("Stage3 registry extension key set differs")
    if (
        extension.get("contract_version")
        != (
            "p1-v2-stage3-registry-extension/2"
            if thinking_plan is not None
            else "p1-v2-stage3-registry-extension/1"
        )
        or extension.get("status") != "LOCKED"
        or extension.get("base_registry_sha256") != BASE_REGISTRY_SHA256
        or extension.get("allowed_mutation") != _allowed_mutation(thinking_plan)
        or extension.get("dependency_additions")
        != [
            {"task_id": task_id, "append_dependency": dependency}
            for task_id, dependency in _dependency_additions(thinking_plan)
        ]
    ):
        raise Stage3RegistryError("Stage3 registry extension content differs")
    if thinking_plan is not None and (
        extension.get("thinking_quota_plan_sha256")
        != sha256_file(receipt_path.parent / THINKING_PLAN_FILENAME)
        or extension.get("thinking_quota_probe_sha256")
        != sha256_file(receipt_path.parent / THINKING_PROBE_FILENAME)
        or extension.get("thinking_quota_branch") != thinking_plan["quota_branch"]
        or extension.get("thinking_metadata_overrides")
        != _thinking_metadata_overrides(thinking_plan)
    ):
        raise Stage3RegistryError("Stage3 thinking registry extension differs")
    expected_extension_sha = canonical_sha256(
        {key: value for key, value in extension.items() if key != "extension_sha256"}
    )
    if extension.get("extension_sha256") != expected_extension_sha:
        raise Stage3RegistryError("Stage3 registry extension self hash differs")
    expected_receipt_keys = {
        "contract_version",
        "status",
        "base_registry_sha256",
        "extension_sha256",
        "effective_registry_sha256",
        "composite_registry_sha256",
        "audit",
        "receipt_sha256",
    }
    if thinking_plan is not None:
        expected_receipt_keys |= {
            "thinking_quota_plan_sha256",
            "thinking_quota_probe_sha256",
            "thinking_quota_branch",
        }
    if set(receipt) != expected_receipt_keys:
        raise Stage3RegistryError("Stage3 registry rebind receipt key set differs")
    effective_sha = sha256_file(effective_registry_path)
    composite = canonical_sha256(
        {
            "base_registry_sha256": BASE_REGISTRY_SHA256,
            "extension_sha256": expected_extension_sha,
            "effective_registry_sha256": effective_sha,
        }
    )
    if (
        receipt.get("contract_version")
        != (
            "p1-v2-stage3-registry-rebind-receipt/2"
            if thinking_plan is not None
            else "p1-v2-stage3-registry-rebind-receipt/1"
        )
        or receipt.get("status") != "PASS"
        or receipt.get("base_registry_sha256") != BASE_REGISTRY_SHA256
        or receipt.get("extension_sha256") != expected_extension_sha
        or receipt.get("effective_registry_sha256") != effective_sha
        or receipt.get("composite_registry_sha256") != composite
        or receipt.get("audit") != audit
    ):
        raise Stage3RegistryError("Stage3 registry rebind receipt content differs")
    if thinking_plan is not None and (
        receipt.get("thinking_quota_plan_sha256")
        != extension["thinking_quota_plan_sha256"]
        or receipt.get("thinking_quota_probe_sha256")
        != extension["thinking_quota_probe_sha256"]
        or receipt.get("thinking_quota_branch") != thinking_plan["quota_branch"]
    ):
        raise Stage3RegistryError("Stage3 thinking registry receipt differs")
    expected_receipt_sha = canonical_sha256(
        {key: value for key, value in receipt.items() if key != "receipt_sha256"}
    )
    if receipt.get("receipt_sha256") != expected_receipt_sha:
        raise Stage3RegistryError("Stage3 registry rebind receipt self hash differs")
    return receipt


def build(
    base_registry_path: Path,
    output_dir: Path,
    *,
    thinking_quota_plan_path: Path | None = None,
    require_fresh_thinking_probe: bool = True,
) -> dict[str, Any]:
    if sha256_file(base_registry_path) != BASE_REGISTRY_SHA256:
        raise Stage3RegistryError("canonical base registry hash differs")
    if output_dir.exists() and any(output_dir.iterdir()):
        raise Stage3RegistryError(f"output directory is not empty: {output_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)
    base = read_json(base_registry_path)
    thinking_plan = None
    if thinking_quota_plan_path is not None:
        thinking_quota_plan_path = thinking_quota_plan_path.resolve()
        thinking_plan = read_json(thinking_quota_plan_path)
        thinking_quota.validate_plan(
            thinking_plan,
            plan_path=thinking_quota_plan_path,
            require_fresh=require_fresh_thinking_probe,
        )
        probe_source = thinking_quota._probe_path(  # noqa: SLF001
            thinking_quota_plan_path,
            thinking_plan["quota_probe"],
        )
        shutil.copy2(thinking_quota_plan_path, output_dir / THINKING_PLAN_FILENAME)
        shutil.copy2(probe_source, output_dir / THINKING_PROBE_FILENAME)
    effective = build_effective_registry(base, thinking_plan)
    effective_path = output_dir / "stage3_task_registry.json"
    extension_path = output_dir / "stage3_registry_extension.json"
    receipt_path = output_dir / "stage3_registry_rebind_receipt.json"
    atomic_json(effective_path, effective)
    extension = {
        "contract_version": (
            "p1-v2-stage3-registry-extension/2"
            if thinking_plan is not None
            else "p1-v2-stage3-registry-extension/1"
        ),
        "status": "LOCKED",
        "base_registry_sha256": BASE_REGISTRY_SHA256,
        "allowed_mutation": _allowed_mutation(thinking_plan),
        "dependency_additions": [
            {"task_id": task_id, "append_dependency": dependency}
            for task_id, dependency in _dependency_additions(thinking_plan)
        ],
    }
    if thinking_plan is not None:
        extension.update(
            {
                "thinking_quota_plan_sha256": sha256_file(
                    output_dir / THINKING_PLAN_FILENAME
                ),
                "thinking_quota_probe_sha256": sha256_file(
                    output_dir / THINKING_PROBE_FILENAME
                ),
                "thinking_quota_branch": thinking_plan["quota_branch"],
                "thinking_metadata_overrides": _thinking_metadata_overrides(
                    thinking_plan
                ),
            }
        )
    extension["extension_sha256"] = canonical_sha256(extension)
    atomic_json(extension_path, extension)
    audit = validate_effective_registry(
        base,
        effective,
        thinking_plan=thinking_plan,
    )
    effective_sha = sha256_file(effective_path)
    receipt = {
        "contract_version": (
            "p1-v2-stage3-registry-rebind-receipt/2"
            if thinking_plan is not None
            else "p1-v2-stage3-registry-rebind-receipt/1"
        ),
        "status": "PASS",
        "base_registry_sha256": BASE_REGISTRY_SHA256,
        "extension_sha256": extension["extension_sha256"],
        "effective_registry_sha256": effective_sha,
        "composite_registry_sha256": canonical_sha256(
            {
                "base_registry_sha256": BASE_REGISTRY_SHA256,
                "extension_sha256": extension["extension_sha256"],
                "effective_registry_sha256": effective_sha,
            }
        ),
        "audit": audit,
    }
    if thinking_plan is not None:
        receipt.update(
            {
                "thinking_quota_plan_sha256": extension[
                    "thinking_quota_plan_sha256"
                ],
                "thinking_quota_probe_sha256": extension[
                    "thinking_quota_probe_sha256"
                ],
                "thinking_quota_branch": thinking_plan["quota_branch"],
            }
        )
    receipt["receipt_sha256"] = canonical_sha256(receipt)
    atomic_json(receipt_path, receipt)
    return validate_rebind_bundle(
        base_registry_path=base_registry_path,
        effective_registry_path=effective_path,
        extension_path=extension_path,
        receipt_path=receipt_path,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build the immutable EMT P1 v2 Stage3 effective registry")
    parser.add_argument(
        "--base-registry",
        type=Path,
        default=ROOT / "qa_v2/task_registry.json",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--thinking-quota-plan", type=Path)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    receipt = build(
        args.base_registry,
        args.output_dir,
        thinking_quota_plan_path=args.thinking_quota_plan,
    )
    print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
