from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.metadata
import json
import platform
import sys
import time
from pathlib import Path, PurePosixPath
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if __name__ == "__main__":
    sys.modules.setdefault("scripts.run_stage3a_v2_task", sys.modules[__name__])
OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
MODELS = ("frozen_embedding", "bert_finetuned", "mlp_plr", "ft_transformer")
FOLDS = (0, 1, 2, 3, 4)
HPO_MODELS = {"mlp_plr", "ft_transformer"}
TEXT_DERIVED_FEATURES = {
    "is_text_missing",
    "text_source_count",
    "text_char_count",
    "nlp_frozen_embedding",
    "nlp_bert_finetuned",
}
BGE_MODEL = "BAAI/bge-m3"
BGE_DIMENSION = 1024
BERT_MAX_EPOCHS = 3
BOOTSTRAP_REPLICATES = 2000
FT_MAX_FEATURES = 128
TABULAR_TRAINING_EPOCHS = 5
OPTUNA_PRUNER = {
    "name": "MedianPruner",
    "n_startup_trials": 10,
    "n_warmup_steps": 1,
    "interval_steps": 1,
}
HPO_CONTEXTS = tuple([f"outer_{fold}" for fold in FOLDS] + ["final"])
FORMAL_REBIND_KEYS = {
    "contract_version",
    "status",
    "formal_training_authorized",
    "task_id",
    "runner_contract_sha256",
    "prelaunch_manifest_sha256",
    "task_registry_sha256",
    "registry_task_sha256",
    "runner_sha256",
    "registry_metadata",
    "accepted_dependency_artifacts",
    "accepted_root_anchor",
    "shared_embedding_artifact",
    "input_artifacts",
    "maximum_year",
    "2025_access_count",
    "strict_no_arrival_leakage",
    "seed",
    "authorization_sha256",
}
REQUIRED_ARTIFACTS = {
    "predictions.parquet",
    "metrics.parquet",
    "coverage.parquet",
    "spec.json",
    "hashes.json",
    "task_manifest.json",
    "_SUCCESS.json",
    "canary_inputs.parquet",
    "canary_expected.parquet",
    "sealed_model_manifest.json",
    "checkpoint_manifest.json",
}
PREDICTION_COLUMNS = (
    "task_id",
    "row_hash",
    "outcome",
    "model",
    "split",
    "fold",
    "y_true",
    "prediction",
)
METRIC_COLUMNS = (
    "task_id",
    "outcome",
    "model",
    "split",
    "metric",
    "value",
    "status",
    "n",
    "events",
    "lower_ci",
    "upper_ci",
)
COVERAGE_COLUMNS = ("row_hash", "outcome", "model", "split", "eligible")
MODEL_FILE_NAMES = tuple([f"models/fold_{fold}.bin" for fold in FOLDS] + ["models/final.bin"])
NO_TEXT_MODEL_FILE_NAMES = tuple(
    [f"models/no_text_fold_{fold}.bin" for fold in FOLDS]
    + ["models/no_text_final.bin"]
)
SEARCH_SPACES = {
    "mlp_plr": {
        "lr": {"distribution": "log_float", "low": 1e-5, "high": 1e-2},
        "weight_decay": {"distribution": "log_float", "low": 1e-7, "high": 1e-2},
        "plr_bins": {"distribution": "categorical", "choices": [8, 16, 32, 48, 64]},
        "d_main": {"distribution": "int", "low": 64, "high": 512, "step": 64},
        "dropout": {"distribution": "float", "low": 0.0, "high": 0.5},
    },
    "ft_transformer": {
        "n_blocks": {"distribution": "int", "low": 1, "high": 4},
        "d_token": {"distribution": "categorical", "choices": [64, 128, 192, 256]},
        "n_heads": {"distribution": "categorical", "choices": [4, 8]},
        "attention_dropout": {"distribution": "float", "low": 0.0, "high": 0.4},
    },
}


class Stage3aContractError(RuntimeError):
    pass


class SyntheticProbabilityModel:
    def __init__(
        self,
        feature_order: list[str],
        coefficients: np.ndarray,
        intercept: float,
    ):
        self.feature_order = list(feature_order)
        self.coefficients = np.asarray(coefficients, dtype="float64")
        self.intercept = float(intercept)

    def predict_proba(self, values: pd.DataFrame | np.ndarray) -> np.ndarray:
        if isinstance(values, pd.DataFrame):
            matrix = values.loc[:, self.feature_order].to_numpy(dtype="float64")
        else:
            matrix = np.asarray(values, dtype="float64")
        score = np.clip(matrix @ self.coefficients + self.intercept, -30, 30)
        probability = 1.0 / (1.0 + np.exp(-score))
        return np.column_stack([1.0 - probability, probability])


class TorchTabularModelBundle:
    def __init__(
        self,
        *,
        family: str,
        feature_order: list[str],
        preprocessor: dict[str, Any],
        model_config: dict[str, Any],
        state_dict: dict[str, Any],
    ):
        self.family = family
        self.feature_order = list(feature_order)
        self.preprocessor = preprocessor
        self.model_config = dict(model_config)
        self.state_dict = state_dict

    def _transform(self, values: pd.DataFrame) -> np.ndarray:
        matrix = self.preprocessor["imputer"].transform(values.loc[:, self.feature_order])
        if self.family == "mlp_plr":
            matrix = self.preprocessor["plr_encoder"].transform(matrix)
        return self.preprocessor["scaler"].transform(matrix).astype("float32")

    def predict_proba(self, values: pd.DataFrame) -> np.ndarray:
        from scripts import run_stage3a as legacy

        import torch

        matrix = self._transform(values)
        if self.family == "mlp_plr":
            model = legacy.MLPPLR(
                matrix.shape[1],
                hidden=int(self.model_config["d_main"]),
                dropout=float(self.model_config["dropout"]),
            )
        else:
            model = legacy.TinyFTTransformer(
                matrix.shape[1],
                d_token=int(self.model_config["d_token"]),
                n_heads=int(self.model_config["n_heads"]),
                n_layers=int(self.model_config["n_blocks"]),
                dropout=float(self.model_config["attention_dropout"]),
            )
        model.load_state_dict(self.state_dict)
        model.eval()
        outputs = []
        with torch.no_grad():
            for start in range(0, len(matrix), 512):
                logits = model(torch.from_numpy(matrix[start : start + 512]))
                outputs.append(torch.sigmoid(logits).numpy())
        probability = np.concatenate(outputs).astype("float64")
        return np.column_stack([1.0 - probability, probability])


class BertModelBundle:
    def __init__(
        self,
        *,
        tokenizer: Any,
        config: dict[str, Any],
        state_dict: dict[str, Any],
        max_length: int,
        batch_size: int,
    ):
        self.tokenizer = tokenizer
        self.config = copy.deepcopy(config)
        self.state_dict = state_dict
        self.max_length = int(max_length)
        self.batch_size = int(batch_size)
        self.feature_order = ["emt_text_sanitized", "is_text_missing"]

    def predict_proba(self, values: pd.DataFrame) -> np.ndarray:
        import torch

        model = build_bert_missing_flag_model(config=self.config)
        model.load_state_dict(self.state_dict)
        model.eval()
        texts = values["emt_text_sanitized"].fillna("").astype(str).tolist()
        missing = pd.to_numeric(
            values["is_text_missing"], errors="raise"
        ).to_numpy(dtype="float32")
        outputs = []
        with torch.no_grad():
            for start in range(0, len(texts), self.batch_size):
                encoded = self.tokenizer(
                    texts[start : start + self.batch_size],
                    padding=True,
                    truncation=True,
                    max_length=self.max_length,
                    return_tensors="pt",
                )
                flag = torch.from_numpy(missing[start : start + self.batch_size])
                logits = model(
                    encoded["input_ids"], encoded["attention_mask"], flag
                )
                outputs.append(torch.sigmoid(logits).numpy())
        probability = np.concatenate(outputs).astype("float64")
        return np.column_stack([1.0 - probability, probability])


for _persisted_model_class in (
    SyntheticProbabilityModel,
    TorchTabularModelBundle,
    BertModelBundle,
):
    _persisted_model_class.__module__ = "scripts.run_stage3a_v2_task"


def build_bert_missing_flag_model(
    *,
    model_name: str | None = None,
    config: dict[str, Any] | None = None,
) -> Any:
    import torch
    from transformers import AutoConfig, AutoModel

    class BertMissingFlagClassifier(torch.nn.Module):
        def __init__(self) -> None:
            super().__init__()
            if config is None:
                if model_name is None:
                    raise Stage3aContractError("BERT model name/config is missing")
                self.encoder = AutoModel.from_pretrained(model_name)
            else:
                config_value = dict(config)
                model_type = str(config_value.pop("model_type"))
                self.encoder = AutoModel.from_config(
                    AutoConfig.for_model(model_type, **config_value)
                )
            hidden = int(self.encoder.config.hidden_size)
            self.dropout = torch.nn.Dropout(0.1)
            self.head = torch.nn.Linear(hidden + 1, 1)

        def forward(
            self,
            input_ids: Any,
            attention_mask: Any,
            is_text_missing: Any,
        ) -> Any:
            output = self.encoder(
                input_ids=input_ids, attention_mask=attention_mask
            )
            pooled = output.last_hidden_state[:, 0]
            combined = torch.cat(
                [pooled, is_text_missing.float().reshape(-1, 1)], dim=1
            )
            return self.head(self.dropout(combined)).squeeze(-1)

    return BertMissingFlagClassifier()


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_sha256(value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def atomic_parquet(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp.parquet")
    frame.to_parquet(temporary, index=False)
    temporary.replace(path)


def atomic_joblib(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    joblib.dump(value, temporary)
    temporary.replace(path)


def _registry_task(registry: dict[str, Any], task_id: str) -> dict[str, Any]:
    matches = [task for task in registry.get("tasks", []) if task.get("task_id") == task_id]
    if len(matches) != 1:
        raise Stage3aContractError(f"task registry match count for {task_id}: {len(matches)}")
    return matches[0]


def _artifact_names(task: dict[str, Any]) -> set[str]:
    return {
        Path(str(artifact["path"])).name
        for artifact in task.get("required_artifacts", [])
        if artifact.get("required") is True
    }


def _validate_contract_digest(contract: dict[str, Any]) -> None:
    expected = str(contract.get("contract_sha256", ""))
    actual = canonical_sha256(
        {key: value for key, value in contract.items() if key != "contract_sha256"}
    )
    if expected.casefold() != actual.casefold():
        raise Stage3aContractError("runner contract digest mismatch")


def _family_plan(model: str, registry_task: dict[str, Any]) -> dict[str, Any]:
    if model == "frozen_embedding":
        return {
            "execution_phase": "W03A",
            "backend": "live_bge_m3_embedding_plus_fold_local_pca_classifier",
            "text_model": BGE_MODEL,
            "embedding_fit": "weights_frozen",
            "embedding_dimension": BGE_DIMENSION,
            "embedding_generation": "shared_immutable_artifact_from_hash_bound_stage1a_text",
            "pca_fit_scope": "each outer training fold and final 2020_2023 fit only",
            "pca_components": {"minimum": 32, "maximum": 128},
            "missing_text": "zero_vector_plus_is_text_missing",
            "shared_embedding_binding_required": True,
        }
    if model == "bert_finetuned":
        return {
            "execution_phase": "W03A",
            "backend": "chinese_roberta_binary_finetune",
            "text_model": registry_task["metadata"]["bert_model"],
            "checkpoint_selection_metric": "AUPRC",
            "checkpoint_selection_scope": "group_disjoint_inner_validation_inside_each_outer_training_set",
            "final_selection_scope": "group_disjoint_inner_validation_inside_all_2020_2023_development",
            "missing_text": "fixed_no_text_representation_plus_explicit_model_input_flag",
            "local_snapshot_required": True,
            "network_required_for_reload": False,
            "validation_2024_used_for_checkpoint_selection": False,
        }
    if model == "mlp_plr":
        return {
            "execution_phase": "W03B",
            "backend": "run_stage3a.MLPPLR_with_formal_per_task_adapter",
            "structured_preprocessing": "fold_local_imputation_plus_missing_indicators",
            "nlp_inputs": ["accepted frozen_embedding OOF/final", "accepted bert_finetuned OOF/final"],
            "search_space": SEARCH_SPACES[model],
        }
    return {
        "execution_phase": "W03B",
        "backend": "run_stage3a.TinyFTTransformer_with_formal_per_task_adapter",
        "structured_preprocessing": "fold_local_imputation_plus_missing_indicators",
        "nlp_inputs": ["accepted frozen_embedding OOF/final", "accepted bert_finetuned OOF/final"],
        "feature_selection": {
            "method": "fold_local_training_only_standardized_mean_difference",
            "maximum_features": FT_MAX_FEATURES,
            "held_out_outer_fold_used": False,
            "validation_2024_used": False,
            "explicit_artifact_required": True,
        },
        "search_space": SEARCH_SPACES[model],
    }


def build_runner_contract(
    prelaunch_manifest: dict[str, Any],
    registry: dict[str, Any],
    *,
    prelaunch_manifest_sha256: str | None = None,
    registry_sha256: str | None = None,
) -> dict[str, Any]:
    task_id = str(prelaunch_manifest.get("task_id", ""))
    registry_task = _registry_task(registry, task_id)
    outcome = str(prelaunch_manifest.get("outcome", ""))
    model = str(prelaunch_manifest.get("model", ""))
    expected_task_id = f"P1_05a-{outcome}-{model}"
    if outcome not in OUTCOMES or model not in MODELS or task_id != expected_task_id:
        raise Stage3aContractError(f"invalid Stage3a task identity: {task_id}")
    common = {
        "stage": "P1_05a",
        "wave": "W03",
        "task_family": "stage3a_model",
        "outcome": outcome,
        "model": model,
        "compute_target": "kaggle_gpu",
    }
    for key, expected in common.items():
        if prelaunch_manifest.get(key) != expected or registry_task.get(key) != expected:
            raise Stage3aContractError(f"{task_id} {key} mismatch")
    if prelaunch_manifest.get("formal_training_authorized") is not False:
        raise Stage3aContractError("preparation manifest must keep formal authorization false")
    if prelaunch_manifest.get("formal_training_launched") is not False:
        raise Stage3aContractError("preparation manifest must keep launch false")
    if prelaunch_manifest.get("maximum_year") != 2024 or prelaunch_manifest.get("2025_access_count") != 0:
        raise Stage3aContractError("Stage3a preparation must be limited to <=2024")
    if prelaunch_manifest.get("strict_no_arrival_leakage") is not True:
        raise Stage3aContractError("strict no-arrival contract is missing")
    if prelaunch_manifest.get("dependencies") != registry_task.get("dependencies"):
        raise Stage3aContractError(f"{task_id} dependency order/content drift")
    if prelaunch_manifest.get("required_artifacts") != registry_task.get("required_artifacts"):
        raise Stage3aContractError(f"{task_id} required artifact drift")
    if _artifact_names(registry_task) != REQUIRED_ARTIFACTS:
        raise Stage3aContractError(f"{task_id} required artifact set is incomplete")
    metadata = registry_task.get("metadata", {})
    if metadata.get("cv_folds") != 5:
        raise Stage3aContractError(f"{task_id} must declare five OOF folds")
    expected_trials = 50 if model in HPO_MODELS else 0
    if metadata.get("optuna_trials") != expected_trials:
        raise Stage3aContractError(f"{task_id} Optuna trial declaration mismatch")
    expected_phase = "W03B" if model in HPO_MODELS else "W03A"
    if metadata.get("execution_phase") != expected_phase:
        raise Stage3aContractError(f"{task_id} execution phase mismatch")
    if registry_sha256 is not None:
        locked_registry_sha = str(prelaunch_manifest.get("source_hashes", {}).get("task_registry", ""))
        if locked_registry_sha.casefold() != registry_sha256.casefold():
            raise Stage3aContractError(f"{task_id} registry hash mismatch")
    input_paths = [str(value.get("path", "")) for value in prelaunch_manifest.get("input_artifacts", [])]
    if not input_paths or any("2025" in value.casefold() for value in input_paths):
        raise Stage3aContractError(f"{task_id} has missing/future preparation inputs")
    text_inputs = [value for value in input_paths if "text" in Path(value).name.casefold()]
    if (model in {"frozen_embedding", "bert_finetuned"}) != bool(text_inputs):
        raise Stage3aContractError(f"{task_id} text input contract mismatch")
    dependency_tasks = list(registry_task["dependencies"])
    stage3a_dependencies = [value for value in dependency_tasks if value.startswith("P1_05a-")]
    expected_stage3a_dependencies = (
        [f"P1_05a-{outcome}-frozen_embedding", f"P1_05a-{outcome}-bert_finetuned"]
        if model in HPO_MODELS
        else []
    )
    if stage3a_dependencies != expected_stage3a_dependencies:
        raise Stage3aContractError(f"{task_id} within-stage dependency mismatch")
    hpo = {
        "enabled": model in HPO_MODELS,
        "engine": "Optuna",
        "study_scope": "one_group_disjoint_training_only_study_per_outer_fold_plus_final",
        "target_trials": expected_trials,
        "trials_per_selection_context": expected_trials,
        "selection_contexts": list(HPO_CONTEXTS) if model in HPO_MODELS else [],
        "target_trials_total": expected_trials * len(HPO_CONTEXTS),
        "attempted_trials_required_for_formal_seal": expected_trials,
        "minimum_complete_trials": 1 if model in HPO_MODELS else 0,
        "accepted_trial_states": ["COMPLETE", "PRUNED"] if model in HPO_MODELS else [],
        "pruner": OPTUNA_PRUNER if model in HPO_MODELS else None,
        "training_epochs_per_trial_and_final": TABULAR_TRAINING_EPOCHS if model in HPO_MODELS else None,
        "storage": "optuna_{selection_context}.sqlite3" if model in HPO_MODELS else None,
        "trial_table": "optuna_trials.parquet" if model in HPO_MODELS else None,
        "objective": "training_only_group_disjoint_inner_validation_AUPRC" if model in HPO_MODELS else None,
        "outer_oof_selection": "each outer fold uses its own 50-trial study that cannot read that outer fold",
        "final_selection": "separate 50-trial group-disjoint study using only 2020_2023 development",
        "validation_2024_used_for_hpo": False,
        "resume_policy": "same_task_same_owner_checkpoint_resume",
        "search_space": SEARCH_SPACES.get(model),
    }
    contract = {
        "contract_version": "p1-v2-stage3a-per-task-runner/1",
        "status": "PREPARED_NOT_AUTHORIZED",
        "task_id": task_id,
        **common,
        "scientific_artifact": True,
        "formal_training_authorized": False,
        "formal_training_launched": False,
        "historical_2025_exposure": True,
        "maximum_year": 2024,
        "2025_access_count": 0,
        "strict_no_arrival_leakage": True,
        "prelaunch_manifest_sha256": prelaunch_manifest_sha256,
        "task_registry_sha256": registry_sha256,
        "source_hashes": dict(prelaunch_manifest.get("source_hashes", {})),
        "input_artifacts": list(prelaunch_manifest.get("input_artifacts", [])),
        "dependency_gate": {
            "status": "UNSATISFIED_AT_PREPARATION",
            "all_required": dependency_tasks,
            "accepted_p1_04_required": [value for value in dependency_tasks if value.startswith("P1_04-")],
            "accepted_w03a_required": stage3a_dependencies,
            "binding_rule": "accepted scientific artifacts with exact manifest/model/spec hashes",
        },
        "execution": {
            "fixed_outer_folds": list(FOLDS),
            "oof_split": "oof_2020_2023",
            "oof_rows_must_appear_once": True,
            "outer_fold_fit_rule": "fit only the other four fixed group folds",
            "final_fit_years": [2020, 2021, 2022, 2023],
            "final_prediction_split": "validation_2024",
            "final_model_required": True,
            "validation_2024_used_for_fit_or_selection": False,
            "test_2025_access_allowed": False,
            "seed_source": "formal execution overlay locked seed",
        },
        "family_plan": _family_plan(model, registry_task),
        "hpo": hpo,
        "checkpoint": {
            "manifest": "checkpoint_manifest.json",
            "fold_models": [f"models/fold_{fold}.bin" for fold in FOLDS],
            "final_model": "models/final.bin",
            "no_text_fold_models": (
                [f"models/no_text_fold_{fold}.bin" for fold in FOLDS]
                if model in HPO_MODELS
                else []
            ),
            "no_text_final_model": (
                "models/no_text_final.bin" if model in HPO_MODELS else None
            ),
            "optuna_storage": (
                "optuna_{selection_context}.sqlite3"
                if model in HPO_MODELS
                else None
            ),
            "ft_feature_selection_artifacts": (
                [
                    "checkpoints/ft_feature_selection_{selection_context}.json",
                    "checkpoints/no_text_ft_feature_selection_{selection_context}.json",
                ]
                if model == "ft_transformer"
                else []
            ),
            "atomic_updates": True,
            "resume_must_match_contract_sha256": True,
        },
        "sealed_outputs": {
            "required_artifacts": sorted(REQUIRED_ARTIFACTS),
            "strict_prediction_columns": list(PREDICTION_COLUMNS),
            "strict_metric_columns": list(METRIC_COLUMNS),
            "strict_coverage_columns": list(COVERAGE_COLUMNS),
            "canary_rows_formal": 100,
            "canary_max_abs_error": 1e-5,
            "artifact_hash_inventory_required": True,
        },
        "legacy_code_reuse": {
            "source": "scripts/run_stage3a.py",
            "reused_components": (
                ["MLPPLR", "train_torch_binary"]
                if model == "mlp_plr"
                else ["TinyFTTransformer", "train_torch_binary"]
                if model == "ft_transformer"
                else ["BertBinaryClassifier", "train_bert_binary", "bert_predict"]
                if model == "bert_finetuned"
                else ["tokenize_texts", "embedding batch inference"]
            ),
            "legacy_global_runner_reused": False,
            "reason": "legacy runner is multi-outcome and does not implement the frozen five-fold per-task artifact contract",
        },
    }
    contract["contract_sha256"] = canonical_sha256(contract)
    return contract


def load_runner_contract(task_manifest_path: Path, registry_path: Path) -> dict[str, Any]:
    return build_runner_contract(
        read_json(task_manifest_path),
        read_json(registry_path),
        prelaunch_manifest_sha256=sha256_file(task_manifest_path),
        registry_sha256=sha256_file(registry_path),
    )


def validate_stage3_registry_rebind(
    registry_path: Path, receipt_path: Path
) -> dict[str, Any]:
    from scripts import build_p1_v2_stage3_effective_registry as stage3_registry

    receipt_path = receipt_path.resolve()
    directory = receipt_path.parent
    expected_receipt = directory / "stage3_registry_rebind_receipt.json"
    effective_registry = directory / "task_registry.json"
    base_registry = directory / "base_task_registry.json"
    extension = directory / "stage3_registry_extension.json"
    if receipt_path != expected_receipt or registry_path.resolve() != effective_registry:
        raise Stage3aContractError(
            "formal Stage3 registry paths differ from the frozen package layout"
        )
    try:
        receipt = stage3_registry.validate_rebind_bundle(
            base_registry_path=base_registry,
            effective_registry_path=effective_registry,
            extension_path=extension,
            receipt_path=receipt_path,
        )
    except (OSError, ValueError, stage3_registry.Stage3RegistryError) as error:
        raise Stage3aContractError(
            f"formal Stage3 registry rebind validation failed: {error}"
        ) from error
    return {
        **receipt,
        "base_registry_file_sha256": sha256_file(base_registry),
        "effective_registry_file_sha256": sha256_file(effective_registry),
        "extension_file_sha256": sha256_file(extension),
        "receipt_file_sha256": sha256_file(receipt_path),
    }


def _formal_input_roles(model: str) -> set[str]:
    roles = {"stage1a_features", "stage1a_manifest", "stage1a_schema", "fold_map"}
    if model in {"frozen_embedding", "bert_finetuned"}:
        roles.add("stage1a_text")
    else:
        roles.update({"frozen_embedding_predictions", "bert_finetuned_predictions"})
    return roles


def _sha256_value(value: Any, label: str) -> str:
    text = str(value)
    if len(text) != 64 or any(character not in "0123456789abcdefABCDEF" for character in text):
        raise Stage3aContractError(f"{label} must be a SHA256 value")
    return text.casefold()


def _resolved_bound_file(binding: dict[str, Any], label: str) -> Path:
    if not isinstance(binding, dict) or set(binding) != {"path", "sha256"}:
        raise Stage3aContractError(f"{label} binding schema differs")
    path = Path(str(binding.get("path", ""))).resolve()
    if not path.is_file():
        raise Stage3aContractError(f"{label} is missing")
    if _sha256_value(binding.get("sha256"), f"{label} hash") != sha256_file(path):
        raise Stage3aContractError(f"{label} hash mismatch")
    return path


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
    except ValueError:
        return False
    return True


def _arrival_feature_hits(values: list[str]) -> list[str]:
    from scripts.run_stage2a_v2 import forbidden_arrival_columns

    return forbidden_arrival_columns([str(value) for value in values])


def _json_feature_names(value: Any, *, parent_key: str = "") -> list[str]:
    names: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            names.extend(_json_feature_names(child, parent_key=str(key)))
    elif isinstance(value, list):
        if "feature" in parent_key.casefold() or "column" in parent_key.casefold():
            names.extend(str(child) for child in value if isinstance(child, str))
        else:
            for child in value:
                names.extend(_json_feature_names(child, parent_key=parent_key))
    elif isinstance(value, str) and (
        "feature" in parent_key.casefold() or "column" in parent_key.casefold()
    ):
        names.append(value)
    return names


def _dependency_artifact_paths(
    manifest_path: Path,
    manifest: dict[str, Any],
    accepted_root: Path,
    *,
    task_id: str,
) -> dict[str, list[Path]]:
    artifact_bindings = manifest.get("artifact_bindings")
    model_bindings = manifest.get("model_artifact_bindings")
    if not isinstance(artifact_bindings, dict) or not isinstance(model_bindings, dict):
        raise Stage3aContractError(
            f"accepted dependency lacks normalized artifact bindings: {task_id}"
        )
    status = manifest.get("status")
    if status == "PASS" and (
        not {"predictions.parquet", "metrics.parquet", "spec.json"}
        <= set(artifact_bindings)
        or not model_bindings
    ):
        raise Stage3aContractError(
            f"accepted PASS dependency lacks prediction/metrics/spec/model bindings: {task_id}"
        )
    if status == "NOT_ESTIMABLE" and (
        "terminal_evidence" not in artifact_bindings or model_bindings
    ):
        raise Stage3aContractError(
            f"NOT_ESTIMABLE dependency terminal/model bindings differ: {task_id}"
        )
    categories: dict[str, list[Path]] = {
        "prediction": [],
        "model": [],
        "spec": [],
    }
    for logical_name, binding in {**artifact_bindings, **model_bindings}.items():
        if not isinstance(binding, dict) or set(binding) != {"path", "sha256"}:
            raise Stage3aContractError(
                f"accepted dependency artifact binding schema differs: {task_id}/{logical_name}"
            )
        artifact = Path(str(binding.get("path", ""))).resolve()
        if not _inside(artifact, accepted_root) or not artifact.is_file():
            raise Stage3aContractError(
                f"accepted dependency artifact is missing/outside root: {task_id}/{logical_name}"
            )
        if (
            _sha256_value(binding.get("sha256"), f"{task_id}/{logical_name} hash")
            != sha256_file(artifact)
        ):
            raise Stage3aContractError(
                f"accepted dependency artifact hash mismatch: {task_id}/{logical_name}"
            )
        if logical_name == "predictions.parquet":
            category = "prediction"
        elif logical_name == "spec.json":
            category = "spec"
        elif logical_name in model_bindings:
            category = "model"
        else:
            continue
        categories[category].append(artifact)
    for prediction in categories["prediction"]:
        import pyarrow.parquet as pq

        columns = [str(name) for name in pq.ParquetFile(prediction).schema.names]
        arrival_hits = _arrival_feature_hits(columns)
        if arrival_hits:
            raise Stage3aContractError(
                f"accepted dependency prediction has arrival columns: {task_id}/{arrival_hits[:10]}"
            )
        if "split_year" in columns:
            years = pd.read_parquet(prediction, columns=["split_year"])["split_year"]
            years = pd.to_numeric(years, errors="coerce")
            if years.isna().any() or (years > 2024).any():
                raise Stage3aContractError(
                    f"accepted dependency prediction exceeds 2024: {task_id}"
                )
    for spec_path in categories["spec"]:
        spec = read_json(spec_path)
        if spec.get("2025_access_count") != 0:
            raise Stage3aContractError(
                f"accepted dependency spec violates temporal/leakage contract: {task_id}"
            )
        arrival_hits = _arrival_feature_hits(_json_feature_names(spec))
        if arrival_hits:
            raise Stage3aContractError(
                f"accepted dependency spec has arrival features: {task_id}/{arrival_hits[:10]}"
            )
    return categories


def _validate_accepted_dependencies(
    base_contract: dict[str, Any],
    rebind: dict[str, Any],
) -> dict[str, dict[str, Any]]:
    dependencies = rebind.get("accepted_dependency_artifacts")
    expected_tasks = list(base_contract["dependency_gate"]["all_required"])
    if (
        not isinstance(dependencies, dict)
        or set(dependencies) != set(expected_tasks)
        or len(dependencies) != len(expected_tasks)
    ):
        raise Stage3aContractError("formal rebind dependency task order/content differs")
    anchor_path = _resolved_bound_file(
        rebind.get("accepted_root_anchor"), "accepted-root anchor"
    )
    anchor = read_json(anchor_path)
    anchor_keys = {
        "contract_version",
        "status",
        "accepted_root",
        "dependency_receipts",
        "anchor_sha256",
    }
    if frozenset(anchor) not in {
        frozenset(anchor_keys),
        frozenset(anchor_keys | {"adapter_root"}),
    }:
        raise Stage3aContractError("accepted-root anchor schema differs")
    if (
        anchor.get("contract_version") != "p1-v2-stage3a-accepted-root-anchor/1"
        or anchor.get("status") != "LOCKED"
        or _sha256_value(anchor.get("anchor_sha256"), "accepted-root anchor self hash")
        != canonical_sha256(
            {key: value for key, value in anchor.items() if key != "anchor_sha256"}
        )
    ):
        raise Stage3aContractError("accepted-root anchor contract/self hash differs")
    accepted_root = Path(str(anchor.get("accepted_root", ""))).resolve()
    adapter_root = Path(str(anchor.get("adapter_root", accepted_root))).resolve()
    if (
        not accepted_root.is_dir()
        or not adapter_root.is_dir()
        or not _inside(anchor_path, adapter_root)
    ):
        raise Stage3aContractError(
            "accepted-root anchor is not inside its immutable adapter root"
        )
    anchor_receipts = anchor.get("dependency_receipts")
    if (
        not isinstance(anchor_receipts, dict)
        or set(anchor_receipts) != set(expected_tasks)
        or len(anchor_receipts) != len(expected_tasks)
    ):
        raise Stage3aContractError("accepted-root receipt inventory differs")
    dependency_manifests: dict[str, dict[str, Any]] = {}
    record_keys = {
        "task_id",
        "manifest_path",
        "manifest_sha256",
        "acceptance_receipt_path",
        "acceptance_receipt_sha256",
        "lineage_id",
        "status",
        "scientific_artifact",
        "accepted",
    }
    for task_id, record in dependencies.items():
        if not isinstance(record, dict) or set(record) != record_keys:
            raise Stage3aContractError(f"accepted dependency record schema differs: {task_id}")
        if (
            record.get("task_id") != task_id
            or record.get("accepted") is not True
            or record.get("status") not in {"PASS", "NOT_ESTIMABLE"}
            or not isinstance(record.get("lineage_id"), str)
            or not record.get("lineage_id")
        ):
            raise Stage3aContractError(f"dependency is not accepted: {task_id}")
        manifest_path = Path(str(record.get("manifest_path", ""))).resolve()
        receipt_path = Path(str(record.get("acceptance_receipt_path", ""))).resolve()
        if (
            not _inside(manifest_path, adapter_root)
            or not _inside(receipt_path, adapter_root)
            or not manifest_path.is_file()
            or not receipt_path.is_file()
        ):
            raise Stage3aContractError(
                f"dependency paths are outside accepted adapter root: {task_id}"
            )
        manifest_sha = sha256_file(manifest_path)
        receipt_sha = sha256_file(receipt_path)
        if (
            _sha256_value(record["manifest_sha256"], f"{task_id} manifest hash")
            != manifest_sha
            or _sha256_value(
                record["acceptance_receipt_sha256"], f"{task_id} receipt hash"
            )
            != receipt_sha
        ):
            raise Stage3aContractError(f"dependency manifest/receipt hash mismatch: {task_id}")
        anchor_binding = anchor_receipts.get(task_id)
        if (
            not isinstance(anchor_binding, dict)
            or set(anchor_binding) != {"path", "sha256"}
            or Path(str(anchor_binding.get("path", ""))).resolve() != receipt_path
            or _sha256_value(anchor_binding.get("sha256"), f"{task_id} anchor receipt hash")
            != receipt_sha
        ):
            raise Stage3aContractError(f"accepted-root receipt binding differs: {task_id}")
        receipt = read_json(receipt_path)
        receipt_keys = {
            "contract_version",
            "task_id",
            "status",
            "accepted",
            "scientific_artifact",
            "maximum_year",
            "2025_access_count",
            "strict_no_arrival_leakage",
            "lineage_id",
            "task_manifest_path",
            "task_manifest_sha256",
            "artifact_binding_hashes",
            "model_artifact_binding_hashes",
            "receipt_sha256",
        }
        artifact_binding_hashes = {
            str(name): str(binding.get("sha256", "")).casefold()
            for name, binding in read_json(manifest_path)
            .get("artifact_bindings", {})
            .items()
            if isinstance(binding, dict)
        }
        model_binding_hashes = {
            str(name): str(binding.get("sha256", "")).casefold()
            for name, binding in read_json(manifest_path)
            .get("model_artifact_bindings", {})
            .items()
            if isinstance(binding, dict)
        }
        if (
            set(receipt) != receipt_keys
            or receipt.get("contract_version")
            != "p1-v2-promoted-task-acceptance-receipt/1"
            or _sha256_value(
                receipt.get("receipt_sha256"), f"{task_id} receipt self hash"
            )
            != canonical_sha256(
                {
                    key: value
                    for key, value in receipt.items()
                    if key != "receipt_sha256"
                }
            )
            or receipt.get("task_id") != task_id
            or receipt.get("status") != record["status"]
            or receipt.get("accepted") is not True
            or receipt.get("scientific_artifact") is not record["scientific_artifact"]
            or receipt.get("maximum_year") != 2024
            or receipt.get("2025_access_count") != 0
            or receipt.get("strict_no_arrival_leakage") is not True
            or receipt.get("lineage_id") != record["lineage_id"]
            or Path(str(receipt.get("task_manifest_path", ""))).resolve()
            != manifest_path
            or _sha256_value(
                receipt.get("task_manifest_sha256"), f"{task_id} receipt manifest hash"
            )
            != manifest_sha
            or receipt.get("artifact_binding_hashes") != artifact_binding_hashes
            or receipt.get("model_artifact_binding_hashes") != model_binding_hashes
        ):
            raise Stage3aContractError(f"dependency importer receipt differs: {task_id}")
        manifest = read_json(manifest_path)
        if set(manifest) != {
            "contract_version",
            "task_id",
            "status",
            "scientific_artifact",
            "source_task_manifest",
            "source_success_marker",
            "artifact_bindings",
            "model_artifact_bindings",
            "maximum_year",
            "2025_access_count",
            "strict_no_arrival_leakage",
            "lineage_id",
            "accepted_manifest_sha256",
        }:
            raise Stage3aContractError(
                f"normalized accepted dependency manifest schema differs: {task_id}"
            )
        if (
            manifest.get("contract_version")
            != "p1-v2-promoted-task-acceptance-manifest/1"
            or manifest.get("task_id") != task_id
            or manifest.get("status") != record["status"]
            or manifest.get("scientific_artifact") is not record["scientific_artifact"]
            or manifest.get("maximum_year") != 2024
            or manifest.get("2025_access_count") != 0
            or manifest.get("strict_no_arrival_leakage") is not True
            or manifest.get("lineage_id") != record["lineage_id"]
            or (record["status"] == "PASS" and record["scientific_artifact"] is not True)
            or _sha256_value(
                manifest.get("accepted_manifest_sha256"),
                f"{task_id} normalized manifest self hash",
            )
            != canonical_sha256(
                {
                    key: value
                    for key, value in manifest.items()
                    if key != "accepted_manifest_sha256"
                }
            )
        ):
            raise Stage3aContractError(f"accepted dependency manifest differs: {task_id}")
        for source_name in ("source_task_manifest", "source_success_marker"):
            source_path = _resolved_bound_file(
                manifest[source_name], f"{task_id} {source_name}"
            )
            if not _inside(source_path, accepted_root):
                raise Stage3aContractError(
                    f"accepted dependency source is outside root: {task_id}/{source_name}"
                )
        arrival_hits = _arrival_feature_hits(_json_feature_names(manifest))
        if arrival_hits:
            raise Stage3aContractError(
                f"accepted dependency manifest has arrival features: {task_id}/{arrival_hits[:10]}"
            )
        _dependency_artifact_paths(
            manifest_path, manifest, accepted_root, task_id=task_id
        )
        dependency_manifests[task_id] = manifest
    return dependency_manifests


def _validate_bge_snapshot_manifest(
    binding: dict[str, Any], *, model_revision: str
) -> dict[str, Any]:
    manifest_path = _resolved_bound_file(binding, "BGE snapshot manifest")
    manifest = read_json(manifest_path)
    v1_keys = {
        "contract_version",
        "status",
        "model_id",
        "model_revision",
        "snapshot_root",
        "files",
        "model_weight_files",
        "model_weights_composite_sha256",
        "snapshot_payload_sha256",
    }
    v2_keys = (v1_keys - {"snapshot_root"}) | {
        "scientific_artifact",
        "snapshot_root_relative",
        "privacy_contract",
    }
    version = manifest.get("contract_version")
    if version == "p1-v2-stage3a-bge-snapshot-manifest/1":
        expected_keys = v1_keys
    elif version == "p1-v2-stage3a-bge-snapshot-manifest/2":
        expected_keys = v2_keys
    else:
        raise Stage3aContractError("BGE snapshot manifest contract version differs")
    if set(manifest) != expected_keys:
        raise Stage3aContractError("BGE snapshot manifest schema differs")
    if (
        manifest.get("status") != "LOCKED"
        or manifest.get("model_id") != BGE_MODEL
        or manifest.get("model_revision") != model_revision
        or _sha256_value(
            manifest.get("snapshot_payload_sha256"), "BGE snapshot payload hash"
        )
        != canonical_sha256(
            {
                key: value
                for key, value in manifest.items()
                if key != "snapshot_payload_sha256"
            }
        )
    ):
        raise Stage3aContractError("BGE snapshot manifest contract/self hash differs")
    if version == "p1-v2-stage3a-bge-snapshot-manifest/1":
        snapshot_root = Path(str(manifest.get("snapshot_root", ""))).resolve()
    else:
        privacy = manifest.get("privacy_contract")
        relative_text = str(manifest.get("snapshot_root_relative", ""))
        relative = PurePosixPath(relative_text)
        if (
            manifest.get("scientific_artifact") is not False
            or not isinstance(privacy, dict)
            or privacy
            != {
                "source_class": "PUBLIC_PRETRAINED_MODEL_SNAPSHOT",
                "contains_research_cohort_data": False,
                "contains_patient_data": False,
                "2025_access_count": 0,
                "strict_no_arrival_leakage": True,
            }
            or not relative_text
            or relative.is_absolute()
            or ".." in relative.parts
            or "\\" in relative_text
            or ":" in relative_text
        ):
            raise Stage3aContractError("portable BGE snapshot privacy/path contract differs")
        manifest_parent = manifest_path.parent.resolve()
        snapshot_root = (manifest_parent / Path(*relative.parts)).resolve()
        try:
            snapshot_root.relative_to(manifest_parent)
        except ValueError as exc:
            raise Stage3aContractError(
                "portable BGE snapshot root escapes its dataset"
            ) from exc
    if not snapshot_root.is_dir():
        raise Stage3aContractError("BGE snapshot root is missing")
    files = manifest.get("files")
    weights = manifest.get("model_weight_files")
    if not isinstance(files, dict) or not files or not isinstance(weights, dict) or not weights:
        raise Stage3aContractError("BGE snapshot file inventory is empty")
    actual_files = {
        path.relative_to(snapshot_root).as_posix(): sha256_file(path)
        for path in sorted(snapshot_root.rglob("*"))
        if path.is_file()
    }
    declared_files = {
        str(name): _sha256_value(value, f"BGE snapshot file {name} hash")
        for name, value in files.items()
    }
    declared_weights = {
        str(name): _sha256_value(value, f"BGE model weight {name} hash")
        for name, value in weights.items()
    }
    if actual_files != declared_files:
        raise Stage3aContractError("BGE snapshot files differ from immutable inventory")
    if (
        any(declared_files.get(name) != digest for name, digest in declared_weights.items())
        or any(
            Path(name).suffix.casefold() not in {".bin", ".safetensors"}
            for name in declared_weights
        )
        or _sha256_value(
            manifest.get("model_weights_composite_sha256"),
            "BGE model weights composite hash",
        )
        != canonical_sha256(declared_weights)
    ):
        raise Stage3aContractError("BGE model weight inventory/hash differs")
    return {
        "manifest_path": str(manifest_path),
        "manifest_sha256": sha256_file(manifest_path),
        "snapshot_root": str(snapshot_root),
        "model_revision": model_revision,
        "model_weights_composite_sha256": manifest[
            "model_weights_composite_sha256"
        ],
        "portable": version == "p1-v2-stage3a-bge-snapshot-manifest/2",
    }


def validate_shared_bge_artifact(
    binding: dict[str, Any],
    *,
    stage1a_text_path: Path,
    stage1a_text_sha256: str,
) -> tuple[Path, dict[str, Any]]:
    expected_keys = {
        "contract_version",
        "status",
        "scientific_artifact",
        "model_id",
        "model_revision",
        "model_snapshot_manifest",
        "embedding_artifact",
        "source_text_sha256",
        "row_hash_order_sha256",
        "embedding_dimension",
        "missing_text_zero_vector",
        "missing_flag_included",
        "maximum_year",
        "2025_access_count",
        "strict_no_arrival_leakage",
        "artifact_payload_sha256",
    }
    if not isinstance(binding, dict) or set(binding) != expected_keys:
        raise Stage3aContractError("shared BGE artifact schema differs")
    revision = str(binding.get("model_revision", ""))
    if (
        binding.get("contract_version") != "p1-v2-stage3a-shared-bge-artifact/1"
        or binding.get("status") != "PASS"
        or binding.get("scientific_artifact") is not True
        or binding.get("model_id") != BGE_MODEL
        or len(revision) != 40
        or any(value not in "0123456789abcdefABCDEF" for value in revision)
        or binding.get("embedding_dimension") != BGE_DIMENSION
        or binding.get("missing_text_zero_vector") is not True
        or binding.get("missing_flag_included") is not True
        or binding.get("maximum_year") != 2024
        or binding.get("2025_access_count") != 0
        or binding.get("strict_no_arrival_leakage") is not True
        or _sha256_value(
            binding.get("artifact_payload_sha256"), "shared BGE artifact self hash"
        )
        != canonical_sha256(
            {
                key: value
                for key, value in binding.items()
                if key != "artifact_payload_sha256"
            }
        )
        or _sha256_value(
            binding.get("source_text_sha256"), "shared BGE source text hash"
        )
        != stage1a_text_sha256
    ):
        raise Stage3aContractError("shared BGE artifact contract/self hash differs")
    snapshot = _validate_bge_snapshot_manifest(
        binding["model_snapshot_manifest"], model_revision=revision
    )
    embedding_path = _resolved_bound_file(
        binding["embedding_artifact"], "shared BGE embedding artifact"
    )
    text = pd.read_parquet(
        stage1a_text_path,
        columns=["row_hash", "is_text_missing"],
    )
    embedding = pd.read_parquet(embedding_path)
    expected_columns = [
        "row_hash",
        *[f"bge_m3_{index:04d}" for index in range(BGE_DIMENSION)],
        "is_text_missing",
    ]
    if list(embedding.columns) != expected_columns:
        raise Stage3aContractError("shared BGE embedding column order/schema differs")
    text_rows = text["row_hash"].astype(str).tolist()
    embedding_rows = embedding["row_hash"].astype(str).tolist()
    if (
        text["row_hash"].astype(str).duplicated().any()
        or embedding["row_hash"].astype(str).duplicated().any()
        or text_rows != embedding_rows
        or _sha256_value(
            binding.get("row_hash_order_sha256"), "shared BGE row-order hash"
        )
        != canonical_sha256(text_rows)
    ):
        raise Stage3aContractError("shared BGE row order/key set differs from Stage1a text")
    text_missing = pd.to_numeric(text["is_text_missing"], errors="coerce")
    embedding_missing = pd.to_numeric(embedding["is_text_missing"], errors="coerce")
    if (
        text_missing.isna().any()
        or embedding_missing.isna().any()
        or not text_missing.isin([0, 1]).all()
        or not embedding_missing.isin([0, 1]).all()
        or not np.array_equal(
            text_missing.to_numpy(dtype="int8"),
            embedding_missing.to_numpy(dtype="int8"),
        )
    ):
        raise Stage3aContractError("shared BGE missing-text flag differs")
    matrix = embedding[expected_columns[1:-1]].to_numpy(dtype="float32")
    if not np.isfinite(matrix).all():
        raise Stage3aContractError("shared BGE embedding contains non-finite values")
    missing_mask = embedding_missing.eq(1).to_numpy()
    if not np.equal(matrix[missing_mask], 0.0).all():
        raise Stage3aContractError("shared BGE missing rows are not exact zero vectors")
    if (~missing_mask).any() and np.equal(matrix[~missing_mask], 0.0).all(axis=1).any():
        raise Stage3aContractError("shared BGE observed row is an all-zero vector")
    provenance = {
        "contract_version": binding["contract_version"],
        "artifact_payload_sha256": binding["artifact_payload_sha256"],
        "embedding_artifact_sha256": sha256_file(embedding_path),
        "source_text_sha256": stage1a_text_sha256,
        "row_hash_order_sha256": binding["row_hash_order_sha256"],
        "model": BGE_MODEL,
        "model_revision": revision,
        "model_weights_composite_sha256": snapshot[
            "model_weights_composite_sha256"
        ],
        "model_snapshot_manifest_sha256": snapshot["manifest_sha256"],
        "embedding_dimension": BGE_DIMENSION,
        "weights_frozen": True,
        "missing_text_policy": "exact_zero_vector_plus_is_text_missing",
    }
    return embedding_path, provenance


def validate_formal_rebind(
    base_contract: dict[str, Any],
    rebind: dict[str, Any],
    *,
    prelaunch_manifest_path: Path,
    registry_path: Path,
) -> dict[str, Any]:
    _validate_contract_digest(base_contract)
    if set(rebind) != FORMAL_REBIND_KEYS:
        raise Stage3aContractError("formal rebind key set differs from the frozen schema")
    if rebind.get("contract_version") != "p1-v2-stage3a-formal-rebind/1":
        raise Stage3aContractError("formal rebind contract version differs")
    if rebind.get("status") != "PASS" or rebind.get("formal_training_authorized") is not True:
        raise Stage3aContractError("formal rebind is not an accepted authorization")
    if rebind.get("task_id") != base_contract["task_id"]:
        raise Stage3aContractError("formal rebind belongs to another task")
    expected_authorization_sha = canonical_sha256(
        {key: value for key, value in rebind.items() if key != "authorization_sha256"}
    )
    if _sha256_value(rebind["authorization_sha256"], "authorization_sha256") != expected_authorization_sha:
        raise Stage3aContractError("formal rebind self hash mismatch")
    prelaunch_sha = sha256_file(prelaunch_manifest_path)
    registry_sha = sha256_file(registry_path)
    if base_contract.get("prelaunch_manifest_sha256") != prelaunch_sha:
        raise Stage3aContractError("base contract/prelaunch manifest hash mismatch")
    if base_contract.get("task_registry_sha256") != registry_sha:
        raise Stage3aContractError("base contract/task registry hash mismatch")
    if (
        _sha256_value(rebind["runner_contract_sha256"], "runner contract hash")
        != base_contract["contract_sha256"]
    ):
        raise Stage3aContractError("formal rebind runner contract hash mismatch")
    if _sha256_value(rebind["prelaunch_manifest_sha256"], "prelaunch manifest hash") != prelaunch_sha:
        raise Stage3aContractError("formal rebind prelaunch manifest hash mismatch")
    if _sha256_value(rebind["task_registry_sha256"], "task registry hash") != registry_sha:
        raise Stage3aContractError("formal rebind task registry hash mismatch")
    registry = read_json(registry_path)
    registry_task = _registry_task(registry, base_contract["task_id"])
    registry_task_sha = canonical_sha256(registry_task)
    if _sha256_value(rebind["registry_task_sha256"], "registry task hash") != registry_task_sha:
        raise Stage3aContractError("formal rebind registry task hash mismatch")
    if rebind.get("registry_metadata") != registry_task.get("metadata"):
        raise Stage3aContractError("formal rebind metadata differs from the exact registry task")
    if _sha256_value(rebind["runner_sha256"], "runner hash") != sha256_file(Path(__file__).resolve()):
        raise Stage3aContractError("formal rebind runner hash mismatch")
    if (
        rebind.get("maximum_year") != 2024
        or rebind.get("2025_access_count") != 0
        or rebind.get("strict_no_arrival_leakage") is not True
    ):
        raise Stage3aContractError("formal rebind violates the <=2024 leakage contract")
    if not isinstance(rebind.get("seed"), int) or isinstance(rebind.get("seed"), bool):
        raise Stage3aContractError("formal rebind seed must be an integer")
    dependencies = rebind.get("accepted_dependency_artifacts")
    dependency_manifests = _validate_accepted_dependencies(base_contract, rebind)
    input_artifacts = rebind.get("input_artifacts")
    expected_roles = _formal_input_roles(base_contract["model"])
    if not isinstance(input_artifacts, dict) or set(input_artifacts) != expected_roles:
        raise Stage3aContractError("formal rebind input role set differs")
    actual_input_hashes: dict[str, str] = {}
    for role, record in input_artifacts.items():
        if not isinstance(record, dict) or set(record) != {"path", "sha256"}:
            raise Stage3aContractError(f"formal input record schema differs: {role}")
        path = Path(str(record.get("path", ""))).resolve()
        if not path.is_file() or "2025" in path.name.casefold():
            raise Stage3aContractError(f"formal input is missing/future: {role}")
        actual = sha256_file(path)
        if _sha256_value(record["sha256"], f"{role} hash") != actual:
            raise Stage3aContractError(f"formal input hash mismatch: {role}")
        actual_input_hashes[role] = actual
    prelaunch_hashes = {
        str(record.get("sha256", "")).casefold()
        for record in base_contract.get("input_artifacts", [])
    }
    if actual_input_hashes["stage1a_features"] not in prelaunch_hashes:
        raise Stage3aContractError("formal Stage1a feature input differs from prelaunch")
    if base_contract["model"] in {"frozen_embedding", "bert_finetuned"} and actual_input_hashes["stage1a_text"] not in prelaunch_hashes:
        raise Stage3aContractError("formal Stage1a text input differs from prelaunch")
    if base_contract["model"] in HPO_MODELS:
        for upstream_model, role in (
            ("frozen_embedding", "frozen_embedding_predictions"),
            ("bert_finetuned", "bert_finetuned_predictions"),
        ):
            task_id = f"P1_05a-{base_contract['outcome']}-{upstream_model}"
            manifest = dependency_manifests.get(task_id)
            artifact_bindings = (
                manifest.get("artifact_bindings", {})
                if isinstance(manifest, dict)
                else {}
            )
            expected = str(
                artifact_bindings.get("predictions.parquet", {}).get("sha256", "")
            ).casefold()
            if actual_input_hashes[role] != expected:
                raise Stage3aContractError(
                    f"formal {upstream_model} predictions differ from the "
                    "accepted dependency manifest"
                )
    shared_embedding = rebind.get("shared_embedding_artifact")
    if base_contract["model"] == "frozen_embedding":
        _, shared_embedding_provenance = validate_shared_bge_artifact(
            shared_embedding,
            stage1a_text_path=Path(input_artifacts["stage1a_text"]["path"]),
            stage1a_text_sha256=actual_input_hashes["stage1a_text"],
        )
    else:
        if shared_embedding is not None:
            raise Stage3aContractError(
                "shared BGE artifact is valid only for frozen_embedding tasks"
            )
        shared_embedding_provenance = None
    locked_fold_hash = str(
        base_contract.get("source_hashes", {}).get("qa_v2/fixed_group_folds_v2.parquet", "")
    ).casefold()
    if actual_input_hashes["fold_map"] != locked_fold_hash:
        raise Stage3aContractError("formal fold map differs from the prelaunch lock")
    stage1a_manifest = read_json(Path(input_artifacts["stage1a_manifest"]["path"]))
    if (
        stage1a_manifest.get("strict_no_arrival_leakage") is not True
        or stage1a_manifest.get("holdout_policy", {}).get("2025_access_count") != 0
    ):
        raise Stage3aContractError("formal Stage1a manifest violates the leakage contract")
    artifact_hashes = {
        str(key): str(value).casefold()
        for key, value in stage1a_manifest.get("artifact_sha256", {}).items()
    }
    expected_stage1a = {
        "stage1a_features_le2024.parquet": actual_input_hashes["stage1a_features"],
        "stage1a_schema_v2.json": actual_input_hashes["stage1a_schema"],
    }
    if base_contract["model"] in {"frozen_embedding", "bert_finetuned"}:
        expected_stage1a["stage1a_text_le2024.parquet"] = actual_input_hashes["stage1a_text"]
    if any(artifact_hashes.get(name) != digest for name, digest in expected_stage1a.items()):
        raise Stage3aContractError("formal Stage1a artifact lineage differs from its manifest")
    rebound = copy.deepcopy(base_contract)
    rebound.update(
        {
            "status": "AUTHORIZED_NOT_LAUNCHED",
            "formal_training_authorized": True,
            "formal_training_launched": False,
            "formal_rebind_sha256": rebind["authorization_sha256"],
            "formal_seed": rebind["seed"],
            "formal_input_hashes": actual_input_hashes,
            "accepted_root_anchor": copy.deepcopy(rebind["accepted_root_anchor"]),
            "shared_embedding_artifact": copy.deepcopy(shared_embedding),
            "shared_embedding_provenance": shared_embedding_provenance,
            "dependency_gate": {
                **rebound["dependency_gate"],
                "status": "SATISFIED_BY_ACCEPTED_REBIND",
                "accepted_manifest_hashes": {
                    task_id: record["manifest_sha256"] for task_id, record in dependencies.items()
                },
            },
        }
    )
    rebound.pop("contract_sha256")
    rebound["contract_sha256"] = canonical_sha256(rebound)
    return rebound


def write_checkpoint_manifest(
    output_dir: Path,
    contract: dict[str, Any],
    *,
    completed_folds: list[int],
    final_completed: bool,
    attempted_trials: int,
    smoke: bool,
) -> dict[str, Any]:
    _validate_contract_digest(contract)
    if not smoke and contract.get("formal_training_authorized") is not True:
        raise Stage3aContractError("formal checkpoint write requires an authorized rebound contract")
    folds = sorted(set(int(value) for value in completed_folds))
    if folds != sorted(int(value) for value in completed_folds) or any(value not in FOLDS for value in folds):
        raise Stage3aContractError("checkpoint folds are invalid or duplicated")
    target_trials = int(contract["hpo"]["target_trials"])
    if target_trials == 0 and attempted_trials != 0:
        raise Stage3aContractError("non-HPO family cannot record Optuna trials")
    if target_trials and not 0 <= attempted_trials <= target_trials:
        raise Stage3aContractError("checkpoint trial count is outside the frozen target")
    if not smoke and target_trials and attempted_trials != target_trials:
        raise Stage3aContractError(
            "formal checkpoint requires 50 attempted trials per completed selection context"
        )
    required_models = [f"models/fold_{fold}.bin" for fold in folds]
    if final_completed:
        required_models.append("models/final.bin")
    if not smoke and contract["model"] in HPO_MODELS:
        required_models.extend(f"models/no_text_fold_{fold}.bin" for fold in folds)
        if final_completed:
            required_models.append("models/no_text_final.bin")
    missing = [name for name in required_models if not (output_dir / name).is_file()]
    if missing:
        raise Stage3aContractError(f"checkpoint model files are missing: {missing}")
    checkpoint_files = list(required_models)
    if not smoke:
        prediction_files = [
            f"checkpoints/fold_{fold}_predictions.parquet" for fold in folds
        ]
        if final_completed:
            prediction_files.append("checkpoints/final_predictions.parquet")
        if contract["model"] in HPO_MODELS:
            prediction_files.extend(
                f"checkpoints/no_text_fold_{fold}_predictions.parquet"
                for fold in folds
            )
            if final_completed:
                prediction_files.append(
                    "checkpoints/no_text_final_predictions.parquet"
                )
        missing_predictions = [
            name for name in prediction_files if not (output_dir / name).is_file()
        ]
        if missing_predictions:
            raise Stage3aContractError(
                f"checkpoint prediction files are missing: {missing_predictions}"
            )
        checkpoint_files.extend(prediction_files)
    completed_contexts = [f"outer_{fold}" for fold in folds]
    if final_completed:
        completed_contexts.append("final")
    if target_trials and attempted_trials:
        if smoke:
            if not (output_dir / "optuna.sqlite3").is_file():
                raise Stage3aContractError("resumable Optuna storage is missing")
            checkpoint_files.append("optuna.sqlite3")
        else:
            for context in completed_contexts:
                checkpoint_files.extend(
                    [
                        f"optuna_{context}.sqlite3",
                        f"checkpoints/optuna_{context}_trials.parquet",
                        f"checkpoints/selection_{context}.json",
                    ]
                )
    elif not smoke and contract["model"] == "bert_finetuned":
        checkpoint_files.extend(
            f"checkpoints/selection_{context}.json"
            for context in completed_contexts
        )
    if not smoke and contract["model"] == "ft_transformer":
        for context in completed_contexts:
            checkpoint_files.extend(
                [
                    f"checkpoints/ft_feature_selection_{context}.json",
                    f"checkpoints/no_text_ft_feature_selection_{context}.json",
                ]
            )
    missing_selection = [
        name for name in checkpoint_files if not (output_dir / name).is_file()
    ]
    if missing_selection:
        raise Stage3aContractError(
            f"checkpoint selection artifacts are missing: {missing_selection}"
        )
    complete = folds == list(FOLDS) and final_completed and (
        target_trials == 0 or attempted_trials == target_trials or smoke
    )
    value = {
        "contract_version": "p1-v2-stage3a-checkpoint/3",
        "task_id": contract["task_id"],
        "status": "SMOKE_COMPLETE" if smoke and complete else "COMPLETE" if complete else "PARTIAL",
        "contract_sha256": contract["contract_sha256"],
        "completed_folds": folds,
        "remaining_folds": [fold for fold in FOLDS if fold not in folds],
        "final_completed": bool(final_completed),
        "optuna": {
            "enabled": bool(contract["hpo"]["enabled"]),
            "target_trials": target_trials,
            "attempted_trials": int(attempted_trials),
            "completed_selection_contexts": completed_contexts,
            "attempted_trials_total": (
                int(attempted_trials) * len(completed_contexts)
                if target_trials and not smoke
                else int(attempted_trials)
            ),
            "study_scope": contract["hpo"]["study_scope"],
            "resume_policy": contract["hpo"]["resume_policy"],
        },
        "checkpoint_artifact_hashes": {
            name: sha256_file(output_dir / name) for name in checkpoint_files
        },
        "formal_training_authorized": bool(contract.get("formal_training_authorized")),
        "smoke": bool(smoke),
        "2025_access_count": 0,
    }
    atomic_json(output_dir / "checkpoint_manifest.json", value)
    return value


def _checkpoint_path(output_dir: Path, relative: str) -> Path:
    path = Path(relative)
    if path.is_absolute() or ".." in path.parts:
        raise Stage3aContractError(f"unsafe checkpoint artifact path: {relative}")
    return output_dir / path


def _validate_prediction_checkpoint(
    contract: dict[str, Any],
    frame: pd.DataFrame,
    *,
    split: str,
    fold: int | None,
) -> None:
    if tuple(frame.columns) != PREDICTION_COLUMNS or frame.empty:
        raise Stage3aContractError("checkpoint prediction schema is invalid")
    if (
        not frame["task_id"].eq(contract["task_id"]).all()
        or not frame["outcome"].eq(contract["outcome"]).all()
        or not frame["model"].eq(contract["model"]).all()
        or not frame["split"].eq(split).all()
    ):
        raise Stage3aContractError("checkpoint prediction identity differs")
    if frame["row_hash"].astype(str).str.fullmatch(r"[0-9a-fA-F]{64}").ne(True).any():
        raise Stage3aContractError("checkpoint prediction row hash is invalid")
    if frame["row_hash"].astype(str).duplicated().any():
        raise Stage3aContractError("checkpoint prediction rows are duplicated")
    if frame["y_true"].isin([0, 1]).ne(True).any():
        raise Stage3aContractError("checkpoint prediction labels are invalid")
    probability = pd.to_numeric(frame["prediction"], errors="coerce")
    if probability.isna().any() or not probability.between(0, 1).all():
        raise Stage3aContractError("checkpoint prediction probabilities are invalid")
    if fold is None:
        if frame["fold"].notna().any():
            raise Stage3aContractError("final checkpoint predictions have a fold")
    elif not pd.to_numeric(frame["fold"], errors="coerce").eq(fold).all():
        raise Stage3aContractError("OOF checkpoint prediction fold differs")


def _load_resume_checkpoint(
    output_dir: Path, contract: dict[str, Any]
) -> tuple[dict[str, Any] | None, list[pd.DataFrame]]:
    path = output_dir / "checkpoint_manifest.json"
    if not path.is_file():
        return None, []
    checkpoint = read_json(path)
    if checkpoint.get("contract_version") != "p1-v2-stage3a-checkpoint/3":
        raise Stage3aContractError("resume checkpoint version differs")
    if (
        checkpoint.get("task_id") != contract["task_id"]
        or checkpoint.get("contract_sha256") != contract["contract_sha256"]
        or checkpoint.get("formal_training_authorized") is not True
        or checkpoint.get("smoke") is not False
        or checkpoint.get("2025_access_count") != 0
    ):
        raise Stage3aContractError("resume checkpoint contract binding differs")
    completed_folds = checkpoint.get("completed_folds")
    if not isinstance(completed_folds, list) or completed_folds != list(
        FOLDS[: len(completed_folds)]
    ):
        raise Stage3aContractError("resume checkpoint folds are not an exact prefix")
    if checkpoint.get("remaining_folds") != [
        fold for fold in FOLDS if fold not in completed_folds
    ]:
        raise Stage3aContractError("resume checkpoint remaining folds differ")
    final_completed = checkpoint.get("final_completed")
    if not isinstance(final_completed, bool) or final_completed and completed_folds != list(FOLDS):
        raise Stage3aContractError("resume checkpoint final state differs")
    expected_status = "COMPLETE" if final_completed else "PARTIAL"
    if checkpoint.get("status") != expected_status:
        raise Stage3aContractError("resume checkpoint status differs")
    optuna = checkpoint.get("optuna")
    target_trials = int(contract["hpo"]["target_trials"])
    if not isinstance(optuna, dict) or optuna.get("target_trials") != target_trials:
        raise Stage3aContractError("resume checkpoint Optuna target differs")
    attempted_trials = optuna.get("attempted_trials")
    if attempted_trials != target_trials:
        raise Stage3aContractError(
            "resume checkpoint does not bind 50 attempted trials per selection context"
        )
    expected_files = [f"models/fold_{fold}.bin" for fold in completed_folds]
    expected_files.extend(
        f"checkpoints/fold_{fold}_predictions.parquet" for fold in completed_folds
    )
    if contract["model"] in HPO_MODELS:
        expected_files.extend(
            f"models/no_text_fold_{fold}.bin" for fold in completed_folds
        )
        expected_files.extend(
            f"checkpoints/no_text_fold_{fold}_predictions.parquet"
            for fold in completed_folds
        )
    if final_completed:
        expected_files.extend(
            ["models/final.bin", "checkpoints/final_predictions.parquet"]
        )
        if contract["model"] in HPO_MODELS:
            expected_files.extend(
                [
                    "models/no_text_final.bin",
                    "checkpoints/no_text_final_predictions.parquet",
                ]
            )
    completed_contexts = [f"outer_{fold}" for fold in completed_folds]
    if final_completed:
        completed_contexts.append("final")
    if optuna.get("completed_selection_contexts") != completed_contexts:
        raise Stage3aContractError("resume checkpoint selection contexts differ")
    expected_trial_total = target_trials * len(completed_contexts)
    if optuna.get("attempted_trials_total") != expected_trial_total:
        raise Stage3aContractError("resume checkpoint total trial count differs")
    if target_trials:
        for context in completed_contexts:
            expected_files.extend(
                [
                    f"optuna_{context}.sqlite3",
                    f"checkpoints/optuna_{context}_trials.parquet",
                    f"checkpoints/selection_{context}.json",
                ]
            )
    elif contract["model"] == "bert_finetuned":
        expected_files.extend(
            f"checkpoints/selection_{context}.json"
            for context in completed_contexts
        )
    if contract["model"] == "ft_transformer":
        for context in completed_contexts:
            expected_files.extend(
                [
                    f"checkpoints/ft_feature_selection_{context}.json",
                    f"checkpoints/no_text_ft_feature_selection_{context}.json",
                ]
            )
    artifact_hashes = checkpoint.get("checkpoint_artifact_hashes")
    if not isinstance(artifact_hashes, dict) or set(artifact_hashes) != set(expected_files):
        raise Stage3aContractError("resume checkpoint artifact inventory differs")
    for relative, expected_hash in artifact_hashes.items():
        artifact = _checkpoint_path(output_dir, str(relative))
        if not artifact.is_file() or _sha256_value(
            expected_hash, f"checkpoint artifact {relative} hash"
        ) != sha256_file(artifact):
            raise Stage3aContractError(
                f"resume checkpoint artifact hash mismatch: {relative}"
            )
    for context in completed_contexts:
        if not (target_trials or contract["model"] == "bert_finetuned"):
            continue
        selection = read_json(
            output_dir / "checkpoints" / f"selection_{context}.json"
        )
        if (
            selection.get("selection_context") != context
            or selection.get("outer_validation_rows_read_for_selection") != 0
            or selection.get("validation_2024_rows_read_for_selection") != 0
            or selection.get("patient_group_overlap") != 0
        ):
            raise Stage3aContractError(
                f"resume selection leakage contract differs: {context}"
            )
        if target_trials:
            trials = pd.read_parquet(
                output_dir
                / "checkpoints"
                / f"optuna_{context}_trials.parquet"
            )
            if (
                len(trials) != 50
                or trials["trial_number"].duplicated().any()
                or not trials["state"].isin(["COMPLETE", "PRUNED"]).all()
                or not trials["state"].eq("COMPLETE").any()
                or trials["selection_context"].ne(context).any()
            ):
                raise Stage3aContractError(
                    f"resume Optuna trial evidence differs: {context}"
                )
        if contract["model"] == "ft_transformer":
            for no_text in (False, True):
                prefix = (
                    "no_text_ft_feature_selection"
                    if no_text
                    else "ft_feature_selection"
                )
                selection = read_json(
                    output_dir / "checkpoints" / f"{prefix}_{context}.json"
                )
                selected_features = selection.get("selected_features")
                if (
                    selection.get("selection_context") != context
                    or selection.get("no_text") is not no_text
                    or selection.get("runner_contract_sha256")
                    != contract["contract_sha256"]
                    or selection.get("held_out_rows_read") != 0
                    or selection.get("validation_2024_rows_read") != 0
                    or selection.get("silent_positional_truncation") is not False
                    or not 0
                    < int(selection.get("selected_feature_count", 0))
                    <= FT_MAX_FEATURES
                    or not isinstance(selected_features, list)
                    or len(selected_features)
                    != int(selection.get("selected_feature_count", 0))
                    or selection.get("selected_features_sha256")
                    != canonical_sha256(selected_features)
                ):
                    raise Stage3aContractError(
                        f"resume FT feature selection differs: {context}"
                    )
    predictions = []
    for fold in completed_folds:
        frame = pd.read_parquet(
            output_dir / f"checkpoints/fold_{fold}_predictions.parquet"
        )
        _validate_prediction_checkpoint(
            contract, frame, split="oof_2020_2023", fold=fold
        )
        predictions.append(frame)
    if final_completed:
        frame = pd.read_parquet(output_dir / "checkpoints/final_predictions.parquet")
        _validate_prediction_checkpoint(
            contract, frame, split="validation_2024", fold=None
        )
        predictions.append(frame)
    return checkpoint, predictions


def _load_no_text_resume_predictions(
    output_dir: Path,
    contract: dict[str, Any],
    checkpoint: dict[str, Any] | None,
) -> list[pd.DataFrame]:
    if contract["model"] not in HPO_MODELS or checkpoint is None:
        return []
    predictions = []
    for fold in checkpoint["completed_folds"]:
        frame = pd.read_parquet(
            output_dir
            / "checkpoints"
            / f"no_text_fold_{fold}_predictions.parquet"
        )
        _validate_prediction_checkpoint(
            contract, frame, split="oof_2020_2023", fold=int(fold)
        )
        predictions.append(frame)
    if checkpoint["final_completed"]:
        frame = pd.read_parquet(
            output_dir / "checkpoints" / "no_text_final_predictions.parquet"
        )
        _validate_prediction_checkpoint(
            contract, frame, split="validation_2024", fold=None
        )
        predictions.append(frame)
    return predictions


def _validate_checkpoint_against_data(
    frame: pd.DataFrame,
    expected: pd.DataFrame,
    *,
    label: str,
) -> None:
    joined = expected[["row_hash", "label"]].merge(
        frame[["row_hash", "y_true"]],
        on="row_hash",
        how="outer",
        validate="one_to_one",
        indicator=True,
    )
    if not joined["_merge"].eq("both").all() or not np.array_equal(
        joined["label"].to_numpy(dtype="int8"),
        joined["y_true"].to_numpy(dtype="int8"),
    ):
        raise Stage3aContractError(f"{label} row/label coverage differs")


def _existing_success(
    output_dir: Path, contract: dict[str, Any]
) -> dict[str, Any] | None:
    path = output_dir / "_SUCCESS.json"
    if not path.is_file():
        return None
    success = read_json(path)
    if (
        success.get("status") != "PASS"
        or success.get("scientific_artifact") is not True
        or success.get("smoke") is not False
        or success.get("task_id") != contract["task_id"]
    ):
        raise Stage3aContractError("existing Stage3a success receipt differs")
    manifest_path = output_dir / str(success.get("manifest", ""))
    if not manifest_path.is_file() or _sha256_value(
        success.get("manifest_sha256"), "existing task manifest hash"
    ) != sha256_file(manifest_path):
        raise Stage3aContractError("existing Stage3a task manifest hash differs")
    manifest = read_json(manifest_path)
    if (
        manifest.get("runner_contract_sha256") != contract["contract_sha256"]
        or manifest.get("formal_training_authorized") is not True
        or manifest.get("formal_training_launched") is not True
        or manifest.get("fixed_outer_folds") != list(FOLDS)
        or manifest.get("2025_access_count") != 0
    ):
        raise Stage3aContractError("existing Stage3a task manifest binding differs")
    hashes = success.get("artifact_hashes")
    if not isinstance(hashes, dict) or not hashes:
        raise Stage3aContractError("existing Stage3a success hash inventory is missing")
    for relative, expected_hash in hashes.items():
        artifact = _checkpoint_path(output_dir, str(relative))
        if not artifact.is_file() or _sha256_value(
            expected_hash, f"existing artifact {relative} hash"
        ) != sha256_file(artifact):
            raise Stage3aContractError(
                f"existing Stage3a artifact hash mismatch: {relative}"
            )
    recompute_reload_canary(
        output_dir,
        contract,
        canary_inputs=pd.read_parquet(output_dir / "canary_inputs.parquet"),
        canary_expected=pd.read_parquet(output_dir / "canary_expected.parquet"),
    )
    return success


def _initialize_formal_output(
    output_dir: Path,
    contract: dict[str, Any],
    rebind: dict[str, Any],
) -> dict[str, Any] | None:
    if not output_dir.exists() or not any(output_dir.iterdir()):
        output_dir.mkdir(parents=True, exist_ok=True)
        atomic_json(output_dir / "runner_contract.json", contract)
        atomic_json(output_dir / "formal_rebind.json", rebind)
        return None
    runner_path = output_dir / "runner_contract.json"
    rebind_path = output_dir / "formal_rebind.json"
    if not runner_path.is_file() or not rebind_path.is_file():
        raise Stage3aContractError("resume directory lacks its bound runner/rebind")
    if read_json(runner_path) != contract or read_json(rebind_path) != rebind:
        raise Stage3aContractError("resume directory runner/rebind content differs")
    return _existing_success(output_dir, contract)


def _validate_frames(
    contract: dict[str, Any],
    predictions: pd.DataFrame,
    metrics: pd.DataFrame,
    coverage: pd.DataFrame,
    *,
    smoke: bool,
) -> None:
    if tuple(predictions.columns) != PREDICTION_COLUMNS:
        raise Stage3aContractError("prediction column contract mismatch")
    if tuple(metrics.columns) != METRIC_COLUMNS:
        raise Stage3aContractError("metric column contract mismatch")
    if tuple(coverage.columns) != COVERAGE_COLUMNS:
        raise Stage3aContractError("coverage column contract mismatch")
    task_id = contract["task_id"]
    outcome = contract["outcome"]
    model = contract["model"]
    for frame in (predictions, metrics):
        if not frame["task_id"].eq(task_id).all() or not frame["outcome"].eq(outcome).all() or not frame["model"].eq(model).all():
            raise Stage3aContractError("task identity drift in result frame")
    if not coverage["outcome"].eq(outcome).all() or not coverage["model"].eq(model).all():
        raise Stage3aContractError("task identity drift in coverage")
    if predictions.duplicated(["row_hash", "outcome", "model", "split"]).any():
        raise Stage3aContractError("duplicate strict-long predictions")
    if predictions["row_hash"].astype(str).str.fullmatch(r"[0-9a-fA-F]{64}").ne(True).any():
        raise Stage3aContractError("invalid row hash")
    if predictions["y_true"].isin([0, 1]).ne(True).any():
        raise Stage3aContractError("invalid binary label")
    numeric_prediction = pd.to_numeric(predictions["prediction"], errors="coerce")
    if numeric_prediction.isna().any() or not numeric_prediction.between(0, 1).all():
        raise Stage3aContractError("invalid prediction")
    if set(predictions["split"]) != {"oof_2020_2023", "validation_2024"}:
        raise Stage3aContractError("OOF/final validation split coverage mismatch")
    oof = predictions.loc[predictions["split"].eq("oof_2020_2023")]
    validation = predictions.loc[predictions["split"].eq("validation_2024")]
    if sorted(pd.to_numeric(oof["fold"], errors="raise").astype(int).unique().tolist()) != list(FOLDS):
        raise Stage3aContractError("five-fold OOF coverage is incomplete")
    if validation["fold"].notna().any():
        raise Stage3aContractError("final validation rows must have null fold")
    if not smoke and len(validation) == 0:
        raise Stage3aContractError("formal final validation predictions are empty")
    prediction_keys = set(
        zip(
            predictions["row_hash"].astype(str),
            predictions["outcome"].astype(str),
            predictions["model"].astype(str),
            predictions["split"].astype(str),
        )
    )
    eligible = coverage.loc[coverage["eligible"].eq(True)]
    coverage_keys = set(
        zip(
            eligible["row_hash"].astype(str),
            eligible["outcome"].astype(str),
            eligible["model"].astype(str),
            eligible["split"].astype(str),
        )
    )
    if prediction_keys != coverage_keys:
        raise Stage3aContractError("prediction/eligible coverage keys differ")
    if coverage.duplicated(["row_hash", "outcome", "model", "split"]).any():
        raise Stage3aContractError("duplicate coverage keys")
    if metrics["split"].isin({"oof_2020_2023", "validation_2024"}).ne(True).any():
        raise Stage3aContractError("metric split contract mismatch")
    if not set(metrics["status"]).issubset({"ESTIMATED", "NOT_ESTIMABLE"}):
        raise Stage3aContractError("Stage3a metric status is invalid")
    estimated = metrics["status"].eq("ESTIMATED")
    if (
        pd.to_numeric(metrics.loc[estimated, "value"], errors="coerce").isna().any()
        or pd.to_numeric(metrics.loc[estimated, "lower_ci"], errors="coerce").isna().any()
        or pd.to_numeric(metrics.loc[estimated, "upper_ci"], errors="coerce").isna().any()
    ):
        raise Stage3aContractError("estimated Stage3a metrics lack finite CI values")


def recompute_reload_canary(
    output_dir: Path,
    contract: dict[str, Any],
    *,
    canary_inputs: pd.DataFrame,
    canary_expected: pd.DataFrame,
) -> dict[str, Any]:
    if not set(canary_expected.columns) >= {"canary_id", "prediction"} or "canary_id" not in canary_inputs:
        raise Stage3aContractError("canary schema is incomplete")
    if canary_inputs["canary_id"].astype(str).tolist() != canary_expected["canary_id"].astype(str).tolist():
        raise Stage3aContractError("canary input/expected order differs")
    required_rows = int(contract["sealed_outputs"]["canary_rows_formal"])
    if len(canary_inputs) != required_rows:
        raise Stage3aContractError("canary row count differs from the exact contract")
    final_model_path = output_dir / "models/final.bin"
    if not final_model_path.is_file():
        raise Stage3aContractError("sealed final model is missing")
    loaded_model = joblib.load(final_model_path)
    if not hasattr(loaded_model, "predict_proba"):
        raise Stage3aContractError("reloaded final model cannot predict probabilities")
    feature_order = list(
        getattr(loaded_model, "feature_order", getattr(loaded_model, "feature_order_", []))
    )
    if not feature_order or any(column not in canary_inputs for column in feature_order):
        raise Stage3aContractError("reloaded final model feature order differs from canary inputs")
    actual = np.asarray(
        loaded_model.predict_proba(canary_inputs.loc[:, feature_order])[:, 1],
        dtype="float64",
    )
    expected = pd.to_numeric(
        canary_expected["prediction"], errors="coerce"
    ).to_numpy(dtype="float64")
    if (
        len(actual) != len(expected)
        or not np.isfinite(actual).all()
        or not np.isfinite(expected).all()
    ):
        raise Stage3aContractError("reloaded final model canary output is invalid")
    maximum_error = float(np.max(np.abs(actual - expected)))
    tolerance = float(contract["sealed_outputs"]["canary_max_abs_error"])
    if maximum_error > tolerance:
        raise Stage3aContractError("model reload canary tolerance failed")
    return {
        "status": "PASS",
        "rows": int(len(canary_inputs)),
        "max_abs_error": maximum_error,
        "tolerance": tolerance,
        "independently_reloaded": True,
    }


def write_bert_local_snapshot(
    output_dir: Path, model: BertModelBundle
) -> dict[str, Any]:
    target = output_dir / "models" / "bert_local_snapshot"
    manifest_path = target / "snapshot_manifest.json"
    if manifest_path.is_file():
        manifest = read_json(manifest_path)
        for relative, expected in manifest.get("file_hashes", {}).items():
            path = target / relative
            if not path.is_file() or sha256_file(path) != expected:
                raise Stage3aContractError("existing BERT local snapshot hash differs")
        return manifest
    if target.exists():
        raise Stage3aContractError("partial BERT local snapshot exists")
    staging = output_dir / "models" / ".bert_local_snapshot.tmp"
    if staging.exists():
        raise Stage3aContractError("partial BERT snapshot staging directory exists")
    staging.mkdir(parents=True)
    import torch
    from transformers import AutoConfig

    config_value = dict(model.config)
    model_type = str(config_value.pop("model_type"))
    config = AutoConfig.for_model(model_type, **config_value)
    config.save_pretrained(staging)
    model.tokenizer.save_pretrained(staging)
    temporary_state = staging / "fine_tuned_state.pt.tmp"
    torch.save(model.state_dict, temporary_state)
    temporary_state.replace(staging / "fine_tuned_state.pt")
    file_hashes = {
        path.relative_to(staging).as_posix(): sha256_file(path)
        for path in sorted(staging.rglob("*"))
        if path.is_file()
    }
    manifest = {
        "contract_version": "p1-v2-stage3a-bert-local-snapshot/1",
        "status": "PASS",
        "local_files_only_reload": True,
        "network_required_for_reload": False,
        "model_config_source": "sealed_config_json",
        "tokenizer_source": "sealed_local_snapshot",
        "fine_tuned_state": "fine_tuned_state.pt",
        "file_hashes": file_hashes,
    }
    atomic_json(staging / "snapshot_manifest.json", manifest)
    staging.replace(target)
    return manifest


def hardware_record() -> dict[str, Any]:
    import psutil

    packages = {}
    for name in (
        "joblib",
        "numpy",
        "optuna",
        "pandas",
        "scikit-learn",
        "sentence-transformers",
        "torch",
        "transformers",
    ):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    cuda = []
    try:
        import torch

        for index in range(torch.cuda.device_count()):
            properties = torch.cuda.get_device_properties(index)
            cuda.append(
                {
                    "index": index,
                    "name": properties.name,
                    "total_vram_bytes": int(properties.total_memory),
                    "peak_allocated_vram_bytes": int(
                        torch.cuda.max_memory_allocated(index)
                    ),
                    "peak_reserved_vram_bytes": int(
                        torch.cuda.max_memory_reserved(index)
                    ),
                    "capability": list(torch.cuda.get_device_capability(index)),
                }
            )
        torch_version = torch.__version__
        cuda_version = torch.version.cuda
    except ImportError:
        torch_version = None
        cuda_version = None
    memory = psutil.virtual_memory()
    process_memory = psutil.Process().memory_info()
    return {
        "contract_version": "p1-v2-stage3a-hardware/1",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "logical_cpu_count": psutil.cpu_count(logical=True),
        "physical_cpu_count": psutil.cpu_count(logical=False),
        "total_ram_bytes": int(memory.total),
        "available_ram_bytes_at_seal": int(memory.available),
        "process_rss_bytes_at_seal": int(process_memory.rss),
        "process_vms_bytes_at_seal": int(process_memory.vms),
        "torch": torch_version,
        "cuda_runtime": cuda_version,
        "cuda_available": bool(cuda),
        "cuda_devices": cuda,
        "packages": packages,
    }


def write_sealed_task_artifacts(
    output_dir: Path,
    contract: dict[str, Any],
    *,
    predictions: pd.DataFrame,
    metrics: pd.DataFrame,
    coverage: pd.DataFrame,
    canary_inputs: pd.DataFrame,
    canary_expected: pd.DataFrame,
    hpo_trials: pd.DataFrame | None,
    smoke: bool,
    nlp_features: pd.DataFrame | None = None,
    nlp_provenance: dict[str, Any] | None = None,
    no_text_predictions: pd.DataFrame | None = None,
    candidate_feature_order: list[str] | None = None,
) -> dict[str, Any]:
    started = time.perf_counter()
    _validate_contract_digest(contract)
    if not smoke and contract.get("formal_training_authorized") is not True:
        raise Stage3aContractError("formal artifact seal requires an authorized rebound contract")
    checkpoint_path = output_dir / "checkpoint_manifest.json"
    if not checkpoint_path.is_file():
        raise Stage3aContractError("checkpoint manifest is missing")
    checkpoint = read_json(checkpoint_path)
    required_checkpoint_status = "SMOKE_COMPLETE" if smoke else "COMPLETE"
    if checkpoint.get("status") != required_checkpoint_status or checkpoint.get("contract_sha256") != contract["contract_sha256"]:
        raise Stage3aContractError("checkpoint is incomplete or bound to another contract")
    _validate_frames(contract, predictions, metrics, coverage, smoke=smoke)
    reload_canary = recompute_reload_canary(
        output_dir,
        contract,
        canary_inputs=canary_inputs,
        canary_expected=canary_expected,
    )
    final_model_path = output_dir / "models/final.bin"
    bert_snapshot = None
    if contract["model"] == "bert_finetuned" and not smoke:
        loaded_final = joblib.load(final_model_path)
        if not isinstance(loaded_final, BertModelBundle):
            raise Stage3aContractError("sealed BERT model bundle type differs")
        bert_snapshot = write_bert_local_snapshot(output_dir, loaded_final)
    missing_models = [name for name in MODEL_FILE_NAMES if not (output_dir / name).is_file()]
    if missing_models:
        raise Stage3aContractError(f"sealed model files are missing: {missing_models}")
    target_trials = int(contract["hpo"]["target_trials"])
    if target_trials:
        if hpo_trials is None:
            raise Stage3aContractError("HPO family is missing its trial table")
        if not {"trial_number", "state", "value"}.issubset(hpo_trials.columns):
            raise Stage3aContractError("Optuna trial table schema is incomplete")
        duplicate_trial = (
            hpo_trials.duplicated(["selection_context", "trial_number"]).any()
            if not smoke and "selection_context" in hpo_trials
            else hpo_trials["trial_number"].duplicated().any()
        )
        if (
            duplicate_trial
            or not hpo_trials["state"].isin(["COMPLETE", "PRUNED"]).all()
            or not hpo_trials["state"].eq("COMPLETE").any()
        ):
            raise Stage3aContractError(
                "Optuna trial table contains duplicate/invalid trial states"
            )
        expected_trial_rows = int(checkpoint["optuna"]["attempted_trials"])
        if smoke and len(hpo_trials) != expected_trial_rows:
            raise Stage3aContractError("Optuna table/checkpoint count mismatch")
        if not smoke:
            expected_total = int(contract["hpo"]["target_trials_total"])
            if len(hpo_trials) != expected_total:
                raise Stage3aContractError(
                    "formal MLP/FT seal requires 50 trials in every outer/final context"
                )
            counts = hpo_trials.groupby("selection_context").size().to_dict()
            if counts != {context: 50 for context in HPO_CONTEXTS}:
                raise Stage3aContractError("formal Optuna selection-context coverage differs")
    elif hpo_trials is not None and len(hpo_trials):
        raise Stage3aContractError("non-HPO family cannot seal an Optuna trial table")
    atomic_parquet(output_dir / "predictions.parquet", predictions)
    atomic_parquet(output_dir / "metrics.parquet", metrics)
    atomic_parquet(output_dir / "coverage.parquet", coverage)
    atomic_parquet(output_dir / "canary_inputs.parquet", canary_inputs)
    atomic_parquet(output_dir / "canary_expected.parquet", canary_expected)
    extra_artifacts: list[Path] = []
    if hpo_trials is not None:
        trial_path = output_dir / "optuna_trials.parquet"
        atomic_parquet(trial_path, hpo_trials)
        extra_artifacts.append(trial_path)
    if nlp_features is None:
        nlp_features = predictions[["row_hash", "split", "prediction"]].rename(
            columns={"prediction": f"nlp_{contract['model']}"}
        )
    else:
        nlp_features = nlp_features.copy()
        nlp_features["split"] = nlp_features["split"].replace(
            {"train_2020_2023": "oof_2020_2023"}
        )
    if "row_hash" not in nlp_features or "split" not in nlp_features:
        raise Stage3aContractError("consolidated NLP feature schema is incomplete")
    if nlp_features["row_hash"].astype(str).duplicated().any():
        raise Stage3aContractError("consolidated NLP features contain duplicate rows")
    if set(nlp_features["split"].astype(str)) != {
        "oof_2020_2023",
        "validation_2024",
    }:
        raise Stage3aContractError("consolidated NLP feature split coverage differs")
    if set(nlp_features["row_hash"].astype(str)) != set(
        predictions["row_hash"].astype(str)
    ):
        raise Stage3aContractError("consolidated NLP feature row coverage differs")
    nlp_path = output_dir / "stage3a_nlp_features.parquet"
    atomic_parquet(nlp_path, nlp_features)
    extra_artifacts.append(nlp_path)
    if no_text_predictions is not None:
        if contract["model"] not in HPO_MODELS:
            raise Stage3aContractError(
                "only structured Stage3a models may seal no-text predictions"
            )
        if tuple(no_text_predictions.columns) != PREDICTION_COLUMNS:
            raise Stage3aContractError(
                "sealed no-text prediction schema differs"
            )
        for split, fold in (
            *[("oof_2020_2023", value) for value in FOLDS],
            ("validation_2024", None),
        ):
            subset = no_text_predictions.loc[
                no_text_predictions["split"].eq(split)
                & (
                    no_text_predictions["fold"].isna()
                    if fold is None
                    else pd.to_numeric(
                        no_text_predictions["fold"], errors="coerce"
                    ).eq(fold)
                )
            ]
            _validate_prediction_checkpoint(
                contract, subset, split=split, fold=fold
            )
        no_text_keys = no_text_predictions[
            ["row_hash", "split", "fold", "y_true"]
        ].copy()
        prediction_keys = predictions[
            ["row_hash", "split", "fold", "y_true"]
        ].copy()
        joined = prediction_keys.merge(
            no_text_keys,
            on=["row_hash", "split", "fold", "y_true"],
            how="outer",
            validate="one_to_one",
            indicator=True,
        )
        if not joined["_merge"].eq("both").all():
            raise Stage3aContractError(
                "sealed with/no-text prediction coverage differs"
            )
        no_text_path = output_dir / "no_text_predictions.parquet"
        atomic_parquet(no_text_path, no_text_predictions)
        extra_artifacts.append(no_text_path)
    loaded_final = joblib.load(final_model_path)
    feature_order = list(
        getattr(
            loaded_final,
            "feature_order",
            getattr(loaded_final, "feature_order_", []),
        )
    )
    candidate_feature_order = (
        list(candidate_feature_order)
        if candidate_feature_order is not None
        else list(feature_order)
    )
    no_text_feature_order = None
    if no_text_predictions is not None:
        no_text_final_model = joblib.load(
            output_dir / "models" / "no_text_final.bin"
        )
        no_text_feature_order = list(
            getattr(
                no_text_final_model,
                "feature_order",
                getattr(no_text_final_model, "feature_order_", []),
            )
        )
        if not no_text_feature_order:
            raise Stage3aContractError(
                "sealed no-text final model lacks its feature order"
            )
    feature_selection = {
        "contract_version": "p1-v2-stage3a-feature-selection/1",
        "task_id": contract["task_id"],
        "policy": (
            "fold_local_training_only_explicit_selection_from_full_schema"
            if contract["model"] == "ft_transformer"
            else "full_locked_stage1a_model_schema_plus_hash_bound_nlp_predictions"
            if contract["model"] == "mlp_plr"
            else "model_specific_text_feature_contract"
        ),
        "silent_truncation_allowed": False,
        "candidate_ordered_features": candidate_feature_order,
        "candidate_feature_count": len(candidate_feature_order),
        "candidate_ordered_features_sha256": canonical_sha256(
            candidate_feature_order
        ),
        "ordered_features": feature_order,
        "feature_count": len(feature_order),
        "ordered_features_sha256": canonical_sha256(feature_order),
        "source_schema_sha256": contract["formal_input_hashes"]["stage1a_schema"]
        if not smoke and "formal_input_hashes" in contract
        else None,
        "no_text_ordered_features": (
            no_text_feature_order if not smoke else None
        ),
        "no_text_removed_features": (
            [
                feature
                for feature in candidate_feature_order
                if feature in TEXT_DERIVED_FEATURES
            ]
            if contract["model"] in HPO_MODELS and not smoke
            else None
        ),
    }
    feature_selection_path = output_dir / "feature_selection.json"
    atomic_json(feature_selection_path, feature_selection)
    extra_artifacts.append(feature_selection_path)
    dl_bundle_path = output_dir / "stage3a_dl_models_oof.pkl"
    atomic_joblib(
        dl_bundle_path,
        {
            "task_id": contract["task_id"],
            "runner_contract_sha256": contract["contract_sha256"],
            "oof_predictions": predictions.loc[
                predictions["split"].eq("oof_2020_2023")
            ].copy(),
            "validation_predictions": predictions.loc[
                predictions["split"].eq("validation_2024")
            ].copy(),
            "no_text_predictions": no_text_predictions,
            "model_weight_storage_policy": (
                "hash_bound_external_model_files_no_byte_duplication"
            ),
            "fold_models": {
                name: sha256_file(output_dir / name)
                for name in MODEL_FILE_NAMES[:-1]
            },
            "final_model": {
                "path": MODEL_FILE_NAMES[-1],
                "sha256": sha256_file(output_dir / MODEL_FILE_NAMES[-1]),
            },
            "no_text_fold_models": (
                {
                    name: sha256_file(output_dir / name)
                    for name in NO_TEXT_MODEL_FILE_NAMES[:-1]
                }
                if no_text_predictions is not None
                else {}
            ),
            "no_text_final_model": (
                {
                    "path": NO_TEXT_MODEL_FILE_NAMES[-1],
                    "sha256": sha256_file(
                        output_dir / NO_TEXT_MODEL_FILE_NAMES[-1]
                    ),
                }
                if no_text_predictions is not None
                else None
            ),
        },
    )
    extra_artifacts.append(dl_bundle_path)
    hardware_path = output_dir / "hardware.json"
    atomic_json(hardware_path, hardware_record())
    extra_artifacts.append(hardware_path)
    spec = {
        "contract_version": "p1-v2-stage3a-sealed-spec/1",
        "task_id": contract["task_id"],
        "stage": "P1_05a",
        "outcome": contract["outcome"],
        "model": contract["model"],
        "runner_contract_sha256": contract["contract_sha256"],
        "fixed_outer_folds": list(FOLDS),
        "oof_split": "oof_2020_2023",
        "final_fit_years": [2020, 2021, 2022, 2023],
        "final_prediction_split": "validation_2024",
        "hpo": contract["hpo"],
        "family_plan": contract["family_plan"],
        "nlp_provenance": nlp_provenance or {},
        "evaluation": {
            "confidence_interval_method": "patient_group_bootstrap",
            "bootstrap_replicates": BOOTSTRAP_REPLICATES if not smoke else 200,
            "no_text_delta": (
                "paired_same_rows_same_folds_same_hyperparameters"
                if no_text_predictions is not None
                else None
            ),
        },
        "formal_training_authorized": bool(contract.get("formal_training_authorized")),
        "scientific_artifact": not smoke,
        "smoke": bool(smoke),
        "historical_2025_exposure": True,
        "2025_access_count": 0,
        "package_provenance": {
            "prelaunch_manifest_sha256": contract.get("prelaunch_manifest_sha256"),
            "effective_task_registry_sha256": contract.get("task_registry_sha256"),
            "runner_contract_sha256": contract["contract_sha256"],
            "formal_rebind_sha256": contract.get("formal_rebind_sha256"),
            "stage3_registry_rebind": contract.get(
                "stage3_registry_rebind", {}
            ),
            "source_hashes": contract.get("source_hashes", {}),
            "formal_input_hashes": contract.get("formal_input_hashes", {}),
        },
    }
    atomic_json(output_dir / "spec.json", spec)
    sealed_model_manifest = {
        "contract_version": "p1-v2-stage3a-sealed-models/1",
        "task_id": contract["task_id"],
        "runner_contract_sha256": contract["contract_sha256"],
        "fold_model_hashes": {
            name: sha256_file(output_dir / name) for name in MODEL_FILE_NAMES if "fold_" in name
        },
        "final_model": {
            "path": "models/final.bin",
            "sha256": sha256_file(output_dir / "models/final.bin"),
        },
        "reload_canary": {
            **reload_canary,
            "model_sha256": sha256_file(final_model_path),
        },
        "bert_local_snapshot": bert_snapshot,
        "no_text_model_hashes": (
            {
                name: sha256_file(output_dir / name)
                for name in NO_TEXT_MODEL_FILE_NAMES
            }
            if no_text_predictions is not None
            else {}
        ),
        "scientific_artifact": not smoke,
        "smoke": bool(smoke),
    }
    atomic_json(output_dir / "sealed_model_manifest.json", sealed_model_manifest)
    core_paths = [
        output_dir / "predictions.parquet",
        output_dir / "metrics.parquet",
        output_dir / "coverage.parquet",
        output_dir / "spec.json",
        output_dir / "canary_inputs.parquet",
        output_dir / "canary_expected.parquet",
        output_dir / "sealed_model_manifest.json",
        checkpoint_path,
        *[output_dir / name for name in MODEL_FILE_NAMES],
        *(
            [output_dir / name for name in NO_TEXT_MODEL_FILE_NAMES]
            if no_text_predictions is not None
            else []
        ),
        *extra_artifacts,
        *sorted(
            path
            for path in (output_dir / "checkpoints").rglob("*")
            if path.is_file()
        ),
        *sorted(
            path
            for path in (output_dir / "models" / "bert_local_snapshot").rglob("*")
            if path.is_file()
        ),
    ]
    for bound_name in ("runner_contract.json", "formal_rebind.json"):
        bound_path = output_dir / bound_name
        if bound_path.is_file():
            core_paths.append(bound_path)
    if target_trials:
        if smoke:
            core_paths.append(output_dir / "optuna.sqlite3")
        else:
            core_paths.extend(
                output_dir / f"optuna_{context}.sqlite3"
                for context in HPO_CONTEXTS
            )
    core_hashes = {path.relative_to(output_dir).as_posix(): sha256_file(path) for path in core_paths}
    hashes = {
        "contract_version": "p1-v2-stage3a-hash-inventory/1",
        "task_id": contract["task_id"],
        "runner_contract_sha256": contract["contract_sha256"],
        "source_hashes": contract["source_hashes"],
        "artifact_hashes": core_hashes,
    }
    atomic_json(output_dir / "hashes.json", hashes)
    artifact_hashes = {**core_hashes, "hashes.json": sha256_file(output_dir / "hashes.json")}
    manifest = {
        "contract_version": "p1-v2-stage3a-task-manifest/1",
        "task_id": contract["task_id"],
        "stage": "P1_05a",
        "wave": "W03",
        "task_family": "stage3a_model",
        "outcome": contract["outcome"],
        "model": contract["model"],
        "status": "PASS",
        "scientific_artifact": not smoke,
        "formal_training_authorized": bool(contract.get("formal_training_authorized")),
        "formal_training_launched": not smoke,
        "smoke": bool(smoke),
        "fixed_outer_folds": list(FOLDS),
        "final_model_sealed": True,
        "prediction_rows": int(len(predictions)),
        "metric_rows": int(len(metrics)),
        "runner_contract_sha256": contract["contract_sha256"],
        "artifact_hashes": artifact_hashes,
        "strict_no_arrival_leakage": True,
        "historical_2025_exposure": True,
        "2025_access_count": 0,
        "runtime_seconds": float(time.perf_counter() - started),
        "runtime": {"python": platform.python_version(), "platform": platform.platform()},
        "hardware_sha256": sha256_file(hardware_path),
        "package_provenance": spec["package_provenance"],
        "nlp_provenance": spec["nlp_provenance"],
        "consolidated_artifacts": {
            "nlp_features": nlp_path.name,
            "dl_models_oof": dl_bundle_path.name,
            "feature_selection": feature_selection_path.name,
            "no_text_predictions": (
                "no_text_predictions.parquet"
                if no_text_predictions is not None
                else None
            ),
        },
    }
    atomic_json(output_dir / "task_manifest.json", manifest)
    success = {
        "contract_version": "p1-v2-stage3a-success/1",
        "task_id": contract["task_id"],
        "status": "PASS",
        "scientific_artifact": not smoke,
        "smoke": bool(smoke),
        "manifest": "task_manifest.json",
        "manifest_sha256": sha256_file(output_dir / "task_manifest.json"),
        "artifact_hashes": artifact_hashes,
    }
    atomic_json(output_dir / "_SUCCESS.json", success)
    return success


def _metric_value(
    metric: str,
    y: np.ndarray,
    probability: np.ndarray,
    sample_weight: np.ndarray | None = None,
) -> float:
    if metric == "AUROC":
        return float(roc_auc_score(y, probability, sample_weight=sample_weight))
    if metric == "AUPRC":
        return float(
            average_precision_score(y, probability, sample_weight=sample_weight)
        )
    if metric == "Brier":
        return float(
            brier_score_loss(y, probability, sample_weight=sample_weight)
        )
    raise Stage3aContractError(f"unknown Stage3a metric: {metric}")


def _bootstrap_metric_values(
    y: np.ndarray,
    probabilities: list[np.ndarray],
    group_hash: np.ndarray,
    *,
    metric: str,
    seed: int,
    replicates: int = BOOTSTRAP_REPLICATES,
) -> list[list[float]]:
    codes, unique = pd.factorize(group_hash.astype(str), sort=True)
    if len(unique) < 2 or len(np.unique(y)) != 2:
        return [[] for _ in probabilities]
    strata = [np.unique(codes[y == outcome]) for outcome in (0, 1)]
    if any(len(indices) == 0 for indices in strata):
        return [[] for _ in probabilities]
    rng = np.random.default_rng(seed)
    values = [[] for _ in probabilities]
    for _ in range(replicates):
        counts = np.zeros(len(unique), dtype="int64")
        for indices in strata:
            sampled = rng.choice(indices, size=len(indices), replace=True)
            counts += np.bincount(sampled, minlength=len(unique))
        weights = counts[codes].astype("float64")
        for index, prediction in enumerate(probabilities):
            values[index].append(
                _metric_value(metric, y, prediction, sample_weight=weights)
            )
    if any(len(metric_values) != replicates for metric_values in values):
        raise Stage3aContractError("outcome-stratified group bootstrap lost replicates")
    return values


def _confidence_interval(values: list[float]) -> tuple[float | None, float | None]:
    if len(values) < 100:
        return None, None
    return (
        float(np.quantile(values, 0.025)),
        float(np.quantile(values, 0.975)),
    )


def _metric_rows(
    contract: dict[str, Any],
    predictions: pd.DataFrame,
    group_by_row: pd.Series | None = None,
) -> pd.DataFrame:
    rows = []
    for split, frame in predictions.groupby("split", sort=True):
        y = frame["y_true"].to_numpy(dtype="int8")
        probability = frame["prediction"].to_numpy(dtype="float64")
        if group_by_row is not None:
            mapped_groups = frame["row_hash"].astype(str).map(group_by_row)
            if mapped_groups.isna().any():
                raise Stage3aContractError(
                    "metric bootstrap group mapping is incomplete"
                )
            groups = mapped_groups.astype(str).to_numpy()
        else:
            groups = frame["row_hash"].astype(str).to_numpy()
        for metric in ("AUROC", "AUPRC", "Brier"):
            if len(np.unique(y)) != 2:
                value = None
                lower, upper = None, None
                status = "NOT_ESTIMABLE"
            else:
                point_value = _metric_value(metric, y, probability)
                bootstrap = _bootstrap_metric_values(
                    y,
                    [probability],
                    groups,
                    metric=metric,
                    seed=int(
                        hashlib.sha256(
                            f"{contract['task_id']}:{split}:{metric}".encode()
                        ).hexdigest()[:8],
                        16,
                    ),
                    replicates=(
                        BOOTSTRAP_REPLICATES
                        if contract.get("formal_training_authorized") is True
                        else 200
                    ),
                )[0]
                lower, upper = _confidence_interval(bootstrap)
                if lower is None:
                    value = None
                    status = "NOT_ESTIMABLE"
                else:
                    value = point_value
                    status = "ESTIMATED"
            rows.append(
                {
                    "task_id": contract["task_id"],
                    "outcome": contract["outcome"],
                    "model": contract["model"],
                    "split": split,
                    "metric": metric,
                    "value": value,
                    "status": status,
                    "n": int(len(frame)),
                    "events": int(y.sum()),
                    "lower_ci": lower,
                    "upper_ci": upper,
                }
            )
    return pd.DataFrame(rows, columns=METRIC_COLUMNS)


def _paired_text_metric_rows(
    contract: dict[str, Any],
    with_text: pd.DataFrame,
    no_text: pd.DataFrame,
    group_by_row: pd.Series,
) -> pd.DataFrame:
    joined = with_text.merge(
        no_text[["row_hash", "split", "y_true", "prediction"]],
        on=["row_hash", "split", "y_true"],
        how="outer",
        validate="one_to_one",
        suffixes=("_with_text", "_no_text"),
        indicator=True,
    )
    if not joined["_merge"].eq("both").all():
        raise Stage3aContractError("with/no-text prediction coverage differs")
    rows = []
    for split, frame in joined.groupby("split", sort=True):
        y = frame["y_true"].to_numpy(dtype="int8")
        with_probability = frame["prediction_with_text"].to_numpy(dtype="float64")
        without_probability = frame["prediction_no_text"].to_numpy(dtype="float64")
        groups = frame["row_hash"].astype(str).map(group_by_row)
        if groups.isna().any() or len(np.unique(y)) != 2:
            values = {
                "AUPRC_no_text": (None, None, None),
                "Delta_AUPRC_text_minus_no_text": (None, None, None),
            }
        else:
            bootstrap = _bootstrap_metric_values(
                y,
                [with_probability, without_probability],
                groups.to_numpy(dtype=str),
                metric="AUPRC",
                seed=int(
                    hashlib.sha256(
                        f"{contract['task_id']}:{split}:paired_text_delta".encode()
                    ).hexdigest()[:8],
                    16,
                ),
                replicates=(
                    BOOTSTRAP_REPLICATES
                    if contract.get("formal_training_authorized") is True
                    else 200
                ),
            )
            no_text_value = _metric_value("AUPRC", y, without_probability)
            delta_value = _metric_value("AUPRC", y, with_probability) - no_text_value
            no_text_interval = _confidence_interval(bootstrap[1])
            delta_interval = _confidence_interval(
                [left - right for left, right in zip(bootstrap[0], bootstrap[1])]
            )
            values = {
                "AUPRC_no_text": (
                    (no_text_value, *no_text_interval)
                    if no_text_interval[0] is not None
                    else (None, None, None)
                ),
                "Delta_AUPRC_text_minus_no_text": (
                    (delta_value, *delta_interval)
                    if delta_interval[0] is not None
                    else (None, None, None)
                ),
            }
        for metric, (value, lower, upper) in values.items():
            rows.append(
                {
                    "task_id": contract["task_id"],
                    "outcome": contract["outcome"],
                    "model": contract["model"],
                    "split": split,
                    "metric": metric,
                    "value": value,
                    "status": "ESTIMATED" if lower is not None else "NOT_ESTIMABLE",
                    "n": int(len(frame)),
                    "events": int(y.sum()),
                    "lower_ci": lower,
                    "upper_ci": upper,
                }
            )
    return pd.DataFrame(rows, columns=METRIC_COLUMNS)


def _validate_development_frame(frame: pd.DataFrame, label: str) -> None:
    if "split_year" in frame:
        years = pd.to_numeric(frame["split_year"], errors="coerce")
        if years.isna().any() or years.gt(2024).any():
            raise Stage3aContractError(f"{label} contains future/invalid years")
    if "split" in frame:
        observed = set(frame["split"].dropna().astype(str))
        if not observed <= {"train_2020_2023", "validation_2024", "oof_2020_2023"}:
            raise Stage3aContractError(f"{label} contains forbidden split values")
    if any("2025" in str(column).casefold() for column in frame.columns):
        raise Stage3aContractError(f"{label} contains a future-holdout column")
    if "row_hash" in frame and frame["row_hash"].astype(str).duplicated().any():
        raise Stage3aContractError(f"{label} contains duplicate row hashes")


def _validate_upstream_predictions(
    path: Path,
    *,
    outcome: str,
    model: str,
    expected_rows: pd.DataFrame,
) -> pd.Series:
    frame = pd.read_parquet(path)
    required = set(PREDICTION_COLUMNS)
    if not required <= set(frame.columns):
        raise Stage3aContractError(f"accepted {model} predictions have schema drift")
    _validate_development_frame(frame, f"accepted {model} predictions")
    expected_task_id = f"P1_05a-{outcome}-{model}"
    if (
        set(frame["task_id"].astype(str)) != {expected_task_id}
        or set(frame["outcome"].astype(str)) != {outcome}
        or set(frame["model"].astype(str)) != {model}
    ):
        raise Stage3aContractError(f"accepted {model} predictions have identity drift")
    if set(frame["split"].astype(str)) != {"oof_2020_2023", "validation_2024"}:
        raise Stage3aContractError(f"accepted {model} predictions lack OOF/final splits")
    if frame.duplicated(["row_hash", "outcome", "model", "split"]).any():
        raise Stage3aContractError(f"accepted {model} predictions contain duplicates")
    joined = expected_rows[["row_hash", "split", "label", "fold"]].merge(
        frame[["row_hash", "split", "fold", "y_true", "prediction"]],
        on=["row_hash", "split"],
        how="outer",
        validate="one_to_one",
        suffixes=("_expected", "_actual"),
        indicator=True,
    )
    if not joined["_merge"].eq("both").all():
        raise Stage3aContractError(f"accepted {model} prediction key coverage differs")
    if not np.array_equal(
        joined["label"].to_numpy(dtype="int8"),
        joined["y_true"].to_numpy(dtype="int8"),
    ):
        raise Stage3aContractError(f"accepted {model} labels differ")
    oof = joined["split"].eq("oof_2020_2023")
    if not np.array_equal(
        pd.to_numeric(joined.loc[oof, "fold_expected"], errors="raise").to_numpy(dtype="int8"),
        pd.to_numeric(joined.loc[oof, "fold_actual"], errors="raise").to_numpy(dtype="int8"),
    ):
        raise Stage3aContractError(f"accepted {model} folds differ")
    probability = pd.to_numeric(joined["prediction"], errors="coerce")
    if probability.isna().any() or not probability.between(0, 1).all():
        raise Stage3aContractError(f"accepted {model} predictions are invalid")
    return pd.Series(
        probability.to_numpy(dtype="float64"),
        index=joined["row_hash"].astype(str),
        name=f"nlp_{model}",
    )


def generate_bge_m3_embeddings(
    text: pd.DataFrame,
    *,
    device: str,
    encoder: Any | None = None,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    required = {"row_hash", "emt_text_sanitized", "is_text_missing"}
    if not required <= set(text.columns):
        raise Stage3aContractError("Stage1a text lacks BGE input columns")
    if text["row_hash"].astype(str).duplicated().any():
        raise Stage3aContractError("Stage1a text has duplicate BGE row keys")
    missing = pd.to_numeric(text["is_text_missing"], errors="coerce")
    if missing.isna().any() or not missing.isin([0, 1]).all():
        raise Stage3aContractError("Stage1a text missing flag is invalid")
    if encoder is None:
        from sentence_transformers import SentenceTransformer

        encoder = SentenceTransformer(BGE_MODEL, device=device)
    dimension = int(encoder.get_sentence_embedding_dimension())
    if dimension != BGE_DIMENSION:
        raise Stage3aContractError(
            f"{BGE_MODEL} embedding dimension differs: {dimension}"
        )
    matrix = np.zeros((len(text), BGE_DIMENSION), dtype="float32")
    observed = missing.eq(0).to_numpy()
    observed_text = (
        text.loc[observed, "emt_text_sanitized"].fillna("").astype(str).tolist()
    )
    if observed_text:
        encoded = np.asarray(
            encoder.encode(
                observed_text,
                batch_size=64,
                show_progress_bar=False,
                convert_to_numpy=True,
                normalize_embeddings=True,
            ),
            dtype="float32",
        )
        if encoded.shape != (len(observed_text), BGE_DIMENSION):
            raise Stage3aContractError("BAAI/bge-m3 output shape differs")
        matrix[observed] = encoded
    if not np.equal(matrix[~observed], 0.0).all():
        raise Stage3aContractError("missing text BGE rows are not exact zero vectors")
    columns = [f"bge_m3_{index:04d}" for index in range(BGE_DIMENSION)]
    features = pd.DataFrame(matrix, columns=columns)
    features.insert(0, "row_hash", text["row_hash"].astype(str).to_numpy())
    features["is_text_missing"] = missing.to_numpy(dtype="int8")
    model = getattr(encoder, "_first_module", lambda: None)()
    config = getattr(getattr(model, "auto_model", None), "config", None)
    provenance = {
        "model": BGE_MODEL,
        "embedding_dimension": BGE_DIMENSION,
        "weights_frozen": True,
        "normalized": True,
        "missing_text_policy": "exact_zero_vector_plus_is_text_missing",
        "model_commit_hash": getattr(config, "_commit_hash", None),
        "model_name_or_path": getattr(config, "_name_or_path", BGE_MODEL),
    }
    return features, provenance


def load_formal_training_data(
    contract: dict[str, Any], rebind: dict[str, Any], *, device: str
) -> tuple[
    pd.DataFrame,
    pd.DataFrame,
    list[str],
    pd.DataFrame | None,
    dict[str, Any],
    list[str],
]:
    inputs = {
        role: Path(str(record["path"])).resolve()
        for role, record in rebind["input_artifacts"].items()
    }
    schema = read_json(inputs["stage1a_schema"])
    feature_order = [
        str(record["name"])
        for record in schema.get("features", [])
        if record.get("model_feature") is True
    ]
    if len(feature_order) != int(schema.get("model_feature_count", -1)):
        raise Stage3aContractError("Stage1a schema model-feature count differs")
    target = f"y_{contract['outcome']}"
    metadata = ["row_hash", "group_hash", "split_year", "split", target]
    if contract["model"] in {"mlp_plr", "ft_transformer"}:
        feature_frame = pd.read_parquet(
            inputs["stage1a_features"], columns=[*metadata, *feature_order]
        )
    else:
        feature_frame = pd.read_parquet(inputs["stage1a_features"], columns=metadata)
    _validate_development_frame(feature_frame, "Stage1a formal features")
    if set(feature_frame["split"].astype(str)) != {"train_2020_2023", "validation_2024"}:
        raise Stage3aContractError("Stage1a formal features lack the exact train/validation split")
    fold_map = pd.read_parquet(inputs["fold_map"])
    fold_map = fold_map.loc[
        fold_map["outcome"].astype(str).eq(contract["outcome"]),
        ["row_hash", "fold", "split_year"],
    ].copy()
    _validate_development_frame(fold_map, "fixed fold map")
    if fold_map["row_hash"].astype(str).duplicated().any():
        raise Stage3aContractError("fixed fold map has duplicate outcome rows")
    train = feature_frame.loc[feature_frame["split"].eq("train_2020_2023")].merge(
        fold_map[["row_hash", "fold"]],
        on="row_hash",
        how="left",
        validate="one_to_one",
    )
    validation = feature_frame.loc[feature_frame["split"].eq("validation_2024")].copy()
    validation["fold"] = pd.array([pd.NA] * len(validation), dtype="Int8")
    if train["fold"].isna().any() or sorted(train["fold"].astype(int).unique().tolist()) != list(FOLDS):
        raise Stage3aContractError("formal training rows lack the exact five fixed folds")
    train["fold"] = train["fold"].astype("int8")
    train = train.rename(columns={target: "label"})
    validation = validation.rename(columns={target: "label"})
    expected_rows = pd.concat(
        [
            train[["row_hash", "split", "label", "fold"]],
            validation[["row_hash", "split", "label", "fold"]],
        ],
        ignore_index=True,
    )
    expected_rows.loc[
        expected_rows["split"].eq("train_2020_2023"), "split"
    ] = "oof_2020_2023"
    nlp_features = None
    nlp_provenance: dict[str, Any] = {}
    if contract["model"] == "frozen_embedding":
        text = pd.read_parquet(inputs["stage1a_text"])
        _validate_development_frame(text, "Stage1a formal text")
        embedding_path, nlp_provenance = validate_shared_bge_artifact(
            contract["shared_embedding_artifact"],
            stage1a_text_path=inputs["stage1a_text"],
            stage1a_text_sha256=contract["formal_input_hashes"]["stage1a_text"],
        )
        embedding = pd.read_parquet(embedding_path)
        feature_order = [
            column for column in embedding.columns if column != "row_hash"
        ]
        nlp_features = text[["row_hash", "split", "split_year"]].merge(
            embedding, on="row_hash", how="left", validate="one_to_one"
        )
        for frame_name, frame in (("train", train), ("validation", validation)):
            merged = frame.merge(
                embedding[["row_hash", *feature_order]],
                on="row_hash",
                how="left",
                validate="one_to_one",
            )
            if merged[feature_order].isna().all(axis=1).any():
                raise Stage3aContractError(
                    f"generated frozen embedding misses {frame_name} rows"
                )
            if frame_name == "train":
                train = merged
            else:
                validation = merged
    elif contract["model"] == "bert_finetuned":
        text = pd.read_parquet(inputs["stage1a_text"])
        _validate_development_frame(text, "Stage1a formal text")
        text_columns = ["row_hash", "emt_text_sanitized", "is_text_missing"]
        if any(column not in text for column in text_columns):
            raise Stage3aContractError("Stage1a formal text schema differs")
        train = train.merge(text[text_columns], on="row_hash", how="left", validate="one_to_one")
        validation = validation.merge(
            text[text_columns], on="row_hash", how="left", validate="one_to_one"
        )
        if train["is_text_missing"].isna().any() or validation["is_text_missing"].isna().any():
            raise Stage3aContractError("Stage1a formal text key coverage differs")
        train["emt_text_sanitized"] = train["emt_text_sanitized"].fillna("").astype(str)
        validation["emt_text_sanitized"] = validation["emt_text_sanitized"].fillna("").astype(str)
        feature_order = ["emt_text_sanitized", "is_text_missing"]
        nlp_provenance = {
            "model": contract["family_plan"]["text_model"],
            "missing_flag_is_model_input": True,
            "checkpoint_selection_metric": "AUPRC",
        }
    else:
        for upstream_model, role in (
            ("frozen_embedding", "frozen_embedding_predictions"),
            ("bert_finetuned", "bert_finetuned_predictions"),
        ):
            probability = _validate_upstream_predictions(
                inputs[role],
                outcome=contract["outcome"],
                model=upstream_model,
                expected_rows=expected_rows,
            )
            name = probability.name
            assert name is not None
            train[name] = train["row_hash"].astype(str).map(probability)
            validation[name] = validation["row_hash"].astype(str).map(probability)
            if train[name].isna().any() or validation[name].isna().any():
                raise Stage3aContractError(f"accepted {upstream_model} prediction join differs")
            feature_order.append(name)
        nlp_features = pd.concat(
            [
                train[["row_hash", "split", *[name for name in feature_order if name.startswith("nlp_")]]],
                validation[["row_hash", "split", *[name for name in feature_order if name.startswith("nlp_")]]],
            ],
            ignore_index=True,
        )
        nlp_provenance = {
            "sources": ["frozen_embedding", "bert_finetuned"],
            "source_predictions_hash_bound": True,
        }
    expected_counts = read_json(inputs["stage1a_manifest"])["cohort_split_counts"]
    if len(train) != int(expected_counts["train_2020_2023"]):
        raise Stage3aContractError("formal training cohort count differs from Stage1a manifest")
    if len(validation) != int(expected_counts["validation_2024"]):
        raise Stage3aContractError("formal validation cohort count differs from Stage1a manifest")
    if train["label"].isin([0, 1]).ne(True).any() or validation["label"].isin([0, 1]).ne(True).any():
        raise Stage3aContractError("formal outcome labels are not binary")
    no_text_feature_order = (
        _no_text_feature_order(feature_order, schema)
        if contract["model"] in HPO_MODELS
        else []
    )
    if no_text_feature_order:
        nlp_provenance["no_text_feature_order_sha256"] = canonical_sha256(
            no_text_feature_order
        )
        nlp_provenance["no_text_removed_features"] = [
            feature for feature in feature_order if feature not in no_text_feature_order
        ]
    return (
        train,
        validation,
        feature_order,
        nlp_features,
        nlp_provenance,
        no_text_feature_order,
    )


def training_only_selection_split(
    train: pd.DataFrame,
    selection_context: str,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    if selection_context not in HPO_CONTEXTS:
        raise Stage3aContractError("selection context is invalid")
    if selection_context == "final":
        candidate = train
        outer_fold = None
        validation_fold = 0
    else:
        outer_fold = int(selection_context.removeprefix("outer_"))
        candidate = train.loc[train["fold"].ne(outer_fold)]
        validation_fold = (outer_fold + 1) % len(FOLDS)
    selection_train = candidate.loc[candidate["fold"].ne(validation_fold)].copy()
    selection_validation = candidate.loc[
        candidate["fold"].eq(validation_fold)
    ].copy()
    if selection_train.empty or selection_validation.empty:
        raise Stage3aContractError("training-only selection split is empty")
    if (
        selection_train["label"].nunique() != 2
        or selection_validation["label"].nunique() != 2
    ):
        raise Stage3aContractError("training-only selection split lacks both classes")
    train_groups = set(selection_train["group_hash"].astype(str))
    validation_groups = set(selection_validation["group_hash"].astype(str))
    overlap = train_groups & validation_groups
    outer_rows = (
        set(train.loc[train["fold"].eq(outer_fold), "row_hash"].astype(str))
        if outer_fold is not None
        else set()
    )
    selection_rows = set(candidate["row_hash"].astype(str))
    if overlap or outer_rows & selection_rows:
        raise Stage3aContractError("selection split is not outer/group disjoint")
    evidence = {
        "contract_version": "p1-v2-stage3a-training-only-selection/1",
        "selection_context": selection_context,
        "outer_validation_fold": outer_fold,
        "inner_validation_fold": validation_fold,
        "selection_train_folds": sorted(
            selection_train["fold"].astype(int).unique().tolist()
        ),
        "selection_validation_folds": [validation_fold],
        "selection_train_rows": int(len(selection_train)),
        "selection_validation_rows": int(len(selection_validation)),
        "selection_train_groups": len(train_groups),
        "selection_validation_groups": len(validation_groups),
        "patient_group_overlap": 0,
        "outer_validation_rows_read_for_selection": 0,
        "validation_2024_rows_read_for_selection": 0,
        "maximum_selection_year": int(selection_train["split_year"].max()),
    }
    return selection_train, selection_validation, evidence


def _bert_predict_probability(
    model: Any,
    tokenizer: Any,
    values: pd.DataFrame,
    *,
    device: str,
    batch_size: int,
    max_length: int,
) -> np.ndarray:
    import torch

    model.eval()
    texts = values["emt_text_sanitized"].fillna("").astype(str).tolist()
    missing = pd.to_numeric(
        values["is_text_missing"], errors="raise"
    ).to_numpy(dtype="float32")
    outputs = []
    with torch.no_grad():
        for start in range(0, len(values), batch_size):
            encoded = tokenizer(
                texts[start : start + batch_size],
                padding=True,
                truncation=True,
                max_length=max_length,
                return_tensors="pt",
            )
            flag = torch.from_numpy(missing[start : start + batch_size]).to(device)
            logits = model(
                encoded["input_ids"].to(device),
                encoded["attention_mask"].to(device),
                flag,
            )
            outputs.append(torch.sigmoid(logits).detach().cpu().numpy())
    return np.concatenate(outputs).astype("float64")


def _new_bert_training_objects(
    model_name: str,
    train_y: np.ndarray,
    *,
    device: str,
    learning_rate: float,
    seed: int,
) -> tuple[Any, Any, Any, Any]:
    import torch
    from transformers import AutoTokenizer

    torch.manual_seed(seed)
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = build_bert_missing_flag_model(model_name=model_name).to(device)
    positive = max(1.0, float(train_y.sum()))
    negative = max(1.0, float(len(train_y) - train_y.sum()))
    criterion = torch.nn.BCEWithLogitsLoss(
        pos_weight=torch.tensor(
            [negative / positive], dtype=torch.float32, device=device
        )
    )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=learning_rate, weight_decay=0.01
    )
    return model, tokenizer, criterion, optimizer


def _train_one_bert_epoch(
    model: Any,
    tokenizer: Any,
    criterion: Any,
    optimizer: Any,
    train_x: pd.DataFrame,
    train_y: np.ndarray,
    *,
    device: str,
    batch_size: int,
    max_length: int,
    rng: np.random.Generator,
) -> None:
    import torch

    order = np.arange(len(train_x))
    rng.shuffle(order)
    texts = train_x["emt_text_sanitized"].fillna("").astype(str).tolist()
    missing = pd.to_numeric(
        train_x["is_text_missing"], errors="raise"
    ).to_numpy(dtype="float32")
    model.train()
    for start in range(0, len(order), batch_size):
        indexes = order[start : start + batch_size]
        encoded = tokenizer(
            [texts[index] for index in indexes],
            padding=True,
            truncation=True,
            max_length=max_length,
            return_tensors="pt",
        )
        flag = torch.from_numpy(missing[indexes]).to(device)
        labels = torch.from_numpy(train_y[indexes].astype("float32")).to(device)
        optimizer.zero_grad(set_to_none=True)
        logits = model(
            encoded["input_ids"].to(device),
            encoded["attention_mask"].to(device),
            flag,
        )
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()


def select_bert_epoch(
    contract: dict[str, Any],
    selection_train: pd.DataFrame,
    selection_validation: pd.DataFrame,
    *,
    device: str,
    seed: int,
) -> tuple[int, list[dict[str, Any]]]:
    model, tokenizer, criterion, optimizer = _new_bert_training_objects(
        str(contract["family_plan"]["text_model"]),
        selection_train["label"].to_numpy(dtype="int8"),
        device=device,
        learning_rate=2e-5,
        seed=seed,
    )
    rng = np.random.default_rng(seed)
    values = []
    for epoch in range(1, BERT_MAX_EPOCHS + 1):
        _train_one_bert_epoch(
            model,
            tokenizer,
            criterion,
            optimizer,
            selection_train,
            selection_train["label"].to_numpy(dtype="int8"),
            device=device,
            batch_size=16,
            max_length=192,
            rng=rng,
        )
        probability = _bert_predict_probability(
            model,
            tokenizer,
            selection_validation,
            device=device,
            batch_size=64,
            max_length=192,
        )
        values.append(
            {
                "epoch": epoch,
                "selection_auprc": float(
                    average_precision_score(
                        selection_validation["label"].to_numpy(dtype="int8"),
                        probability,
                    )
                ),
            }
        )
    best = max(values, key=lambda value: (value["selection_auprc"], -value["epoch"]))
    return int(best["epoch"]), values


def fit_bert_epochs(
    contract: dict[str, Any],
    train_x: pd.DataFrame,
    train_y: np.ndarray,
    evaluate_x: pd.DataFrame,
    *,
    epochs: int,
    device: str,
    seed: int,
) -> tuple[BertModelBundle, np.ndarray]:
    model, tokenizer, criterion, optimizer = _new_bert_training_objects(
        str(contract["family_plan"]["text_model"]),
        train_y,
        device=device,
        learning_rate=2e-5,
        seed=seed,
    )
    rng = np.random.default_rng(seed)
    for _ in range(epochs):
        _train_one_bert_epoch(
            model,
            tokenizer,
            criterion,
            optimizer,
            train_x,
            train_y,
            device=device,
            batch_size=16,
            max_length=192,
            rng=rng,
        )
    probability = _bert_predict_probability(
        model,
        tokenizer,
        evaluate_x,
        device=device,
        batch_size=64,
        max_length=192,
    )
    bundle = BertModelBundle(
        tokenizer=tokenizer,
        config=model.encoder.config.to_dict(),
        state_dict={
            key: value.detach().cpu() for key, value in model.state_dict().items()
        },
        max_length=192,
        batch_size=64,
    )
    model.cpu()
    return bundle, probability


def _torch_train(
    model: Any,
    matrix: np.ndarray,
    labels: np.ndarray,
    *,
    epochs: int,
    batch_size: int,
    learning_rate: float,
    weight_decay: float,
    device: str,
    seed: int,
    evaluation_matrix: np.ndarray | None = None,
    evaluation_labels: np.ndarray | None = None,
    trial: Any | None = None,
) -> list[float]:
    import torch
    from torch.utils.data import DataLoader, TensorDataset

    torch.manual_seed(seed)
    model.to(device)
    labels = labels.astype("float32")
    positive = max(1.0, float(labels.sum()))
    negative = max(1.0, float(len(labels) - labels.sum()))
    criterion = torch.nn.BCEWithLogitsLoss(
        pos_weight=torch.tensor([negative / positive], dtype=torch.float32, device=device)
    )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=learning_rate, weight_decay=weight_decay
    )
    loader = DataLoader(
        TensorDataset(
            torch.from_numpy(matrix.astype("float32")),
            torch.from_numpy(labels),
        ),
        batch_size=batch_size,
        shuffle=True,
    )
    epoch_scores: list[float] = []
    for epoch in range(epochs):
        model.train()
        for batch_x, batch_y in loader:
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(batch_x.to(device)), batch_y.to(device))
            loss.backward()
            optimizer.step()
        if trial is not None:
            if evaluation_matrix is None or evaluation_labels is None:
                raise Stage3aContractError(
                    "Optuna epoch reporting lacks inner-validation data"
                )
            model.eval()
            with torch.no_grad():
                probability = np.concatenate(
                    [
                        torch.sigmoid(
                            model(
                                torch.from_numpy(
                                    evaluation_matrix[start : start + batch_size].astype(
                                        "float32"
                                    )
                                ).to(device)
                            )
                        )
                        .detach()
                        .cpu()
                        .numpy()
                        for start in range(0, len(evaluation_matrix), batch_size)
                    ]
                )
            score = float(
                average_precision_score(
                    np.asarray(evaluation_labels, dtype="int8"), probability
                )
            )
            epoch_scores.append(score)
            trial.report(score, step=epoch)
            if trial.should_prune():
                import optuna

                model.cpu().eval()
                raise optuna.TrialPruned()
    model.cpu().eval()
    return epoch_scores


def select_ft_features_training_only(
    train_x: pd.DataFrame,
    train_y: np.ndarray,
) -> tuple[list[str], dict[str, Any]]:
    candidates = list(train_x.columns)
    if len(candidates) <= FT_MAX_FEATURES:
        selected = candidates
        scores = {feature: None for feature in selected}
        method = "all_candidates_within_locked_limit"
    else:
        labels = np.asarray(train_y, dtype="int8")
        if len(np.unique(labels)) != 2:
            raise Stage3aContractError(
                "FT training-only feature selection lacks both classes"
            )
        scored = []
        for position, feature in enumerate(candidates):
            values = pd.to_numeric(train_x[feature], errors="coerce")
            median = values.median()
            fill_value = float(median) if pd.notna(median) else 0.0
            array = values.fillna(fill_value).to_numpy(dtype="float64")
            standard_deviation = float(np.std(array))
            if not np.isfinite(standard_deviation) or standard_deviation == 0:
                score = 0.0
            else:
                score = abs(
                    float(array[labels == 1].mean())
                    - float(array[labels == 0].mean())
                ) / standard_deviation
            priority = 0 if feature in TEXT_DERIVED_FEATURES else 1
            scored.append((priority, -score, position, feature, score))
        ranked = sorted(scored)
        selected = [value[3] for value in ranked[:FT_MAX_FEATURES]]
        scores = {value[3]: float(value[4]) for value in ranked[:FT_MAX_FEATURES]}
        method = "fold_local_training_only_standardized_mean_difference"
    evidence = {
        "contract_version": "p1-v2-stage3a-ft-feature-selection/1",
        "method": method,
        "candidate_feature_count": len(candidates),
        "selected_feature_count": len(selected),
        "maximum_features": FT_MAX_FEATURES,
        "selected_features": selected,
        "selected_feature_scores": scores,
        "candidate_features_sha256": canonical_sha256(candidates),
        "selected_features_sha256": canonical_sha256(selected),
        "selection_fit_scope": "current_training_rows_only",
        "held_out_rows_read": 0,
        "validation_2024_rows_read": 0,
        "silent_positional_truncation": False,
    }
    return selected, evidence


def write_ft_feature_selection_artifact(
    output_dir: Path,
    contract: dict[str, Any],
    model: TorchTabularModelBundle,
    *,
    context: str,
    no_text: bool,
) -> Path:
    if model.family != "ft_transformer":
        raise Stage3aContractError("FT selection artifact received another model")
    evidence = model.model_config.get("feature_selection")
    if not isinstance(evidence, dict):
        raise Stage3aContractError("FT model lacks feature-selection evidence")
    value = {
        **evidence,
        "task_id": contract["task_id"],
        "runner_contract_sha256": contract["contract_sha256"],
        "selection_context": context,
        "no_text": no_text,
    }
    prefix = "no_text_ft_feature_selection" if no_text else "ft_feature_selection"
    path = output_dir / "checkpoints" / f"{prefix}_{context}.json"
    atomic_json(path, value)
    return path


def fit_formal_model(
    contract: dict[str, Any],
    train_x: pd.DataFrame,
    train_y: np.ndarray,
    evaluate_x: pd.DataFrame,
    *,
    params: dict[str, Any],
    device: str,
    seed: int,
    hpo_trial: bool = False,
    trial: Any | None = None,
    evaluate_y: np.ndarray | None = None,
) -> tuple[Any, np.ndarray]:
    model_name = contract["model"]
    if len(np.unique(train_y)) != 2:
        raise Stage3aContractError("formal fit subset lacks both outcome classes")
    if model_name == "frozen_embedding":
        component_count = min(128, train_x.shape[1], max(1, len(train_x) - 1))
        model = Pipeline(
            [
                ("imputer", SimpleImputer(strategy="constant", fill_value=0.0)),
                ("scaler", StandardScaler()),
                ("pca", PCA(n_components=component_count, random_state=seed)),
                (
                    "model",
                    LogisticRegression(
                        max_iter=2000,
                        class_weight="balanced",
                        solver="lbfgs",
                        random_state=seed,
                    ),
                ),
            ]
        )
        model.fit(train_x, train_y)
        model.feature_order_ = list(train_x.columns)
        probability = model.predict_proba(evaluate_x)[:, 1]
        return model, np.asarray(probability, dtype="float64")
    if model_name == "bert_finetuned":
        epochs = int(params.get("bert_epochs", 1 if hpo_trial else BERT_MAX_EPOCHS))
        if not 1 <= epochs <= BERT_MAX_EPOCHS:
            raise Stage3aContractError("selected BERT epoch is outside the locked range")
        return fit_bert_epochs(
            contract,
            train_x,
            train_y,
            evaluate_x,
            epochs=epochs,
            device=device,
            seed=seed,
        )
    from scripts import run_stage3a as legacy

    mode = "mlp_plr" if model_name == "mlp_plr" else "ft"
    ft_feature_selection = None
    if model_name == "ft_transformer":
        selected, ft_feature_selection = select_ft_features_training_only(
            train_x, train_y
        )
        train_x = train_x.loc[:, selected]
        evaluate_x = evaluate_x.loc[:, selected]
    bins = int(params.get("plr_bins", 16))
    transformed_train, transformed_evaluate, preprocessor = legacy.fit_tabular_preprocessor(
        train_x.apply(pd.to_numeric, errors="coerce"),
        evaluate_x.apply(pd.to_numeric, errors="coerce"),
        mode,
        bins,
    )
    if model_name == "mlp_plr":
        model_config = {
            "plr_bins": bins,
            "d_main": int(params.get("d_main", 128)),
            "dropout": float(params.get("dropout", 0.2)),
            "lr": float(params.get("lr", 1e-3)),
            "weight_decay": float(params.get("weight_decay", 1e-4)),
        }
        model = legacy.MLPPLR(
            transformed_train.shape[1],
            hidden=model_config["d_main"],
            dropout=model_config["dropout"],
        )
    else:
        model_config = {
            "d_token": int(params.get("d_token", 128)),
            "n_heads": int(params.get("n_heads", 8)),
            "n_blocks": int(params.get("n_blocks", 2)),
            "attention_dropout": float(params.get("attention_dropout", 0.1)),
            "lr": 1e-3,
            "weight_decay": 1e-4,
            "feature_selection": ft_feature_selection,
        }
        model = legacy.TinyFTTransformer(
            transformed_train.shape[1],
            d_token=model_config["d_token"],
            n_heads=model_config["n_heads"],
            n_layers=model_config["n_blocks"],
            dropout=model_config["attention_dropout"],
        )
    _torch_train(
        model,
        transformed_train,
        train_y,
        epochs=TABULAR_TRAINING_EPOCHS,
        batch_size=512,
        learning_rate=float(model_config["lr"]),
        weight_decay=float(model_config["weight_decay"]),
        device=device,
        seed=seed,
        evaluation_matrix=transformed_evaluate if trial is not None else None,
        evaluation_labels=evaluate_y if trial is not None else None,
        trial=trial,
    )
    bundle = TorchTabularModelBundle(
        family=model_name,
        feature_order=list(train_x.columns),
        preprocessor=preprocessor,
        model_config=model_config,
        state_dict={key: value.detach().cpu() for key, value in model.state_dict().items()},
    )
    return bundle, bundle.predict_proba(evaluate_x)[:, 1]


def run_locked_optuna(
    contract: dict[str, Any],
    train: pd.DataFrame,
    feature_order: list[str],
    output_dir: Path,
    *,
    selection_context: str,
    device: str,
    seed: int,
) -> tuple[dict[str, Any], pd.DataFrame, dict[str, Any]]:
    import optuna

    selection_train, selection_validation, selection = (
        training_only_selection_split(train, selection_context)
    )
    storage_path = output_dir / f"optuna_{selection_context}.sqlite3"
    storage = f"sqlite:///{storage_path.as_posix()}"
    storage_backend = optuna.storages.RDBStorage(url=storage)
    study = optuna.create_study(
        study_name=f"{contract['task_id']}:{selection_context}",
        storage=storage_backend,
        direction="maximize",
        sampler=optuna.samplers.TPESampler(seed=seed),
        pruner=optuna.pruners.MedianPruner(
            n_startup_trials=OPTUNA_PRUNER["n_startup_trials"],
            n_warmup_steps=OPTUNA_PRUNER["n_warmup_steps"],
            interval_steps=OPTUNA_PRUNER["interval_steps"],
        ),
        load_if_exists=True,
    )
    binding = {
        "runner_contract_sha256": contract["contract_sha256"],
        "task_id": contract["task_id"],
        "selection_context": selection_context,
        "selection_contract_sha256": canonical_sha256(selection),
        "target_trials": 50,
        "accepted_trial_states": ["COMPLETE", "PRUNED"],
        "pruner": OPTUNA_PRUNER,
        "training_epochs_per_trial_and_final": TABULAR_TRAINING_EPOCHS,
        "maximum_year": 2024,
        "outer_validation_rows_read_for_selection": 0,
        "validation_2024_rows_read_for_selection": 0,
    }
    for key, value in binding.items():
        existing = study.user_attrs.get(key)
        if existing not in (None, value):
            raise Stage3aContractError(f"Optuna study binding mismatch: {key}")
        if existing is None:
            study.set_user_attr(key, value)
    allowed_states = {
        optuna.trial.TrialState.COMPLETE,
        optuna.trial.TrialState.PRUNED,
    }
    if any(trial.state not in allowed_states for trial in study.trials) or len(study.trials) > 50:
        raise Stage3aContractError("Optuna study has failed/running/extra trials")

    def objective(trial: Any) -> float:
        if contract["model"] == "mlp_plr":
            params = {
                "lr": trial.suggest_float("lr", 1e-5, 1e-2, log=True),
                "weight_decay": trial.suggest_float("weight_decay", 1e-7, 1e-2, log=True),
                "plr_bins": trial.suggest_categorical("plr_bins", [8, 16, 32, 48, 64]),
                "d_main": trial.suggest_int("d_main", 64, 512, step=64),
                "dropout": trial.suggest_float("dropout", 0.0, 0.5),
            }
        else:
            params = {
                "n_blocks": trial.suggest_int("n_blocks", 1, 4),
                "d_token": trial.suggest_categorical("d_token", [64, 128, 192, 256]),
                "n_heads": trial.suggest_categorical("n_heads", [4, 8]),
                "attention_dropout": trial.suggest_float("attention_dropout", 0.0, 0.4),
            }
        _, probability = fit_formal_model(
            contract,
            selection_train[feature_order],
            selection_train["label"].to_numpy(dtype="int8"),
            selection_validation[feature_order],
            params=params,
            device=device,
            seed=seed + int(trial.number),
            hpo_trial=True,
            trial=trial,
            evaluate_y=selection_validation["label"].to_numpy(dtype="int8"),
        )
        return float(
            average_precision_score(
                selection_validation["label"].to_numpy(dtype="int8"),
                probability,
            )
        )

    remaining = 50 - len(study.trials)
    if remaining:
        study.optimize(objective, n_trials=remaining, catch=())
    complete = [trial for trial in study.trials if trial.state == optuna.trial.TrialState.COMPLETE]
    pruned = [trial for trial in study.trials if trial.state == optuna.trial.TrialState.PRUNED]
    if (
        len(study.trials) != 50
        or not complete
        or len(complete) + len(pruned) != 50
    ):
        raise Stage3aContractError(
            "formal MLP/FT HPO did not finish exactly 50 COMPLETE/PRUNED attempts"
        )
    rows = [
        {
            "trial_number": int(trial.number),
            "selection_context": selection_context,
            "state": trial.state.name,
            "value": (
                float(trial.value)
                if trial.value is not None
                else float("nan")
            ),
            "params_json": json.dumps(trial.params, sort_keys=True),
        }
        for trial in sorted(study.trials, key=lambda value: value.number)
    ]
    trials = pd.DataFrame(rows)
    atomic_parquet(
        output_dir / "checkpoints" / f"optuna_{selection_context}_trials.parquet",
        trials,
    )
    best_trial = int(study.best_trial.number)
    best_value = float(study.best_value)
    best_params = dict(study.best_params)
    storage_backend.remove_session()
    storage_backend.engine.dispose()
    evidence = {
        **selection,
        "selection_method": "optuna_training_only_group_disjoint_inner_validation",
        "selection_metric": "AUPRC",
        "trials_attempted_required": 50,
        "trials_attempted": 50,
        "trials_completed": len(complete),
        "trials_pruned": len(pruned),
        "accepted_trial_states": ["COMPLETE", "PRUNED"],
        "pruner": OPTUNA_PRUNER,
        "training_epochs_per_trial_and_final": TABULAR_TRAINING_EPOCHS,
        "best_trial": best_trial,
        "best_value": best_value,
        "best_params": best_params,
        "study_storage": storage_path.name,
        "study_sha256": sha256_file(storage_path),
    }
    atomic_json(
        output_dir / "checkpoints" / f"selection_{selection_context}.json",
        evidence,
    )
    return best_params, trials, evidence


def _no_text_feature_order(
    feature_order: list[str], stage1a_schema: dict[str, Any]
) -> list[str]:
    text_features = {"nlp_frozen_embedding", "nlp_bert_finetuned"}
    if not text_features.issubset(feature_order):
        raise Stage3aContractError(
            "structured Stage3a model lacks both hash-bound NLP inputs"
        )
    records = {
        str(record.get("name")): record
        for record in stage1a_schema.get("features", [])
        if isinstance(record, dict) and record.get("model_feature") is True
    }
    keyword_records = [
        record for name, record in records.items() if name.startswith("kw_")
    ]
    if len(keyword_records) != 8:
        raise Stage3aContractError(
            "Stage1a schema does not identify the exact eight raw-text keyword features"
        )
    text_source_columns = {
        str(source)
        for record in keyword_records
        for source in record.get("source_columns", [])
    }
    if not text_source_columns:
        raise Stage3aContractError("Stage1a schema lacks raw-text source columns")
    removed = set(TEXT_DERIVED_FEATURES)
    removed.update(name for name in records if name.startswith("kw_"))
    for name, record in records.items():
        sources = {str(source) for source in record.get("source_columns", [])}
        structured_multihot = (
            len(sources) == 1
            and any(name.startswith(f"{source}__") for source in sources)
            and record.get("semantic_type")
            in {"binary_indicator", "missingness_indicator", "source_state_indicator"}
        )
        if sources & text_source_columns and not structured_multihot:
            removed.add(name)
    selected = [
        feature
        for feature in feature_order
        if feature not in removed
    ]
    if not selected:
        raise Stage3aContractError("no-text structured feature schema is empty")
    if any(feature.startswith("kw_") for feature in selected):
        raise Stage3aContractError("no-text schema retains raw-text keyword features")
    return selected


def _prediction_frame(
    contract: dict[str, Any],
    evaluate: pd.DataFrame,
    probability: np.ndarray,
    *,
    split: str,
    fold: int | None,
) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "task_id": contract["task_id"],
            "row_hash": evaluate["row_hash"].astype(str),
            "outcome": contract["outcome"],
            "model": contract["model"],
            "split": split,
            "fold": pd.array(
                [fold if fold is not None else pd.NA] * len(evaluate),
                dtype="Int8",
            ),
            "y_true": evaluate["label"].to_numpy(dtype="int8"),
            "prediction": np.clip(probability, 0, 1),
        },
        columns=PREDICTION_COLUMNS,
    )


def resolve_formal_device(model: str, requested: str) -> str:
    if requested not in {"auto", "cpu", "cuda"}:
        raise Stage3aContractError("formal device request is invalid")
    import torch

    available = bool(torch.cuda.is_available())
    if model == "frozen_embedding":
        if requested == "cuda" and not available:
            raise Stage3aContractError("formal frozen embedding requested unavailable CUDA")
        return "cuda" if requested != "cpu" and available else "cpu"
    if requested == "cpu" or not available:
        raise Stage3aContractError(f"formal {model} execution requires CUDA")
    return "cuda"


def run_formal_execution(
    base_contract: dict[str, Any],
    rebind: dict[str, Any],
    *,
    prelaunch_manifest_path: Path,
    registry_path: Path,
    registry_rebind_receipt_path: Path,
    output_dir: Path,
    device_request: str,
) -> dict[str, Any]:
    registry_rebind = validate_stage3_registry_rebind(
        registry_path, registry_rebind_receipt_path
    )
    contract = validate_formal_rebind(
        base_contract,
        rebind,
        prelaunch_manifest_path=prelaunch_manifest_path,
        registry_path=registry_path,
    )
    contract["stage3_registry_rebind"] = registry_rebind
    contract.pop("contract_sha256")
    contract["contract_sha256"] = canonical_sha256(contract)
    existing_success = _initialize_formal_output(output_dir, contract, rebind)
    if existing_success is not None:
        return existing_success
    device = resolve_formal_device(contract["model"], device_request)
    (
        train,
        validation,
        feature_order,
        nlp_features,
        nlp_provenance,
        no_text_feature_order,
    ) = (
        load_formal_training_data(contract, rebind, device=device)
    )
    seed = int(rebind["seed"])
    checkpoint, prediction_parts = _load_resume_checkpoint(output_dir, contract)
    no_text_prediction_parts = _load_no_text_resume_predictions(
        output_dir, contract, checkpoint
    )
    hpo_trial_parts = []
    if contract["model"] in HPO_MODELS and checkpoint is not None:
        for context in checkpoint["optuna"]["completed_selection_contexts"]:
            hpo_trial_parts.append(
                pd.read_parquet(
                    output_dir
                    / "checkpoints"
                    / f"optuna_{context}_trials.parquet"
                )
            )
    completed_folds = (
        [int(value) for value in checkpoint["completed_folds"]]
        if checkpoint is not None
        else []
    )
    final_completed = bool(checkpoint and checkpoint["final_completed"])
    for frame in prediction_parts:
        if frame["split"].eq("oof_2020_2023").all():
            fold = int(pd.to_numeric(frame["fold"], errors="raise").iloc[0])
            expected = train.loc[train["fold"].eq(fold)]
            _validate_checkpoint_against_data(
                frame, expected, label=f"resumed fold {fold}"
            )
        else:
            _validate_checkpoint_against_data(
                frame, validation, label="resumed final validation"
            )
    for frame in no_text_prediction_parts:
        if frame["split"].eq("oof_2020_2023").all():
            fold = int(pd.to_numeric(frame["fold"], errors="raise").iloc[0])
            expected = train.loc[train["fold"].eq(fold)]
            _validate_checkpoint_against_data(
                frame, expected, label=f"resumed no-text fold {fold}"
            )
        else:
            _validate_checkpoint_against_data(
                frame, validation, label="resumed no-text final validation"
            )
    for fold in FOLDS:
        if fold in completed_folds:
            continue
        selection_context = f"outer_{fold}"
        params: dict[str, Any] = {}
        if contract["model"] in HPO_MODELS:
            params, trials, _ = run_locked_optuna(
                contract,
                train,
                feature_order,
                output_dir,
                selection_context=selection_context,
                device=device,
                seed=seed + fold * 1000,
            )
            hpo_trial_parts.append(trials)
        elif contract["model"] == "bert_finetuned":
            selection_train, selection_validation, selection = (
                training_only_selection_split(train, selection_context)
            )
            selected_epoch, epoch_metrics = select_bert_epoch(
                contract,
                selection_train,
                selection_validation,
                device=device,
                seed=seed + fold * 1000,
            )
            params = {"bert_epochs": selected_epoch}
            atomic_json(
                output_dir / "checkpoints" / f"selection_{selection_context}.json",
                {
                    **selection,
                    "selection_method": "epoch_checkpoint_AUPRC_then_refit_outer_training",
                    "selection_metric": "AUPRC",
                    "epoch_metrics": epoch_metrics,
                    "selected_epoch": selected_epoch,
                },
            )
        fit = train.loc[train["fold"].ne(fold)]
        evaluate = train.loc[train["fold"].eq(fold)]
        model, probability = fit_formal_model(
            contract,
            fit[feature_order],
            fit["label"].to_numpy(dtype="int8"),
            evaluate[feature_order],
            params=params,
            device=device,
            seed=seed + fold,
        )
        model_path = output_dir / f"models/fold_{fold}.bin"
        atomic_joblib(model_path, model)
        if contract["model"] == "ft_transformer":
            write_ft_feature_selection_artifact(
                output_dir,
                contract,
                model,
                context=selection_context,
                no_text=False,
            )
        fold_predictions = _prediction_frame(
            contract,
            evaluate,
            probability,
            split="oof_2020_2023",
            fold=fold,
        )
        _validate_prediction_checkpoint(
            contract, fold_predictions, split="oof_2020_2023", fold=fold
        )
        atomic_parquet(
            output_dir / f"checkpoints/fold_{fold}_predictions.parquet",
            fold_predictions,
        )
        prediction_parts.append(fold_predictions)
        if contract["model"] in HPO_MODELS:
            no_text_model, no_text_probability = fit_formal_model(
                contract,
                fit[no_text_feature_order],
                fit["label"].to_numpy(dtype="int8"),
                evaluate[no_text_feature_order],
                params=params,
                device=device,
                seed=seed + fold,
            )
            atomic_joblib(
                output_dir / f"models/no_text_fold_{fold}.bin",
                no_text_model,
            )
            if contract["model"] == "ft_transformer":
                write_ft_feature_selection_artifact(
                    output_dir,
                    contract,
                    no_text_model,
                    context=selection_context,
                    no_text=True,
                )
            no_text_fold_predictions = _prediction_frame(
                contract,
                evaluate,
                no_text_probability,
                split="oof_2020_2023",
                fold=fold,
            )
            _validate_prediction_checkpoint(
                contract,
                no_text_fold_predictions,
                split="oof_2020_2023",
                fold=fold,
            )
            atomic_parquet(
                output_dir
                / "checkpoints"
                / f"no_text_fold_{fold}_predictions.parquet",
                no_text_fold_predictions,
            )
            no_text_prediction_parts.append(no_text_fold_predictions)
        completed_folds.append(fold)
        checkpoint = write_checkpoint_manifest(
            output_dir,
            contract,
            completed_folds=completed_folds,
            final_completed=False,
            attempted_trials=50 if contract["model"] in HPO_MODELS else 0,
            smoke=False,
        )
    if final_completed:
        final_model = joblib.load(output_dir / "models/final.bin")
    else:
        final_params: dict[str, Any] = {}
        if contract["model"] in HPO_MODELS:
            final_params, trials, _ = run_locked_optuna(
                contract,
                train,
                feature_order,
                output_dir,
                selection_context="final",
                device=device,
                seed=seed + 9000,
            )
            hpo_trial_parts.append(trials)
        elif contract["model"] == "bert_finetuned":
            selection_train, selection_validation, selection = (
                training_only_selection_split(train, "final")
            )
            selected_epoch, epoch_metrics = select_bert_epoch(
                contract,
                selection_train,
                selection_validation,
                device=device,
                seed=seed + 9000,
            )
            final_params = {"bert_epochs": selected_epoch}
            atomic_json(
                output_dir / "checkpoints" / "selection_final.json",
                {
                    **selection,
                    "selection_method": "epoch_checkpoint_AUPRC_then_refit_all_development",
                    "selection_metric": "AUPRC",
                    "epoch_metrics": epoch_metrics,
                    "selected_epoch": selected_epoch,
                },
            )
        final_model, validation_probability = fit_formal_model(
            contract,
            train[feature_order],
            train["label"].to_numpy(dtype="int8"),
            validation[feature_order],
            params=final_params,
            device=device,
            seed=seed + 100,
        )
        atomic_joblib(output_dir / "models/final.bin", final_model)
        if contract["model"] == "ft_transformer":
            write_ft_feature_selection_artifact(
                output_dir,
                contract,
                final_model,
                context="final",
                no_text=False,
            )
        final_predictions = _prediction_frame(
            contract,
            validation,
            validation_probability,
            split="validation_2024",
            fold=None,
        )
        _validate_prediction_checkpoint(
            contract, final_predictions, split="validation_2024", fold=None
        )
        atomic_parquet(
            output_dir / "checkpoints/final_predictions.parquet",
            final_predictions,
        )
        prediction_parts.append(final_predictions)
        if contract["model"] in HPO_MODELS:
            no_text_final_model, no_text_validation_probability = (
                fit_formal_model(
                    contract,
                    train[no_text_feature_order],
                    train["label"].to_numpy(dtype="int8"),
                    validation[no_text_feature_order],
                    params=final_params,
                    device=device,
                    seed=seed + 100,
                )
            )
            atomic_joblib(
                output_dir / "models/no_text_final.bin", no_text_final_model
            )
            if contract["model"] == "ft_transformer":
                write_ft_feature_selection_artifact(
                    output_dir,
                    contract,
                    no_text_final_model,
                    context="final",
                    no_text=True,
                )
            no_text_final_predictions = _prediction_frame(
                contract,
                validation,
                no_text_validation_probability,
                split="validation_2024",
                fold=None,
            )
            _validate_prediction_checkpoint(
                contract,
                no_text_final_predictions,
                split="validation_2024",
                fold=None,
            )
            atomic_parquet(
                output_dir
                / "checkpoints"
                / "no_text_final_predictions.parquet",
                no_text_final_predictions,
            )
            no_text_prediction_parts.append(no_text_final_predictions)
        checkpoint = write_checkpoint_manifest(
            output_dir,
            contract,
            completed_folds=list(FOLDS),
            final_completed=True,
            attempted_trials=50 if contract["model"] in HPO_MODELS else 0,
            smoke=False,
        )
    predictions = pd.concat(prediction_parts, ignore_index=True)
    predictions = predictions.sort_values(
        ["split", "row_hash"], kind="mergesort"
    ).reset_index(drop=True)
    coverage = predictions[["row_hash", "outcome", "model", "split"]].copy()
    coverage["eligible"] = True
    coverage = coverage[list(COVERAGE_COLUMNS)]
    group_by_row = pd.concat(
        [
            train[["row_hash", "group_hash"]],
            validation[["row_hash", "group_hash"]],
        ],
        ignore_index=True,
    ).set_index("row_hash")["group_hash"]
    metrics = _metric_rows(contract, predictions, group_by_row)
    no_text_predictions = None
    if contract["model"] in HPO_MODELS:
        no_text_predictions = pd.concat(
            no_text_prediction_parts, ignore_index=True
        ).sort_values(["split", "row_hash"], kind="mergesort").reset_index(
            drop=True
        )
        metrics = pd.concat(
            [
                metrics,
                _paired_text_metric_rows(
                    contract,
                    predictions,
                    no_text_predictions,
                    group_by_row,
                ),
            ],
            ignore_index=True,
        )[list(METRIC_COLUMNS)]
    canary_source = validation.sort_values("row_hash", kind="mergesort").head(100)
    if len(canary_source) != 100:
        raise Stage3aContractError("formal validation has fewer than 100 canary rows")
    canary_inputs = canary_source[feature_order].reset_index(drop=True).copy()
    canary_inputs.insert(0, "canary_id", canary_source["row_hash"].astype(str).tolist())
    canary_probability = final_model.predict_proba(canary_inputs[feature_order])[:, 1]
    canary_expected = pd.DataFrame(
        {
            "canary_id": canary_inputs["canary_id"],
            "prediction": canary_probability,
        }
    )
    write_checkpoint_manifest(
        output_dir,
        contract,
        completed_folds=list(FOLDS),
        final_completed=True,
        attempted_trials=50 if contract["model"] in HPO_MODELS else 0,
        smoke=False,
    )
    return write_sealed_task_artifacts(
        output_dir,
        contract,
        predictions=predictions,
        metrics=metrics,
        coverage=coverage,
        canary_inputs=canary_inputs,
        canary_expected=canary_expected,
        hpo_trials=(
            pd.concat(hpo_trial_parts, ignore_index=True)
            if hpo_trial_parts
            else None
        ),
        smoke=False,
        nlp_features=nlp_features,
        nlp_provenance=nlp_provenance,
        no_text_predictions=no_text_predictions,
        candidate_feature_order=feature_order,
    )


def synthetic_smoke(output_dir: Path, contract: dict[str, Any]) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    for fold in FOLDS:
        for index in range(4):
            y = index % 2
            rows.append(
                {
                    "task_id": contract["task_id"],
                    "row_hash": hashlib.sha256(f"{contract['task_id']}:oof:{fold}:{index}".encode()).hexdigest(),
                    "outcome": contract["outcome"],
                    "model": contract["model"],
                    "split": "oof_2020_2023",
                    "fold": fold,
                    "y_true": y,
                    "prediction": 0.75 if y else 0.25,
                }
            )
    for index in range(8):
        y = index % 2
        rows.append(
            {
                "task_id": contract["task_id"],
                "row_hash": hashlib.sha256(f"{contract['task_id']}:validation:{index}".encode()).hexdigest(),
                "outcome": contract["outcome"],
                "model": contract["model"],
                "split": "validation_2024",
                "fold": None,
                "y_true": y,
                "prediction": 0.7 if y else 0.3,
            }
        )
    predictions = pd.DataFrame(rows, columns=PREDICTION_COLUMNS)
    predictions["fold"] = pd.array(predictions["fold"], dtype="Int8")
    metrics = _metric_rows(contract, predictions)
    coverage = predictions[["row_hash", "outcome", "model", "split"]].copy()
    coverage["eligible"] = True
    coverage = coverage[list(COVERAGE_COLUMNS)]
    model_dir = output_dir / "models"
    model_dir.mkdir(parents=True, exist_ok=True)
    synthetic_model = SyntheticProbabilityModel(
        ["synthetic_feature"], np.asarray([0.35]), -0.1
    )
    for name in MODEL_FILE_NAMES:
        joblib.dump(synthetic_model, output_dir / name)
    completed_trials = 2 if contract["model"] in HPO_MODELS else 0
    if completed_trials:
        (output_dir / "optuna.sqlite3").write_bytes(
            f"synthetic-optuna-smoke:{contract['task_id']}\n".encode()
        )
    write_checkpoint_manifest(
        output_dir,
        contract,
        completed_folds=list(FOLDS),
        final_completed=True,
        attempted_trials=completed_trials,
        smoke=True,
    )
    hpo_trials = None
    if completed_trials:
        hpo_trials = pd.DataFrame(
            {
                "trial_number": list(range(completed_trials)),
                "state": ["COMPLETE"] * completed_trials,
                "value": [0.61, 0.62],
            }
        )
    canary_inputs = pd.DataFrame(
        {
            "canary_id": [f"canary-{index}" for index in range(100)],
            "synthetic_feature": np.linspace(-2, 2, 100, dtype="float32"),
        }
    )
    canary_expected = pd.DataFrame(
        {
            "canary_id": canary_inputs["canary_id"],
            "prediction": synthetic_model.predict_proba(
                canary_inputs[["synthetic_feature"]]
            )[:, 1],
        }
    )
    return write_sealed_task_artifacts(
        output_dir,
        contract,
        predictions=predictions,
        metrics=metrics,
        coverage=coverage,
        canary_inputs=canary_inputs,
        canary_expected=canary_expected,
        hpo_trials=hpo_trials,
        smoke=True,
    )


def prepare_contract(task_manifest: Path, registry: Path, output_dir: Path) -> dict[str, Any]:
    if output_dir.exists() and any(output_dir.iterdir()):
        raise Stage3aContractError(f"output directory is not empty: {output_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)
    contract = load_runner_contract(task_manifest, registry)
    atomic_json(output_dir / "runner_contract.json", contract)
    receipt = {
        "contract_version": "p1-v2-stage3a-runner-preparation/1",
        "status": "PREPARED_NOT_AUTHORIZED",
        "task_id": contract["task_id"],
        "runner_contract": "runner_contract.json",
        "runner_contract_file_sha256": sha256_file(output_dir / "runner_contract.json"),
        "formal_training_authorized": False,
        "formal_training_launched": False,
        "2025_access_count": 0,
    }
    atomic_json(output_dir / "_PREPARED.json", receipt)
    return receipt


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Prepare, smoke, or formally execute one EMT P1 v2 Stage3a task"
    )
    parser.add_argument("--task-manifest", type=Path, required=True)
    parser.add_argument("--registry", type=Path, default=ROOT / "qa_v2" / "task_registry.json")
    parser.add_argument("--output-dir", type=Path, required=True)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--prepare-only", action="store_true")
    mode.add_argument(
        "--synthetic-smoke",
        "--smoke",
        dest="synthetic_smoke",
        action="store_true",
    )
    mode.add_argument("--formal-execute", action="store_true")
    parser.add_argument("--formal-rebind", type=Path)
    parser.add_argument("--registry-rebind-receipt", type=Path)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args(argv)
    if args.formal_execute and (
        args.formal_rebind is None or args.registry_rebind_receipt is None
    ):
        parser.error(
            "--formal-execute requires --formal-rebind and "
            "--registry-rebind-receipt"
        )
    if not args.formal_execute and (
        args.formal_rebind is not None
        or args.registry_rebind_receipt is not None
    ):
        parser.error(
            "--formal-rebind/--registry-rebind-receipt are valid only with "
            "--formal-execute"
        )
    if args.device != "auto" and not args.formal_execute:
        parser.error("--device is valid only with --formal-execute")
    return args


def main() -> int:
    args = parse_args()
    if args.formal_execute:
        contract = load_runner_contract(args.task_manifest, args.registry)
        receipt = run_formal_execution(
            contract,
            read_json(args.formal_rebind),
            prelaunch_manifest_path=args.task_manifest,
            registry_path=args.registry,
            registry_rebind_receipt_path=args.registry_rebind_receipt,
            output_dir=args.output_dir,
            device_request=args.device,
        )
    else:
        receipt = prepare_contract(args.task_manifest, args.registry, args.output_dir)
    if args.synthetic_smoke:
        contract = read_json(args.output_dir / "runner_contract.json")
        receipt = synthetic_smoke(args.output_dir, contract)
    print(json.dumps(receipt, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
