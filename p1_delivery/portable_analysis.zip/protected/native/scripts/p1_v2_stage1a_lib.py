from __future__ import annotations

import re
import unicodedata
from collections import Counter
from typing import Any

import numpy as np
import pandas as pd

from qa_v2 import contextual_security_scan as security_scan

try:
    from .p1_v2_score_recompute import (
        COMPLETE_SCORE_COMPONENTS,
        PASSIVE_SCORE_VALUE_COLUMNS,
        compute_score_values_v2,
    )
except ImportError:
    from p1_v2_score_recompute import (
        COMPLETE_SCORE_COMPONENTS,
        PASSIVE_SCORE_VALUE_COLUMNS,
        compute_score_values_v2,
    )

try:
    from .run_stage1a import (
        CATEGORICAL_SOURCE_COLUMNS,
        KEYWORD_PATTERNS,
        MULTI_HOT_SOURCE_COLUMNS,
        NUMERIC_SOURCE_COLUMNS,
        SENTINELS,
        TEXT_SOURCE_COLUMNS,
        add_time_features,
        apply_bounds,
        ensure_allowed_sources,
        forbidden_feature_name,
        parse_sbp_value,
        scene_sbp_ordinal,
        split_tokens,
    )
except ImportError:
    from run_stage1a import (
        CATEGORICAL_SOURCE_COLUMNS,
        KEYWORD_PATTERNS,
        MULTI_HOT_SOURCE_COLUMNS,
        NUMERIC_SOURCE_COLUMNS,
        SENTINELS,
        TEXT_SOURCE_COLUMNS,
        add_time_features,
        apply_bounds,
        ensure_allowed_sources,
        forbidden_feature_name,
        parse_sbp_value,
        scene_sbp_ordinal,
        split_tokens,
    )


EXPLICIT_NONE_TOKENS = {
    "0",
    "[]",
    "N",
    "NO",
    "None",
    "none",
    "否",
    "未施作",
    "無",
    "無處置",
}
NOT_MEASURED_PATTERN = re.compile(r"拒絕量測|拒測|未測|無法量測|量測不到|無")
RAW_CONTINUOUS_OR_ORDINAL_FEATURES = frozenset(
    {
        *NUMERIC_SOURCE_COLUMNS,
        "EMT_現場_意識_AVPU",
        "EMT_現場_收縮壓_ord",
        "EMT_現場_收縮壓_for_score",
        "EMT_車上_收縮壓_for_score",
    }
)

NUMERIC_BOUNDS: dict[str, tuple[float | None, float | None, bool]] = {
    "EMT_年齡": (18, 115, False),
    "EMT_現場_脈搏": (20, 250, True),
    "EMT_車上_脈搏": (20, 250, True),
    "EMT_現場_舒張壓": (20, 200, False),
    "EMT_車上_舒張壓": (20, 200, False),
    "EMT_現場_呼吸": (0, 60, False),
    "EMT_車上_呼吸": (0, 60, False),
    "EMT_現場_SPO2": (50, 100, False),
    "EMT_車上_SPO2": (50, 100, False),
    "EMT_現場_體溫": (25, 43, False),
    "EMT_車上_體溫": (25, 43, False),
    "EMT_現場_GCS": (3, 15, False),
    "EMT_車上_GCS": (3, 15, False),
    "EMT_現場_GCS_E": (1, 4, False),
    "EMT_車上_GCS_E": (1, 4, False),
    "EMT_現場_GCS_V": (1, 5, False),
    "EMT_車上_GCS_V": (1, 5, False),
    "EMT_現場_GCS_M": (1, 6, False),
    "EMT_車上_GCS_M": (1, 6, False),
    "EMT_問卷_血糖值mgdl": (20, 1000, False),
}

SCORE_COMPONENTS = COMPLETE_SCORE_COMPONENTS
MODEL_OUTPUT_EXCLUDED_FEATURES = {
    "EMT_現場_舒張壓": "duplicate_scene_dbp_not_used_by_prehosp_dbp_ambulance_only_policy",
}


def _text_values(series: pd.Series) -> pd.Series:
    return series.astype("string").fillna("").str.strip()


def source_states(series: pd.Series) -> pd.DataFrame:
    values = _text_values(series)
    missing = series.isna() | values.eq("")
    explicit_none = values.isin(EXPLICIT_NONE_TOKENS) & ~missing
    return pd.DataFrame(
        {
            "source_available": (~missing).astype("int8"),
            "explicit_none": explicit_none.astype("int8"),
            "source_missing": missing.astype("int8"),
        },
        index=series.index,
    )


def split_tokens_v2(value: object) -> list[str]:
    if pd.isna(value) or str(value).strip() in EXPLICIT_NONE_TOKENS:
        return []
    return [token for token in split_tokens(value) if token not in EXPLICIT_NONE_TOKENS]


def numeric_with_reasons(
    series: pd.Series,
    bounds: tuple[float | None, float | None, bool] | None = None,
) -> tuple[pd.Series, pd.DataFrame]:
    values = _text_values(series)
    source_missing = series.isna() | values.eq("")
    not_measured = values.str.contains(NOT_MEASURED_PATTERN, na=False) & ~source_missing
    numeric_raw = pd.to_numeric(values.str.replace(",", "", regex=False), errors="coerce")
    sentinel = numeric_raw.isin(SENTINELS).fillna(False)
    invalid = (numeric_raw.isna() & ~source_missing & ~not_measured & ~sentinel).fillna(False)
    numeric = numeric_raw.mask(source_missing | not_measured | sentinel)
    out_of_range = pd.Series(False, index=series.index)
    if bounds is not None:
        low, high, keep_zero = bounds
        if low is not None:
            out_of_range |= (numeric < low) & ~(keep_zero & numeric.eq(0))
        if high is not None:
            out_of_range |= numeric > high
        out_of_range = out_of_range.fillna(False)
        numeric = numeric.mask(out_of_range)
    reasons = pd.DataFrame(
        {
            "source_missing": source_missing.astype("int8"),
            "not_measured": not_measured.astype("int8"),
            "sentinel": sentinel.astype("int8"),
            "invalid_or_out_of_range": (invalid | out_of_range).astype("int8"),
        },
        index=series.index,
    )
    return numeric.astype("float64"), reasons


def _reason_name(source: str, reason: str) -> str:
    return f"MISSREASON_{source}__{reason}"


def add_numeric_features_v2(
    df: pd.DataFrame,
    features: pd.DataFrame,
    source_map: dict[str, list[str]],
) -> None:
    for col in ensure_allowed_sources(df, NUMERIC_SOURCE_COLUMNS):
        values, reasons = numeric_with_reasons(df[col], NUMERIC_BOUNDS.get(col))
        features[col] = values
        features[f"MISS_{col}"] = values.isna().astype("int8")
        source_map[col] = [col]
        source_map[f"MISS_{col}"] = [col]
        for reason in reasons.columns:
            name = _reason_name(col, reason)
            features[name] = reasons[reason]
            source_map[name] = [col]


def _is_unmeasurable(value: object) -> bool:
    return not pd.isna(value) and "量測不到" in str(value).strip()


def scene_sbp_components(series: pd.Series) -> pd.DataFrame:
    unmeasurable = series.map(_is_unmeasurable)
    ordinal = series.map(scene_sbp_ordinal).astype("float64")
    numeric = series.map(parse_sbp_value).astype("float64").mask(unmeasurable)
    numeric = apply_bounds(numeric, 40, 300)
    return pd.DataFrame(
        {
            "ordinal": ordinal,
            "score_numeric": numeric,
            "unmeasurable": unmeasurable.astype("int8"),
        },
        index=series.index,
    )


def ambulance_sbp_components(series: pd.Series) -> pd.DataFrame:
    unmeasurable = series.map(_is_unmeasurable)
    numeric = series.map(parse_sbp_value).astype("float64").mask(unmeasurable)
    numeric = apply_bounds(numeric, 40, 300)
    return pd.DataFrame(
        {
            "score_numeric": numeric,
            "unmeasurable": unmeasurable.astype("int8"),
        },
        index=series.index,
    )


def hr_zero_indicator(scene_hr: pd.Series, ambulance_hr: pd.Series) -> pd.Series:
    return ((scene_hr.eq(0).fillna(False)) | (ambulance_hr.eq(0).fillna(False))).astype("int8")


def add_bp_and_vital_features_v2(
    df: pd.DataFrame,
    features: pd.DataFrame,
    source_map: dict[str, list[str]],
) -> None:
    scene_source = "EMT_現場_收縮壓"
    ambulance_source = "EMT_車上_收縮壓"
    scene = scene_sbp_components(df[scene_source])
    ambulance = ambulance_sbp_components(df[ambulance_source])

    bp_features = {
        "EMT_現場_收縮壓_ord": scene["ordinal"],
        "EMT_現場_收縮壓_for_score": scene["score_numeric"],
        "EMT_車上_收縮壓_for_score": ambulance["score_numeric"],
        "EMT_現場_收縮壓_unmeasurable": scene["unmeasurable"],
        "EMT_車上_收縮壓_unmeasurable": ambulance["unmeasurable"],
    }
    for name, values in bp_features.items():
        features[name] = values
        source_map[name] = [scene_source if "現場" in name else ambulance_source]
    for source, values in [
        (scene_source, scene["score_numeric"]),
        (ambulance_source, ambulance["score_numeric"]),
    ]:
        name = f"MISS_{source}_for_score"
        features[name] = values.isna().astype("int8")
        source_map[name] = [source]

    features["prehosp_sbp"] = ambulance["score_numeric"].combine_first(scene["score_numeric"])
    combination_sources = {
        "prehosp_sbp": [ambulance_source, scene_source],
        "prehosp_dbp": ["EMT_車上_舒張壓", "EMT_現場_舒張壓"],
        "prehosp_hr": ["EMT_車上_脈搏", "EMT_現場_脈搏"],
        "prehosp_rr": ["EMT_車上_呼吸", "EMT_現場_呼吸"],
        "prehosp_spo2": ["EMT_車上_SPO2", "EMT_現場_SPO2"],
        "prehosp_bt": ["EMT_車上_體溫", "EMT_現場_體溫"],
        "prehosp_gcs": ["EMT_車上_GCS", "EMT_現場_GCS"],
        "prehosp_gcs_e": ["EMT_車上_GCS_E", "EMT_現場_GCS_E"],
        "prehosp_gcs_v": ["EMT_車上_GCS_V", "EMT_現場_GCS_V"],
        "prehosp_gcs_m": ["EMT_車上_GCS_M", "EMT_現場_GCS_M"],
    }
    for name, sources in combination_sources.items():
        if name == "prehosp_dbp":
            sources = sources[:1]
        if name != "prehosp_sbp":
            features[name] = (
                features[sources[0]]
                if len(sources) == 1
                else features[sources[0]].combine_first(features[sources[1]])
            )
        source_map[name] = sources

    features["is_OHCA_hr0"] = hr_zero_indicator(features["EMT_現場_脈搏"], features["EMT_車上_脈搏"])
    source_map["is_OHCA_hr0"] = ["EMT_現場_脈搏", "EMT_車上_脈搏"]


def fit_feature_vocabulary(train_df: pd.DataFrame, min_count: int = 20) -> dict[str, Any]:
    categorical: dict[str, list[str]] = {}
    for col in ensure_allowed_sources(train_df, CATEGORICAL_SOURCE_COLUMNS):
        values = _text_values(train_df[col])
        counts = values[values.ne("")].value_counts()
        categorical[col] = sorted(str(value) for value in counts[counts >= min_count].index)

    multi_hot: dict[str, list[str]] = {}
    for col in ensure_allowed_sources(train_df, MULTI_HOT_SOURCE_COLUMNS):
        counts: Counter[str] = Counter()
        for tokens in train_df[col].map(split_tokens_v2):
            counts.update(set(tokens))
        multi_hot[col] = sorted(token for token, count in counts.items() if count >= min_count)
    return {"min_count": min_count, "fit_years": [2020, 2021, 2022, 2023], "categorical": categorical, "multi_hot": multi_hot}


def add_categorical_features_v2(
    df: pd.DataFrame,
    vocabulary: dict[str, Any],
    features: pd.DataFrame,
    source_map: dict[str, list[str]],
) -> None:
    for col, kept in vocabulary["categorical"].items():
        values = _text_values(df[col])
        missing = df[col].isna() | values.eq("")
        for value in kept:
            name = f"{col}__{value}"
            if forbidden_feature_name(name):
                continue
            features[name] = values.eq(value).astype("int8")
            source_map[name] = [col]
        rare_name = f"{col}__OTHER_RARE"
        missing_name = f"{col}__MISSING"
        features[rare_name] = (~missing & ~values.isin(kept)).astype("int8")
        features[missing_name] = missing.astype("int8")
        source_map[rare_name] = [col]
        source_map[missing_name] = [col]
    if "EMT_現場_意識" in df.columns:
        mapping = {"清": 4, "聲": 3, "痛": 2, "否": 1}
        features["EMT_現場_意識_AVPU"] = df["EMT_現場_意識"].map(
            lambda value: mapping.get(str(value).strip(), np.nan) if not pd.isna(value) else np.nan
        )
        source_map["EMT_現場_意識_AVPU"] = ["EMT_現場_意識"]


def _combined_source_text(df: pd.DataFrame, sources: list[str]) -> tuple[pd.Series, pd.Series]:
    if not sources:
        return pd.Series("", index=df.index), pd.Series(False, index=df.index)
    states = pd.concat([source_states(df[col])["source_available"].rename(col) for col in sources], axis=1)
    available = states.any(axis=1)
    return df[sources].fillna("").astype(str).agg("、".join, axis=1), available


def _procedure_tokens(value: object) -> list[str]:
    if pd.isna(value):
        return []
    normalized = unicodedata.normalize("NFKC", str(value)).strip()
    if not normalized:
        return []
    normalized = normalized.strip("[]{}()'\"")
    return [
        token.strip().strip("[]{}()'\"")
        for token in re.split(r"[、,，;；|\n]+", normalized)
        if token.strip().strip("[]{}()'\"")
    ]


def _normalized_procedure_token(value: str) -> str:
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", value)).casefold()


def _supplemental_oxygen_source_status(value: object, source: str) -> str:
    if pd.isna(value) or not str(value).strip():
        return "missing"
    raw = _normalized_procedure_token(str(value))
    if raw in {"[]", "{}", "()"}:
        return "none"
    tokens = _procedure_tokens(value)
    if not tokens:
        return "none" if raw in {_normalized_procedure_token(token) for token in EXPLICIT_NONE_TOKENS} else "missing"
    normalized = [_normalized_procedure_token(token) for token in tokens]
    none_tokens = {_normalized_procedure_token(token) for token in EXPLICIT_NONE_TOKENS}
    if all(token in none_tokens for token in normalized):
        return "none"
    if source == "questionnaire":
        positives = {
            _normalized_procedure_token(token)
            for token in ("氧氣面罩", "NRM", "氧氣鼻管", "正壓給氧")
        }
        return "positive" if any(token in positives for token in normalized) else "unknown"
    for token in normalized:
        aliases = (
            "氧氣鼻管",
            "鼻導管",
            "鼻管",
            "nasalcannula",
            "氧氣面罩",
            "面罩",
            "oxygenmask",
            "非再呼吸型面罩",
            "非再呼吸面罩",
            "非再吸入面罩",
            "不再吸入面罩",
            "nonrebreathermask",
            "nonrebreather",
            "non-rebreathermask",
            "non-rebreather",
            "nrm",
        )
        for alias in aliases:
            if not token.startswith(alias):
                continue
            suffix = token[len(alias) :]
            if not suffix or re.fullmatch(
                r"[(:：\-]*\d+(?:\.\d+)?(?:l/min|lpm|l|min|公升/分|公升每分鐘)?[)]*",
                suffix,
            ):
                return "positive"
    return "unknown"


def supplemental_oxygen_state(
    questionnaire: pd.Series | None,
    taipei: pd.Series | None,
    *,
    index: pd.Index | None = None,
) -> pd.Series:
    if index is None:
        if questionnaire is not None:
            index = questionnaire.index
        elif taipei is not None:
            index = taipei.index
        else:
            index = pd.RangeIndex(0)
    sources = []
    if questionnaire is not None:
        sources.append(questionnaire.reindex(index).map(lambda value: _supplemental_oxygen_source_status(value, "questionnaire")))
    if taipei is not None:
        sources.append(taipei.reindex(index).map(lambda value: _supplemental_oxygen_source_status(value, "taipei")))
    if not sources:
        return pd.Series(np.nan, index=index, dtype="float64")
    statuses = pd.concat(sources, axis=1)
    positive = statuses.eq("positive").any(axis=1)
    unknown = statuses.eq("unknown").any(axis=1)
    explicit_none = statuses.eq("none").any(axis=1)
    result = pd.Series(np.nan, index=index, dtype="float64")
    result.loc[explicit_none & ~unknown] = 0.0
    result.loc[positive] = 1.0
    return result


def _procedure_flag(text: pd.Series, available: pd.Series, pattern: str) -> pd.Series:
    normalized = text.map(lambda value: _normalized_procedure_token(str(value)))
    positive = normalized.str.contains(pattern, regex=True, na=False)
    ambiguous = normalized.str.contains(r"(?:^|、)(?:其他|外科口罩|一般口罩|自行戴口罩)(?:$|、)", regex=True, na=False)
    result = pd.Series(np.where(available, 0.0, np.nan), index=text.index, dtype="float64")
    result.loc[ambiguous] = np.nan
    result.loc[positive] = 1.0
    return result


def scrub_text_v2(df: pd.DataFrame, text_cols: list[str]) -> tuple[pd.Series, pd.Series]:
    source_values = df[text_cols].fillna("").astype(str) if text_cols else pd.DataFrame(index=df.index)
    combined = source_values.agg(" ".join, axis=1) if text_cols else pd.Series("", index=df.index)
    source_count = source_values.apply(lambda column: column.str.strip().ne("")).sum(axis=1).astype("int16")
    for identifier_column in security_scan.DIRECT_IDENTIFIER_SOURCE_COLUMNS:
        if identifier_column not in df.columns:
            continue
        identifiers = df[identifier_column].fillna("").astype(str).str.strip()
        combined = pd.Series(
            [text.replace(identifier, "[REDACTED]") if identifier else text for text, identifier in zip(combined, identifiers)],
            index=df.index,
        )
    combined = combined.map(security_scan.redact_labeled_chinese_names)
    combined = combined.str.replace(
        security_scan.PII_REDACTION_PATTERNS["taiwan_national_id"],
        "[ID]",
        regex=True,
    )
    combined = combined.str.replace(
        security_scan.PII_REDACTION_PATTERNS["taiwan_mobile_formatted"],
        "[PHONE]",
        regex=True,
    )
    combined = combined.str.replace(
        security_scan.PII_REDACTION_PATTERNS["email"],
        "[EMAIL]",
        regex=True,
    )
    combined = combined.str.replace(
        security_scan.PII_REDACTION_PATTERNS["address"],
        "[ADDRESS]",
        regex=True,
    )
    combined = combined.str.replace(
        security_scan.PII_REDACTION_PATTERNS["address_tail"],
        "[ADDRESS]",
        regex=True,
    )
    combined = combined.str.replace(
        security_scan.PII_REDACTION_PATTERNS["long_identifier"],
        "[NUMBER]",
        regex=True,
    )
    combined = combined.str.replace(r"\s+", " ", regex=True).str.strip()
    return combined, source_count


def add_text_features_v2(
    df: pd.DataFrame,
    features: pd.DataFrame,
    source_map: dict[str, list[str]],
) -> pd.DataFrame:
    text_cols = ensure_allowed_sources(df, TEXT_SOURCE_COLUMNS)
    text, source_count = scrub_text_v2(df, text_cols)
    is_missing = source_count.eq(0).astype("int8")
    for name, pattern in KEYWORD_PATTERNS.items():
        features[name] = text.str.contains(pattern, regex=True, na=False).astype("int8")
        source_map[name] = text_cols
    features["is_text_missing"] = is_missing
    features["text_source_count"] = source_count
    features["text_char_count"] = text.str.len().astype("int32")
    for name in ["is_text_missing", "text_source_count", "text_char_count"]:
        source_map[name] = text_cols
    return pd.DataFrame(
        {
            "emt_text_sanitized": text,
            "is_text_missing": is_missing,
            "text_source_count": source_count,
            "text_char_count": text.str.len().astype("int32"),
        },
        index=df.index,
    )


def add_multi_hot_features_v2(
    df: pd.DataFrame,
    vocabulary: dict[str, Any],
    features: pd.DataFrame,
    source_map: dict[str, list[str]],
) -> None:
    for col, kept in vocabulary["multi_hot"].items():
        token_lists = df[col].map(split_tokens_v2)
        states = source_states(df[col])
        for token in kept:
            name = f"{col}__{token}"
            if forbidden_feature_name(name):
                continue
            features[name] = token_lists.map(lambda tokens, current=token: int(current in tokens)).astype("int8")
            source_map[name] = [col]
        rare_name = f"{col}__OTHER_RARE"
        features[rare_name] = token_lists.map(lambda tokens: int(any(token not in kept for token in tokens))).astype("int8")
        source_map[rare_name] = [col]
        for state in states.columns:
            name = f"{col}__{state}"
            features[name] = states[state]
            source_map[name] = [col]

    questionnaire_oxygen = df["EMT_問卷_呼吸給氧裝置"] if "EMT_問卷_呼吸給氧裝置" in df else None
    taipei_oxygen = df["EMT_台北_呼吸處置"] if "EMT_台北_呼吸處置" in df else None
    oxygen_sources = [col for col in ["EMT_問卷_呼吸給氧裝置", "EMT_台北_呼吸處置"] if col in df.columns]
    oxygen_text, oxygen_available = _combined_source_text(df, oxygen_sources)
    features["has_oxygen"] = supplemental_oxygen_state(
        questionnaire_oxygen,
        taipei_oxygen,
        index=df.index,
    )
    features["has_ventilatory_support"] = _procedure_flag(
        oxygen_text,
        oxygen_available,
        r"bvm|ambu|袋瓣|呼吸球|正壓|cpap|bagvalve",
    )
    features["has_airway_adjunct"] = _procedure_flag(
        oxygen_text,
        oxygen_available,
        r"鼻咽|口咽|聲門上|sga|lma|i-gel|igel|插管|氣管內管|ett",
    )
    support_flags = pd.concat(
        [features["has_ventilatory_support"], features["has_airway_adjunct"]],
        axis=1,
    )
    features["has_advanced_airway"] = pd.Series(np.nan, index=df.index, dtype="float64")
    features.loc[support_flags.eq(0).all(axis=1), "has_advanced_airway"] = 0.0
    features.loc[support_flags.eq(1).any(axis=1), "has_advanced_airway"] = 1.0
    for name in [
        "has_oxygen",
        "has_ventilatory_support",
        "has_airway_adjunct",
        "has_advanced_airway",
    ]:
        source_map[name] = oxygen_sources

    als_sources = [col for col in ["EMT_問卷_加護處置", "EMT_台北_藥物處置", "EMT_台北_CPR處置"] if col in df.columns]
    als_text, als_available = _combined_source_text(df, als_sources)
    als_positive = als_text.str.contains("IV|IO|給藥|NTG|Berotec|CPR|AED|支氣管", regex=True)
    features["has_ALS_procedure"] = pd.Series(np.where(als_available, als_positive.astype(float), np.nan), index=df.index)
    source_map["has_ALS_procedure"] = als_sources


def _component_status(components: list[pd.Series]) -> tuple[pd.Series, pd.Series]:
    observed = sum((component.notna().astype("int8") for component in components), start=pd.Series(0, index=components[0].index, dtype="int8"))
    return observed, observed.eq(len(components))


def _store_complete_score(
    features: pd.DataFrame,
    source_map: dict[str, list[str]],
    name: str,
    score: pd.Series,
    components: list[pd.Series],
    sources: list[str],
) -> None:
    observed, available = _component_status(components)
    features[name] = score.replace([np.inf, -np.inf], np.nan).where(available)
    features[f"{name}_available"] = available.astype("int8")
    features[f"{name}_observed_components"] = observed.astype("int8")
    features[f"{name}_required_components"] = np.int8(len(components))
    features[f"MISS_{name}"] = (~available).astype("int8")
    for feature in [name, f"{name}_available", f"{name}_observed_components", f"{name}_required_components", f"MISS_{name}"]:
        source_map[feature] = sources


def add_score_features_v2(features: pd.DataFrame, source_map: dict[str, list[str]]) -> None:
    age = features["EMT_年齡"]
    sbp = features["prehosp_sbp"]
    hr = features["prehosp_hr"]
    rr = features["prehosp_rr"]
    spo2 = features["prehosp_spo2"]
    bt = features["prehosp_bt"]
    gcs = features["prehosp_gcs"]
    avpu = features.get("EMT_現場_意識_AVPU", pd.Series(np.nan, index=features.index))
    oxygen = features.get("has_oxygen", pd.Series(np.nan, index=features.index))
    score_values = compute_score_values_v2(features)
    map_value = score_values["MAP"]
    consciousness_observed = gcs.notna() | avpu.notna()
    consciousness_abnormal = ((gcs.lt(15) & gcs.notna()) | (avpu.lt(4) & avpu.notna())).astype("float64").where(consciousness_observed)

    derived = PASSIVE_SCORE_VALUE_COLUMNS[:14]
    base_sources = ["EMT_年齡", "prehosp_sbp", "prehosp_dbp", "prehosp_hr", "prehosp_rr", "prehosp_spo2", "prehosp_bt", "prehosp_gcs", "prehosp_gcs_m"]
    for name in derived:
        features[name] = score_values[name]
        features[f"MISS_{name}"] = features[name].isna().astype("int8")
        source_map[name] = base_sources
        source_map[f"MISS_{name}"] = base_sources

    _store_complete_score(features, source_map, "qSOFA", score_values["qSOFA"], [rr, sbp, consciousness_abnormal], SCORE_COMPONENTS["qSOFA"])

    news_components = [rr, spo2, bt, sbp, hr, consciousness_abnormal, oxygen]
    _store_complete_score(features, source_map, "NEWS2", score_values["NEWS2"], news_components, SCORE_COMPONENTS["NEWS2"])

    mews_components = [rr, bt, sbp, hr, avpu]
    _store_complete_score(features, source_map, "MEWS", score_values["MEWS"], mews_components, SCORE_COMPONENTS["MEWS"])

    rems_components = [age, map_value, hr, rr, spo2, gcs]
    _store_complete_score(features, source_map, "REMS", score_values["REMS"], rems_components, SCORE_COMPONENTS["REMS"])

    rts_components = [gcs, sbp, rr]
    _store_complete_score(features, source_map, "RTS", score_values["RTS"], rts_components, SCORE_COMPONENTS["RTS"])


def transform_feature_split(
    df: pd.DataFrame,
    vocabulary: dict[str, Any],
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, list[str]]]:
    features = pd.DataFrame(index=df.index)
    source_map: dict[str, list[str]] = {}
    add_numeric_features_v2(df, features, source_map)
    add_categorical_features_v2(df, vocabulary, features, source_map)
    add_multi_hot_features_v2(df, vocabulary, features, source_map)
    add_bp_and_vital_features_v2(df, features, source_map)
    add_time_features(df, features, source_map)
    add_score_features_v2(features, source_map)
    text_frame = add_text_features_v2(df, features, source_map)
    return features, text_frame, source_map


def feature_semantic_type(name: str) -> str:
    if name.startswith("MISSREASON_"):
        return "missing_reason_indicator"
    if name.startswith("MISS_") or name.endswith("_available") or name.endswith("_source_missing"):
        return "missingness_indicator"
    if name.endswith("_explicit_none") or name.endswith("_source_available"):
        return "source_state_indicator"
    if "__" in name or name.startswith("has_") or name == "is_OHCA_hr0":
        return "binary_indicator"
    if name.endswith("_observed_components") or name.endswith("_required_components"):
        return "score_component_count"
    if name in PASSIVE_SCORE_VALUE_COLUMNS:
        return "clinical_score"
    return "continuous_or_ordinal"


def feature_imputation_block(name: str) -> str:
    return "raw_continuous_or_ordinal" if name in RAW_CONTINUOUS_OR_ORDINAL_FEATURES else "other"
