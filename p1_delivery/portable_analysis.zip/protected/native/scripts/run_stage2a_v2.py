from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import os
import platform
import re
import socket
import time
import zipfile
from importlib import metadata as package_metadata
from pathlib import Path
from typing import Any

import joblib
import matplotlib
import numpy as np
import pandas as pd
from scipy import stats
from scipy.special import expit
from sklearn.isotonic import IsotonicRegression
from sklearn.metrics import (
    average_precision_score,
    precision_recall_curve,
    roc_auc_score,
    roc_curve,
)

from qa_v2 import contextual_security_scan as security_scan

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_REGISTRY = ROOT / "qa_v2" / "task_registry.json"
OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
TREE_SHAP_MODELS = {"catboost", "lightgbm", "xgboost"}
PREDICTION_COLUMNS = [
    "task_id",
    "row_hash",
    "outcome",
    "model",
    "split",
    "fold",
    "y_true",
    "prediction",
]
METRIC_COLUMNS = [
    "task_id",
    "outcome",
    "model",
    "split",
    "metric",
    "value",
    "status",
    "n",
    "events",
    "lower_ci",
    "upper_ci",
]
COVERAGE_COLUMNS = ["task_id", "row_hash", "outcome", "model", "split", "eligible"]
SHAP_COLUMNS = [
    "row_hash",
    "outcome",
    "model",
    "feature",
    "feature_value",
    "shap_value",
    "split",
]
BASE_MODEL_CANARY_COLUMNS = [
    "source_task_id",
    "row_hash",
    "outcome",
    "model",
    "split",
    "expected_prediction",
    "model_artifact_path",
    "model_sha256",
    "feature_schema_artifact_path",
    "feature_schema_sha256",
]
LOCAL_RUNTIME_LIMIT_HOURS = 2.0
SHAP_BASE_TOLERANCE = 0.05
AUTHORIZATION_ANCHOR_ENV = "EMT_P1_V2_LAUNCH_AUTHORIZATION_SHA256"
MODEL_RELOAD_TOLERANCE = 1e-5
SHAP_ADDITIVITY_ATOL = 1e-5
SHAP_ADDITIVITY_RTOL = 1e-5
SHAP_RECOMPUTE_TOLERANCE = 1e-6
CANARY_SELECTION_SEED = 20260710
FORMAL_COHORT_SPLIT_COUNTS = {
    "oof_2020_2023": 24784,
    "validation_2024": 7504,
}
PREDICTIVE_FAMILIES = {
    "clinical_score",
    "stage1b_model",
    "missingness_bundle",
    "stage3a_model",
    "stage3b_model",
}
CORE_PREDICTIVE_FAMILIES = {"clinical_score", "stage1b_model", "missingness_bundle"}
FINAL_PREDICTIVE_FAMILIES = CORE_PREDICTIVE_FAMILIES | {"stage3a_model", "stage3b_model"}
MANDATORY_MODELS = {"score_rSI_sMS", "catboost", "xgboost", "lightgbm"}
BASE_REQUIRED_MISSINGNESS_STRATEGIES = {
    "median_indicator",
    "mean_indicator",
    "tree_native",
    "median_no_indicator",
    "full_complete_case",
    "core_vitals_complete_case",
    "knn_k5_continuous_ordinal_block",
    "bayesian_iterative_m10",
}
MNAR_MISSINGNESS_STRATEGIES = {
    "mnar_minus_0_5sd",
    "mnar_plus_0_5sd",
}
ARRIVAL_ALLOWLIST = {"運送時間", "總到院前時間", "MISS_運送時間", "MISS_總到院前時間"}
ARRIVAL_TOKENS = ("arrival", "到院", "送達醫院", "檢傷", "交接", "離開醫院", "返隊")
HEX64 = re.compile(r"^[0-9a-fA-F]{64}$")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def stable_seed(seed: int, outcome: str, model: str) -> int:
    digest = hashlib.sha256(f"{seed}|{outcome}|{model}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "little") % (2**32 - 1)


def formal_missingness_strategy_contract(outcome: str) -> tuple[set[str], int]:
    if outcome not in OUTCOMES:
        raise ValueError(f"unknown missingness outcome: {outcome}")
    strategies = set(BASE_REQUIRED_MISSINGNESS_STRATEGIES)
    if outcome in {"P1", "P2", "P3"}:
        strategies.update(MNAR_MISSINGNESS_STRATEGIES)
    return strategies, 19 if outcome in {"P1", "P2", "P3"} else 15


def sha256_json(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def deterministic_canary_rows(row_hashes: list[str], count: int) -> list[str]:
    ranked = sorted(
        {str(row_hash) for row_hash in row_hashes},
        key=lambda row_hash: hashlib.sha256(
            f"{CANARY_SELECTION_SEED}:{row_hash}".encode("utf-8")
        ).hexdigest(),
    )
    return ranked[:count]


def deterministic_canary_sequence(row_hashes: list[str], count: int) -> list[str]:
    if count < 0:
        raise ValueError("canary row count cannot be negative")
    unique_count = len(set(map(str, row_hashes)))
    selected = deterministic_canary_rows(row_hashes, min(count, unique_count))
    if count and not selected:
        raise ValueError("cannot build a canary from an empty row set")
    return [selected[index % len(selected)] for index in range(count)]


def canonical_frame_sha256(frame: pd.DataFrame, columns: list[str]) -> str:
    canonical = frame[columns].copy()
    for column in columns:
        if pd.api.types.is_integer_dtype(canonical[column].dtype):
            canonical[column] = canonical[column].astype(int)
        else:
            canonical[column] = canonical[column].astype(str)
    canonical = canonical.sort_values(columns, kind="mergesort").reset_index(drop=True)
    return sha256_json(canonical.to_dict("records"))


def stage1a_key_contract(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": int(len(frame)),
        "oof_2020_2023_rows": int(frame["split_year"].between(2020, 2023).sum()),
        "validation_2024_rows": int(frame["split_year"].eq(2024).sum()),
        "row_key_set_sha256": sha256_json(sorted(frame["row_hash"].astype(str))),
        "row_group_year_split_sha256": canonical_frame_sha256(
            frame,
            ["row_hash", "group_hash", "split_year", "split"],
        ),
    }


def fold_key_contract(frame: pd.DataFrame) -> dict[str, Any]:
    return {
        "rows": int(len(frame)),
        "row_key_set_sha256": sha256_json(sorted(frame["row_hash"].astype(str))),
        "row_group_outcome_fold_year_sha256": canonical_frame_sha256(
            frame,
            ["row_hash", "group_hash", "outcome", "fold", "split_year"],
        ),
    }


def atomic_json(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def atomic_parquet(path: Path, frame: pd.DataFrame) -> None:
    temporary = path.with_suffix(".tmp.parquet")
    frame.to_parquet(temporary, index=False)
    temporary.replace(path)


def atomic_joblib(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    joblib.dump(value, temporary)
    temporary.replace(path)


def deterministic_zip(path: Path, members: list[Path], root: Path) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for member in sorted(members, key=lambda item: item.relative_to(root).as_posix()):
            info = zipfile.ZipInfo(member.relative_to(root).as_posix(), date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o600 << 16
            archive.writestr(info, member.read_bytes())
    temporary.replace(path)


def package_versions() -> dict[str, str | None]:
    result: dict[str, str | None] = {}
    for name in ("numpy", "pandas", "scikit-learn", "scipy", "pyarrow", "psutil", "torch"):
        try:
            result[name] = package_metadata.version(name)
        except package_metadata.PackageNotFoundError:
            result[name] = None
    return result


def hardware_record() -> dict[str, Any]:
    record: dict[str, Any] = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "logical_cpu_count": os.cpu_count(),
        "hostname_sha256": hashlib.sha256(socket.gethostname().encode("utf-8")).hexdigest(),
        "packages": package_versions(),
    }
    try:
        import psutil

        memory = psutil.virtual_memory()
        record["ram_total_bytes"] = int(memory.total)
        record["ram_available_bytes_at_start"] = int(memory.available)
    except ImportError:
        record["ram_total_bytes"] = None
        record["ram_available_bytes_at_start"] = None
    try:
        import torch

        record["cuda_available"] = bool(torch.cuda.is_available())
        record["cuda_device_count"] = int(torch.cuda.device_count()) if torch.cuda.is_available() else 0
        record["cuda_devices"] = [
            torch.cuda.get_device_name(index) for index in range(record["cuda_device_count"])
        ]
    except ImportError:
        record["cuda_available"] = False
        record["cuda_device_count"] = 0
        record["cuda_devices"] = []
    return record


def reject_holdout_path(path: Path, label: str) -> None:
    text = str(path.resolve()).lower()
    if "2025" in text or "source_seal" in text:
        raise ValueError(f"{label} path may expose the 2025/source_seal holdout: {path}")


def pii_columns(columns: list[str]) -> list[str]:
    return security_scan.pii_column_hits(columns)


def forbidden_arrival_columns(columns: list[str]) -> list[str]:
    hits = []
    for name in columns:
        if any(allowed in name for allowed in ARRIVAL_ALLOWLIST):
            continue
        normalized = str(name).lower()
        if any(token.lower() in normalized for token in ARRIVAL_TOKENS):
            hits.append(str(name))
    return sorted(hits)


def load_stage1a_metadata(path: Path, manifest_path: Path | None, *, smoke: bool) -> tuple[pd.DataFrame, dict[str, Any]]:
    reject_holdout_path(path, "Stage1a")
    import pyarrow.parquet as pq

    parquet = pq.ParquetFile(path)
    columns = [str(name) for name in parquet.schema.names]
    required = {"row_hash", "group_hash", "split_year", "split"}
    missing = sorted(required - set(columns))
    if missing:
        raise ValueError(f"Stage1a metadata columns are missing: {missing}")
    pii = pii_columns(columns)
    if pii:
        raise ValueError(f"PII columns found in Stage1a input: {pii}")
    arrival_hits = forbidden_arrival_columns(columns)
    if arrival_hits:
        raise ValueError(f"forbidden arrival feature names found in Stage1a input: {arrival_hits[:20]}")
    frame = pd.read_parquet(path, columns=["row_hash", "group_hash", "split_year", "split"])
    frame["row_hash"] = frame["row_hash"].astype(str)
    frame["group_hash"] = frame["group_hash"].astype(str)
    if frame["row_hash"].duplicated().any():
        raise ValueError("Stage1a row_hash is duplicated")
    if not frame["row_hash"].map(lambda value: bool(HEX64.fullmatch(value))).all():
        raise ValueError("Stage1a row_hash is not a 64-character hash")
    if not frame["group_hash"].map(lambda value: bool(HEX64.fullmatch(value))).all():
        raise ValueError("Stage1a group_hash is missing or not a 64-character hash")
    frame["split_year"] = pd.to_numeric(frame["split_year"], errors="raise").astype(int)
    if not frame["split_year"].between(2020, 2024).all() or frame["split"].astype(str).str.contains("2025", na=False).any():
        raise ValueError("Stage1a contains 2025 or other rows outside 2020-2024")
    expected_split = np.where(frame["split_year"].eq(2024), "validation_2024", "train_2020_2023")
    if not frame["split"].astype(str).eq(expected_split).all():
        raise ValueError("Stage1a split label and split_year are inconsistent")

    if manifest_path is None:
        candidate = path.parent / "stage1a_feature_manifest_v2.json"
        manifest_path = candidate if candidate.is_file() else None
    if manifest_path is None:
        if not smoke:
            raise ValueError("formal Stage2a requires the Stage1a v2 manifest")
        manifest = {"strict_no_arrival_leakage": True, "holdout_policy": {"2025_access_count": 0}}
        manifest_hash = None
    else:
        manifest_path = manifest_path.resolve()
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("strict_no_arrival_leakage") is not True:
            raise ValueError("Stage1a manifest is not strict_no_arrival_leakage")
        holdout = manifest.get("holdout_policy", {})
        has_access_evidence = "2025_access_count" in holdout or "2025_access_count" in manifest
        if not smoke and not has_access_evidence:
            raise ValueError("formal Stage1a manifest lacks explicit 2025 zero-access evidence")
        access_count = holdout.get("2025_access_count", manifest.get("2025_access_count", 0))
        if access_count != 0:
            raise ValueError("Stage1a manifest reports 2025 access")
        manifest_hash = sha256_file(manifest_path)
    return frame, {
        "path": str(path.resolve()),
        "sha256": sha256_file(path),
        "manifest_path": str(manifest_path) if manifest_path is not None else None,
        "manifest_sha256": manifest_hash,
        "strict_no_arrival_leakage": True,
        "pii_hits": 0,
        "arrival_feature_hits": 0,
        "2025_access_count": 0,
    }


def load_predictions(path: Path) -> pd.DataFrame:
    reject_holdout_path(path, "prediction")
    frame = pd.read_parquet(path)
    if frame.columns.tolist() != PREDICTION_COLUMNS:
        raise ValueError(f"predictions are not canonical 8-column long format: {frame.columns.tolist()}")
    for column in ("task_id", "row_hash", "outcome", "model", "split"):
        frame[column] = frame[column].astype(str)
    if not frame["row_hash"].map(lambda value: bool(HEX64.fullmatch(value))).all():
        raise ValueError("prediction row_hash is not a 64-character hash")
    if not set(frame["outcome"]).issubset(OUTCOMES):
        raise ValueError("predictions contain an unknown outcome")
    if not frame["split"].isin(["oof_2020_2023", "validation_2024"]).all():
        raise ValueError("Stage2a accepts only OOF 2020-2023 and validation 2024 predictions")
    probability = pd.to_numeric(frame["prediction"], errors="coerce")
    if probability.isna().any() or not np.isfinite(probability).all() or not probability.between(0, 1).all():
        raise ValueError("predictions contain non-finite or out-of-range probabilities")
    frame["prediction"] = probability.astype(float)
    labels = pd.to_numeric(frame["y_true"], errors="coerce")
    if labels.isna().any() or not labels.isin([0, 1]).all():
        raise ValueError("prediction y_true must be binary 0/1")
    frame["y_true"] = labels.astype("int8")
    duplicate_key = ["task_id", "row_hash", "outcome", "model", "split"]
    if frame.duplicated(duplicate_key).any():
        raise ValueError("duplicate canonical prediction keys")
    analytic_key = ["row_hash", "outcome", "model", "split"]
    if frame.duplicated(analytic_key).any():
        raise ValueError("duplicate analytic prediction keys across tasks")
    inconsistent = frame.groupby(["row_hash", "outcome"], observed=True)["y_true"].nunique()
    if inconsistent.gt(1).any():
        raise ValueError("y_true differs across models for the same row/outcome")
    oof = frame["split"].eq("oof_2020_2023")
    folds = pd.to_numeric(frame["fold"], errors="coerce")
    if folds.loc[oof].isna().any() or not folds.loc[oof].between(0, 4).all():
        raise ValueError("OOF fold must be an integer from 0 through 4")
    if not np.allclose(folds.loc[oof], np.floor(folds.loc[oof])):
        raise ValueError("OOF fold must be integral")
    if folds.loc[~oof].notna().any():
        raise ValueError("validation fold must be null")
    frame["fold"] = pd.array(folds, dtype="Int8")
    return frame


def load_coverage(path: Path) -> pd.DataFrame:
    reject_holdout_path(path, "coverage")
    frame = pd.read_parquet(path)
    if frame.columns.tolist() != COVERAGE_COLUMNS:
        raise ValueError(f"coverage is not canonical: {frame.columns.tolist()}")
    for column in ("task_id", "row_hash", "outcome", "model", "split"):
        frame[column] = frame[column].astype(str)
    if not set(frame["outcome"]).issubset(OUTCOMES):
        raise ValueError("coverage contains an unknown outcome")
    if not frame["row_hash"].map(lambda value: bool(HEX64.fullmatch(value))).all():
        raise ValueError("coverage row_hash is not a 64-character hash")
    if not frame["split"].isin(["oof_2020_2023", "validation_2024"]).all():
        raise ValueError("coverage contains a forbidden split")
    eligible = frame["eligible"]
    if eligible.dtype != bool:
        mapped = eligible.map({0: False, 1: True, "0": False, "1": True, "False": False, "True": True})
        if mapped.isna().any():
            raise ValueError("coverage eligible must be boolean")
        frame["eligible"] = mapped.astype(bool)
    if frame.duplicated(["task_id", "row_hash", "outcome", "model", "split"]).any():
        raise ValueError("duplicate coverage keys")
    return frame


def validate_coverage_cohort(coverage: pd.DataFrame, stage1a: pd.DataFrame) -> None:
    metadata = stage1a[["row_hash", "split_year"]].copy()
    checked = coverage.merge(metadata, on="row_hash", how="left", validate="many_to_one")
    if checked["split_year"].isna().any():
        raise ValueError("coverage contains a row outside the locked Stage1a cohort")
    expected = np.where(
        checked["split_year"].astype(int).eq(2024),
        "validation_2024",
        "oof_2020_2023",
    )
    if not checked["split"].eq(expected).all():
        raise ValueError("coverage split differs from the locked Stage1a split year")


def load_access_log(path: Path | None, *, smoke: bool) -> tuple[dict[str, Any], str | None]:
    if path is None:
        if not smoke:
            raise ValueError("formal Stage2a requires --access-log with explicit 2025 zero-access evidence")
        return {
            "2025_access_count": 0,
            "holdout_mounted": False,
            "predictions_computed": False,
            "smoke_fixture": True,
        }, None
    path = path.resolve()
    value = json.loads(path.read_text(encoding="utf-8"))
    holdout = value.get("holdout_policy", value)
    required = {"2025_access_count", "holdout_mounted", "predictions_computed"}
    if not required.issubset(holdout):
        raise ValueError(f"access log lacks explicit holdout evidence: {sorted(required - set(holdout))}")
    if holdout["2025_access_count"] != 0 or holdout["holdout_mounted"] is not False or holdout["predictions_computed"] is not False:
        raise ValueError("access log reports 2025 access, mount, or predictions")
    return value, sha256_file(path)


def validate_required_artifact(
    path: Path,
    descriptor: dict[str, Any],
    task_id: str,
    registry_task: dict[str, Any],
) -> dict[str, dict[str, str]]:
    nested_roles: dict[str, dict[str, str]] = {}
    kind = descriptor.get("kind")
    if kind == "parquet":
        import pyarrow.parquet as pq

        try:
            columns = [str(column) for column in pq.ParquetFile(path).schema.names]
        except Exception as exc:
            raise ValueError(f"upstream artifact is not readable Parquet: {task_id}/{path.name}") from exc
        expected_columns = descriptor.get("columns")
        if not isinstance(expected_columns, list) or columns != expected_columns:
            raise ValueError(f"upstream Parquet schema differs from registry: {task_id}/{path.name}")
    elif kind == "json":
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError(f"upstream artifact is not readable JSON: {task_id}/{path.name}") from exc
        expected_schema = descriptor.get("schema_version")
        if (
            not isinstance(value, dict)
            or not isinstance(expected_schema, str)
            or value.get("schema_version") != expected_schema
        ):
            raise ValueError(f"upstream JSON schema differs from registry: {task_id}/{path.name}")
    elif kind == "joblib":
        if path.suffix.lower() not in {".joblib", ".pkl", ".pickle"}:
            raise ValueError(f"upstream joblib artifact extension is invalid: {task_id}/{path.name}")
    elif kind in {"zip", "session_task_bundle"}:
        try:
            with zipfile.ZipFile(path) as archive:
                if (
                    archive.testzip() is not None
                    or len(archive.namelist()) != len(set(archive.namelist()))
                ):
                    raise ValueError
                if kind == "session_task_bundle":
                    if "task_manifest.json" not in archive.namelist():
                        raise ValueError
                    embedded = json.loads(
                        archive.read("task_manifest.json").decode("utf-8")
                    )
                    embedded_hashes = embedded.get("artifact_hashes")
                    embedded_roles = embedded.get("artifact_roles", {})
                    if (
                        embedded.get("schema_version") != "1.0"
                        or embedded.get("task_id") != task_id
                        or embedded.get("stage") != registry_task.get("stage")
                        or embedded.get("outcome") != registry_task.get("outcome")
                        or embedded.get("status") != "PASS"
                        or not isinstance(embedded_hashes, dict)
                        or not embedded_hashes
                        or not isinstance(embedded_roles, dict)
                        or set(archive.namelist())
                        != set(embedded_hashes) | {"task_manifest.json"}
                    ):
                        raise ValueError
                    for member, expected_hash in embedded_hashes.items():
                        if (
                            not isinstance(member, str)
                            or not HEX64.fullmatch(str(expected_hash))
                            or hashlib.sha256(archive.read(member)).hexdigest()
                            != str(expected_hash).lower()
                        ):
                            raise ValueError
                    for role, member in embedded_roles.items():
                        if (
                            not isinstance(role, str)
                            or not role
                            or not isinstance(member, str)
                            or member not in embedded_hashes
                        ):
                            raise ValueError
                        nested_roles[role] = {
                            "container_path": str(path),
                            "member": member,
                            "sha256": str(embedded_hashes[member]).lower(),
                        }
        except (OSError, ValueError, zipfile.BadZipFile) as exc:
            raise ValueError(f"upstream ZIP artifact is invalid: {task_id}/{path.name}") from exc
    elif kind != "binary":
        raise ValueError(f"upstream artifact kind is unsupported: {task_id}/{kind}")
    return nested_roles


def load_upstream_completion(
    path: Path,
    registry: dict[str, Any],
    closure: set[str],
    root_task_id: str,
    expected_input_hashes: dict[str, str],
) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if value.get("schema_version") != "1.0":
        raise ValueError("upstream completion ledger schema version is not 1.0")
    if value.get("input_hashes") != expected_input_hashes:
        raise ValueError("upstream completion ledger input hashes differ from Stage2a inputs")
    for field, expected in {
        "strict_no_arrival_leakage": True,
        "forbidden_arrival_feature_hits": 0,
        "pii_hits": 0,
        "2025_access_count": 0,
    }.items():
        if value.get(field) != expected:
            raise ValueError(f"upstream completion ledger violates {field}")
    rows = value.get("tasks")
    if not isinstance(rows, list):
        raise ValueError("upstream completion ledger has no task list")
    task_ids = [str(row.get("task_id", "")) for row in rows]
    if "" in task_ids or len(task_ids) != len(set(task_ids)):
        raise ValueError("upstream completion ledger has blank or duplicate task IDs")
    registry_ids = {str(task["task_id"]) for task in registry["tasks"]}
    unknown = sorted(set(task_ids) - registry_ids)
    if unknown:
        raise ValueError(f"upstream completion ledger has unknown tasks: {unknown[:10]}")
    required = closure - {root_task_id}
    indexed = {str(row["task_id"]): row for row in rows}
    missing = sorted(required - set(indexed))
    if missing:
        raise ValueError(f"upstream completion ledger does not close the registry: {missing[:10]}")
    failures = []
    verified_artifacts = []
    claimed_manifest_paths: set[Path] = set()
    member_owners: dict[Path, str] = {}
    task_artifact_roles: dict[str, dict[str, dict[str, str]]] = {}
    for task_id in sorted(required):
        row = indexed[task_id]
        declared_hash = str(row.get("artifact_sha256", ""))
        declared_path = str(row.get("artifact_path", ""))
        artifact_path = Path(declared_path)
        if not artifact_path.is_absolute():
            artifact_path = (path.parent / artifact_path).resolve()
        if (
            row.get("status") != "IMPORTED_PASS"
            or not HEX64.fullmatch(declared_hash)
            or not declared_path
            or not artifact_path.is_file()
            or sha256_file(artifact_path).lower() != declared_hash.lower()
        ):
            failures.append(task_id)
            continue
        if artifact_path in claimed_manifest_paths:
            raise ValueError(
                f"upstream task manifests must be task-owned and unique: {artifact_path}"
            )
        claimed_manifest_paths.add(artifact_path)
        try:
            artifact_manifest = json.loads(artifact_path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError(
                f"upstream artifact is not a readable task manifest: {task_id}"
            ) from exc
        registry_task = next(
            task for task in registry["tasks"] if str(task["task_id"]) == task_id
        )
        required_artifacts = registry_task.get("required_artifacts")
        locked_input_hashes = registry_task.get("locked_input_hashes")
        locked_code_hashes = registry_task.get("locked_code_sha256")
        if (
            not isinstance(required_artifacts, list)
            or not required_artifacts
            or any(not isinstance(descriptor, dict) for descriptor in required_artifacts)
            or any(
                descriptor.get("required") is not True
                or not isinstance(descriptor.get("schema"), str)
                or not descriptor["schema"]
                for descriptor in required_artifacts
            )
            or not isinstance(locked_input_hashes, dict)
            or not locked_input_hashes
            or not isinstance(locked_code_hashes, dict)
            or not locked_code_hashes
        ):
            raise ValueError(f"registry task lacks an immutable artifact/input/code contract: {task_id}")
        if (
            locked_input_hashes.get("stage1a") != expected_input_hashes["stage1a"]
            or locked_input_hashes.get("fold_map") != expected_input_hashes["fold_map"]
        ):
            raise ValueError(f"registry task locked inputs differ from current Stage2a inputs: {task_id}")
        required_by_path = {
            str(descriptor.get("path", "")): descriptor
            for descriptor in required_artifacts
        }
        if (
            "" in required_by_path
            or len(required_by_path) != len(required_artifacts)
            or any(
                Path(relative).is_absolute()
                or ".." in Path(relative).parts
                or Path(relative).as_posix() != relative
                for relative in required_by_path
            )
        ):
            raise ValueError(f"registry required_artifacts paths are invalid: {task_id}")
        required_roles = {
            str(descriptor["role"]): relative
            for relative, descriptor in required_by_path.items()
            if "role" in descriptor
        }
        if (
            len(required_roles)
            != sum("role" in descriptor for descriptor in required_artifacts)
            or any(not role for role in required_roles)
        ):
            raise ValueError(f"registry artifact roles are blank or duplicated: {task_id}")
        if (
            artifact_manifest.get("schema_version") != "1.0"
            or artifact_manifest.get("task_id") != task_id
            or artifact_manifest.get("stage") != registry_task.get("stage")
            or artifact_manifest.get("status") != "PASS"
            or artifact_manifest.get("outcome") != registry_task.get("outcome")
            or artifact_manifest.get("strict_no_arrival_leakage") is not True
            or artifact_manifest.get("2025_access_count") != 0
        ):
            raise ValueError(f"upstream task manifest ownership/status mismatch: {task_id}")
        manifest_input_hashes = artifact_manifest.get("input_hashes")
        manifest_code_hashes = artifact_manifest.get("code_sha256")
        if (
            not isinstance(manifest_input_hashes, dict)
            or not manifest_input_hashes
            or any(
                not isinstance(name, str)
                or not name
                or not HEX64.fullmatch(str(hash_value))
                for name, hash_value in manifest_input_hashes.items()
            )
            or not isinstance(manifest_code_hashes, dict)
            or not manifest_code_hashes
            or any(
                not isinstance(name, str)
                or not name
                or not HEX64.fullmatch(str(hash_value))
                for name, hash_value in manifest_code_hashes.items()
            )
            or manifest_input_hashes != locked_input_hashes
            or manifest_code_hashes != locked_code_hashes
        ):
            raise ValueError(f"upstream task manifest input/code hashes differ from registry: {task_id}")
        manifest_hashes = artifact_manifest.get("artifact_hashes")
        manifest_roles = artifact_manifest.get("artifact_roles", {})
        if not isinstance(manifest_hashes, dict) or not manifest_hashes:
            raise ValueError(f"upstream task manifest has no artifact hash map: {task_id}")
        if set(manifest_hashes) != set(required_by_path):
            raise ValueError(f"upstream task artifact set differs from registry: {task_id}")
        if manifest_roles != required_roles:
            raise ValueError(f"upstream task artifact roles differ from registry: {task_id}")
        manifest_root = artifact_path.parent.resolve()
        declared_members: set[str] = set()
        verified_roles: dict[str, dict[str, str]] = {}
        for relative, expected_hash in manifest_hashes.items():
            if not isinstance(relative, str) or not HEX64.fullmatch(str(expected_hash)):
                raise ValueError(f"upstream task manifest has an invalid member hash: {task_id}")
            member = (manifest_root / relative).resolve()
            if not member.is_relative_to(manifest_root):
                raise ValueError(f"upstream task manifest member escapes its task directory: {task_id}")
            if not member.is_file() or sha256_file(member).lower() != str(expected_hash).lower():
                raise ValueError(f"upstream task manifest member hash mismatch: {task_id}/{relative}")
            prior_owner = member_owners.get(member)
            if prior_owner is not None and prior_owner != task_id:
                raise ValueError(
                    f"upstream artifact member is claimed by multiple tasks: {prior_owner}/{task_id}/{member}"
                )
            member_owners[member] = task_id
            nested_roles = validate_required_artifact(
                member,
                required_by_path[relative],
                task_id,
                registry_task,
            )
            expected_nested_roles = required_by_path[relative].get(
                "artifact_roles", {}
            )
            observed_nested_roles = {
                role: record["member"] for role, record in nested_roles.items()
            }
            if observed_nested_roles != expected_nested_roles:
                raise ValueError(
                    f"upstream bundled artifact roles differ from registry: {task_id}/{relative}"
                )
            for role, record in nested_roles.items():
                if role in verified_roles:
                    raise ValueError(f"upstream task artifact role is duplicated: {task_id}/{role}")
                verified_roles[role] = record
            direct_role = required_by_path[relative].get("role")
            if direct_role is not None:
                if direct_role in verified_roles:
                    raise ValueError(
                        f"upstream task artifact role is duplicated: {task_id}/{direct_role}"
                    )
                verified_roles[str(direct_role)] = {
                    "path": str(member),
                    "sha256": str(expected_hash).lower(),
                }
            declared_members.add(member.relative_to(manifest_root).as_posix())
        success_path = manifest_root / "_SUCCESS.json"
        try:
            task_success = json.loads(success_path.read_text(encoding="utf-8"))
        except (FileNotFoundError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError(f"upstream task lacks a valid immutable success marker: {task_id}") from exc
        if (
            task_success.get("schema_version") != "1.0"
            or task_success.get("task_id") != task_id
            or task_success.get("status") != "SUCCESS"
            or task_success.get("manifest") != artifact_path.name
            or task_success.get("manifest_sha256") != declared_hash
            or task_success.get("artifact_hashes") != manifest_hashes
            or task_success.get("artifact_roles", {}) != manifest_roles
        ):
            raise ValueError(f"upstream task success marker contract mismatch: {task_id}")
        actual_members = {
            member.relative_to(manifest_root).as_posix()
            for member in manifest_root.rglob("*")
            if member.is_file() and member not in {artifact_path, success_path}
        }
        if actual_members != declared_members:
            raise ValueError(
                f"upstream task manifest member set is not exact: {task_id} "
                f"missing={sorted(declared_members - actual_members)[:10]} "
                f"extra={sorted(actual_members - declared_members)[:10]}"
            )
        task_artifact_roles[task_id] = verified_roles
        verified_artifacts.append(
            {
                "task_id": task_id,
                "task_manifest_path": str(artifact_path),
                "task_manifest_sha256": declared_hash.lower(),
                "artifact_member_count": len(manifest_hashes),
                "artifact_hashes_sha256": sha256_json(manifest_hashes),
                "input_hashes_sha256": sha256_json(manifest_input_hashes),
                "code_sha256": sha256_json(manifest_code_hashes),
            }
        )
    if failures:
        raise ValueError(
            f"upstream registry closure contains non-PASS or unhashed tasks: {failures[:10]}"
        )
    return {
        "path": str(path.resolve()),
        "sha256": sha256_file(path),
        "root_task_id": root_task_id,
        "required_closure_tasks": int(len(required)),
        "completed_closure_tasks": int(len(required)),
        "verified_artifact_count": int(len(verified_artifacts)),
        "verified_artifacts_sha256": sha256_json(verified_artifacts),
        "task_artifact_roles": task_artifact_roles,
        "strict_no_arrival_leakage": True,
        "forbidden_arrival_feature_hits": 0,
        "pii_hits": 0,
        "2025_access_count": 0,
    }


def load_fold_map(
    path: Path | None,
    stage1a: pd.DataFrame,
    outcome: str,
    *,
    expected_sha256: str | None,
    smoke: bool,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    if path is None:
        if not smoke:
            raise ValueError("formal Stage2a requires --fold-map")
        raise ValueError("smoke Stage2a also requires a synthetic locked fold map")
    path = path.resolve()
    reject_holdout_path(path, "fold map")
    actual_sha256 = sha256_file(path)
    if not smoke and expected_sha256 is None:
        raise ValueError("formal Stage2a requires --fold-map-sha256")
    if expected_sha256 is not None and expected_sha256.lower() != actual_sha256.lower():
        raise ValueError("locked fold map SHA256 mismatch")
    frame = pd.read_parquet(path)
    required = ["row_hash", "group_hash", "outcome", "fold", "split_year"]
    if not set(required).issubset(frame.columns):
        raise ValueError(f"fold map lacks columns: {sorted(set(required) - set(frame.columns))}")
    frame = frame[required].copy()
    frame["row_hash"] = frame["row_hash"].astype(str)
    frame["group_hash"] = frame["group_hash"].astype(str)
    frame["outcome"] = frame["outcome"].astype(str)
    if frame["split_year"].astype(int).gt(2024).any():
        raise ValueError("fold map contains 2025")
    frame = frame.loc[frame["outcome"].eq(outcome)].copy()
    if frame.duplicated(["row_hash", "outcome"]).any():
        raise ValueError("fold map contains duplicate row/outcome keys")
    frame["fold"] = pd.to_numeric(frame["fold"], errors="raise").astype(int)
    if not frame["fold"].between(0, 4).all():
        raise ValueError("fold map contains a fold outside 0-4")
    train = stage1a.loc[stage1a["split_year"].between(2020, 2023), ["row_hash", "group_hash", "split_year"]]
    if set(frame["row_hash"]) != set(train["row_hash"]):
        raise ValueError("fold map key set differs from the locked 2020-2023 cohort")
    check = frame.merge(train, on="row_hash", how="left", suffixes=("_fold", "_stage1a"), validate="one_to_one")
    if not check["group_hash_fold"].eq(check["group_hash_stage1a"]).all():
        raise ValueError("fold map group_hash differs from Stage1a")
    if not check["split_year_fold"].astype(int).eq(check["split_year_stage1a"].astype(int)).all():
        raise ValueError("fold map split_year differs from Stage1a")
    if frame.groupby("group_hash", observed=True)["fold"].nunique().gt(1).any():
        raise ValueError("locked fold map places one patient group in multiple folds")
    if not smoke and set(frame["fold"]) != set(range(5)):
        raise ValueError("formal fold map does not contain all five folds")
    contract = {
        "path": str(path),
        "sha256": actual_sha256,
        "rows": int(len(frame)),
        "outcome": outcome,
        "patient_group_overlap": 0,
    }
    contract.update(fold_key_contract(frame))
    return frame, contract


def resolve_artifact_path(declared_path: str, manifest_path: Path) -> Path:
    artifact_path = Path(declared_path)
    if not artifact_path.is_absolute():
        artifact_path = manifest_path.parent / artifact_path
    return artifact_path.resolve()


def load_model_feature_schema(
    path: Path,
    model: str,
    *,
    require_tree_shap: bool = False,
) -> dict[str, Any]:
    try:
        schema = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"model feature schema is not valid JSON: {model}") from exc
    required = {
        "schema_version": "1.0",
        "model": model,
        "prediction_adapter": "joblib_probability_v1",
    }
    if any(schema.get(key) != expected for key, expected in required.items()):
        raise ValueError(f"model feature schema ownership/adapter mismatch: {model}")
    input_features = schema.get("input_feature_names")
    transformed_features = schema.get("feature_names")
    input_dtypes = schema.get("input_dtypes")
    selector = schema.get("artifact_selector")
    predictor_types = schema.get("predictor_types")
    if (
        not isinstance(input_features, list)
        or not input_features
        or any(not isinstance(feature, str) or not feature for feature in input_features)
        or len(input_features) != len(set(input_features))
        or not isinstance(transformed_features, list)
        or not transformed_features
        or any(not isinstance(feature, str) or not feature for feature in transformed_features)
        or len(transformed_features) != len(set(transformed_features))
        or not isinstance(input_dtypes, dict)
        or set(input_dtypes) != set(input_features)
        or any(not isinstance(dtype, str) or not dtype for dtype in input_dtypes.values())
        or not isinstance(selector, dict)
        or not isinstance(predictor_types, list)
        or not predictor_types
        or any(not isinstance(identity, dict) for identity in predictor_types)
    ):
        raise ValueError(f"model feature schema is incomplete: {model}")
    if pii_columns([*input_features, *transformed_features]) or forbidden_arrival_columns(
        [*input_features, *transformed_features]
    ):
        raise ValueError(f"model feature schema contains unsafe features: {model}")
    if selector.get("kind") not in {"direct", "mapping_key", "missingness_pair"}:
        raise ValueError(f"model artifact selector is unsupported: {model}")
    if require_tree_shap and model in TREE_SHAP_MODELS and (
        schema.get("shap_adapter") != "tree_explainer_raw_v1"
        or not isinstance(schema.get("shap_estimator_step"), str)
        or not schema["shap_estimator_step"]
        or not isinstance(schema.get("shap_source_device"), str)
        or not schema["shap_source_device"]
        or schema.get("shap_execution_device") != "cpu"
        or schema.get("shap_device_adapter")
        not in {
            "serialized_tree_cpu_inference_v1",
            "xgboost_booster_cpu_rebind_v1",
        }
    ):
        raise ValueError(f"{model} SHAP schema contract is incomplete")
    return schema


def predictor_identity(predictor: Any) -> dict[str, Any]:
    identity: dict[str, Any] = {
        "module": type(predictor).__module__,
        "qualname": type(predictor).__qualname__,
    }
    if hasattr(predictor, "named_steps"):
        identity["pipeline_steps"] = [
            {
                "name": str(name),
                "module": type(step).__module__,
                "qualname": type(step).__qualname__,
            }
            for name, step in predictor.named_steps.items()
        ]
    return identity


def read_locked_feature_rows(
    stage1a_path: Path,
    row_hashes: list[str],
    schema: dict[str, Any],
    model: str,
) -> pd.DataFrame:
    feature_names = [str(feature) for feature in schema["input_feature_names"]]
    frame = pd.read_parquet(stage1a_path, columns=["row_hash", *feature_names])
    frame["row_hash"] = frame["row_hash"].astype(str)
    if frame["row_hash"].duplicated().any():
        raise ValueError("Stage1a feature source contains duplicate row hashes")
    observed_dtypes = {feature: str(frame[feature].dtype) for feature in feature_names}
    if observed_dtypes != schema["input_dtypes"]:
        raise ValueError(f"locked feature dtypes differ for model: {model}")
    indexed = frame.set_index("row_hash", verify_integrity=True)
    if not set(row_hashes).issubset(indexed.index):
        raise ValueError(f"model canary references rows outside locked Stage1a: {model}")
    return indexed.loc[row_hashes, feature_names].copy()


def select_artifact_predictors(
    artifact: Any,
    selector: dict[str, Any],
    model: str,
) -> list[Any]:
    kind = selector.get("kind")
    if kind == "direct":
        selected = artifact
    elif kind == "mapping_key":
        key = selector.get("key")
        if not isinstance(artifact, dict) or not isinstance(key, str) or key not in artifact:
            raise ValueError(f"model artifact mapping key is unavailable: {model}")
        selected = artifact[key]
    else:
        pair_id = selector.get("pair_id")
        if (
            not isinstance(artifact, dict)
            or not isinstance(pair_id, str)
            or pair_id not in artifact
            or not isinstance(artifact[pair_id], dict)
            or "final" not in artifact[pair_id]
        ):
            raise ValueError(f"missingness model artifact pair is unavailable: {model}")
        expected_label = f"missingness__{pair_id.replace('::', '__')}"
        if expected_label != model:
            raise ValueError(f"missingness model selector ownership mismatch: {model}")
        selected = artifact[pair_id]["final"]
    predictors = selected if isinstance(selected, list) else [selected]
    if not predictors or any(
        not hasattr(predictor, "predict_proba") and not hasattr(predictor, "predict")
        for predictor in predictors
    ):
        raise ValueError(f"model artifact is not an executable probability predictor: {model}")
    return predictors


def predictor_probability(predictor: Any, frame: pd.DataFrame) -> np.ndarray:
    if hasattr(predictor, "predict_proba"):
        prediction = np.asarray(predictor.predict_proba(frame))
        if prediction.ndim == 2:
            if prediction.shape[1] < 2:
                raise ValueError("predict_proba returned fewer than two probability columns")
            prediction = prediction[:, -1]
    else:
        prediction = np.asarray(predictor.predict(frame))
    prediction = prediction.reshape(-1).astype(float)
    if (
        len(prediction) != len(frame)
        or not np.isfinite(prediction).all()
        or (prediction < 0).any()
        or (prediction > 1).any()
    ):
        raise ValueError("reloaded model produced invalid probabilities")
    return prediction


def ensemble_probability(predictors: list[Any], frame: pd.DataFrame) -> np.ndarray:
    return np.mean(
        np.vstack([predictor_probability(predictor, frame) for predictor in predictors]),
        axis=0,
    )


def load_base_model_canary(
    path: Path,
    raw_validation: pd.DataFrame,
    stage1a_path: Path,
    upstream_task_roles: dict[str, dict[str, dict[str, str]]],
    outcome: str,
    shap_model: str,
    *,
    smoke: bool,
) -> tuple[
    pd.DataFrame,
    dict[str, dict[str, Any]],
    dict[str, Any],
    dict[str, dict[str, Any]],
]:
    frame = pd.read_parquet(path)
    if frame.columns.tolist() != BASE_MODEL_CANARY_COLUMNS:
        raise ValueError(
            f"base-model canary is not canonical: {frame.columns.tolist()}"
        )
    for column in (
        "source_task_id",
        "row_hash",
        "outcome",
        "model",
        "split",
        "model_artifact_path",
        "model_sha256",
        "feature_schema_artifact_path",
        "feature_schema_sha256",
    ):
        frame[column] = frame[column].astype(str)
    if set(frame["outcome"]) != {outcome} or not frame["split"].eq(
        "validation_2024"
    ).all():
        raise ValueError("base-model canary outcome/split ownership mismatch")
    if not frame["row_hash"].map(lambda value: bool(HEX64.fullmatch(value))).all():
        raise ValueError("base-model canary row_hash is not a 64-character hash")
    frame["expected_prediction"] = pd.to_numeric(
        frame["expected_prediction"], errors="coerce"
    )
    if (
        frame["expected_prediction"].isna().any()
        or not np.isfinite(frame["expected_prediction"].to_numpy(dtype=float)).all()
        or not frame["expected_prediction"].between(0, 1).all()
    ):
        raise ValueError("base-model canary expected_prediction is invalid")
    expected_models = set(raw_validation["model"])
    if set(frame["model"]) != expected_models:
        raise ValueError("base-model canary model set differs from validation inputs")
    source = raw_validation.set_index(["model", "row_hash"])
    provenance: dict[str, dict[str, Any]] = {}
    inference_contexts: dict[str, dict[str, Any]] = {}
    computed_prediction = pd.Series(index=frame.index, dtype=float)
    maximum_reload_error = 0.0
    maximum_source_error = 0.0
    for model, group in frame.groupby("model", observed=True, sort=True):
        source_group = raw_validation.loc[raw_validation["model"].eq(model)]
        required_rows = min(100, len(source_group)) if smoke else 100
        expected_canary_rows = deterministic_canary_sequence(
            source_group["row_hash"].astype(str).tolist(), required_rows
        )
        expected_unique_rows = min(required_rows, source_group["row_hash"].nunique())
        if (
            len(group) != required_rows
            or group["row_hash"].nunique() != expected_unique_rows
        ):
            raise ValueError(
                "base-model reload canary row/unique-row counts differ from the "
                f"locked selection: {model}"
            )
        if group["row_hash"].tolist() != expected_canary_rows:
            raise ValueError(
                f"base-model canary rows are not the deterministic locked selection: {model}"
            )
        keys = [(str(model), row_hash) for row_hash in group["row_hash"]]
        if any(key not in source.index for key in keys):
            raise ValueError(f"base-model canary row is outside validation: {model}")
        source_rows = source.loc[keys]
        source_task_ids = set(source_rows["task_id"].astype(str))
        if len(source_task_ids) != 1 or set(group["source_task_id"]) != source_task_ids:
            raise ValueError(f"base-model canary source task ownership mismatch: {model}")
        source_task_id = next(iter(source_task_ids))
        source_error = np.abs(
            group["expected_prediction"].to_numpy(dtype=float)
            - source_rows["prediction"].to_numpy(dtype=float)
        )
        maximum_source_error = max(maximum_source_error, float(source_error.max()))
        if float(source_error.max()) > 1e-12:
            raise ValueError(f"base-model canary differs from canonical predictions: {model}")
        model_paths = set(group["model_artifact_path"])
        feature_paths = set(group["feature_schema_artifact_path"])
        model_hashes = set(group["model_sha256"].str.lower())
        feature_hashes = set(group["feature_schema_sha256"].str.lower())
        if (
            len(model_paths) != 1
            or len(feature_paths) != 1
            or len(model_hashes) != 1
            or len(feature_hashes) != 1
        ):
            raise ValueError(f"base-model canary provenance is inconsistent: {model}")
        model_hash = next(iter(model_hashes))
        feature_hash = next(iter(feature_hashes))
        model_path = resolve_artifact_path(next(iter(model_paths)), path)
        feature_path = resolve_artifact_path(next(iter(feature_paths)), path)
        if (
            not HEX64.fullmatch(model_hash)
            or not HEX64.fullmatch(feature_hash)
            or not model_path.is_file()
            or sha256_file(model_path).lower() != model_hash
            or not feature_path.is_file()
            or sha256_file(feature_path).lower() != feature_hash
        ):
            raise ValueError(f"base-model canary model/feature hash is invalid: {model}")
        task_roles = upstream_task_roles.get(source_task_id, {})
        model_role = f"model_artifact:{model}"
        feature_role = f"feature_schema:{model}"
        model_role_record = task_roles.get(model_role)
        feature_role_record = task_roles.get(feature_role)
        if (
            model_role_record is None
            or feature_role_record is None
            or model_role_record.get("sha256") != model_hash
            or feature_role_record.get("sha256") != feature_hash
            or (
                "path" in model_role_record
                and model_role_record["path"] != str(model_path)
            )
            or (
                "path" in feature_role_record
                and feature_role_record["path"] != str(feature_path)
            )
        ):
            raise ValueError(
                f"base-model artifacts are not bound to the verified source task roles: {model}"
            )
        schema = load_model_feature_schema(
            feature_path,
            str(model),
            require_tree_shap=str(model) == shap_model,
        )
        inputs = read_locked_feature_rows(
            stage1a_path,
            group["row_hash"].tolist(),
            schema,
            str(model),
        )
        try:
            artifact = joblib.load(model_path)
        except Exception as exc:
            raise ValueError(f"base-model artifact cannot be deserialized: {model}") from exc
        predictors = select_artifact_predictors(
            artifact,
            schema["artifact_selector"],
            str(model),
        )
        predictor_types = [predictor_identity(predictor) for predictor in predictors]
        if predictor_types != schema["predictor_types"]:
            raise ValueError(f"reloaded predictor type differs from locked schema: {model}")
        actual_prediction = ensemble_probability(predictors, inputs)
        reload_error = np.abs(
            actual_prediction - group["expected_prediction"].to_numpy(dtype=float)
        )
        maximum_reload_error = max(maximum_reload_error, float(reload_error.max()))
        if float(reload_error.max()) > MODEL_RELOAD_TOLERANCE:
            raise ValueError(
                f"base-model reload canary exceeds {MODEL_RELOAD_TOLERANCE}: {model}"
            )
        computed_prediction.loc[group.index] = actual_prediction
        provenance[str(model)] = {
            "source_task_id": source_task_id,
            "model_artifact_path": str(model_path),
            "model_sha256": model_hash,
            "feature_schema_artifact_path": str(feature_path),
            "feature_schema_sha256": feature_hash,
            "canary_rows": required_rows,
            "unique_canary_rows": expected_unique_rows,
            "repeated_canary_rows": required_rows - expected_unique_rows,
            "prediction_adapter": schema["prediction_adapter"],
            "artifact_selector": schema["artifact_selector"],
            "input_feature_order_sha256": sha256_json(schema["input_feature_names"]),
            "input_dtypes_sha256": sha256_json(schema["input_dtypes"]),
            "predictor_types": predictor_types,
            "model_artifact_role": model_role,
            "feature_schema_role": feature_role,
            "canary_selection_seed": CANARY_SELECTION_SEED,
            "actual_reload_inference_performed": True,
        }
        inference_contexts[str(model)] = {
            "predictors": predictors,
            "schema": schema,
        }
    verified_frame = frame.copy()
    verified_frame["computed_reloaded_prediction"] = computed_prediction
    verified_frame["absolute_reload_error"] = np.abs(
        verified_frame["computed_reloaded_prediction"]
        - verified_frame["expected_prediction"]
    )
    return verified_frame, provenance, {
        "path": str(path.resolve()),
        "sha256": sha256_file(path),
        "models": int(len(provenance)),
        "verified_model_artifact_count": int(len(provenance)),
        "model_provenance_sha256": sha256_json(provenance),
        "canary_rows_per_full_model": 100,
        "maximum_source_prediction_error": maximum_source_error,
        "maximum_reload_prediction_error": maximum_reload_error,
        "tolerance": MODEL_RELOAD_TOLERANCE,
        "verification_method": "stage2a_joblib_reload_and_fresh_inference",
        "status": "SMOKE_PASS" if smoke else "PASS",
    }, inference_contexts


def load_launch_authorization(
    path: Path,
    task_id: str,
    outcome: str,
    locked_hashes: dict[str, str],
    cohort_contract: dict[str, Any],
    fold_contract: dict[str, Any],
    run_contract: dict[str, Any],
    *,
    smoke: bool,
) -> dict[str, Any]:
    authorization_sha256 = sha256_file(path)
    value = json.loads(path.read_text(encoding="utf-8"))
    if (
        value.get("schema_version") != "1.0"
        or value.get("authorization_status") != "AUTHORIZED"
        or value.get("stage") != "P1_03"
        or value.get("task_id") != task_id
        or value.get("outcome") != outcome
        or value.get("maximum_development_year") != 2024
        or value.get("historical_2025_exposure") is not True
    ):
        raise ValueError("launch authorization ownership/status contract mismatch")
    for field in ("prompt_set_sha256", "requirement_matrix_sha256"):
        if not HEX64.fullmatch(str(value.get(field, ""))):
            raise ValueError(f"launch authorization lacks a locked {field}")
    if value.get("locked_hashes") != locked_hashes:
        raise ValueError("launch authorization locked hashes differ from current inputs")
    if value.get("cohort_contract") != cohort_contract:
        raise ValueError("launch authorization cohort key-set contract mismatch")
    expected_fold_contract = {
        key: fold_contract[key]
        for key in (
            "rows",
            "row_key_set_sha256",
            "row_group_outcome_fold_year_sha256",
        )
    }
    if value.get("fold_contract") != expected_fold_contract:
        raise ValueError("launch authorization fold key-set contract mismatch")
    if value.get("run_contract") != run_contract:
        raise ValueError("launch authorization run contract mismatch")
    anchor = os.environ.get(AUTHORIZATION_ANCHOR_ENV)
    if not smoke:
        if not anchor or not HEX64.fullmatch(anchor):
            raise ValueError(
                f"formal Stage2a requires precommitted {AUTHORIZATION_ANCHOR_ENV}"
            )
        if anchor.lower() != authorization_sha256.lower():
            raise ValueError("launch authorization does not match the precommitted trust anchor")
    return {
        "path": str(path.resolve()),
        "sha256": authorization_sha256,
        "anchor_environment_variable": AUTHORIZATION_ANCHOR_ENV,
        "anchor_verified": not smoke,
        "prompt_set_sha256": value["prompt_set_sha256"],
        "requirement_matrix_sha256": value["requirement_matrix_sha256"],
        "cohort_contract": cohort_contract,
        "fold_contract": expected_fold_contract,
        "run_contract": run_contract,
    }


def registry_closure(by_id: dict[str, dict[str, Any]], root_task_id: str) -> set[str]:
    visited: set[str] = set()
    active: set[str] = set()

    def visit(task_id: str) -> None:
        if task_id in active:
            raise ValueError(f"task registry dependency cycle reaches {task_id}")
        if task_id in visited:
            return
        if task_id not in by_id:
            raise ValueError(f"task registry dependency is missing: {task_id}")
        active.add(task_id)
        for dependency in by_id[task_id].get("dependencies", []):
            visit(str(dependency))
        active.remove(task_id)
        visited.add(task_id)

    visit(root_task_id)
    return visited


def prespecified_full_complete_case_validation_omission(
    model: str,
    predictions: pd.DataFrame,
    group_hash_by_row: pd.Series,
    not_estimable_allowed_models: set[str],
) -> bool:
    if (
        model not in not_estimable_allowed_models
        or not model.startswith("missingness__full_complete_case__")
    ):
        return False
    validation = predictions.loc[
        predictions["split"].eq("validation_2024"),
        ["row_hash", "y_true"],
    ].copy()
    validation["group_hash"] = validation["row_hash"].map(group_hash_by_row)
    if validation["group_hash"].isna().any():
        raise ValueError(
            f"complete-case validation row is absent from Stage1a metadata: {model}"
        )
    group_event = validation.groupby("group_hash", observed=True)["y_true"].max()
    return set(group_event.astype(int)) != {0, 1}


def load_registry(
    path: Path,
    mode: str,
    outcome: str,
    predictions: pd.DataFrame,
    coverage: pd.DataFrame,
    stage1a_path: Path,
    expected_split_counts: dict[str, int],
    *,
    smoke: bool,
) -> tuple[
    dict[str, Any],
    dict[str, dict[str, Any]],
    dict[str, Any],
    set[str],
    pd.DataFrame,
    pd.DataFrame,
    list[dict[str, Any]],
    set[str],
]:
    registry = json.loads(path.read_text(encoding="utf-8"))
    tasks = registry.get("tasks")
    if not isinstance(tasks, list):
        raise ValueError("task registry has no task list")
    task_ids = [str(task.get("task_id", "")) for task in tasks]
    if "" in task_ids or len(task_ids) != len(set(task_ids)):
        raise ValueError("task registry contains blank or duplicate task IDs")
    by_id = {str(task["task_id"]): task for task in tasks}
    evaluation_family = "evaluation_bundle" if mode == "core" else "evaluation_refresh_bundle"
    evaluation_tasks = [
        task
        for task in tasks
        if task.get("task_family") == evaluation_family and task.get("outcome") == outcome
    ]
    if len(evaluation_tasks) != 1:
        raise ValueError(f"registry must contain exactly one {mode} Stage2a task for {outcome}")
    evaluation_task = evaluation_tasks[0]
    closure = registry_closure(by_id, str(evaluation_task["task_id"]))
    predictive_families = CORE_PREDICTIVE_FAMILIES if mode == "core" else FINAL_PREDICTIVE_FAMILIES
    expected = {
        task_id: by_id[task_id]
        for task_id in closure
        if by_id[task_id].get("task_family") in predictive_families
        and by_id[task_id].get("outcome") == outcome
    }
    selected_predictions = predictions.loc[predictions["outcome"].eq(outcome)].copy()
    selected_coverage = coverage.loc[coverage["outcome"].eq(outcome)].copy()
    missingness_contracts: dict[str, dict[str, Any]] = {}
    observed = set(selected_predictions["task_id"]) | set(selected_coverage["task_id"])
    missing = sorted(set(expected) - observed)
    extra = sorted(observed - set(expected))
    if missing or extra:
        raise ValueError(f"prediction/registry ownership mismatch missing={missing[:10]} extra={extra[:10]}")
    for task_id, task in expected.items():
        group = selected_predictions.loc[selected_predictions["task_id"].eq(task_id)]
        task_outcome = str(task.get("outcome"))
        family = task.get("task_family")
        if group.empty and family != "missingness_bundle":
            raise ValueError(f"predictive task has no predictions: {task_id}")
        if not group.empty and not group["outcome"].eq(task_outcome).all():
            raise ValueError(f"outcome ownership mismatch for {task_id}")
        registered_model = task.get("model")
        if family == "clinical_score":
            allowed_models = {f"score_{registered_model}"}
        elif family == "stage1b_model":
            allowed_models = {str(registered_model)}
        elif family == "missingness_bundle":
            metadata = task.get("metadata", {})
            if not isinstance(metadata, dict):
                raise ValueError(f"missingness registry metadata is invalid: {task_id}")

            def contract_value(name: str) -> Any:
                return task.get(name, metadata.get(name))

            expected_models_value = contract_value("expected_models")
            partial_models_value = contract_value("partial_eligibility_models")
            not_estimable_value = contract_value("not_estimable_allowed_models")
            eligibility_features_value = contract_value("eligibility_required_features")
            if not isinstance(expected_models_value, list) or not expected_models_value:
                raise ValueError(f"missingness task lacks an exact expected_models contract: {task_id}")
            if not isinstance(partial_models_value, list) or not isinstance(not_estimable_value, list):
                raise ValueError(f"missingness task lacks eligibility exception lists: {task_id}")
            if not isinstance(eligibility_features_value, dict):
                raise ValueError(f"missingness task lacks eligibility feature rules: {task_id}")
            allowed_models = {str(model) for model in expected_models_value}
            partial_models = {str(model) for model in partial_models_value}
            not_estimable_models = {str(model) for model in not_estimable_value}
            if len(allowed_models) != len(expected_models_value) or not all(
                model.startswith("missingness__") for model in allowed_models
            ):
                raise ValueError(f"missingness task emitted an invalid model label: {task_id}")
            strategies = {
                model.removeprefix("missingness__").rsplit("__", 1)[0]
                for model in allowed_models
            }
            if (
                contract_value("model_strategy_pair_count") != len(allowed_models)
                or contract_value("strategy_count") != len(strategies)
                or not partial_models.issubset(allowed_models)
                or not not_estimable_models.issubset(partial_models)
                or set(eligibility_features_value) != partial_models
                or any("complete_case" not in model for model in partial_models)
            ):
                raise ValueError(f"missingness registry count/eligibility contract mismatch: {task_id}")
            required_strategies, required_pair_count = (
                formal_missingness_strategy_contract(str(task.get("outcome")))
            )
            if not smoke and (
                len(allowed_models) != required_pair_count
                or strategies != required_strategies
            ):
                raise ValueError(
                    "formal missingness contract differs from the outcome-specific "
                    f"frozen strategy/pair set: {task_id}"
                )
            normalized_features: dict[str, list[str]] = {}
            for model, features in eligibility_features_value.items():
                if (
                    not isinstance(features, list)
                    or not features
                    or any(not isinstance(feature, str) or not feature for feature in features)
                    or len(features) != len(set(features))
                ):
                    raise ValueError(f"invalid missingness eligibility feature rule: {task_id}/{model}")
                if pii_columns(features) or forbidden_arrival_columns(features):
                    raise ValueError(f"unsafe missingness eligibility feature rule: {task_id}/{model}")
                normalized_features[str(model)] = [str(feature) for feature in features]
            missingness_contracts[task_id] = {
                "expected_models": allowed_models,
                "partial_eligibility_models": partial_models,
                "not_estimable_allowed_models": not_estimable_models,
                "eligibility_required_features": normalized_features,
            }
        else:
            allowed_models = {str(registered_model)}
        if not set(group["model"]).issubset(allowed_models):
            raise ValueError(f"model ownership mismatch for {task_id}: {sorted(set(group['model']))}")
        if not group.empty and set(group["split"]) != {"oof_2020_2023", "validation_2024"}:
            raise ValueError(f"task lacks both required prediction splits: {task_id}")
        if family in {"stage1b_model", "stage3a_model", "stage3b_model"}:
            actual_counts = group.groupby("split", observed=True)["row_hash"].nunique().to_dict()
            if actual_counts != expected_split_counts:
                raise ValueError(
                    f"full-coverage task is truncated: {task_id} actual={actual_counts} expected={expected_split_counts}"
                )
            if not smoke and set(group.loc[group["split"].eq("oof_2020_2023"), "fold"].astype(int)) != set(range(5)):
                raise ValueError(f"formal full-coverage task does not contain all five OOF folds: {task_id}")
    expected_coverage_tasks = {
        task_id for task_id, task in expected.items() if task.get("stage") == "P1_02"
    }
    observed_coverage_tasks = set(selected_coverage["task_id"])
    if expected_coverage_tasks != observed_coverage_tasks:
        raise ValueError(
            "coverage/registry ownership mismatch "
            f"missing={sorted(expected_coverage_tasks - observed_coverage_tasks)[:10]} "
            f"extra={sorted(observed_coverage_tasks - expected_coverage_tasks)[:10]}"
        )
    coverage_omissions: list[dict[str, Any]] = []
    terminal_evaluation_models: set[str] = set()
    all_stage1a_rows = sum(expected_split_counts.values())
    required_eligibility_features = sorted(
        {
            feature
            for contract in missingness_contracts.values()
            for features in contract["eligibility_required_features"].values()
            for feature in features
        }
    )
    stage1a_eligibility = pd.read_parquet(
        stage1a_path,
        columns=["row_hash", "group_hash", *required_eligibility_features],
    )
    stage1a_eligibility["row_hash"] = stage1a_eligibility["row_hash"].astype(str)
    stage1a_eligibility = stage1a_eligibility.set_index("row_hash", verify_integrity=True)
    for task_id in sorted(expected_coverage_tasks):
        task = expected[task_id]
        task_predictions = selected_predictions.loc[selected_predictions["task_id"].eq(task_id)]
        task_coverage = selected_coverage.loc[selected_coverage["task_id"].eq(task_id)]
        coverage_models = sorted(set(task_coverage["model"]))
        if not coverage_models:
            raise ValueError(f"coverage task has no model rows: {task_id}")
        missingness_contract = missingness_contracts.get(task_id)
        if missingness_contract is not None and set(coverage_models) != missingness_contract[
            "expected_models"
        ]:
            raise ValueError(f"missingness coverage models differ from the locked registry: {task_id}")
        for model in coverage_models:
            model_coverage = task_coverage.loc[task_coverage["model"].eq(model)]
            if len(model_coverage) != all_stage1a_rows:
                raise ValueError(f"coverage is not 100% over the locked cohort: {task_id}/{model}")
            counts = model_coverage.groupby("split", observed=True)["row_hash"].nunique().to_dict()
            if counts != expected_split_counts:
                raise ValueError(f"coverage split counts differ from Stage1a: {task_id}/{model}")
            if missingness_contract is not None:
                indexed_coverage = model_coverage.set_index("row_hash", verify_integrity=True)
                if model in missingness_contract["partial_eligibility_models"]:
                    required_features = missingness_contract["eligibility_required_features"][model]
                    derived = stage1a_eligibility.loc[indexed_coverage.index, required_features].notna().all(axis=1)
                else:
                    derived = pd.Series(True, index=indexed_coverage.index)
                submitted = indexed_coverage["eligible"].astype(bool)
                if not submitted.equals(derived.astype(bool)):
                    raise ValueError(
                        f"missingness eligibility differs from locked Stage1a derivation: {task_id}/{model}"
                    )
            eligible_keys = set(
                zip(
                    model_coverage.loc[model_coverage["eligible"], "row_hash"],
                    model_coverage.loc[model_coverage["eligible"], "split"],
                )
            )
            model_predictions = task_predictions.loc[task_predictions["model"].eq(model)]
            prediction_keys = set(zip(model_predictions["row_hash"], model_predictions["split"]))
            if model_predictions.empty:
                if task.get("task_family") != "missingness_bundle":
                    raise ValueError(f"non-missingness model has no predictions: {task_id}/{model}")
                eligible_rows = int(model_coverage["eligible"].sum())
                allowed_not_estimable = (
                    missingness_contract is not None
                    and model in missingness_contract["not_estimable_allowed_models"]
                )
                if eligible_rows != 0 or not allowed_not_estimable:
                    raise ValueError(
                        "missingness model omission is not a locked, independently derived "
                        f"NOT_ESTIMABLE case: {task_id}/{model} eligible={eligible_rows}"
                    )
                coverage_omissions.append(
                    {
                        "task_id": task_id,
                        "model": model,
                        "eligible_rows": eligible_rows,
                        "status": "NOT_ESTIMABLE",
                    }
                )
                continue
            if prediction_keys != eligible_keys:
                raise ValueError(f"prediction rows do not equal eligible coverage rows: {task_id}/{model}")
            if (
                missingness_contract is not None
                and prespecified_full_complete_case_validation_omission(
                    model,
                    model_predictions,
                    stage1a_eligibility["group_hash"],
                    missingness_contract["not_estimable_allowed_models"],
                )
            ):
                coverage_omissions.append(
                    {
                        "task_id": task_id,
                        "model": model,
                        "eligible_rows": int(model_coverage["eligible"].sum()),
                        "status": "NOT_ESTIMABLE",
                    }
                )
                terminal_evaluation_models.add(model)
        prediction_models = set(task_predictions["model"])
        unmanifested_models = sorted(prediction_models - set(coverage_models))
        if unmanifested_models:
            raise ValueError(
                f"prediction models are absent from coverage: {task_id}/{unmanifested_models}"
            )
        missing_prediction_models = set(coverage_models) - prediction_models
        allowed_absent_omissions = {
            row["model"]
            for row in coverage_omissions
            if row["task_id"] == task_id and row["eligible_rows"] == 0
        }
        if missing_prediction_models != allowed_absent_omissions:
            raise ValueError(f"coverage models differ from prediction models: {task_id}")
    return (
        registry,
        expected,
        evaluation_task,
        closure,
        selected_predictions,
        selected_coverage,
        coverage_omissions,
        terminal_evaluation_models,
    )


def join_and_validate(
    predictions: pd.DataFrame, stage1a: pd.DataFrame, fold_map: pd.DataFrame
) -> pd.DataFrame:
    joined = predictions.merge(stage1a, on="row_hash", how="left", validate="many_to_one")
    if joined["group_hash"].isna().any():
        raise ValueError("prediction row_hash is absent from Stage1a metadata")
    oof = joined["split_x"].eq("oof_2020_2023") if "split_x" in joined else joined["split"].eq("oof_2020_2023")
    prediction_split = "split_x" if "split_x" in joined else "split"
    metadata_split = "split_y" if "split_y" in joined else "split"
    if not joined.loc[oof, "split_year"].between(2020, 2023).all():
        raise ValueError("OOF predictions are not restricted to 2020-2023")
    if not joined.loc[~oof, "split_year"].eq(2024).all():
        raise ValueError("Stage2a evaluation is not restricted to 2024 validation")
    if joined[metadata_split].astype(str).str.contains("2025", na=False).any():
        raise ValueError("joined Stage1a metadata contains 2025")
    split_overlap = joined.groupby("group_hash", observed=True)[prediction_split].nunique()
    if split_overlap.gt(1).any():
        raise ValueError("patient group overlaps OOF and validation splits")
    oof_frame = joined.loc[oof]
    row_fold = oof_frame.groupby(["outcome", "row_hash"], observed=True)["fold"].nunique()
    if row_fold.gt(1).any():
        raise ValueError("row fold overlap across models")
    group_fold = oof_frame.groupby(["outcome", "group_hash"], observed=True)["fold"].nunique()
    if group_fold.gt(1).any():
        raise ValueError("patient group fold overlap across models")
    locked = fold_map[["row_hash", "fold", "group_hash"]].rename(
        columns={"fold": "locked_fold", "group_hash": "locked_group_hash"}
    )
    fold_check = oof_frame.merge(locked, on="row_hash", how="left", validate="many_to_one")
    if fold_check["locked_fold"].isna().any():
        raise ValueError("OOF prediction row is absent from the locked fold map")
    if not fold_check["fold"].astype(int).eq(fold_check["locked_fold"].astype(int)).all():
        raise ValueError("OOF prediction fold differs from the locked fold map")
    if not fold_check["group_hash"].astype(str).eq(fold_check["locked_group_hash"].astype(str)).all():
        raise ValueError("OOF prediction group differs from the locked fold map")
    if prediction_split != "split":
        joined = joined.drop(columns=[metadata_split]).rename(columns={prediction_split: "split"})
    return joined


def base_model_name(model: str) -> str:
    for suffix in ("__raw", "__platt", "__isotonic"):
        if model.endswith(suffix):
            return model[: -len(suffix)]
    return model


def model_family(model: str) -> str:
    model = base_model_name(model)
    lower = model.lower()
    if model.startswith("missingness__"):
        return "missingness_sensitivity"
    if model.startswith("score_"):
        return "traditional_score"
    if model in {"xgboost", "lightgbm", "catboost"}:
        return "gbdt"
    if "logistic" in lower:
        return "linear"
    if "stack" in lower:
        return "stacking"
    if any(token in lower for token in ("bert", "mlp", "transformer", "cnn")):
        return "deep"
    if any(token in lower for token in ("tabpfn", "tabicl")):
        return "foundation"
    return "common_ml"


def clip_probability(prediction: np.ndarray) -> np.ndarray:
    return np.clip(np.asarray(prediction, dtype=float), 1e-8, 1 - 1e-8)


def logit(prediction: np.ndarray) -> np.ndarray:
    probability = clip_probability(prediction)
    return np.log(probability / (1 - probability))


def fit_platt(prediction: np.ndarray, y: np.ndarray, seed: int) -> dict[str, Any]:
    if len(np.unique(y)) != 2:
        raise ValueError("Platt calibration training rows lack one outcome class")
    intercept, slope = calibration_intercept_slope(
        y,
        prediction,
        np.ones(len(y), dtype=float),
    )
    if not math.isfinite(intercept) or not math.isfinite(slope):
        raise ValueError("Platt calibration failed to converge")
    return {
        "intercept": float(intercept),
        "slope": float(slope),
        "solver": "unpenalized_damped_newton_logistic",
        "seed_contract": int(seed),
        "converged": True,
    }


def fit_isotonic(prediction: np.ndarray, y: np.ndarray) -> IsotonicRegression:
    if len(np.unique(y)) != 2 or len(np.unique(prediction)) < 2:
        raise ValueError("isotonic calibration is not estimable")
    model = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
    model.fit(prediction, y)
    return model


def apply_calibrator(model: Any, method: str, prediction: np.ndarray) -> np.ndarray:
    if method == "raw":
        calibrated = np.asarray(prediction, dtype=float)
    elif method == "platt":
        calibrated = expit(
            float(model["intercept"]) + float(model["slope"]) * logit(prediction)
        )
    elif method == "isotonic":
        calibrated = model.predict(prediction)
    else:
        raise ValueError(f"unknown calibration method: {method}")
    calibrated = np.asarray(calibrated, dtype=float)
    if not np.isfinite(calibrated).all() or ((calibrated < 0) | (calibrated > 1)).any():
        raise ValueError(f"{method} produced an invalid calibrated probability")
    return calibrated


def calibration_metric_rows(
    frame: pd.DataFrame, base_model: str, method: str, split: str, selected: bool
) -> list[dict[str, Any]]:
    y = frame["y_true"].to_numpy(dtype=int)
    prediction = frame["prediction"].to_numpy(dtype=float)
    values = metric_values(y, prediction, np.ones(len(frame), dtype=float))
    return [
        {
            "outcome": str(frame["outcome"].iloc[0]),
            "base_model": base_model,
            "calibration_method": method,
            "model": f"{base_model}__{method}",
            "split": split,
            "selected_by_crossfit_oof_brier": selected,
            "metric": metric,
            "value": float(value) if math.isfinite(value) else None,
            "n": int(len(frame)),
            "events": int(y.sum()),
        }
        for metric, value in values.items()
    ]


def crossfit_calibration(
    group: pd.DataFrame,
    evaluation_task_id: str,
    *,
    seed: int,
) -> tuple[dict[str, Any], pd.DataFrame, list[dict[str, Any]]]:
    outcome = str(group["outcome"].iloc[0])
    base_model = str(group["model"].iloc[0])
    oof = group.loc[group["split"].eq("oof_2020_2023")].copy()
    validation = group.loc[group["split"].eq("validation_2024")].copy()
    if oof.empty or validation.empty:
        raise ValueError(f"calibration requires both OOF and validation predictions: {base_model}")
    crossfit = {
        "raw": oof["prediction"].to_numpy(dtype=float),
        "platt": np.full(len(oof), np.nan, dtype=float),
        "isotonic": np.full(len(oof), np.nan, dtype=float),
    }
    folds = sorted(oof["fold"].astype(int).unique())
    for fold in folds:
        fit_mask = oof["fold"].astype(int).ne(fold).to_numpy()
        test_mask = ~fit_mask
        y_fit = oof.loc[fit_mask, "y_true"].to_numpy(dtype=int)
        prediction_fit = oof.loc[fit_mask, "prediction"].to_numpy(dtype=float)
        prediction_test = oof.loc[test_mask, "prediction"].to_numpy(dtype=float)
        platt = fit_platt(prediction_fit, y_fit, stable_seed(seed + fold, outcome, base_model))
        isotonic = fit_isotonic(prediction_fit, y_fit)
        crossfit["platt"][test_mask] = apply_calibrator(platt, "platt", prediction_test)
        crossfit["isotonic"][test_mask] = apply_calibrator(isotonic, "isotonic", prediction_test)
    if not np.isfinite(crossfit["platt"]).all() or not np.isfinite(crossfit["isotonic"]).all():
        raise ValueError(f"cross-fit calibration did not cover every OOF row: {base_model}")
    y_oof = oof["y_true"].to_numpy(dtype=int)
    oof_brier = {
        method: float(np.mean((y_oof - prediction) ** 2))
        for method, prediction in crossfit.items()
    }
    method_order = {"raw": 0, "platt": 1, "isotonic": 2}
    selected_method = min(oof_brier, key=lambda method: (oof_brier[method], method_order[method]))
    final_platt = fit_platt(
        oof["prediction"].to_numpy(dtype=float),
        y_oof,
        stable_seed(seed + 1000, outcome, base_model),
    )
    final_isotonic = fit_isotonic(oof["prediction"].to_numpy(dtype=float), y_oof)
    validation_raw = validation["prediction"].to_numpy(dtype=float)
    validation_predictions = {
        "raw": validation_raw,
        "platt": apply_calibrator(final_platt, "platt", validation_raw),
        "isotonic": apply_calibrator(final_isotonic, "isotonic", validation_raw),
    }
    prediction_parts = []
    comparison_rows: list[dict[str, Any]] = []
    for method in ("raw", "platt", "isotonic"):
        oof_part = oof[PREDICTION_COLUMNS].copy()
        oof_part["task_id"] = evaluation_task_id
        oof_part["model"] = f"{base_model}__{method}"
        oof_part["prediction"] = crossfit[method]
        validation_part = validation[PREDICTION_COLUMNS].copy()
        validation_part["task_id"] = evaluation_task_id
        validation_part["model"] = f"{base_model}__{method}"
        validation_part["prediction"] = validation_predictions[method]
        prediction_parts.extend([oof_part, validation_part])
        comparison_rows.extend(
            calibration_metric_rows(
                oof_part,
                base_model,
                method,
                "oof_2020_2023_crossfit",
                method == selected_method,
            )
        )
        comparison_rows.extend(
            calibration_metric_rows(
                validation_part,
                base_model,
                method,
                "validation_2024",
                method == selected_method,
            )
        )
    bundle = {
        "outcome": outcome,
        "base_model": base_model,
        "source_task_id": str(group["task_id"].iloc[0]),
        "platt": final_platt,
        "isotonic": final_isotonic,
        "selected_method": selected_method,
        "crossfit_oof_brier": oof_brier,
        "fit_split": "oof_2020_2023",
        "validation_fit_rows": 0,
        "uses_2025": False,
    }
    return bundle, pd.concat(prediction_parts, ignore_index=True), comparison_rows


def write_calibrator_canary(
    model_path: Path,
    output_dir: Path,
    raw_validation: pd.DataFrame,
    in_memory_models: dict[str, Any],
    *,
    smoke: bool,
) -> tuple[dict[str, Any], list[Path]]:
    selected_rows = []
    for model, group in raw_validation.groupby("model", observed=True, sort=True):
        row = group.sort_values("row_hash", kind="mergesort").iloc[0]
        selected_rows.append((str(row["row_hash"]), str(model)))
    selected_hashes = {row_hash for row_hash, _ in selected_rows}
    for row_hash in sorted(set(raw_validation["row_hash"])):
        if len(selected_hashes) >= 100:
            break
        selected_hashes.add(str(row_hash))
    inputs = raw_validation.loc[
        raw_validation["row_hash"].isin(selected_hashes),
        ["row_hash", "outcome", "model", "prediction"],
    ].rename(columns={"model": "base_model", "prediction": "raw_prediction"})
    inputs = inputs.sort_values(["base_model", "row_hash"], kind="mergesort").reset_index(drop=True)

    def predict_from_reload(reloaded: dict[str, Any]) -> pd.DataFrame:
        parts = []
        for base_model, group in inputs.groupby("base_model", observed=True, sort=True):
            bundle = reloaded[str(base_model)]
            raw = group["raw_prediction"].to_numpy(dtype=float)
            for method in ("platt", "isotonic"):
                parts.append(
                    pd.DataFrame(
                        {
                            "row_hash": group["row_hash"].to_numpy(),
                            "outcome": group["outcome"].to_numpy(),
                            "model": f"{base_model}__{method}",
                            "prediction": apply_calibrator(bundle[method], method, raw),
                        }
                    )
                )
        return pd.concat(parts, ignore_index=True).sort_values(
            ["model", "row_hash"], kind="mergesort"
        ).reset_index(drop=True)

    expected = predict_from_reload(in_memory_models)
    inputs_path = output_dir / "calibrator_canary_inputs.parquet"
    expected_path = output_dir / "calibrator_canary_expected.parquet"
    atomic_parquet(inputs_path, inputs)
    atomic_parquet(expected_path, expected)
    actual = predict_from_reload(joblib.load(model_path))
    if not actual[["row_hash", "outcome", "model"]].equals(
        expected[["row_hash", "outcome", "model"]]
    ):
        raise ValueError("calibrator reload canary keys differ")
    error = np.abs(
        actual["prediction"].to_numpy(dtype=float)
        - expected["prediction"].to_numpy(dtype=float)
    )
    maximum_error = float(error.max()) if len(error) else 0.0
    if maximum_error > 1e-5:
        raise ValueError(f"calibrator reload canary error {maximum_error} exceeds 1e-5")
    return {
        "status": "SMOKE_PASS" if smoke else "PASS",
        "unique_validation_rows": int(inputs["row_hash"].nunique()),
        "long_input_rows": int(len(inputs)),
        "expected_prediction_rows": int(len(expected)),
        "maximum_absolute_error": maximum_error,
        "tolerance": 1e-5,
        "inputs_artifact": inputs_path.name,
        "expected_artifact": expected_path.name,
    }, [inputs_path, expected_path]


def calibration_in_large(y: np.ndarray, prediction: np.ndarray, sample_weight: np.ndarray) -> float:
    x = logit(prediction)
    total_weight = float(np.sum(sample_weight))
    event_weight = float(np.sum(sample_weight * y))
    if total_weight <= 0 or event_weight <= 0 or event_weight >= total_weight:
        return float("nan")
    lower = -100.0
    upper = 100.0
    for _ in range(100):
        alpha = (lower + upper) / 2
        gradient = float(np.sum(sample_weight * (y - expit(alpha + x))))
        if abs(gradient) < 1e-12 or upper - lower < 1e-12:
            return float(alpha)
        if gradient > 0:
            lower = alpha
        else:
            upper = alpha
    return float((lower + upper) / 2)


def calibration_intercept_slope(
    y: np.ndarray, prediction: np.ndarray, sample_weight: np.ndarray
) -> tuple[float, float]:
    x = logit(prediction)
    if np.average((x - np.average(x, weights=sample_weight)) ** 2, weights=sample_weight) <= 1e-12:
        return float("nan"), float("nan")
    design = np.column_stack([np.ones(len(x)), x])
    prevalence = float(np.average(y, weights=sample_weight))
    if prevalence <= 0 or prevalence >= 1:
        return float("nan"), float("nan")
    coefficients = np.array([math.log(prevalence / (1 - prevalence)), 0.0], dtype=float)
    ridge = np.diag([1e-10, 1e-10])
    linear_predictor = design @ coefficients
    objective = float(
        np.sum(sample_weight * (y * linear_predictor - np.logaddexp(0, linear_predictor)))
        - 0.5 * coefficients @ ridge @ coefficients
    )
    converged = False
    for _ in range(50):
        fitted = expit(design @ coefficients)
        variance = np.maximum(fitted * (1 - fitted), 1e-10)
        gradient = design.T @ (sample_weight * (y - fitted)) - ridge @ coefficients
        information = design.T @ (design * (sample_weight * variance)[:, None]) + ridge
        try:
            step = np.linalg.solve(information, gradient)
        except np.linalg.LinAlgError:
            return float("nan"), float("nan")
        step_scale = 1.0
        candidate = coefficients + step
        candidate_objective = float("-inf")
        for _ in range(40):
            candidate = coefficients + step_scale * step
            candidate_linear_predictor = design @ candidate
            candidate_objective = float(
                np.sum(
                    sample_weight
                    * (
                        y * candidate_linear_predictor
                        - np.logaddexp(0, candidate_linear_predictor)
                    )
                )
                - 0.5 * candidate @ ridge @ candidate
            )
            if math.isfinite(candidate_objective) and candidate_objective >= objective - 1e-12:
                break
            step_scale *= 0.5
        else:
            return float("nan"), float("nan")
        coefficients = candidate
        objective = candidate_objective
        if not np.isfinite(coefficients).all():
            return float("nan"), float("nan")
        if np.max(np.abs(step_scale * step)) < 1e-9:
            converged = True
            break
    if not converged:
        return float("nan"), float("nan")
    return float(coefficients[0]), float(coefficients[1])


def metric_values(y: np.ndarray, prediction: np.ndarray, sample_weight: np.ndarray) -> dict[str, float]:
    if len(np.unique(y[sample_weight > 0])) < 2:
        auroc = float("nan")
        auprc = float("nan")
    else:
        auroc = float(roc_auc_score(y, prediction, sample_weight=sample_weight))
        auprc = float(average_precision_score(y, prediction, sample_weight=sample_weight))
    brier = float(np.average((y - prediction) ** 2, weights=sample_weight))
    intercept, slope = calibration_intercept_slope(y, prediction, sample_weight)
    return {
        "AUROC": auroc,
        "AUPRC": auprc,
        "Brier": brier,
        "calibration_in_large": calibration_in_large(y, prediction, sample_weight),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
    }


def weighted_rank_metrics(
    sample_weight: np.ndarray, y: np.ndarray, prediction: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    order = np.argsort(prediction, kind="mergesort")
    sorted_prediction = prediction[order]
    sorted_y = y[order]
    sorted_weight = sample_weight[:, order]
    starts = np.r_[0, np.flatnonzero(np.diff(sorted_prediction) != 0) + 1]
    positive = np.add.reduceat(sorted_weight * sorted_y, starts, axis=1)
    negative = np.add.reduceat(sorted_weight * (1 - sorted_y), starts, axis=1)
    cumulative_negative_below = np.cumsum(negative, axis=1) - negative
    total_positive = positive.sum(axis=1)
    total_negative = negative.sum(axis=1)
    denominator = total_positive * total_negative
    auroc = np.divide(
        np.sum(positive * (cumulative_negative_below + 0.5 * negative), axis=1),
        denominator,
        out=np.full(len(sample_weight), np.nan),
        where=denominator > 0,
    )
    positive_descending = positive[:, ::-1]
    negative_descending = negative[:, ::-1]
    true_positive = np.cumsum(positive_descending, axis=1)
    false_positive = np.cumsum(negative_descending, axis=1)
    precision = np.divide(
        true_positive,
        true_positive + false_positive,
        out=np.ones_like(true_positive),
        where=(true_positive + false_positive) > 0,
    )
    recall_increment = np.divide(
        positive_descending,
        total_positive[:, None],
        out=np.zeros_like(positive_descending),
        where=total_positive[:, None] > 0,
    )
    auprc = np.sum(precision * recall_increment, axis=1)
    auprc[total_positive <= 0] = np.nan
    return auroc, auprc


def calibration_batch(
    sample_weight: np.ndarray, y: np.ndarray, prediction: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    x = logit(prediction)
    total_weight = sample_weight.sum(axis=1)
    prevalence = np.divide(
        sample_weight @ y,
        total_weight,
        out=np.full(len(sample_weight), np.nan),
        where=total_weight > 0,
    )
    alpha = np.zeros(len(sample_weight), dtype=float)
    alpha_step = np.full(len(sample_weight), np.inf)
    for _ in range(30):
        fitted = expit(alpha[:, None] + x[None, :])
        gradient = np.sum(sample_weight * (y[None, :] - fitted), axis=1)
        information = np.sum(sample_weight * fitted * (1 - fitted), axis=1)
        alpha_step = np.divide(
            gradient,
            information,
            out=np.full(len(sample_weight), np.nan),
            where=information > 1e-12,
        )
        alpha += np.nan_to_num(alpha_step)
        finite_alpha_step = np.abs(alpha_step[np.isfinite(alpha_step)])
        if len(finite_alpha_step) and np.max(finite_alpha_step) < 1e-9:
            break
    failed_alpha = (~np.isfinite(alpha_step)) | (np.abs(alpha_step) >= 1e-8)
    for index in np.flatnonzero(failed_alpha):
        fallback_alpha = calibration_in_large(y, prediction, sample_weight[index])
        if math.isfinite(fallback_alpha):
            alpha[index] = fallback_alpha
            failed_alpha[index] = False
    alpha[failed_alpha] = np.nan

    intercept = np.log(np.clip(prevalence, 1e-8, 1 - 1e-8) / np.clip(1 - prevalence, 1e-8, 1))
    slope = np.zeros(len(sample_weight), dtype=float)
    maximum_step = np.full(len(sample_weight), np.inf)
    for _ in range(30):
        fitted = expit(intercept[:, None] + slope[:, None] * x[None, :])
        variance_weight = sample_weight * np.maximum(fitted * (1 - fitted), 1e-10)
        residual_weight = sample_weight * (y[None, :] - fitted)
        gradient_intercept = residual_weight.sum(axis=1)
        gradient_slope = residual_weight @ x - 1e-10 * slope
        h00 = variance_weight.sum(axis=1) + 1e-10
        h01 = variance_weight @ x
        h11 = variance_weight @ (x * x) + 1e-10
        determinant = h00 * h11 - h01 * h01
        step_intercept = np.divide(
            gradient_intercept * h11 - gradient_slope * h01,
            determinant,
            out=np.full(len(sample_weight), np.nan),
            where=np.abs(determinant) > 1e-14,
        )
        step_slope = np.divide(
            gradient_slope * h00 - gradient_intercept * h01,
            determinant,
            out=np.full(len(sample_weight), np.nan),
            where=np.abs(determinant) > 1e-14,
        )
        intercept += np.nan_to_num(step_intercept)
        slope += np.nan_to_num(step_slope)
        maximum_step = np.maximum(np.abs(step_intercept), np.abs(step_slope))
        finite_maximum_step = maximum_step[np.isfinite(maximum_step)]
        if len(finite_maximum_step) and np.max(finite_maximum_step) < 1e-8:
            break
    failed = (
        (prevalence <= 0)
        | (prevalence >= 1)
        | ~np.isfinite(maximum_step)
        | (maximum_step >= 1e-7)
        | ~np.isfinite(intercept)
        | ~np.isfinite(slope)
    )
    for index in np.flatnonzero(failed):
        fallback_intercept, fallback_slope = calibration_intercept_slope(
            y,
            prediction,
            sample_weight[index],
        )
        if math.isfinite(fallback_intercept) and math.isfinite(fallback_slope):
            intercept[index] = fallback_intercept
            slope[index] = fallback_slope
            failed[index] = False
    intercept[failed] = np.nan
    slope[failed] = np.nan
    return alpha, intercept, slope


def bootstrap_pair_values(
    y: np.ndarray,
    prediction: np.ndarray,
    group_codes: np.ndarray,
    positive_groups: np.ndarray,
    negative_groups: np.ndarray,
    numerator_by_group: np.ndarray,
    denominator_by_group: np.ndarray,
    *,
    bootstrap_b: int,
    rng: np.random.Generator,
    batch_size: int = 64,
) -> tuple[dict[str, list[float]], np.ndarray]:
    group_count = int(max(group_codes)) + 1
    metric_chunks = {
        name: []
        for name in (
            "AUROC",
            "AUPRC",
            "Brier",
            "calibration_in_large",
            "calibration_intercept",
            "calibration_slope",
        )
    }
    curve_chunks = []
    positive_probability = np.full(len(positive_groups), 1 / len(positive_groups))
    negative_probability = np.full(len(negative_groups), 1 / len(negative_groups))
    squared_error = (y - prediction) ** 2
    for start in range(0, bootstrap_b, batch_size):
        size = min(batch_size, bootstrap_b - start)
        counts = np.zeros((size, group_count), dtype=float)
        counts[:, positive_groups] = rng.multinomial(
            len(positive_groups), positive_probability, size=size
        )
        counts[:, negative_groups] = rng.multinomial(
            len(negative_groups), negative_probability, size=size
        )
        row_weight = counts[:, group_codes]
        total_weight = row_weight.sum(axis=1)
        auroc, auprc = weighted_rank_metrics(row_weight, y, prediction)
        brier = np.divide(
            row_weight @ squared_error,
            total_weight,
            out=np.full(size, np.nan),
            where=total_weight > 0,
        )
        calibration_large, intercept, slope = calibration_batch(row_weight, y, prediction)
        for name, values in {
            "AUROC": auroc,
            "AUPRC": auprc,
            "Brier": brier,
            "calibration_in_large": calibration_large,
            "calibration_intercept": intercept,
            "calibration_slope": slope,
        }.items():
            metric_chunks[name].extend(values.tolist())
        numerator = counts @ numerator_by_group
        denominator = counts @ denominator_by_group
        curve_chunks.append(
            np.divide(
                numerator,
                denominator,
                out=np.full_like(numerator, np.nan),
                where=denominator > 0,
            )
        )
    return metric_chunks, np.vstack(curve_chunks)


def percentile_interval(values: list[float]) -> tuple[float | None, float | None, int]:
    finite = np.asarray([value for value in values if math.isfinite(value)], dtype=float)
    if not len(finite):
        return None, None, 0
    return float(np.percentile(finite, 2.5)), float(np.percentile(finite, 97.5)), int(len(finite))


def compute_midrank(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values)
    sorted_values = values[order]
    ranks = np.empty(len(values), dtype=float)
    start = 0
    while start < len(values):
        end = start + 1
        while end < len(values) and sorted_values[end] == sorted_values[start]:
            end += 1
        ranks[start:end] = 0.5 * (start + end - 1) + 1
        start = end
    result = np.empty(len(values), dtype=float)
    result[order] = ranks
    return result


def fast_delong(predictions: np.ndarray, positive_count: int) -> tuple[np.ndarray, np.ndarray]:
    negative_count = predictions.shape[1] - positive_count
    positive = predictions[:, :positive_count]
    negative = predictions[:, positive_count:]
    model_count = predictions.shape[0]
    positive_rank = np.empty((model_count, positive_count))
    negative_rank = np.empty((model_count, negative_count))
    combined_rank = np.empty((model_count, positive_count + negative_count))
    for index in range(model_count):
        positive_rank[index] = compute_midrank(positive[index])
        negative_rank[index] = compute_midrank(negative[index])
        combined_rank[index] = compute_midrank(predictions[index])
    aucs = (
        combined_rank[:, :positive_count].sum(axis=1)
        / positive_count
        / negative_count
        - (positive_count + 1.0) / (2.0 * negative_count)
    )
    v01 = (combined_rank[:, :positive_count] - positive_rank) / negative_count
    v10 = 1.0 - (combined_rank[:, positive_count:] - negative_rank) / positive_count
    covariance = np.atleast_2d(np.cov(v01)) / positive_count + np.atleast_2d(np.cov(v10)) / negative_count
    return aucs, covariance


def delong_pvalue(y: np.ndarray, prediction_a: np.ndarray, prediction_b: np.ndarray) -> float:
    order = np.argsort(-y, kind="mergesort")
    positive_count = int(y.sum())
    if positive_count == 0 or positive_count == len(y):
        return float("nan")
    aucs, covariance = fast_delong(
        np.vstack([prediction_a, prediction_b])[:, order], positive_count
    )
    difference = float(aucs[0] - aucs[1])
    variance = float(covariance[0, 0] + covariance[1, 1] - 2 * covariance[0, 1])
    if variance <= 0:
        return 1.0 if abs(difference) < 1e-15 else 0.0
    return float(2 * stats.norm.sf(abs(difference) / math.sqrt(variance)))


def paired_auprc_bootstrap(
    y: np.ndarray,
    prediction_a: np.ndarray,
    prediction_b: np.ndarray,
    groups: np.ndarray,
    *,
    bootstrap_b: int,
    seed: int,
    minimum_success: int,
) -> dict[str, Any]:
    group_codes, group_names = pd.factorize(groups.astype(str), sort=True)
    group_event = np.zeros(len(group_names), dtype=int)
    np.maximum.at(group_event, group_codes, y)
    positive_groups = np.where(group_event == 1)[0]
    negative_groups = np.where(group_event == 0)[0]
    if not len(positive_groups) or not len(negative_groups):
        raise ValueError("paired bootstrap common cohort lacks positive or negative patient groups")
    rng = np.random.default_rng(seed)
    differences = []
    positive_probability = np.full(len(positive_groups), 1 / len(positive_groups))
    negative_probability = np.full(len(negative_groups), 1 / len(negative_groups))
    for start in range(0, bootstrap_b, 64):
        size = min(64, bootstrap_b - start)
        counts = np.zeros((size, len(group_names)), dtype=float)
        counts[:, positive_groups] = rng.multinomial(
            len(positive_groups), positive_probability, size=size
        )
        counts[:, negative_groups] = rng.multinomial(
            len(negative_groups), negative_probability, size=size
        )
        row_weight = counts[:, group_codes]
        _, auprc_a = weighted_rank_metrics(row_weight, y, prediction_a)
        _, auprc_b = weighted_rank_metrics(row_weight, y, prediction_b)
        differences.extend((auprc_a - auprc_b).tolist())
    finite = np.asarray([value for value in differences if math.isfinite(value)], dtype=float)
    if len(finite) < minimum_success:
        raise ValueError(
            f"paired AUPRC bootstrap valid replicates {len(finite)} are below {minimum_success}"
        )
    lower, upper = np.percentile(finite, [2.5, 97.5])
    two_sided = float(min(1.0, 2 * min(np.mean(finite <= 0), np.mean(finite >= 0))))
    return {
        "auprc_difference": float(
            average_precision_score(y, prediction_a)
            - average_precision_score(y, prediction_b)
        ),
        "auprc_difference_lower_ci": float(lower),
        "auprc_difference_upper_ci": float(upper),
        "auprc_paired_bootstrap_p": two_sided,
        "bootstrap_b": int(bootstrap_b),
        "bootstrap_success": int(len(finite)),
        "bootstrap_method": "paired_outcome_stratified_patient_group_cluster",
    }


def required_comparison_models(models: set[str], mode: str) -> list[str]:
    logistic = "logistic_l2" if "logistic_l2" in models else "logistic_l1"
    required = ["score_rSI_sMS", logistic, "catboost", "xgboost", "lightgbm"]
    if mode == "final_refresh":
        for candidate in (
            "bert_finetuned",
            "mlp_plr",
            "ft_transformer",
            "cnn_1d",
            "tabpfn_standard",
            "tabicl",
            "stacking",
        ):
            if candidate in models:
                required.append(candidate)
    missing = sorted(set(required) - models)
    if missing:
        raise ValueError(f"paired comparison hard gate lacks models: {missing}")
    return required


def paired_comparison_rows(
    raw_validation: pd.DataFrame,
    mode: str,
    *,
    bootstrap_b: int,
    seed: int,
    minimum_success: int,
) -> pd.DataFrame:
    models = required_comparison_models(set(raw_validation["model"]), mode)
    rows = []
    keyed = {
        model: group.set_index("row_hash")
        for model, group in raw_validation.loc[raw_validation["model"].isin(models)].groupby(
            "model", observed=True
        )
    }
    for model_a, model_b in itertools.combinations(models, 2):
        common = sorted(set(keyed[model_a].index) & set(keyed[model_b].index))
        if not common:
            raise ValueError(f"paired comparison has no common rows: {model_a}/{model_b}")
        frame_a = keyed[model_a].loc[common]
        frame_b = keyed[model_b].loc[common]
        if not frame_a["y_true"].to_numpy().tolist() == frame_b["y_true"].to_numpy().tolist():
            raise ValueError(f"paired comparison labels differ: {model_a}/{model_b}")
        if not frame_a["group_hash"].astype(str).to_numpy().tolist() == frame_b["group_hash"].astype(str).to_numpy().tolist():
            raise ValueError(f"paired comparison groups differ: {model_a}/{model_b}")
        y = frame_a["y_true"].to_numpy(dtype=int)
        prediction_a = frame_a["prediction"].to_numpy(dtype=float)
        prediction_b = frame_b["prediction"].to_numpy(dtype=float)
        bootstrap = paired_auprc_bootstrap(
            y,
            prediction_a,
            prediction_b,
            frame_a["group_hash"].to_numpy(),
            bootstrap_b=bootstrap_b,
            seed=stable_seed(seed, model_a, model_b),
            minimum_success=minimum_success,
        )
        rows.append(
            {
                "outcome": str(frame_a["outcome"].iloc[0]),
                "model_a": model_a,
                "model_b": model_b,
                "comparison_variant": "raw_validation_2024",
                "n_common": int(len(common)),
                "events_common": int(y.sum()),
                "patient_groups_common": int(frame_a["group_hash"].nunique()),
                "auroc_a": float(roc_auc_score(y, prediction_a)),
                "auroc_b": float(roc_auc_score(y, prediction_b)),
                "auroc_difference": float(
                    roc_auc_score(y, prediction_a) - roc_auc_score(y, prediction_b)
                ),
                "auroc_delong_p": delong_pvalue(y, prediction_a, prediction_b),
                "auprc_a": float(average_precision_score(y, prediction_a)),
                "auprc_b": float(average_precision_score(y, prediction_b)),
                **bootstrap,
            }
        )
    return pd.DataFrame(rows)


def calibration_kernel(
    prediction: np.ndarray, y: np.ndarray, group_codes: np.ndarray, group_count: int, grid_points: int
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, float]:
    quantiles = np.linspace(0.01, 0.99, grid_points)
    grid = np.unique(np.quantile(prediction, quantiles))
    x = logit(prediction)
    grid_x = logit(grid)
    standard_deviation = float(np.std(x))
    bandwidth = max(0.25, 1.06 * standard_deviation * max(len(x), 2) ** (-0.2))
    weights = np.exp(-0.5 * ((x[:, None] - grid_x[None, :]) / bandwidth) ** 2)
    numerator_by_group = np.zeros((group_count, len(grid)), dtype=float)
    denominator_by_group = np.zeros((group_count, len(grid)), dtype=float)
    np.add.at(numerator_by_group, group_codes, weights * y[:, None])
    np.add.at(denominator_by_group, group_codes, weights)
    numerator = numerator_by_group.sum(axis=0)
    denominator = denominator_by_group.sum(axis=0)
    observed = np.divide(numerator, denominator, out=np.full(len(grid), np.nan), where=denominator > 0)
    return grid, observed, numerator_by_group, denominator_by_group, bandwidth


def evaluate_pair(
    group: pd.DataFrame,
    *,
    bootstrap_b: int,
    minimum_bootstrap_success: int,
    seed: int,
    grid_points: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    outcome = str(group["outcome"].iloc[0])
    model = str(group["model"].iloc[0])
    task_ids = sorted(set(group["task_id"]))
    if len(task_ids) != 1:
        raise ValueError(f"analytic model is owned by multiple tasks: {outcome}/{model}/{task_ids}")
    task_id = task_ids[0]
    y = group["y_true"].to_numpy(dtype=int)
    prediction = group["prediction"].to_numpy(dtype=float)
    groups, group_names = pd.factorize(group["group_hash"].astype(str), sort=True)
    group_count = len(group_names)
    group_event = np.zeros(group_count, dtype=int)
    np.maximum.at(group_event, groups, y)
    positive_groups = np.where(group_event == 1)[0]
    negative_groups = np.where(group_event == 0)[0]
    if not len(positive_groups) or not len(negative_groups):
        raise ValueError(f"validation cohort lacks outcome-stratified patient groups: {outcome}/{model}")
    rng = np.random.default_rng(stable_seed(seed, outcome, model))
    point = metric_values(y, prediction, np.ones(len(y), dtype=float))
    grid, observed, numerator_by_group, denominator_by_group, bandwidth = calibration_kernel(
        prediction, y, groups, group_count, grid_points
    )
    bootstrap_metrics, curve_array = bootstrap_pair_values(
        y,
        prediction,
        groups,
        positive_groups,
        negative_groups,
        numerator_by_group,
        denominator_by_group,
        bootstrap_b=bootstrap_b,
        rng=rng,
    )
    metric_rows = []
    for name, value in point.items():
        lower, upper, successes = percentile_interval(bootstrap_metrics[name])
        estimated = math.isfinite(value) and successes >= minimum_bootstrap_success
        metric_rows.append(
            {
                "task_id": task_id,
                "outcome": outcome,
                "model": model,
                "model_family": model_family(model),
                "split": "validation_2024",
                "metric": name,
                "value": float(value) if math.isfinite(value) else None,
                "lower_ci": lower if estimated else None,
                "upper_ci": upper if estimated else None,
                "status": "ESTIMATED" if estimated else "NOT_ESTIMABLE",
                "n": int(len(y)),
                "events": int(y.sum()),
                "patient_groups": int(group_count),
                "bootstrap_b": int(bootstrap_b),
                "bootstrap_success": successes,
                "bootstrap_failures": int(bootstrap_b - successes),
                "bootstrap_minimum_success_required": int(minimum_bootstrap_success),
                "bootstrap_method": "outcome_stratified_patient_group_cluster",
            }
        )
    curve_rows = []
    for index, grid_value in enumerate(grid):
        lower, upper, successes = percentile_interval(curve_array[:, index].tolist())
        curve_rows.append(
            {
                "outcome": outcome,
                "model": model,
                "model_family": model_family(model),
                "curve_type": "flexible_kernel",
                "grid_prediction": float(grid_value),
                "observed_probability": float(observed[index]),
                "lower_ci": lower,
                "upper_ci": upper,
                "bootstrap_b": int(bootstrap_b),
                "bootstrap_success": successes,
                "bootstrap_failures": int(bootstrap_b - successes),
                "bootstrap_minimum_success_required": int(minimum_bootstrap_success),
                "status": (
                    "ESTIMATED"
                    if math.isfinite(float(observed[index]))
                    and successes >= minimum_bootstrap_success
                    else "NOT_ESTIMABLE"
                ),
                "kernel_bandwidth_logit": float(bandwidth),
                "n": int(len(y)),
                "events": int(y.sum()),
            }
        )
    return metric_rows, curve_rows


def prespecified_complete_case_not_estimable_mask(frame: pd.DataFrame) -> pd.Series:
    return (
        frame["model"].astype(str).str.startswith("missingness__full_complete_case__")
        & frame["metric"].astype(str).isin(
            {"calibration_intercept", "calibration_slope"}
        )
        & frame["status"].astype(str).eq("NOT_ESTIMABLE")
    )


def select_operating_point(group: pd.DataFrame) -> tuple[dict[str, Any], pd.DataFrame]:
    outcome = str(group["outcome"].iloc[0])
    model = str(group["model"].iloc[0])
    task_id = str(group["task_id"].iloc[0])
    y = group["y_true"].to_numpy(dtype=int)
    prediction = group["prediction"].to_numpy(dtype=float)
    false_positive_rate, sensitivity, thresholds = roc_curve(y, prediction)
    specificity = 1 - false_positive_rate
    finite = np.isfinite(thresholds)
    score = np.minimum(sensitivity, specificity)
    target = finite & (sensitivity >= 0.90) & (specificity >= 0.90)
    candidates = np.where(target)[0]
    rule = "sens_and_spec_ge_0_90"
    if not len(candidates):
        maximum = np.nanmax(np.where(finite, score, np.nan))
        candidates = np.where(finite & np.isclose(score, maximum))[0]
        rule = "max_min_sensitivity_specificity"
    youden = sensitivity + specificity - 1
    best_youden = np.max(youden[candidates])
    candidates = candidates[np.isclose(youden[candidates], best_youden)]
    best = int(candidates[np.argmax(thresholds[candidates])])
    threshold = float(thresholds[best])
    predicted_positive = prediction >= threshold
    tp = int(np.sum((y == 1) & predicted_positive))
    fn = int(np.sum((y == 1) & ~predicted_positive))
    fp = int(np.sum((y == 0) & predicted_positive))
    tn = int(np.sum((y == 0) & ~predicted_positive))
    ppv = tp / (tp + fp) if tp + fp else None
    npv = tn / (tn + fn) if tn + fn else None
    f1 = 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else None
    row = {
        "task_id": task_id,
        "outcome": outcome,
        "model": model,
        "split": "validation_2024",
        "selection_rule": rule,
        "threshold": threshold,
        "sensitivity": float(sensitivity[best]),
        "specificity": float(specificity[best]),
        "sensitivity_gap_to_0_90": float(max(0.0, 0.90 - sensitivity[best])),
        "specificity_gap_to_0_90": float(max(0.0, 0.90 - specificity[best])),
        "sens_spec_ge_0_90": bool(sensitivity[best] >= 0.90 and specificity[best] >= 0.90),
        "ppv": ppv,
        "npv": npv,
        "f1": f1,
        "tp": tp,
        "fp": fp,
        "tn": tn,
        "fn": fn,
        "n": int(len(y)),
        "events": int(y.sum()),
    }
    waterfall = group.loc[group["y_true"].eq(1), ["task_id", "row_hash", "group_hash", "outcome", "model", "y_true", "prediction"]].copy()
    waterfall["threshold"] = threshold
    waterfall["case_type"] = np.where(waterfall["prediction"].ge(threshold), "TP", "FN")
    waterfall["classification_confidence"] = np.where(
        waterfall["case_type"].eq("TP"), waterfall["prediction"], 1 - waterfall["prediction"]
    )
    waterfall = waterfall.sort_values(
        ["case_type", "classification_confidence", "row_hash"],
        ascending=[True, False, True],
        kind="mergesort",
    )
    waterfall["case_rank"] = waterfall.groupby("case_type", observed=True).cumcount() + 1
    return row, waterfall.reset_index(drop=True)


def dca_rows(group: pd.DataFrame, thresholds: np.ndarray) -> list[dict[str, Any]]:
    outcome = str(group["outcome"].iloc[0])
    model = str(group["model"].iloc[0])
    y = group["y_true"].to_numpy(dtype=int)
    prediction = group["prediction"].to_numpy(dtype=float)
    n = len(y)
    events = int(y.sum())
    prevalence = events / n
    rows = []
    for threshold in thresholds:
        odds = threshold / (1 - threshold)
        positive = prediction >= threshold
        tp = int(np.sum((y == 1) & positive))
        fp = int(np.sum((y == 0) & positive))
        values = {
            model: tp / n - fp / n * odds,
            "treat_all": prevalence - (1 - prevalence) * odds,
            "treat_none": 0.0,
        }
        for curve, net_benefit in values.items():
            rows.append(
                {
                    "outcome": outcome,
                    "reference_model": model,
                    "curve": curve,
                    "curve_type": "model" if curve == model else curve,
                    "model_family": model_family(model) if curve == model else "reference",
                    "threshold": float(threshold),
                    "net_benefit": float(net_benefit),
                    "n": int(n),
                    "events": events,
                    "prevalence": float(prevalence),
                }
            )
    return rows


def curve_rows(group: pd.DataFrame, ci_lookup: dict[tuple[str, str, str], tuple[Any, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    outcome = str(group["outcome"].iloc[0])
    model = str(group["model"].iloc[0])
    y = group["y_true"].to_numpy(dtype=int)
    prediction = group["prediction"].to_numpy(dtype=float)
    auroc = float(roc_auc_score(y, prediction))
    auprc = float(average_precision_score(y, prediction))
    auroc_ci = ci_lookup[(outcome, model, "AUROC")]
    auprc_ci = ci_lookup[(outcome, model, "AUPRC")]
    false_positive_rate, true_positive_rate, roc_threshold = roc_curve(y, prediction)
    precision, recall, pr_threshold = precision_recall_curve(y, prediction)
    roc_rows = [
        {
            "outcome": outcome,
            "model": model,
            "reference_model": model,
            "model_family": model_family(model),
            "curve_type": "model",
            "false_positive_rate": float(fpr),
            "true_positive_rate": float(tpr),
            "threshold": float(threshold) if math.isfinite(float(threshold)) else None,
            "AUROC": auroc,
            "lower_ci": auroc_ci[0],
            "upper_ci": auroc_ci[1],
            "n": int(len(y)),
            "events": int(y.sum()),
        }
        for fpr, tpr, threshold in zip(false_positive_rate, true_positive_rate, roc_threshold)
    ]
    extended_pr_threshold = np.append(pr_threshold, np.nan)
    pr_rows = [
        {
            "outcome": outcome,
            "model": model,
            "reference_model": model,
            "model_family": model_family(model),
            "curve_type": "model",
            "recall": float(rec),
            "precision": float(pre),
            "threshold": float(threshold) if math.isfinite(float(threshold)) else None,
            "AUPRC": auprc,
            "lower_ci": auprc_ci[0],
            "upper_ci": auprc_ci[1],
            "prevalence": float(np.mean(y)),
            "n": int(len(y)),
            "events": int(y.sum()),
        }
        for pre, rec, threshold in zip(precision, recall, extended_pr_threshold)
    ]
    prevalence = float(np.mean(y))
    pr_rows.extend(
        [
            {
                "outcome": outcome,
                "model": "__NO_SKILL__",
                "reference_model": model,
                "model_family": "reference",
                "curve_type": "no_skill",
                "recall": recall_value,
                "precision": prevalence,
                "threshold": None,
                "AUPRC": prevalence,
                "lower_ci": None,
                "upper_ci": None,
                "prevalence": prevalence,
                "n": int(len(y)),
                "events": int(y.sum()),
            }
            for recall_value in (0.0, 1.0)
        ]
    )
    return roc_rows, pr_rows


def model_color(model: str) -> str:
    family = model_family(model)
    return {
        "traditional_score": "0.55",
        "gbdt": "#1f77b4",
        "linear": "#2ca02c",
        "deep": "#e6550d",
        "foundation": "#d62728",
        "stacking": "black",
        "common_ml": "#756bb1",
        "missingness_sensitivity": "#bdbdbd",
    }.get(family, "#756bb1")


def feature_matrix_sha256(
    row_hashes: list[str], feature_names: list[str], values: np.ndarray
) -> str:
    records = []
    for row_index, row_hash in enumerate(row_hashes):
        for feature_index, feature in enumerate(feature_names):
            value = float(values[row_index, feature_index])
            records.append(
                {
                    "row_hash": row_hash,
                    "feature": feature,
                    "value": None if math.isnan(value) else value.hex(),
                }
            )
    return sha256_json(records)


def xgboost_device(estimator: Any, model: str) -> str:
    if not hasattr(estimator, "get_booster"):
        raise ValueError(f"SHAP estimator is not an executable XGBoost model: {model}")
    booster = estimator.get_booster()
    config = json.loads(booster.save_config())
    source_device = config["learner"]["generic_param"].get("device")
    if not isinstance(source_device, str) or not source_device:
        raise ValueError(f"XGBoost SHAP source device is not locked: {model}")
    return source_device


def bind_tree_shap_cpu(estimator: Any, schema: dict[str, Any], model: str) -> str:
    source_device = xgboost_device(estimator, model)
    if (
        schema.get("shap_source_device") != source_device
        or schema.get("shap_execution_device") != "cpu"
    ):
        raise ValueError(f"XGBoost SHAP device contract mismatch: {model}")
    estimator.get_booster().set_param({"device": "cpu"})
    if xgboost_device(estimator, model) != "cpu":
        raise ValueError(f"XGBoost SHAP CPU rebind failed: {model}")
    return source_device


def validate_tree_shap_additivity(
    base_value: float,
    values: np.ndarray,
    raw_output: np.ndarray,
    model: str,
) -> float:
    reconstructed = base_value + np.asarray(values, dtype=float).sum(axis=1)
    raw = np.asarray(raw_output, dtype=float)
    error = np.abs(reconstructed - raw)
    tolerance = SHAP_ADDITIVITY_ATOL + SHAP_ADDITIVITY_RTOL * np.abs(raw)
    if (
        not np.isfinite(error).all()
        or not np.isfinite(tolerance).all()
        or (error > tolerance).any()
    ):
        maximum = float(np.nanmax(error)) if error.size else float("nan")
        raise ValueError(
            f"fresh TreeExplainer additivity check failed: {model}; "
            f"maximum_absolute_error={maximum}"
        )
    return float(error.max()) if error.size else 0.0


def tree_shap_components(
    inference_context: dict[str, Any],
    raw_inputs: pd.DataFrame,
    model: str,
) -> tuple[np.ndarray, np.ndarray, list[str], float, np.ndarray, str]:
    schema = inference_context["schema"]
    predictors = inference_context["predictors"]
    if schema.get("shap_adapter") != "tree_explainer_raw_v1" or len(predictors) != 1:
        raise ValueError(f"SHAP model lacks a single executable TreeExplainer adapter: {model}")
    predictor = predictors[0]
    feature_names = [str(feature) for feature in schema["feature_names"]]
    if hasattr(predictor, "named_steps"):
        step_names = list(predictor.named_steps)
        expected_step = schema.get("shap_estimator_step")
        if not step_names or expected_step != step_names[-1]:
            raise ValueError(f"SHAP pipeline estimator step is not locked: {model}")
        estimator = predictor.named_steps[expected_step]
        transformed = predictor[:-1].transform(raw_inputs)
    else:
        if schema.get("shap_estimator_step") not in {None, "direct"}:
            raise ValueError(f"direct SHAP estimator has an invalid step contract: {model}")
        estimator = predictor
        transformed = raw_inputs.to_numpy()
    if hasattr(transformed, "toarray"):
        transformed = transformed.toarray()
    transformed = np.asarray(transformed, dtype=float)
    if transformed.ndim != 2 or transformed.shape != (len(raw_inputs), len(feature_names)):
        raise ValueError(
            f"SHAP transformed feature shape differs from locked schema: {model}"
        )
    try:
        import shap

        if model == "xgboost":
            if schema.get("shap_device_adapter") != "xgboost_booster_cpu_rebind_v1":
                raise ValueError("XGBoost SHAP device adapter is not locked")
            bind_tree_shap_cpu(estimator, schema, model)
        elif (
            model not in TREE_SHAP_MODELS
            or schema.get("shap_device_adapter") != "serialized_tree_cpu_inference_v1"
            or schema.get("shap_execution_device") != "cpu"
        ):
            raise ValueError(f"TreeExplainer execution adapter is not locked: {model}")
        explainer = shap.TreeExplainer(estimator)
        values = explainer.shap_values(transformed)
        expected_value = explainer.expected_value
        shap_version = str(shap.__version__)
    except Exception as exc:
        raise ValueError(f"TreeExplainer recomputation failed for model: {model}") from exc
    if isinstance(values, list):
        values = values[-1]
    values = np.asarray(values, dtype=float)
    if values.ndim == 3:
        values = values[:, :, -1]
    expected_values = np.asarray(expected_value, dtype=float).reshape(-1)
    base_value = float(expected_values[-1])
    if values.shape != transformed.shape or not np.isfinite(values).all():
        raise ValueError(f"TreeExplainer returned an invalid contribution matrix: {model}")
    raw_output = logit(ensemble_probability(predictors, raw_inputs))
    validate_tree_shap_additivity(base_value, values, raw_output, model)
    return values, transformed, feature_names, base_value, raw_output, shap_version


def load_shap_model_selection(
    path: Path,
    raw_validation: pd.DataFrame,
    outcome: str,
    shap_model: str,
    *,
    smoke: bool,
) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    expected_candidates = sorted(TREE_SHAP_MODELS)
    required = {
        "schema_version",
        "outcome",
        "selection_split",
        "selection_metric",
        "candidate_models",
        "candidate_auprc",
        "candidate_rows",
        "selected_model",
        "selected_auprc",
        "tie_break",
        "base_model_fit_performed",
        "2025_access_count",
    }
    if set(value) != required:
        raise ValueError("SHAP model selection schema is not exact")
    if (
        value.get("schema_version") != "1.0"
        or value.get("outcome") != outcome
        or value.get("selection_split") != "validation_2024"
        or value.get("selection_metric") != "AUPRC"
        or value.get("candidate_models") != expected_candidates
        or set(value.get("candidate_auprc", {})) != set(expected_candidates)
        or set(value.get("candidate_rows", {})) != set(expected_candidates)
        or value.get("selected_model") != shap_model
        or value.get("tie_break") != "descending_AUPRC_then_model_name"
        or value.get("base_model_fit_performed") is not False
        or value.get("2025_access_count") != 0
    ):
        raise ValueError("SHAP model selection contract differs from the locked design")
    scores = {
        model: float(value["candidate_auprc"][model]) for model in expected_candidates
    }
    rows = {model: int(value["candidate_rows"][model]) for model in expected_candidates}
    if (
        not all(np.isfinite(score) for score in scores.values())
        or any(count <= 0 for count in rows.values())
        or not np.isfinite(float(value.get("selected_auprc", np.nan)))
        or not np.isclose(
            float(value["selected_auprc"]),
            scores[shap_model],
            rtol=1e-12,
            atol=1e-15,
        )
        or sorted(scores, key=lambda model: (-scores[model], model))[0] != shap_model
    ):
        raise ValueError("SHAP model selection scores do not identify the selected model")
    if not smoke:
        reference_keys: set[tuple[str, int]] | None = None
        recomputed: dict[str, float] = {}
        for model in expected_candidates:
            frame = raw_validation.loc[raw_validation["model"].eq(model)].copy()
            if (
                len(frame) != rows[model]
                or frame["row_hash"].astype(str).duplicated().any()
                or not np.isfinite(frame["prediction"].to_numpy(dtype=float)).all()
            ):
                raise ValueError(f"SHAP model selection rows are invalid: {model}")
            keys = set(
                zip(
                    frame["row_hash"].astype(str),
                    frame["y_true"].to_numpy(dtype=int),
                    strict=True,
                )
            )
            if reference_keys is None:
                reference_keys = keys
            elif keys != reference_keys:
                raise ValueError("SHAP model selection cohorts differ")
            labels = frame["y_true"].to_numpy(dtype=int)
            if len(np.unique(labels)) != 2:
                raise ValueError(f"SHAP model selection is not estimable: {model}")
            recomputed[model] = float(
                average_precision_score(
                    labels,
                    frame["prediction"].to_numpy(dtype=float),
                )
            )
            if not np.isclose(
                recomputed[model], scores[model], rtol=1e-12, atol=1e-15
            ):
                raise ValueError(f"SHAP model selection AUPRC differs: {model}")
        if sorted(recomputed, key=lambda model: (-recomputed[model], model))[0] != shap_model:
            raise ValueError("SHAP model selection is not the best accepted tree model")
    return {
        "sha256": sha256_file(path),
        "selected_model": shap_model,
        "candidate_auprc": scores,
        "candidate_rows": rows,
    }


def load_shap_values(
    path: Path,
    provenance_path: Path,
    stage1a_path: Path,
    outcome: str,
    shap_model: str,
    validation_rows: set[str],
    source_task_id: str,
    model_provenance: dict[str, Any],
    inference_context: dict[str, Any],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    path = path.resolve()
    provenance_path = provenance_path.resolve()
    reject_holdout_path(path, "SHAP")
    frame = pd.read_parquet(path)
    if frame.columns.tolist() != SHAP_COLUMNS:
        raise ValueError(f"SHAP values are not canonical: {frame.columns.tolist()}")
    for column in ("row_hash", "outcome", "model", "feature", "split"):
        frame[column] = frame[column].astype(str)
    if set(frame["outcome"]) != {outcome}:
        raise ValueError("SHAP input must contain exactly the requested outcome")
    pii = pii_columns(frame["feature"].drop_duplicates().tolist())
    if pii:
        raise ValueError(f"PII feature names found in SHAP input: {pii[:20]}")
    arrival_hits = forbidden_arrival_columns(frame["feature"].drop_duplicates().tolist())
    if arrival_hits:
        raise ValueError(f"forbidden arrival feature names found in SHAP input: {arrival_hits[:20]}")
    if frame["split"].str.contains("2025", na=False).any():
        raise ValueError("SHAP values contain 2025")
    if not frame["split"].eq("validation_2024").all():
        raise ValueError("SHAP values must be validation_2024 only")
    raw_feature_value = frame["feature_value"].copy()
    frame["feature_value"] = pd.to_numeric(frame["feature_value"], errors="coerce")
    frame["shap_value"] = pd.to_numeric(frame["shap_value"], errors="coerce")
    invalid_feature = raw_feature_value.notna() & frame["feature_value"].isna()
    if invalid_feature.any():
        raise ValueError("SHAP feature values contain a nonnumeric nonmissing value")
    if frame["shap_value"].isna().any() or not np.isfinite(
        frame["shap_value"].to_numpy(dtype=float)
    ).all():
        raise ValueError("SHAP values contain non-finite contributions")
    frame = frame.loc[frame["outcome"].eq(outcome) & frame["model"].eq(shap_model)].copy()
    if frame.empty:
        raise ValueError(f"SHAP values lack {outcome}/{shap_model}")
    if frame.duplicated(["row_hash", "outcome", "model", "feature"]).any():
        raise ValueError("SHAP values contain duplicate row/feature keys")
    observed_rows = set(frame["row_hash"])
    if observed_rows != validation_rows:
        raise ValueError(
            "SHAP row coverage differs from the complete locked validation cohort"
        )
    feature_counts = frame.groupby("row_hash", observed=True)["feature"].nunique()
    if feature_counts.nunique() != 1:
        raise ValueError("SHAP rows do not share one complete feature set")
    expected_features = set(frame.loc[frame["row_hash"].eq(frame["row_hash"].iloc[0]), "feature"])
    incomplete = frame.groupby("row_hash", observed=True)["feature"].agg(set).map(
        lambda features: features != expected_features
    )
    if incomplete.any():
        raise ValueError("SHAP rows do not share one complete feature set")
    provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
    model_artifact_path = resolve_artifact_path(
        str(provenance.get("model_artifact_path", "")), provenance_path
    )
    feature_schema_artifact_path = resolve_artifact_path(
        str(provenance.get("feature_schema_artifact_path", "")), provenance_path
    )
    expected_feature_count = int(feature_counts.iloc[0])
    ordered_rows = sorted(validation_rows)
    raw_inputs = read_locked_feature_rows(
        stage1a_path,
        ordered_rows,
        inference_context["schema"],
        shap_model,
    )
    (
        recomputed_values,
        transformed_values,
        recomputed_features,
        recomputed_base_value,
        raw_output,
        shap_version,
    ) = tree_shap_components(inference_context, raw_inputs, shap_model)
    recomputed = pd.DataFrame(
        {
            "row_hash": np.repeat(np.asarray(ordered_rows, dtype=object), len(recomputed_features)),
            "feature": np.tile(np.asarray(recomputed_features, dtype=object), len(ordered_rows)),
            "feature_value": transformed_values.reshape(-1),
            "shap_value": recomputed_values.reshape(-1),
        }
    ).sort_values(["row_hash", "feature"], kind="mergesort").reset_index(drop=True)
    submitted = frame[["row_hash", "feature", "feature_value", "shap_value"]].sort_values(
        ["row_hash", "feature"], kind="mergesort"
    ).reset_index(drop=True)
    if not submitted[["row_hash", "feature"]].equals(recomputed[["row_hash", "feature"]]):
        raise ValueError("submitted SHAP keys differ from fresh TreeExplainer output")
    if not np.allclose(
        submitted["feature_value"].to_numpy(dtype=float),
        recomputed["feature_value"].to_numpy(dtype=float),
        rtol=0,
        atol=1e-12,
        equal_nan=True,
    ):
        raise ValueError("submitted SHAP feature values differ from locked transformed features")
    maximum_recompute_error = float(
        np.max(
            np.abs(
                submitted["shap_value"].to_numpy(dtype=float)
                - recomputed["shap_value"].to_numpy(dtype=float)
            )
        )
    )
    if maximum_recompute_error > SHAP_RECOMPUTE_TOLERANCE:
        raise ValueError(
            "submitted SHAP contributions differ from fresh TreeExplainer output: "
            f"{maximum_recompute_error}"
        )
    feature_matrix_hash = feature_matrix_sha256(
        ordered_rows, recomputed_features, transformed_values
    )
    raw_output_hash = sha256_json([float(value).hex() for value in raw_output])
    expected = {
        "schema_version": "1.0",
        "outcome": outcome,
        "model": shap_model,
        "source_task_id": source_task_id,
        "shap_values_sha256": sha256_file(path),
        "model_sha256": model_provenance["model_sha256"],
        "feature_schema_sha256": model_provenance["feature_schema_sha256"],
        "explainer_type": "TreeExplainer",
        "shap_adapter": "tree_explainer_raw_v1",
        "shap_source_device": inference_context["schema"]["shap_source_device"],
        "shap_execution_device": inference_context["schema"][
            "shap_execution_device"
        ],
        "shap_device_adapter": inference_context["schema"]["shap_device_adapter"],
        "output_space": "raw_log_odds",
        "expected_validation_rows": len(validation_rows),
        "expected_feature_count": expected_feature_count,
        "generated_after_model_reload_canary": True,
        "shap_recomputed_by_stage2a": True,
        "feature_matrix_sha256": feature_matrix_hash,
        "model_raw_output_sha256": raw_output_hash,
        "shap_library_version": shap_version,
    }
    for key, expected_value in expected.items():
        if provenance.get(key) != expected_value:
            raise ValueError(f"SHAP provenance mismatch: {key}")
    declared_base_value = pd.to_numeric(provenance.get("expected_value"), errors="coerce")
    if not np.isfinite(declared_base_value) or abs(float(declared_base_value) - recomputed_base_value) > 1e-8:
        raise ValueError("SHAP provenance expected value differs from fresh TreeExplainer")
    if (
        str(model_artifact_path) != model_provenance["model_artifact_path"]
        or not model_artifact_path.is_file()
        or sha256_file(model_artifact_path).lower()
        != model_provenance["model_sha256"].lower()
    ):
        raise ValueError("SHAP provenance model artifact/hash mismatch")
    if (
        str(feature_schema_artifact_path)
        != model_provenance["feature_schema_artifact_path"]
        or not feature_schema_artifact_path.is_file()
        or sha256_file(feature_schema_artifact_path).lower()
        != model_provenance["feature_schema_sha256"].lower()
    ):
        raise ValueError("SHAP provenance feature-schema artifact/hash mismatch")
    feature_schema = json.loads(feature_schema_artifact_path.read_text(encoding="utf-8"))
    feature_names = feature_schema.get("feature_names")
    if feature_names is None and isinstance(feature_schema.get("features"), list):
        feature_names = [feature.get("name") for feature in feature_schema["features"]]
    if (
        not isinstance(feature_names, list)
        or any(not isinstance(feature, str) or not feature for feature in feature_names)
        or len(feature_names) != len(set(feature_names))
        or set(feature_names) != expected_features
    ):
        raise ValueError("SHAP features differ from the locked model feature schema")
    return frame, {
        **expected,
        "path": str(provenance_path),
        "sha256": sha256_file(provenance_path),
        "model_artifact_path": str(model_artifact_path),
        "feature_schema_artifact_path": str(feature_schema_artifact_path),
        "expected_value": recomputed_base_value,
        "maximum_shap_recompute_error": maximum_recompute_error,
        "recompute_tolerance": SHAP_RECOMPUTE_TOLERANCE,
        "status": "RECOMPUTED_AND_VERIFIED",
    }


def prepare_shap_outputs(
    shap_values: pd.DataFrame,
    raw_validation: pd.DataFrame,
    operating_points: pd.DataFrame,
    shap_model: str,
    *,
    cases_per_type: int,
    base_tolerance: float,
) -> tuple[pd.DataFrame, pd.DataFrame, list[dict[str, Any]]]:
    additivity = validate_shap_additivity(
        shap_values,
        raw_validation,
        shap_model,
        base_tolerance=base_tolerance,
    )
    prediction = raw_validation.loc[raw_validation["model"].eq(shap_model)].set_index("row_hash")
    common = additivity["row_hashes"]
    base_value = float(additivity["base_value"])
    maximum_deviation = float(additivity["maximum_base_deviation"])
    shap_output = shap_values.loc[shap_values["row_hash"].isin(common)].copy()
    shap_output["base_value"] = base_value
    threshold_row = operating_points.loc[
        operating_points["model"].eq(f"{shap_model}__raw")
    ]
    if len(threshold_row) != 1:
        raise ValueError("SHAP model operating threshold is missing or duplicated")
    threshold = float(threshold_row.iloc[0]["threshold"])
    candidates = prediction.loc[common, ["outcome", "model", "y_true", "prediction", "group_hash"]].copy()
    candidates["case_type"] = np.where(
        candidates["y_true"].eq(1) & candidates["prediction"].ge(threshold),
        "TP",
        np.where(candidates["y_true"].eq(1), "FN", "OTHER"),
    )
    selected_parts = []
    status_rows = []
    for case_type in ("TP", "FN"):
        group = candidates.loc[candidates["case_type"].eq(case_type)].copy()
        ascending = case_type == "FN"
        group = group.sort_values(["prediction", "row_hash"], ascending=[ascending, True], kind="mergesort")
        if group.empty:
            status_rows.append({"case_type": case_type, "status": "NOT_ESTIMABLE", "available": 0})
            continue
        selected = group.head(cases_per_type).copy()
        selected["case_rank"] = np.arange(1, len(selected) + 1)
        selected["threshold"] = threshold
        selected["base_value"] = base_value
        selected_parts.append(selected.reset_index().rename(columns={"index": "row_hash"}))
        status_rows.append(
            {"case_type": case_type, "status": "ESTIMATED", "available": int(len(group))}
        )
    selected_cases = (
        pd.concat(selected_parts, ignore_index=True)
        if selected_parts
        else pd.DataFrame(
            columns=[
                "row_hash",
                "outcome",
                "model",
                "y_true",
                "prediction",
                "group_hash",
                "case_type",
                "case_rank",
                "threshold",
                "base_value",
            ]
        )
    )
    return shap_output, selected_cases, [
        *status_rows,
        {
            "case_type": "ADDITIVITY",
            "status": "ADDITIVITY_VERIFIED",
            "base_value": base_value,
            "maximum_base_deviation": maximum_deviation,
        },
    ]


def validate_shap_additivity(
    shap_values: pd.DataFrame,
    raw_validation: pd.DataFrame,
    shap_model: str,
    *,
    base_tolerance: float,
) -> dict[str, Any]:
    prediction = raw_validation.loc[raw_validation["model"].eq(shap_model)].set_index(
        "row_hash"
    )
    if prediction.empty:
        raise ValueError(f"SHAP model has no validation predictions: {shap_model}")
    sums = shap_values.groupby("row_hash", observed=True)["shap_value"].sum()
    common = sorted(set(sums.index) & set(prediction.index))
    if not common:
        raise ValueError("SHAP values and model predictions have no common rows")
    base_by_row = (
        logit(prediction.loc[common, "prediction"].to_numpy(dtype=float))
        - sums.loc[common].to_numpy(dtype=float)
    )
    base_value = float(np.median(base_by_row))
    maximum_deviation = float(np.max(np.abs(base_by_row - base_value)))
    if maximum_deviation > base_tolerance:
        raise ValueError(
            f"SHAP additivity/base-value deviation {maximum_deviation} exceeds {base_tolerance}"
        )
    return {
        "row_hashes": common,
        "rows": len(common),
        "base_value": base_value,
        "maximum_base_deviation": maximum_deviation,
        "tolerance": base_tolerance,
        "status": "ADDITIVITY_VERIFIED",
    }


def verify_figure(path: Path) -> dict[str, Any]:
    image = plt.imread(path)
    if image.ndim < 2 or image.shape[0] < 100 or image.shape[1] < 100:
        raise ValueError(f"rendered figure is too small or unreadable: {path.name}")
    finite = image[np.isfinite(image)]
    pixel_standard_deviation = float(np.std(finite)) if len(finite) else 0.0
    if pixel_standard_deviation <= 1e-4:
        raise ValueError(f"rendered figure is blank: {path.name}")
    return {
        "artifact": path.name,
        "height": int(image.shape[0]),
        "width": int(image.shape[1]),
        "pixel_standard_deviation": pixel_standard_deviation,
    }


def plot_shap_figures(
    shap_values: pd.DataFrame,
    selected_cases: pd.DataFrame,
    output_dir: Path,
    *,
    maximum_features: int,
) -> tuple[list[Path], list[dict[str, Any]]]:
    importance = (
        shap_values.assign(absolute=shap_values["shap_value"].abs())
        .groupby("feature", observed=True)["absolute"]
        .mean()
        .sort_values(ascending=False)
    )
    top_features = importance.head(maximum_features).index.tolist()
    summary_path = output_dir / "shap_beeswarm.png"
    figure, axis = plt.subplots(figsize=(10, max(5, 0.35 * len(top_features))))
    rng = np.random.default_rng(20260710)
    for position, feature in enumerate(reversed(top_features)):
        group = shap_values.loc[shap_values["feature"].eq(feature)]
        jitter = rng.normal(0, 0.07, len(group))
        scatter = axis.scatter(
            group["shap_value"],
            position + jitter,
            c=group["feature_value"],
            cmap="coolwarm",
            s=10,
            alpha=0.65,
        )
    axis.axvline(0, color="black", linewidth=0.7)
    axis.set_yticks(np.arange(len(top_features)), list(reversed(top_features)))
    axis.set_xlabel("SHAP value")
    axis.set_title("Validation 2024 SHAP beeswarm")
    figure.colorbar(scatter, ax=axis, label="Feature value")
    figure.tight_layout()
    figure.savefig(summary_path, dpi=180)
    plt.close(figure)

    dependence_feature = top_features[0]
    interaction_feature = top_features[1] if len(top_features) > 1 else top_features[0]
    dependence = shap_values.loc[
        shap_values["feature"].eq(dependence_feature),
        ["row_hash", "feature_value", "shap_value"],
    ].copy()
    interaction = shap_values.loc[
        shap_values["feature"].eq(interaction_feature), ["row_hash", "feature_value"]
    ].rename(columns={"feature_value": "interaction_value"})
    dependence = dependence.merge(interaction, on="row_hash", how="left", validate="one_to_one")
    dependence_path = output_dir / "shap_dependence.png"
    figure, axis = plt.subplots(figsize=(7, 5))
    scatter = axis.scatter(
        dependence["feature_value"],
        dependence["shap_value"],
        c=dependence["interaction_value"],
        cmap="viridis",
        s=14,
        alpha=0.65,
    )
    axis.axhline(0, color="black", linewidth=0.7)
    axis.set_xlabel(dependence_feature)
    axis.set_ylabel("SHAP value")
    axis.set_title(f"SHAP dependence: {dependence_feature} x {interaction_feature}")
    figure.colorbar(scatter, ax=axis, label=interaction_feature)
    figure.tight_layout()
    figure.savefig(dependence_path, dpi=180)
    plt.close(figure)

    paths = [summary_path, dependence_path]
    for case in selected_cases.itertuples(index=False):
        group = shap_values.loc[shap_values["row_hash"].eq(case.row_hash)].copy()
        group["absolute"] = group["shap_value"].abs()
        group = group.sort_values("absolute", ascending=False, kind="mergesort")
        retained = group.head(maximum_features).copy()
        omitted = float(group.iloc[maximum_features:]["shap_value"].sum())
        if abs(omitted) > 1e-12:
            retained = pd.concat(
                [
                    retained,
                    pd.DataFrame(
                        {
                            "feature": ["all_other_features"],
                            "shap_value": [omitted],
                            "absolute": [abs(omitted)],
                        }
                    ),
                ],
                ignore_index=True,
            )
        retained = retained.iloc[::-1].reset_index(drop=True)
        contribution = retained["shap_value"].to_numpy(dtype=float)
        left = float(case.base_value) + np.r_[0.0, np.cumsum(contribution[:-1])]
        final_logit = float(case.base_value + contribution.sum())
        path = output_dir / f"shap_waterfall_{case.case_type}_{int(case.case_rank)}.png"
        figure, axis = plt.subplots(figsize=(10, max(5, 0.35 * len(retained))))
        colors = np.where(contribution >= 0, "#d62728", "#1f77b4")
        axis.barh(retained["feature"], contribution, left=left, color=colors, alpha=0.85)
        axis.axvline(float(case.base_value), color="0.4", linestyle="--", linewidth=0.8)
        axis.axvline(final_logit, color="black", linewidth=0.9)
        axis.set_xlabel("Cumulative model output (log-odds)")
        axis.set_title(
            f"{case.case_type} rank {int(case.case_rank)} | p={case.prediction:.3f} | base={case.base_value:.3f}"
        )
        figure.tight_layout()
        figure.savefig(path, dpi=180)
        plt.close(figure)
        paths.append(path)
    return paths, [verify_figure(path) for path in paths]


def plot_evaluation_figures(
    raw_validation: pd.DataFrame,
    metrics: pd.DataFrame,
    calibration: pd.DataFrame,
    dca: pd.DataFrame,
    selected_methods: dict[str, str],
    comparison_models: list[str],
    output_dir: Path,
) -> tuple[list[Path], list[dict[str, Any]], dict[str, Any]]:
    roc_path = output_dir / "roc_overlay.png"
    pr_path = output_dir / "pr_overlay.png"
    calibration_path = output_dir / "calibration_overlay.png"
    dca_path = output_dir / "dca_overlay.png"

    main = raw_validation.loc[~raw_validation["model"].str.startswith("missingness__")]
    raw_metrics = metrics.loc[
        metrics["model"].str.endswith("__raw")
        & metrics["metric"].isin(["AUROC", "AUPRC"])
    ].copy()
    raw_metrics["base_model"] = raw_metrics["model"].map(base_model_name)
    metric_lookup = {
        (row.base_model, row.metric): row
        for row in raw_metrics.itertuples(index=False)
    }
    auroc_rows = raw_metrics.loc[
        raw_metrics["metric"].eq("AUROC")
        & ~raw_metrics["base_model"].str.startswith("missingness__")
    ].sort_values(["value", "base_model"], ascending=[False, True], kind="mergesort")
    if auroc_rows.empty:
        raise ValueError("cannot identify a validation model to highlight in ROC/PR figures")
    highlighted_model = str(auroc_rows.iloc[0]["base_model"])

    def curve_label(model: str, metric: str) -> str:
        row = metric_lookup[(model, metric)]
        return (
            f"{model} {metric}={float(row.value):.3f} "
            f"(95% CI {float(row.lower_ci):.3f}-{float(row.upper_ci):.3f})"
        )

    figure, axis = plt.subplots(figsize=(10, 8))
    for model, group in main.groupby("model", observed=True, sort=True):
        y = group["y_true"].to_numpy(dtype=int)
        prediction = group["prediction"].to_numpy(dtype=float)
        fpr, tpr, _ = roc_curve(y, prediction)
        highlighted = model == highlighted_model
        axis.plot(
            fpr,
            tpr,
            color=model_color(model),
            linewidth=2.5 if highlighted else 0.9,
            alpha=1.0 if highlighted else 0.7,
            zorder=5 if highlighted else 2,
            label=curve_label(str(model), "AUROC"),
        )
    axis.plot([0, 1], [0, 1], "k--", linewidth=0.7)
    axis.set(xlabel="False positive rate", ylabel="True positive rate", title="ROC overlay, validation 2024")
    axis.legend(fontsize=5, ncol=2)
    figure.tight_layout()
    figure.savefig(roc_path, dpi=180)
    plt.close(figure)

    figure, axis = plt.subplots(figsize=(10, 8))
    for model, group in main.groupby("model", observed=True, sort=True):
        y = group["y_true"].to_numpy(dtype=int)
        prediction = group["prediction"].to_numpy(dtype=float)
        precision, recall, _ = precision_recall_curve(y, prediction)
        highlighted = model == highlighted_model
        axis.plot(
            recall,
            precision,
            color=model_color(model),
            linewidth=2.5 if highlighted else 0.9,
            alpha=1.0 if highlighted else 0.7,
            zorder=5 if highlighted else 2,
            label=curve_label(str(model), "AUPRC"),
        )
    prevalence_source = raw_validation.loc[raw_validation["model"].eq(comparison_models[0])]
    axis.hlines(
        float(prevalence_source["y_true"].mean()),
        0,
        1,
        color="black",
        linestyle=":",
        linewidth=1.0,
        label="No-skill prevalence",
    )
    axis.set(xlabel="Recall", ylabel="Precision", title="PR overlay, validation 2024")
    axis.legend(fontsize=5, ncol=2)
    figure.tight_layout()
    figure.savefig(pr_path, dpi=180)
    plt.close(figure)

    figure, axis = plt.subplots(figsize=(10, 8))
    for base_model in comparison_models:
        for method, style in (("raw", "--"), (selected_methods[base_model], "-")):
            variant = f"{base_model}__{method}"
            curve = calibration.loc[
                calibration["model"].eq(variant) & calibration["curve_type"].eq("flexible_kernel")
            ].sort_values("grid_prediction")
            axis.plot(
                curve["grid_prediction"],
                curve["observed_probability"],
                color=model_color(base_model),
                linestyle=style,
                linewidth=2.5 if base_model == highlighted_model else 1.2,
                label=f"{base_model}:{method}",
            )
    axis.plot([0, 1], [0, 1], "k:", linewidth=0.8)
    axis.set(xlabel="Predicted probability", ylabel="Observed probability", title="Calibration overlay")
    axis.legend(fontsize=6, ncol=2)
    figure.tight_layout()
    figure.savefig(calibration_path, dpi=180)
    plt.close(figure)

    figure, axis = plt.subplots(figsize=(10, 8))
    for base_model in comparison_models:
        variant = f"{base_model}__{selected_methods[base_model]}"
        curve = dca.loc[
            dca["reference_model"].eq(variant) & dca["curve_type"].eq("model")
        ].sort_values("threshold")
        axis.plot(
            curve["threshold"],
            curve["net_benefit"],
            color=model_color(base_model),
            linewidth=2.5 if base_model == highlighted_model else 1.2,
            label=base_model,
        )
    reference = dca.loc[dca["reference_model"].eq(
        f"{comparison_models[0]}__{selected_methods[comparison_models[0]]}"
    )]
    for curve_type, style in (("treat_all", "--"), ("treat_none", ":")):
        curve = reference.loc[reference["curve_type"].eq(curve_type)].sort_values("threshold")
        axis.plot(curve["threshold"], curve["net_benefit"], color="black", linestyle=style, label=curve_type)
    axis.set(xlabel="Threshold probability", ylabel="Net benefit", title="Decision curve analysis")
    axis.legend(fontsize=6, ncol=2)
    figure.tight_layout()
    figure.savefig(dca_path, dpi=180)
    plt.close(figure)
    paths = [roc_path, pr_path, calibration_path, dca_path]
    return paths, [verify_figure(path) for path in paths], {
        "visual_highlight_model": highlighted_model,
        "visual_highlight_criterion": "maximum_apparent_validation_2024_AUROC",
        "visual_highlight_selection_performed": True,
        "visual_highlight_used_for_frozen_model_selection": False,
    }


def validate_mandatory_models(
    validation: pd.DataFrame, mode: str, outcome: str
) -> dict[str, list[str]]:
    missing: dict[str, list[str]] = {}
    models = set(validation.loc[validation["outcome"].eq(outcome), "model"])
    absent = sorted(MANDATORY_MODELS - models)
    if not ({"logistic_l1", "logistic_l2"} & models):
        absent.append("logistic_regression")
    if mode == "final_refresh":
        lower = {model.lower() for model in models}
        for label, tokens in {
            "BERT": ("bert", "roberta"),
            "MLP": ("mlp",),
            "FT-Transformer": ("ft_transformer", "ft-transformer"),
            "1D-CNN": ("cnn",),
            "TabPFN": ("tabpfn",),
            "TabICL": ("tabicl",),
            "Stacking": ("stack",),
        }.items():
            if not any(any(token in model for token in tokens) for model in lower):
                absent.append(label)
    if absent:
        missing[outcome] = absent
    if missing:
        raise ValueError(f"Stage2a mandatory model hard gate failed: {missing}")
    return missing


def json_safe(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value.resolve())
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    return value


def runtime_estimate(
    base_model_count: int,
    comparison_model_count: int,
    validation_rows: int,
    bootstrap_b: int,
    comparison_bootstrap_b: int,
) -> dict[str, Any]:
    reference_rows = 8967
    reference_b = 2000
    reference_pair_seconds = 23.235
    calibrated_pairs = base_model_count * 3
    comparisons = math.comb(comparison_model_count, 2)
    row_scale = max(validation_rows, 1) / reference_rows
    metric_seconds = (
        calibrated_pairs
        * reference_pair_seconds
        * row_scale
        * bootstrap_b
        / reference_b
    )
    comparison_seconds = (
        comparisons
        * reference_pair_seconds
        * 0.35
        * row_scale
        * comparison_bootstrap_b
        / reference_b
    )
    overhead_seconds = 90.0 + 3.0 * base_model_count
    total_seconds = metric_seconds + comparison_seconds + overhead_seconds
    return {
        "method": "scaled_2026_07_10_stage2a_reference_benchmark",
        "reference_pair_seconds": reference_pair_seconds,
        "reference_rows": reference_rows,
        "reference_bootstrap_b": reference_b,
        "base_model_count": int(base_model_count),
        "calibrated_validation_pairs": int(calibrated_pairs),
        "paired_comparisons": int(comparisons),
        "estimated_metric_seconds": float(metric_seconds),
        "estimated_comparison_seconds": float(comparison_seconds),
        "estimated_overhead_seconds": float(overhead_seconds),
        "estimated_total_seconds": float(total_seconds),
        "estimated_total_hours": float(total_seconds / 3600),
    }


def execution_environment(target: str) -> dict[str, Any]:
    runtime_markers = {
        "kernel_run_type": bool(os.environ.get("KAGGLE_KERNEL_RUN_TYPE")),
        "url_base": bool(os.environ.get("KAGGLE_URL_BASE")),
        "working_directory": Path("/kaggle/working").is_dir(),
        "input_directory": Path("/kaggle/input").is_dir(),
        "linux_platform": platform.system() == "Linux",
    }
    kaggle_runtime_hint = all(
        runtime_markers[key]
        for key in (
            "kernel_run_type",
            "working_directory",
            "input_directory",
            "linux_platform",
        )
    )
    cuda_available = False
    try:
        import torch

        cuda_available = bool(torch.cuda.is_available())
    except ImportError:
        pass
    return {
        "declared_target": target,
        "kaggle_runtime_hint": kaggle_runtime_hint,
        "runtime_markers": runtime_markers,
        "formal_attestation": False,
        "formal_attestation_source": "importer_verified_kaggle_receipt_required",
        "cuda_available": cuda_available,
    }


def execution_is_attested(runtime: dict[str, Any], target: str) -> bool:
    return bool(
        target == "local"
        and not runtime["requires_kaggle"]
        and not runtime["execution_environment"]["kaggle_runtime_hint"]
    )


def validate_existing_success(
    output_dir: Path,
    input_hashes: dict[str, Any],
    mode: str,
    outcome: str,
    task_id: str,
    *,
    smoke: bool,
) -> dict[str, Any] | None:
    success_path = output_dir / "_SUCCESS.json"
    if not success_path.is_file():
        return None
    success = json.loads(success_path.read_text(encoding="utf-8"))
    expected_status = "SMOKE_SUCCESS" if smoke else "SUCCESS"
    if (
        success.get("status") != expected_status
        or success.get("mode") != mode
        or success.get("outcome") != outcome
        or success.get("task_id") != task_id
    ):
        raise ValueError("existing Stage2a success task/mode/status mismatch")
    if success.get("input_hashes") != input_hashes:
        raise ValueError("existing immutable Stage2a run has different input hashes")
    manifest_path = output_dir / str(success.get("manifest", ""))
    if not manifest_path.is_file() or sha256_file(manifest_path) != success.get("manifest_sha256"):
        raise ValueError("existing Stage2a manifest hash mismatch")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if (
        manifest.get("task_id") != task_id
        or manifest.get("outcome") != outcome
        or manifest.get("artifact_hashes") != success.get("artifact_hashes")
    ):
        raise ValueError("existing Stage2a manifest ownership/artifact hashes differ")
    artifact_hashes = success.get("artifact_hashes", {})
    for relative, expected in artifact_hashes.items():
        path = output_dir / relative
        if not path.is_file() or sha256_file(path) != expected:
            raise ValueError(f"existing Stage2a artifact hash mismatch: {relative}")
    bundle_path = output_dir / str(success.get("bundle", ""))
    if not bundle_path.is_file() or sha256_file(bundle_path) != success.get("bundle_sha256"):
        raise ValueError("existing Stage2a task bundle hash mismatch")
    expected_members = set(artifact_hashes) | {manifest_path.name}
    with zipfile.ZipFile(bundle_path) as archive:
        members = set(archive.namelist())
        if members != expected_members:
            raise ValueError("existing Stage2a task bundle member set mismatch")
        for member, expected in artifact_hashes.items():
            if hashlib.sha256(archive.read(member)).hexdigest() != expected:
                raise ValueError(f"existing Stage2a bundled artifact hash mismatch: {member}")
        if hashlib.sha256(archive.read(manifest_path.name)).hexdigest() != success.get(
            "manifest_sha256"
        ):
            raise ValueError("existing Stage2a bundled manifest hash mismatch")
    return success


def initialize_resume_state(
    output_dir: Path,
    input_hashes: dict[str, Any],
    run_config: dict[str, Any],
    task_id: str,
    outcome: str,
) -> tuple[dict[str, Any], Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    state_path = output_dir / "_RUN_STATE.json"
    checkpoint_dir = output_dir / "_checkpoints"
    fingerprint = sha256_json(
        {
            "input_hashes": input_hashes,
            "run_config": run_config,
            "task_id": task_id,
            "outcome": outcome,
        }
    )
    if state_path.is_file():
        state = json.loads(state_path.read_text(encoding="utf-8"))
        if state.get("resume_fingerprint") != fingerprint:
            raise ValueError("partial Stage2a run has a different all-arguments/input resume hash")
    else:
        unexpected = [path.name for path in output_dir.iterdir()]
        if unexpected:
            raise ValueError(
                f"immutable output directory contains unowned partial files: {sorted(unexpected)}"
            )
        state = {
            "schema_version": "1.0",
            "stage": "P1_03",
            "task_id": task_id,
            "outcome": outcome,
            "resume_fingerprint": fingerprint,
            "all_arguments_sha256": sha256_json(run_config),
            "input_hashes": input_hashes,
            "phase": "INITIALIZED",
            "checkpoints": {},
        }
        atomic_json(state_path, state)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    return state, state_path, checkpoint_dir


def checkpoint_payload(
    path: Path,
    state: dict[str, Any],
    state_path: Path,
    key: str,
    builder: Any,
) -> Any:
    checkpoint = state["checkpoints"].get(key)
    if checkpoint is not None:
        if checkpoint.get("path") != path.relative_to(state_path.parent).as_posix():
            raise ValueError(f"resume checkpoint path mismatch: {key}")
        if not path.is_file() or sha256_file(path) != checkpoint.get("sha256"):
            raise ValueError(f"resume checkpoint hash mismatch: {key}")
        return joblib.load(path)
    value = builder()
    atomic_joblib(path, value)
    state["checkpoints"][key] = {
        "path": path.relative_to(state_path.parent).as_posix(),
        "sha256": sha256_file(path),
    }
    state["phase"] = key
    atomic_json(state_path, state)
    return value


def hard_requirement_statuses(
    checks: dict[str, bool], *, smoke: bool, execution_attested: bool = True
) -> dict[str, str]:
    formal_only_checks = {"bootstrap_valid_rate_and_convergence"}
    enforce = {
        name: passed
        for name, passed in checks.items()
        if not smoke or name not in formal_only_checks
    }
    if not all(enforce.values()):
        failures = sorted(name for name, passed in enforce.items() if not passed)
        raise ValueError(f"Stage2a verification checks failed: {failures}")
    if smoke:
        statuses = {
            name: (
                "NOT_FORMALLY_TESTED"
                if name in formal_only_checks
                else "SMOKE_PASS"
            )
            for name in checks
        }
        statuses.update(
            {
                "formal_authorization_anchor": "NOT_FORMALLY_TESTED",
            "formal_locked_patient_disjoint_cohort": "NOT_FORMALLY_TESTED",
                "formal_bootstrap_b_ge_2000": "NOT_FORMALLY_TESTED",
                "formal_execution_environment": "NOT_FORMALLY_TESTED",
            }
        )
        return statuses
    statuses = {name: "PASS" for name in checks}
    statuses.update(
        {
            "formal_authorization_anchor": "PASS",
            "formal_locked_patient_disjoint_cohort": "PASS",
            "formal_bootstrap_b_ge_2000": "PASS",
            "formal_execution_environment": (
                "PASS" if execution_attested else "AWAITING_IMPORT_VERIFICATION"
            ),
        }
    )
    return statuses


def authorization_run_contract(args: argparse.Namespace) -> dict[str, Any]:
    return {
        "mode": args.mode,
        "outcome": args.outcome,
        "bootstrap_b": int(args.bootstrap_b),
        "comparison_bootstrap_b": int(args.comparison_bootstrap_b),
        "seed": int(args.seed),
        "calibration_grid_points": int(args.calibration_grid_points),
        "dca_thresholds": args.dca_thresholds.tolist(),
        "shap_model": args.shap_model,
        "shap_cases_per_type": int(args.shap_cases_per_type),
        "shap_max_features": int(args.shap_max_features),
        "shap_base_tolerance": SHAP_BASE_TOLERANCE,
        "execution_target": args.execution_target,
        "smoke": bool(args.smoke),
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    if args.bootstrap_b < 1 or args.comparison_bootstrap_b < 1:
        raise ValueError("bootstrap repetitions must be positive")
    if not args.smoke and (
        args.bootstrap_b < 2000 or args.comparison_bootstrap_b < 2000
    ):
        raise ValueError("formal Stage2a requires both bootstrap counts >= 2000")
    started = time.perf_counter()
    predictions_path = args.predictions.resolve()
    coverage_path = args.coverage.resolve()
    stage1a_path = args.stage1a.resolve()
    registry_path = args.registry.resolve()
    fold_map_path = args.fold_map.resolve()
    access_log_path = args.access_log.resolve()
    upstream_completion_path = args.upstream_completion.resolve()
    base_model_canary_path = args.base_model_canary.resolve()
    shap_model_selection_path = args.shap_model_selection.resolve()
    shap_values_path = args.shap_values.resolve()
    shap_provenance_path = args.shap_provenance.resolve()
    launch_authorization_path = args.launch_authorization.resolve()
    output_dir = args.output_dir.resolve()
    registry_sha256 = sha256_file(registry_path)
    if not args.smoke and args.registry_sha256 is None:
        raise ValueError("formal Stage2a requires --registry-sha256 for the locked task registry")
    if args.registry_sha256 is not None and args.registry_sha256.lower() != registry_sha256.lower():
        raise ValueError("locked task registry SHA256 mismatch")
    stage1a_manifest_path = (
        args.stage1a_manifest.resolve() if args.stage1a_manifest is not None else None
    )
    if stage1a_manifest_path is None:
        candidate = stage1a_path.parent / "stage1a_feature_manifest_v2.json"
        stage1a_manifest_path = candidate.resolve() if candidate.is_file() else None

    run_config = {
        key: json_safe(value) for key, value in sorted(vars(args).items())
    }
    code_path = Path(__file__).resolve()
    input_hashes = {
        "predictions": sha256_file(predictions_path),
        "coverage": sha256_file(coverage_path),
        "stage1a": sha256_file(stage1a_path),
        "registry": registry_sha256,
        "fold_map": sha256_file(fold_map_path),
        "access_log": sha256_file(access_log_path),
        "upstream_completion": sha256_file(upstream_completion_path),
        "base_model_canary": sha256_file(base_model_canary_path),
        "shap_model_selection": sha256_file(shap_model_selection_path),
        "shap_values": sha256_file(shap_values_path),
        "shap_provenance": sha256_file(shap_provenance_path),
        "launch_authorization": sha256_file(launch_authorization_path),
        "code": sha256_file(code_path),
        "all_arguments": sha256_json(run_config),
    }
    if stage1a_manifest_path is not None:
        input_hashes["stage1a_manifest"] = sha256_file(stage1a_manifest_path)

    stage1a, stage1a_contract = load_stage1a_metadata(
        stage1a_path, stage1a_manifest_path, smoke=args.smoke
    )
    expected_split_counts = {
        "oof_2020_2023": int(stage1a["split_year"].between(2020, 2023).sum()),
        "validation_2024": int(stage1a["split_year"].eq(2024).sum()),
    }
    predictions = load_predictions(predictions_path)
    coverage = load_coverage(coverage_path)
    if set(predictions["outcome"]) != {args.outcome} or set(coverage["outcome"]) != {
        args.outcome
    }:
        raise ValueError("Stage2a per-outcome inputs must contain exactly the requested outcome")
    validate_coverage_cohort(coverage, stage1a)
    access_log, access_log_sha256 = load_access_log(access_log_path, smoke=args.smoke)
    if access_log_sha256 != input_hashes["access_log"]:
        raise ValueError("access log changed while Stage2a was loading")
    fold_map, fold_contract = load_fold_map(
        fold_map_path,
        stage1a,
        args.outcome,
        expected_sha256=args.fold_map_sha256,
        smoke=args.smoke,
    )
    registry_result = load_registry(
        registry_path,
        args.mode,
        args.outcome,
        predictions,
        coverage,
        stage1a_path,
        expected_split_counts,
        smoke=args.smoke,
    )
    (
        registry,
        expected_tasks,
        evaluation_task,
        closure,
        selected_predictions,
        selected_coverage,
        coverage_omissions,
        terminal_evaluation_models,
    ) = registry_result
    evaluation_task_id = str(evaluation_task["task_id"])
    upstream_contract = load_upstream_completion(
        upstream_completion_path,
        registry,
        closure,
        evaluation_task_id,
        {
            "predictions": input_hashes["predictions"],
            "coverage": input_hashes["coverage"],
            "stage1a": input_hashes["stage1a"],
            "registry": input_hashes["registry"],
            "fold_map": input_hashes["fold_map"],
        },
    )
    if upstream_contract["sha256"] != input_hashes["upstream_completion"]:
        raise ValueError("upstream completion ledger changed while Stage2a was loading")
    authorization_locked_hashes = {
        key: value
        for key, value in input_hashes.items()
        if key not in {"launch_authorization", "all_arguments"}
    }
    authorization_contract = load_launch_authorization(
        launch_authorization_path,
        evaluation_task_id,
        args.outcome,
        authorization_locked_hashes,
        stage1a_key_contract(stage1a),
        fold_contract,
        authorization_run_contract(args),
        smoke=args.smoke,
    )
    if authorization_contract["sha256"] != input_hashes["launch_authorization"]:
        raise ValueError("launch authorization changed while Stage2a was loading")
    if not args.smoke and expected_split_counts != FORMAL_COHORT_SPLIT_COUNTS:
        raise ValueError(
            "formal Stage2a cohort key set changed from locked patient-disjoint "
            "24,784/7,504 counts; reauthorization required"
        )
    if output_dir.name != evaluation_task_id:
        raise ValueError(
            f"per-outcome output directory must be named exactly {evaluation_task_id}"
        )
    joined = join_and_validate(selected_predictions, stage1a, fold_map)
    validation = joined.loc[joined["split"].eq("validation_2024")].copy()
    validate_mandatory_models(validation, args.mode, args.outcome)
    raw_validation = validation.copy()
    shap_selection_contract = load_shap_model_selection(
        shap_model_selection_path,
        raw_validation,
        args.outcome,
        args.shap_model,
        smoke=args.smoke,
    )
    if shap_selection_contract["sha256"] != input_hashes["shap_model_selection"]:
        raise ValueError("SHAP model selection changed while Stage2a was loading")
    (
        base_canary_frame,
        model_provenance,
        base_canary_contract,
        model_inference_contexts,
    ) = load_base_model_canary(
        base_model_canary_path,
        raw_validation,
        stage1a_path,
        upstream_contract["task_artifact_roles"],
        args.outcome,
        args.shap_model,
        smoke=args.smoke,
    )
    if base_canary_contract["sha256"] != input_hashes["base_model_canary"]:
        raise ValueError("base-model canary changed while Stage2a was loading")
    if args.shap_model not in model_provenance:
        raise ValueError(f"SHAP model lacks verified base-model provenance: {args.shap_model}")
    if terminal_evaluation_models:
        joined = joined.loc[
            ~joined["model"].isin(terminal_evaluation_models)
        ].copy()
        raw_validation = raw_validation.loc[
            ~raw_validation["model"].isin(terminal_evaluation_models)
        ].copy()
    shap_validation_rows = set(
        raw_validation.loc[raw_validation["model"].eq(args.shap_model), "row_hash"]
    )
    shap_values, shap_provenance_contract = load_shap_values(
        shap_values_path,
        shap_provenance_path,
        stage1a_path,
        args.outcome,
        args.shap_model,
        shap_validation_rows,
        model_provenance[args.shap_model]["source_task_id"],
        model_provenance[args.shap_model],
        model_inference_contexts[args.shap_model],
    )
    if shap_provenance_contract["shap_values_sha256"] != input_hashes["shap_values"]:
        raise ValueError("SHAP input changed while Stage2a was loading")
    if shap_provenance_contract["sha256"] != input_hashes["shap_provenance"]:
        raise ValueError("SHAP provenance changed while Stage2a was loading")
    shap_additivity_preflight = validate_shap_additivity(
        shap_values,
        raw_validation,
        args.shap_model,
        base_tolerance=SHAP_BASE_TOLERANCE,
    )
    base_models = sorted(set(joined["model"]))
    for model in base_models:
        splits = set(joined.loc[joined["model"].eq(model), "split"])
        if splits != {"oof_2020_2023", "validation_2024"}:
            raise ValueError(f"analytic model lacks OOF/validation provenance: {model}")
    comparison_models = required_comparison_models(set(base_models), args.mode)
    runtime = runtime_estimate(
        len(base_models),
        len(comparison_models),
        expected_split_counts["validation_2024"],
        args.bootstrap_b,
        args.comparison_bootstrap_b,
    )
    runtime["execution_target"] = args.execution_target
    runtime["local_limit_hours"] = LOCAL_RUNTIME_LIMIT_HOURS
    runtime["requires_kaggle"] = bool(
        runtime["estimated_total_hours"] > LOCAL_RUNTIME_LIMIT_HOURS
    )
    runtime["execution_environment"] = execution_environment(args.execution_target)
    if (
        not args.smoke
        and runtime["requires_kaggle"]
        and args.execution_target == "local"
    ):
        raise ValueError(
            "formal Stage2a estimate exceeds the local runtime limit; run this immutable task on Kaggle CPU/GPU"
        )
    if (
        not args.smoke
        and args.execution_target == "kaggle_gpu"
        and runtime["execution_environment"]["kaggle_runtime_hint"]
        and not runtime["execution_environment"]["cuda_available"]
    ):
            raise ValueError("formal kaggle_gpu target has no available CUDA device")

    existing = validate_existing_success(
        output_dir,
        input_hashes,
        args.mode,
        args.outcome,
        evaluation_task_id,
        smoke=args.smoke,
    )
    if existing is not None:
        return existing
    state, state_path, checkpoint_dir = initialize_resume_state(
        output_dir,
        input_hashes,
        run_config,
        evaluation_task_id,
        args.outcome,
    )
    hardware_path = output_dir / "hardware.json"
    atomic_json(hardware_path, hardware_record())
    runtime_path = output_dir / "runtime_estimate.json"
    atomic_json(runtime_path, runtime)

    def build_calibration() -> dict[str, Any]:
        calibrators: dict[str, Any] = {}
        prediction_parts = []
        comparison_rows: list[dict[str, Any]] = []
        for index, (base_model, group) in enumerate(
            joined.groupby("model", observed=True, sort=True), start=1
        ):
            print(
                f"stage2a_calibration {index}/{len(base_models)} outcome={args.outcome} model={base_model}",
                flush=True,
            )
            bundle, calibrated, comparison = crossfit_calibration(
                group,
                evaluation_task_id,
                seed=args.seed,
            )
            calibrators[str(base_model)] = bundle
            prediction_parts.append(calibrated)
            comparison_rows.extend(comparison)
        return {
            "models": calibrators,
            "predictions": pd.concat(prediction_parts, ignore_index=True),
            "comparison": pd.DataFrame(comparison_rows),
        }

    calibration_checkpoint = checkpoint_payload(
        checkpoint_dir / "calibration.joblib",
        state,
        state_path,
        "calibration",
        build_calibration,
    )
    calibrators = calibration_checkpoint["models"]
    calibrated_predictions = calibration_checkpoint["predictions"]
    calibration_comparison = calibration_checkpoint["comparison"]
    if set(calibrators) != set(base_models):
        raise ValueError("calibration checkpoint model set differs from locked inputs")
    calibrated_joined = join_and_validate(calibrated_predictions, stage1a, fold_map)
    validation_variants = calibrated_joined.loc[
        calibrated_joined["split"].eq("validation_2024")
    ].copy()
    expected_variants = {f"{model}__{method}" for model in base_models for method in ("raw", "platt", "isotonic")}
    if set(validation_variants["model"]) != expected_variants:
        raise ValueError("calibrated prediction variants are incomplete")

    calibrator_path = output_dir / "calibrators.joblib"
    atomic_joblib(calibrator_path, calibrators)
    predictions_output_path = output_dir / "predictions.parquet"
    atomic_parquet(predictions_output_path, calibrated_predictions[PREDICTION_COLUMNS])
    calibration_comparison_path = output_dir / "calibration_comparison.parquet"
    atomic_parquet(calibration_comparison_path, calibration_comparison)
    canary, canary_paths = write_calibrator_canary(
        calibrator_path,
        output_dir,
        raw_validation,
        calibrators,
        smoke=args.smoke,
    )
    expected_canary_rows = min(100, int(raw_validation["row_hash"].nunique()))
    if canary["unique_validation_rows"] != expected_canary_rows:
        raise ValueError("calibrator canary does not contain the required 100-row cohort")

    minimum_bootstrap_success = max(
        1, math.ceil(args.bootstrap_b * (0.80 if args.smoke else 0.95))
    )
    metric_rows: list[dict[str, Any]] = []
    calibration_rows: list[dict[str, Any]] = []
    operating_rows: list[dict[str, Any]] = []
    waterfall_frames: list[pd.DataFrame] = []
    dca: list[dict[str, Any]] = []
    grouped = list(validation_variants.groupby("model", observed=True, sort=True))
    for index, (model, group) in enumerate(grouped, start=1):
        checkpoint_key = f"metric_pair:{model}"
        checkpoint_path = checkpoint_dir / f"metric_{hashlib.sha256(str(model).encode()).hexdigest()[:16]}.joblib"

        def build_pair(group: pd.DataFrame = group, model: str = str(model)) -> dict[str, Any]:
            print(
                f"stage2a_pair {index}/{len(grouped)} outcome={args.outcome} model={model}",
                flush=True,
            )
            pair_metrics, pair_calibration = evaluate_pair(
                group,
                bootstrap_b=args.bootstrap_b,
                minimum_bootstrap_success=minimum_bootstrap_success,
                seed=args.seed,
                grid_points=args.calibration_grid_points,
            )
            operating, waterfall = select_operating_point(group)
            return {
                "outcome": args.outcome,
                "model": model,
                "metrics": pair_metrics,
                "calibration": pair_calibration,
                "operating": operating,
                "waterfall": waterfall,
                "dca": dca_rows(group, args.dca_thresholds),
            }

        pair = checkpoint_payload(
            checkpoint_path,
            state,
            state_path,
            checkpoint_key,
            build_pair,
        )
        if pair.get("outcome") != args.outcome or pair.get("model") != model:
            raise ValueError(f"metric checkpoint ownership mismatch: {model}")
        metric_rows.extend(pair["metrics"])
        calibration_rows.extend(pair["calibration"])
        operating_rows.append(pair["operating"])
        waterfall_frames.append(pair["waterfall"])
        dca.extend(pair["dca"])

    metrics_frame = pd.DataFrame(metric_rows)
    metrics_frame["validation_cohort_n"] = expected_split_counts["validation_2024"]
    metrics_frame["coverage_rate"] = (
        metrics_frame["n"] / metrics_frame["validation_cohort_n"]
    )
    metric_failures = metrics_frame.loc[metrics_frame["status"].ne("ESTIMATED")]
    allowed_metric_failures = metric_failures.loc[
        prespecified_complete_case_not_estimable_mask(metric_failures)
    ]
    unexpected_metric_failures = metric_failures.drop(
        index=allowed_metric_failures.index
    )
    if not args.smoke and not unexpected_metric_failures.empty:
        raise ValueError(
            "formal Stage2a has non-estimable metric/bootstrap rows: "
            f"{unexpected_metric_failures[['model', 'metric', 'bootstrap_success']].head(10).to_dict('records')}"
        )
    calibration_rows.extend(
        [
            {
                "outcome": args.outcome,
                "model": "__IDEAL__",
                "model_family": "reference",
                "curve_type": "ideal",
                "grid_prediction": value,
                "observed_probability": value,
                "lower_ci": value,
                "upper_ci": value,
                "bootstrap_b": args.bootstrap_b,
                "bootstrap_success": args.bootstrap_b,
                "bootstrap_failures": 0,
                "bootstrap_minimum_success_required": minimum_bootstrap_success,
                "status": "ESTIMATED",
                "kernel_bandwidth_logit": None,
                "n": None,
                "events": None,
            }
            for value in (0.0, 1.0)
        ]
    )
    calibration_frame = pd.DataFrame(calibration_rows)
    flexible_failures = calibration_frame.loc[
        calibration_frame["curve_type"].eq("flexible_kernel")
        & calibration_frame["status"].ne("ESTIMATED")
    ]
    if not args.smoke and not flexible_failures.empty:
        raise ValueError("formal Stage2a flexible calibration bootstrap did not converge")
    calibration_frame["validation_cohort_n"] = expected_split_counts["validation_2024"]
    calibration_frame["coverage_rate"] = (
        pd.to_numeric(calibration_frame["n"], errors="coerce")
        / calibration_frame["validation_cohort_n"]
    )
    selected_methods = {
        model: str(bundle["selected_method"]) for model, bundle in calibrators.items()
    }
    operating_frame = pd.DataFrame(operating_rows)
    operating_frame["base_model"] = operating_frame["model"].map(base_model_name)
    operating_frame["calibration_method"] = operating_frame["model"].str.rsplit(
        "__", n=1
    ).str[-1]
    operating_frame["selected_by_crossfit_oof_brier"] = operating_frame.apply(
        lambda row: row["calibration_method"] == selected_methods[row["base_model"]], axis=1
    )
    operating_frame["threshold_selection_performed"] = True
    operating_frame["threshold_selection_split"] = "validation_2024"
    waterfall_frame = pd.concat(waterfall_frames, ignore_index=True)
    dca_frame = pd.DataFrame(dca)
    ci_lookup = {
        (row.outcome, row.model, row.metric): (row.lower_ci, row.upper_ci)
        for row in metrics_frame.itertuples(index=False)
    }
    roc_rows: list[dict[str, Any]] = []
    pr_rows: list[dict[str, Any]] = []
    for model, group in grouped:
        pair_roc, pair_pr = curve_rows(group, ci_lookup)
        roc_rows.extend(pair_roc)
        pr_rows.extend(pair_pr)
    roc_frame = pd.DataFrame(roc_rows)
    pr_frame = pd.DataFrame(pr_rows)
    for frame in (operating_frame, dca_frame, roc_frame, pr_frame):
        frame["validation_cohort_n"] = expected_split_counts["validation_2024"]
        frame["coverage_rate"] = frame["n"] / frame["validation_cohort_n"]

    comparison_minimum_success = max(
        1, math.ceil(args.comparison_bootstrap_b * (0.80 if args.smoke else 0.95))
    )

    def build_paired_comparisons() -> pd.DataFrame:
        frame = paired_comparison_rows(
            raw_validation,
            args.mode,
            bootstrap_b=args.comparison_bootstrap_b,
            seed=args.seed,
            minimum_success=comparison_minimum_success,
        )
        frame.insert(0, "task_id", evaluation_task_id)
        frame.insert(3, "split", "validation_2024")
        return frame

    paired_frame = checkpoint_payload(
        checkpoint_dir / "paired_comparisons.joblib",
        state,
        state_path,
        "paired_comparisons",
        build_paired_comparisons,
    )
    if not np.isfinite(
        paired_frame[
            ["auroc_delong_p", "auprc_paired_bootstrap_p"]
        ].to_numpy(dtype=float)
    ).all():
        raise ValueError("paired model comparison produced a non-finite p-value")

    shap_output, shap_cases, shap_status = prepare_shap_outputs(
        shap_values,
        raw_validation,
        operating_frame,
        args.shap_model,
        cases_per_type=args.shap_cases_per_type,
        base_tolerance=SHAP_BASE_TOLERANCE,
    )
    shap_case_statuses = {
        row["case_type"]: row["status"] for row in shap_status if row["case_type"] in {"TP", "FN"}
    }
    if shap_case_statuses != {"TP": "ESTIMATED", "FN": "ESTIMATED"}:
        raise ValueError(f"SHAP TP/FN waterfall requirement is not estimable: {shap_case_statuses}")
    shap_status_frame = pd.DataFrame(shap_status)

    figures_dir = output_dir / "figures"
    figures_dir.mkdir(parents=True, exist_ok=True)
    evaluation_figures, evaluation_figure_checks, figure_selection = plot_evaluation_figures(
        raw_validation,
        metrics_frame,
        calibration_frame,
        dca_frame,
        selected_methods,
        comparison_models,
        figures_dir,
    )
    shap_figures, shap_figure_checks = plot_shap_figures(
        shap_output,
        shap_cases,
        figures_dir,
        maximum_features=args.shap_max_features,
    )
    figure_checks = evaluation_figure_checks + shap_figure_checks
    figure_checks_path = output_dir / "figure_verification.json"
    atomic_json(
        figure_checks_path,
        {
            "status": "SMOKE_VERIFIED" if args.smoke else "PASS",
            "figures": figure_checks,
        },
    )

    bootstrap_diagnostics = pd.concat(
        [
            metrics_frame.assign(diagnostic_type="metric")[[
                "outcome",
                "model",
                "diagnostic_type",
                "metric",
                "status",
                "bootstrap_b",
                "bootstrap_success",
                "bootstrap_failures",
                "bootstrap_minimum_success_required",
            ]],
            calibration_frame.loc[calibration_frame["curve_type"].eq("flexible_kernel")]
            .assign(metric="flexible_calibration", diagnostic_type="curve")[[
                "outcome",
                "model",
                "diagnostic_type",
                "metric",
                "status",
                "bootstrap_b",
                "bootstrap_success",
                "bootstrap_failures",
                "bootstrap_minimum_success_required",
            ]],
        ],
        ignore_index=True,
    )
    selection_frame = pd.DataFrame(
        [
            {
                "task_id": evaluation_task_id,
                "outcome": args.outcome,
                "base_model": model,
                "selected_calibration_method": selected_methods[model],
                "raw_crossfit_oof_brier": bundle["crossfit_oof_brier"]["raw"],
                "platt_crossfit_oof_brier": bundle["crossfit_oof_brier"]["platt"],
                "isotonic_crossfit_oof_brier": bundle["crossfit_oof_brier"]["isotonic"],
                "selection_split": "oof_2020_2023_crossfit",
                "base_model_selection_performed": False,
                "calibration_method_selection_performed": True,
            }
            for model, bundle in sorted(calibrators.items())
        ]
    )
    coverage_omissions_frame = pd.DataFrame(
        coverage_omissions,
        columns=["task_id", "model", "eligible_rows", "status"],
    )
    registry_by_id = {str(task["task_id"]): task for task in registry["tasks"]}
    closure_frame = pd.DataFrame(
        [
            {
                "task_id": task_id,
                "stage": registry_by_id[task_id].get("stage"),
                "task_family": registry_by_id[task_id].get("task_family"),
                "outcome": registry_by_id[task_id].get("outcome"),
            }
            for task_id in sorted(closure)
        ]
    )

    frames = {
        "metrics.parquet": metrics_frame[METRIC_COLUMNS],
        "metrics_bootstrap_detail_2024.parquet": metrics_frame,
        "bootstrap_diagnostics.parquet": bootstrap_diagnostics,
        "calibration_overlay_2024.parquet": calibration_frame,
        "calibration_selection.parquet": selection_frame,
        "operating_points_2024.parquet": operating_frame,
        "waterfall_cases_2024.parquet": waterfall_frame,
        "dca_overlay_2024.parquet": dca_frame,
        "roc_overlay_2024.parquet": roc_frame,
        "pr_overlay_2024.parquet": pr_frame,
        "paired_model_comparisons_2024.parquet": paired_frame,
        "shap_values_2024.parquet": shap_output,
        "shap_waterfall_cases_2024.parquet": shap_cases,
        "shap_status.parquet": shap_status_frame,
        "coverage_audit.parquet": selected_coverage,
        "coverage_omissions.parquet": coverage_omissions_frame,
        "registry_closure.parquet": closure_frame,
        "base_model_reload_canary.parquet": base_canary_frame,
    }
    frame_paths: list[Path] = []
    for filename, frame in frames.items():
        path = output_dir / filename
        atomic_parquet(path, frame)
        frame_paths.append(path)

    hard_requirements = hard_requirement_statuses(
        {
            "per_outcome_task_ownership": True,
            "registry_dependency_closure": True,
            "upstream_task_manifests_and_members_verified": (
                upstream_contract["verified_artifact_count"]
                == upstream_contract["required_closure_tasks"]
            ),
            "expected_equals_completed_predictive_tasks": True,
            "locked_fold_map_exact_match": True,
            "coverage_manifest_complete": True,
            "oof_and_validation_provenance": True,
            "2025_access_zero": True,
            "pii_and_arrival_hits_zero": True,
            "duplicate_predictions_zero": True,
            "calibration_crossfit_oof_only": True,
            "bootstrap_valid_rate_and_convergence": (
                unexpected_metric_failures.empty and flexible_failures.empty
            ),
            "base_model_fresh_reload_inference_within_1e_5": (
                base_canary_contract["maximum_reload_prediction_error"] <= 1e-5
            ),
            "calibrator_reload_canary_within_1e_5": (
                canary["maximum_absolute_error"] <= 1e-5
            ),
            "paired_common_cohort_comparisons": True,
            "shap_fresh_treeexplainer_recompute_matches_locked_features": (
                shap_provenance_contract["status"] == "RECOMPUTED_AND_VERIFIED"
            ),
            "shap_additivity_tp_fn_waterfalls": True,
            "rendered_figures_verified": True,
            "all_arguments_and_inputs_hashed": True,
        },
        smoke=args.smoke,
        execution_attested=execution_is_attested(runtime, args.execution_target),
    )
    formal_release_eligible = not args.smoke and set(hard_requirements.values()) == {"PASS"}
    remote_import_pending = (
        not args.smoke
        and hard_requirements["formal_execution_environment"]
        == "AWAITING_IMPORT_VERIFICATION"
    )
    if not args.smoke and not formal_release_eligible and not remote_import_pending:
        raise ValueError(f"formal Stage2a hard requirements did not all pass: {hard_requirements}")
    run_status = (
        "SMOKE_PASS_NON_RELEASE"
        if args.smoke
        else "COMPUTE_PASS_AWAITING_IMPORT"
        if remote_import_pending
        else "PASS"
    )
    qa_record = {
        "schema_version": "1.0",
        "status": run_status,
        "release_eligible": formal_release_eligible,
        "task_id": evaluation_task_id,
        "outcome": args.outcome,
        "mode": args.mode,
        "hard_requirements": hard_requirements,
        "formal_gate_executed": not args.smoke,
        "hard_requirement_pass_count": (
            sum(value == "PASS" for value in hard_requirements.values())
            if not args.smoke
            else 0
        ),
        "smoke_check_pass_count": sum(
            value == "SMOKE_PASS" for value in hard_requirements.values()
        ),
        "hard_requirement_total": len(hard_requirements),
        "expected_registry_tasks": len(expected_tasks),
        "completed_registry_tasks": len(expected_tasks),
        "registry_closure_tasks": len(closure),
        "upstream_completed_closure_tasks": upstream_contract["completed_closure_tasks"],
        "coverage_omissions": int(len(coverage_omissions_frame)),
        "bootstrap_b": args.bootstrap_b,
        "bootstrap_minimum_success_required": minimum_bootstrap_success,
        "bootstrap_max_failed_replicates": int(metrics_frame["bootstrap_failures"].max()),
        "prespecified_complete_case_not_estimable_metric_rows": int(
            len(allowed_metric_failures)
        ),
        "comparison_bootstrap_b": args.comparison_bootstrap_b,
        "comparison_bootstrap_minimum_success_required": comparison_minimum_success,
        "base_model_fit_performed": False,
        "calibration_model_fit_performed": True,
        "base_model_selection_performed": False,
        "model_family_selection_performed": False,
        "calibration_method_selection_performed": True,
        "calibration_selection_split": "oof_2020_2023_crossfit",
        "threshold_selection_performed": True,
        "threshold_selection_split": "validation_2024",
        "thresholds_are_apparent_validation_operating_points": True,
        **figure_selection,
        "base_model_reload_canary": base_canary_contract,
        "calibrator_reload_canary": canary,
        "shap_additivity_preflight": {
            key: value
            for key, value in shap_additivity_preflight.items()
            if key != "row_hashes"
        },
        "runtime_estimate": runtime,
    }
    qa_path = output_dir / "stage2a_qa_record.json"
    atomic_json(qa_path, qa_record)

    state["phase"] = "COMPLETE_ARTIFACTS_READY"
    state["runtime_seconds_to_artifacts"] = float(time.perf_counter() - started)
    atomic_json(state_path, state)
    artifact_paths = {
        hardware_path,
        runtime_path,
        calibrator_path,
        predictions_output_path,
        calibration_comparison_path,
        *canary_paths,
        *frame_paths,
        qa_path,
        figure_checks_path,
        *evaluation_figures,
        *shap_figures,
        state_path,
        *[path for path in checkpoint_dir.rglob("*") if path.is_file()],
    }
    payload_hashes = {
        path.relative_to(output_dir).as_posix(): sha256_file(path)
        for path in sorted(artifact_paths)
    }
    hashes_path = output_dir / "hashes.json"
    atomic_json(
        hashes_path,
        {
            "schema_version": "1.0",
            "task_id": evaluation_task_id,
            "outcome": args.outcome,
            "input_hashes": input_hashes,
            "code_sha256": {code_path.name: input_hashes["code"]},
            "artifact_hashes_excluding_hashes_json": payload_hashes,
            "hash_contract": {
                "hashes_json_self_hash_excluded": True,
                "manifest_hash_carried_by_success": True,
                "bundle_hash_carried_by_success": True,
            },
        },
    )
    artifact_paths.add(hashes_path)
    artifact_hashes = {
        path.relative_to(output_dir).as_posix(): sha256_file(path)
        for path in sorted(artifact_paths)
    }
    manifest = {
        "schema_version": "1.0",
        "stage": "P1_03",
        "task_id": evaluation_task_id,
        "outcome": args.outcome,
        "status": run_status,
        "release_eligible": formal_release_eligible,
        "evaluation_scope": args.mode,
        "final_overlay_required": args.mode == "core",
        "completed_components": [
            "raw_platt_isotonic_crossfit_calibration",
            "group_cluster_bootstrap_metrics_and_flexible_calibration_ci",
            "paired_delong_and_auprc_bootstrap_comparisons",
            "threshold_operating_points_and_tp_fn_case_index",
            "decision_curve_and_roc_pr_calibration_overlays",
            "shap_beeswarm_dependence_and_tp_fn_waterfalls",
            "stage2a_base_model_reload_and_fresh_inference",
            "serialized_calibrator_reload_canary",
            "rendered_figure_verification",
        ],
        "base_model_fit_allowed": False,
        "base_model_fit_performed": False,
        "calibration_fit_allowed": True,
        "calibration_model_fit_performed": True,
        "base_model_selection_performed": False,
        "model_family_selection_performed": False,
        "calibration_method_selection_performed": True,
        "calibration_selection_split": "oof_2020_2023_crossfit",
        "threshold_selection_performed": True,
        "threshold_selection_split": "validation_2024",
        "thresholds_are_apparent_validation_operating_points": True,
        **figure_selection,
        "run_config": run_config,
        "input_hashes": input_hashes,
        "stage1a_contract": stage1a_contract,
        "fold_contract": fold_contract,
        "launch_authorization_contract": authorization_contract,
        "upstream_completion_contract": upstream_contract,
        "base_model_canary_contract": base_canary_contract,
        "shap_model_selection_contract": shap_selection_contract,
        "shap_provenance_contract": shap_provenance_contract,
        "shap_additivity_preflight": {
            key: value
            for key, value in shap_additivity_preflight.items()
            if key != "row_hashes"
        },
        "access_log_contract": {
            "sha256": access_log_sha256,
            "2025_access_count": access_log.get("holdout_policy", access_log).get("2025_access_count"),
            "holdout_mounted": access_log.get("holdout_policy", access_log).get("holdout_mounted"),
            "predictions_computed": access_log.get("holdout_policy", access_log).get("predictions_computed"),
        },
        "registry_schema_version": registry.get("schema_version"),
        "registry_closure_sha256": sha256_json(sorted(closure)),
        "registry_closure_tasks": len(closure),
        "expected_registry_tasks": len(expected_tasks),
        "completed_registry_tasks": len(expected_tasks),
        "outcomes": [args.outcome],
        "base_models": base_models,
        "calibrated_variants": sorted(expected_variants),
        "bootstrap_b": int(args.bootstrap_b),
        "bootstrap_minimum_success_required": minimum_bootstrap_success,
        "bootstrap_method": "outcome_stratified_patient_group_cluster",
        "prespecified_complete_case_not_estimable_metric_rows": int(
            len(allowed_metric_failures)
        ),
        "comparison_bootstrap_b": int(args.comparison_bootstrap_b),
        "paired_comparison_method": "DeLong_AUROC_and_paired_group_cluster_AUPRC_bootstrap",
        "strict_no_arrival_leakage": True,
        "historical_2025_exposure": True,
        "2025_access_count": 0,
        "pii_hits": 0,
        "duplicate_predictions": 0,
        "patient_group_split_overlap": 0,
        "patient_group_fold_overlap": 0,
        "hard_requirements": hard_requirements,
        "artifact_hashes": artifact_hashes,
        "artifact_rows": {filename: int(len(frame)) for filename, frame in frames.items()},
        "runtime_estimate": runtime,
        "smoke": bool(args.smoke),
        "runtime_seconds": float(time.perf_counter() - started),
    }
    manifest_path = output_dir / "task_manifest.json"
    atomic_json(manifest_path, manifest)
    bundle_path = output_dir / "task_bundle.zip"
    deterministic_zip(bundle_path, [*artifact_paths, manifest_path], output_dir)
    success = {
        "schema_version": "1.0",
        "stage": "P1_03",
        "task_id": evaluation_task_id,
        "outcome": args.outcome,
        "mode": args.mode,
        "status": (
            "SMOKE_SUCCESS"
            if args.smoke
            else "SESSION_SUCCESS_AWAITING_IMPORT"
            if remote_import_pending
            else "SUCCESS"
        ),
        "release_eligible": formal_release_eligible,
        "manifest": manifest_path.name,
        "manifest_sha256": sha256_file(manifest_path),
        "bundle": bundle_path.name,
        "bundle_sha256": sha256_file(bundle_path),
        "input_hashes": input_hashes,
        "artifact_hashes": artifact_hashes,
    }
    marker_name = "_SESSION_SUCCESS.json" if remote_import_pending else "_SUCCESS.json"
    atomic_json(output_dir / marker_name, success)
    return success


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run one immutable EMT P1 v2 Stage2a outcome evaluation task"
    )
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--coverage", type=Path, required=True)
    parser.add_argument("--stage1a", type=Path, required=True)
    parser.add_argument("--stage1a-manifest", type=Path)
    parser.add_argument("--fold-map", type=Path, required=True)
    parser.add_argument("--fold-map-sha256")
    parser.add_argument("--access-log", type=Path, required=True)
    parser.add_argument("--upstream-completion", type=Path, required=True)
    parser.add_argument("--base-model-canary", type=Path, required=True)
    parser.add_argument("--shap-model-selection", type=Path, required=True)
    parser.add_argument("--shap-values", type=Path, required=True)
    parser.add_argument("--shap-provenance", type=Path, required=True)
    parser.add_argument("--launch-authorization", type=Path, required=True)
    parser.add_argument("--shap-model", choices=sorted(TREE_SHAP_MODELS), default="xgboost")
    parser.add_argument("--shap-cases-per-type", type=int, default=3)
    parser.add_argument("--shap-max-features", type=int, default=20)
    parser.add_argument("--registry", type=Path, default=DEFAULT_REGISTRY)
    parser.add_argument("--registry-sha256")
    parser.add_argument("--outcome", choices=OUTCOMES, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--mode", choices=("core", "final_refresh"), default="core")
    parser.add_argument("--bootstrap-b", type=int, default=2000)
    parser.add_argument("--comparison-bootstrap-b", type=int)
    parser.add_argument("--seed", type=int, default=20260710)
    parser.add_argument("--calibration-grid-points", type=int, default=25)
    parser.add_argument("--dca-min", type=float, default=0.01)
    parser.add_argument("--dca-max", type=float, default=0.15)
    parser.add_argument("--dca-step", type=float, default=0.005)
    parser.add_argument(
        "--execution-target",
        choices=("local", "kaggle_cpu", "kaggle_gpu"),
        default="local",
    )
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args(argv)
    if args.comparison_bootstrap_b is None:
        args.comparison_bootstrap_b = args.bootstrap_b
    if args.calibration_grid_points < 3:
        parser.error("--calibration-grid-points must be at least 3")
    if args.shap_cases_per_type < 1 or args.shap_max_features < 1:
        parser.error("SHAP case and feature counts must be positive")
    if not 0 < args.dca_min <= args.dca_max < 1 or args.dca_step <= 0:
        parser.error("DCA thresholds must satisfy 0 < min <= max < 1 and step > 0")
    count = int(math.floor((args.dca_max - args.dca_min) / args.dca_step + 1e-9)) + 1
    args.dca_thresholds = np.round(args.dca_min + np.arange(count) * args.dca_step, 12)
    return args


def main() -> None:
    result = run(parse_args())
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
