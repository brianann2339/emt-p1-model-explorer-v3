from __future__ import annotations

import argparse
import gc
import hashlib
import json
import os
import platform
import shutil
import socket
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from qa_v2 import contextual_security_scan as security_scan

try:
    from .p1_v2_score_recompute import (
        MODEL_OUTPUT_EXCLUDED_FEATURES as MODEL_OUTPUT_EXCLUDED_SCORE_FEATURES,
        passive_score_recompute_contract,
    )
except ImportError:
    from p1_v2_score_recompute import (
        MODEL_OUTPUT_EXCLUDED_FEATURES as MODEL_OUTPUT_EXCLUDED_SCORE_FEATURES,
        passive_score_recompute_contract,
    )

try:
    from .p1_v2_stage1a_lib import (
        SCORE_COMPONENTS,
        MODEL_OUTPUT_EXCLUDED_FEATURES as STRUCTURALLY_UNUSABLE_FEATURES,
        feature_imputation_block,
        feature_semantic_type,
        fit_feature_vocabulary,
        transform_feature_split,
    )
    from .run_stage1a import (
        ARRIVAL_TIME_DERIVED_ALLOWLIST,
        ARRIVAL_TIMESTAMP_SOURCES,
        ARRIVAL_VITAL_SOURCE_PATTERNS,
        CATEGORICAL_SOURCE_COLUMNS,
        HARD_FORBIDDEN_SOURCES,
        MULTI_HOT_SOURCE_COLUMNS,
        NUMERIC_SOURCE_COLUMNS,
        ROOT,
        TEXT_SOURCE_COLUMNS,
        assert_no_arrival_leakage,
        build_targets,
        ensure_allowed_sources,
        forbidden_feature_name,
        sha256_value,
        to_numeric_clean,
    )
except ImportError:
    from p1_v2_stage1a_lib import (
        SCORE_COMPONENTS,
        MODEL_OUTPUT_EXCLUDED_FEATURES as STRUCTURALLY_UNUSABLE_FEATURES,
        feature_imputation_block,
        feature_semantic_type,
        fit_feature_vocabulary,
        transform_feature_split,
    )
    from run_stage1a import (
        ARRIVAL_TIME_DERIVED_ALLOWLIST,
        ARRIVAL_TIMESTAMP_SOURCES,
        ARRIVAL_VITAL_SOURCE_PATTERNS,
        CATEGORICAL_SOURCE_COLUMNS,
        HARD_FORBIDDEN_SOURCES,
        MULTI_HOT_SOURCE_COLUMNS,
        NUMERIC_SOURCE_COLUMNS,
        ROOT,
        TEXT_SOURCE_COLUMNS,
        assert_no_arrival_leakage,
        build_targets,
        ensure_allowed_sources,
        forbidden_feature_name,
        sha256_value,
        to_numeric_clean,
    )


SOURCE_MANIFEST = (
    ROOT
    / "outputs"
    / "v2"
    / "source_seal"
    / "patient_disjoint_development"
    / "patient_disjoint_development_manifest.patient-disjoint-build-20260711T004800Z.json"
)
OUT_DIR = ROOT / "outputs" / "v2" / "stage1a"
EXPECTED_SOURCE_SHAPE = (360_564, 310)
EXPECTED_DEVELOPMENT_SHAPE = (287_646, 310)
EXPECTED_SOURCE_SHA256 = "F704D673E72A8A603653713B4B540825B976AF3A38F928A18377926236B006C5"
EXPECTED_PARTITION_MANIFEST_SHA256 = "9E359D54096939CCDEE59E5BFBAA8AD01652590BFBEE8EE8D7F5F0FA12D551FE"
EXPECTED_DEVELOPMENT_SHA256 = "33E7C29859AC3472BFC3A8CB8DBB7586E7E2398172A1767118E9E614E90D7270"
EXPECTED_BLOCKING_ATTESTATION_SHA256 = "845D93C97274EDB84B303879A20A49D77BDB783D037FEFF307B2B4475018E836"
EXPECTED_PRE_PURGE_COHORT_COUNTS = {"train_2020_2023": 26_745, "validation_2024": 7_504}
EXPECTED_COHORT_COUNTS = {"train_2020_2023": 24_784, "validation_2024": 7_504}
EXPECTED_EVENT_COUNTS = {
    "train_2020_2023": {
        "P1": 138,
        "P2": 1_701,
        "P3": 759,
        "S1": 460,
        "S2": 748,
        "S3": 7_664,
        "S4": 2_512,
        "S5": 385,
        "S6": 1_121,
    },
    "validation_2024": {
        "P1": 107,
        "P2": 609,
        "P3": 285,
        "S1": 191,
        "S2": 291,
        "S3": 2_144,
        "S4": 756,
        "S5": 104,
        "S6": 330,
    },
}
PATIENT_DISJOINT_TEMPORAL_CONTRACT = {
    "strategy": "preserve_all_2024_validation_purge_prior_patient_history",
    "group_source_column": "CHART_NO",
    "outcome_independent": True,
    "pre_purge_total_rows": 34_249,
    "post_purge_total_rows": 32_288,
    "purged_train_rows": 1_961,
    "overlap_groups_before_purge": 1_042,
    "overlap_groups_after_purge": 0,
}
TARGET_COLUMNS = ["y_P1", "y_P2", "y_P3", "y_S1", "y_S2", "y_S3", "y_S4", "y_S5", "y_S6"]
CORE_VITALS = ["prehosp_sbp", "prehosp_dbp", "prehosp_hr", "prehosp_rr", "prehosp_spo2", "prehosp_bt", "prehosp_gcs"]
MODEL_FEATURE_EXCLUSIONS = {
    **STRUCTURALLY_UNUSABLE_FEATURES,
    **{
        name: "duplicate_passive_score_alias_of_rSIG"
        for name in MODEL_OUTPUT_EXCLUDED_SCORE_FEATURES
    },
}
STAGE1A_REQUIRED_SOURCE_COLUMNS = tuple(
    dict.fromkeys(
        [
            "REG_DATE",
            "有EMT前置",
            "AGE",
            "ENCOUNTER_NO",
            "CHART_NO",
            "EMT_城市",
            "EMT_現場_收縮壓",
            "EMT_車上_收縮壓",
            "預後急診名稱",
            "預後住院名稱",
            "ENDO",
            "DISCHGE_DATE",
            "住院天數",
            "ICU天數",
            "PAT_NAME",
            "PAT_NAME.1",
            "EMT_患者姓名",
            "EMT_身分證號",
            "EMT_病歷號",
            "OP_ID",
            "OP_NAME",
            "DISPLAY_NAME",
            "EMT_發生地點",
            *NUMERIC_SOURCE_COLUMNS,
            *CATEGORICAL_SOURCE_COLUMNS,
            *MULTI_HOT_SOURCE_COLUMNS,
            *TEXT_SOURCE_COLUMNS,
            *ARRIVAL_TIMESTAMP_SOURCES,
            *security_scan.DIRECT_IDENTIFIER_SOURCE_COLUMNS,
        ]
    )
)


def file_sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest().upper()


def patient_disjoint_manifest_contract(manifest: dict[str, Any]) -> dict[str, Any]:
    required = {
        "contract_version": "p1-v2-patient-disjoint-development-partition/1",
        "role": "data_steward_partition_only",
        "status": "SUCCESS",
        "upload_forbidden": True,
        "historical_2025_exposure": True,
        "sealed_2025_artifact_created": False,
    }
    for key, expected in required.items():
        if manifest.get(key) != expected:
            raise AssertionError(f"partition manifest {key}={manifest.get(key)!r}; expected {expected!r}")
    source = manifest.get("source", {})
    if (source.get("rows"), source.get("columns")) != EXPECTED_SOURCE_SHAPE:
        raise AssertionError("partition source shape does not match the locked study contract")
    if str(source.get("sha256", "")).upper() != EXPECTED_SOURCE_SHA256:
        raise AssertionError("partition source SHA256 does not match the locked study contract")
    development = manifest.get("development_output", {})
    if (development.get("rows"), development.get("columns")) != EXPECTED_DEVELOPMENT_SHAPE:
        raise AssertionError("partition development shape does not match the locked study contract")
    if str(development.get("sha256", "")).upper() != EXPECTED_DEVELOPMENT_SHA256:
        raise AssertionError("partition development SHA256 does not match the locked study contract")
    if int(development.get("year_min", 9999)) < 2020 or int(development.get("year_max", 9999)) > 2024:
        raise AssertionError("partition development years must be within 2020-2024")
    attestation = manifest.get("blocking_attestation", {})
    if (
        str(attestation.get("sha256", "")).upper() != EXPECTED_BLOCKING_ATTESTATION_SHA256
        or attestation.get("status") != "BLOCKED_OVERLAP"
        or attestation.get("intersection_group_count") != 1_703
    ):
        raise AssertionError("blocking attestation does not match the locked overlap decision")
    verification = manifest.get("verification", {})
    if (
        verification.get("output_max_year_le_2024") is not True
        or verification.get("output_columns_preserved") is not True
        or verification.get("eligible_development_vs_2025_group_overlap") != 0
        or verification.get("independent_readback_recompute") != "PASS"
    ):
        raise AssertionError("partition verification/zero-overlap attestation is not PASS")
    expected = manifest.get("expected_post_stage1a", {})
    locked_expected_values = {
        "eligible_rows_before_dedup": 34_428,
        "dedup_removed_rows": 179,
        "pre_purge_split_counts": EXPECTED_PRE_PURGE_COHORT_COUNTS,
        "post_purge_split_counts": EXPECTED_COHORT_COUNTS,
        "purged_train_rows": 1_961,
        "overlap_groups_before_purge": 1_042,
        "overlap_groups_after_purge": 0,
        "retained_group_counts": {"train_2020_2023": 19_944, "validation_2024": 6_600},
        "event_counts": EXPECTED_EVENT_COUNTS,
    }
    for key, locked_value in locked_expected_values.items():
        if expected.get(key) != locked_value:
            raise AssertionError(f"partition expected_post_stage1a.{key} does not match the locked study contract")
    return {
        "expected_post_stage1a": expected,
        "development_output": development,
        "blocking_attestation": manifest.get("blocking_attestation", {}),
        "verification": verification,
    }


def load_source_seal(path: Path) -> tuple[dict[str, Any], Path]:
    if file_sha256(path) != EXPECTED_PARTITION_MANIFEST_SHA256:
        raise AssertionError("partition manifest SHA256 does not match the authorized immutable anchor")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    contract = patient_disjoint_manifest_contract(manifest)
    development = contract["development_output"]
    development_path = Path(development["path"]).resolve()
    expected_root = (ROOT / "outputs" / "v2" / "source_seal" / "patient_disjoint_development").resolve()
    if development_path.parent != expected_root:
        raise AssertionError("Stage1a accepts only the attested patient-disjoint development partition")
    actual_hash = file_sha256(development_path)
    if actual_hash != str(development["sha256"]).upper():
        raise AssertionError("development parquet SHA256 does not match partition manifest")
    attestation = contract["blocking_attestation"]
    attestation_path = Path(attestation.get("path", "")).resolve()
    if not attestation_path.is_file() or file_sha256(attestation_path) != str(attestation.get("sha256", "")).upper():
        raise AssertionError("blocking attestation hash mismatch")
    normalized = {
        "development_sha256": str(development["sha256"]).upper(),
        "development_rows": int(development["rows"]),
        "development_columns": int(development["columns"]),
        "upload_forbidden": True,
        "partition_manifest_sha256": file_sha256(path),
        "blocking_attestation_sha256": str(attestation["sha256"]).upper(),
        **contract,
    }
    return normalized, development_path


def _stage1a_archive_digest(output_dir: Path) -> str:
    manifest_path = output_dir / "stage1a_feature_manifest_v2.json"
    if not manifest_path.is_file():
        raise FileNotFoundError("active Stage1a manifest is missing; formal supersession is unsafe")
    return file_sha256(manifest_path)


def _write_fsynced_json(path: Path, value: Any) -> None:
    payload = json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8")
    with path.open("xb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())


def _promote_supersession_marker(staged_marker: Path, archive: Path) -> None:
    staged_marker.replace(archive / "_SUPERSEDED.json")


def promote_stage1a_output(staging: Path, output_dir: Path, *, overwrite: bool) -> Path | None:
    if not staging.is_dir():
        raise FileNotFoundError(f"validated Stage1a staging directory is missing: {staging}")
    if not output_dir.exists():
        staging.replace(output_dir)
        return None
    if not overwrite:
        raise FileExistsError(f"output directory already exists: {output_dir}; pass --overwrite to supersede it")

    old_digest = _stage1a_archive_digest(output_dir)
    replacement_manifest = staging / "stage1a_feature_manifest_v2.json"
    if not replacement_manifest.is_file():
        raise FileNotFoundError("validated Stage1a staging manifest is missing")
    replacement_digest = file_sha256(replacement_manifest)
    archive_root = output_dir.parent / "superseded"
    archive_root.mkdir(parents=True, exist_ok=True)
    archive = archive_root / f"{output_dir.name}.superseded.{old_digest.lower()}"
    if archive.exists():
        raise FileExistsError(f"immutable superseded Stage1a archive already exists: {archive}")
    marker_staging = archive_root / f".stage1a-supersession-{uuid.uuid4().hex}.json"
    _write_fsynced_json(
        marker_staging,
        {
            "status": "superseded",
            "reason": "P1_v2_formal_rebuild",
            "superseded_at_utc": datetime.now(timezone.utc).isoformat(),
            "archived_stage1a_manifest_sha256": old_digest,
            "replacement_stage1a_manifest_sha256": replacement_digest,
        },
    )

    old_archived = False
    replacement_promoted = False
    try:
        output_dir.replace(archive)
        old_archived = True
        staging.replace(output_dir)
        replacement_promoted = True
        _promote_supersession_marker(marker_staging, archive)
    except Exception:
        if replacement_promoted and output_dir.exists():
            output_dir.replace(staging)
        if old_archived and archive.exists():
            archive.replace(output_dir)
        if marker_staging.exists():
            marker_staging.unlink()
        raise
    return archive


def _prepare_development_cohort(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    has_emt = df["有EMT前置"].eq(True)
    age = to_numeric_clean(df["AGE"])
    cohort = df.loc[has_emt & age.ge(18)].copy()
    allowed = ensure_allowed_sources(
        cohort,
        NUMERIC_SOURCE_COLUMNS + CATEGORICAL_SOURCE_COLUMNS + MULTI_HOT_SOURCE_COLUMNS + TEXT_SOURCE_COLUMNS,
    )
    cohort["__emt_completeness_score"] = cohort[allowed].notna().sum(axis=1)
    before_dedup = len(cohort)
    cohort = (
        cohort.sort_values(["ENCOUNTER_NO", "__emt_completeness_score"], ascending=[True, False], na_position="last")
        .drop_duplicates(subset=["ENCOUNTER_NO"], keep="first")
        .sort_index()
    )
    return cohort, before_dedup - len(cohort)


def _development_projection_columns(available_columns: list[str]) -> list[str]:
    available = set(available_columns)
    missing = sorted(set(STAGE1A_REQUIRED_SOURCE_COLUMNS) - available)
    if missing:
        raise AssertionError(f"development partition lacks required Stage1a source columns: {missing}")
    required = set(STAGE1A_REQUIRED_SOURCE_COLUMNS)
    return [name for name in available_columns if name in required]


def _read_development_projection(
    development_path: Path,
    expected_shape: tuple[int, int],
) -> tuple[pd.DataFrame, list[str]]:
    import pyarrow.parquet as pq

    parquet = pq.ParquetFile(development_path)
    physical_shape = (parquet.metadata.num_rows, parquet.metadata.num_columns)
    if physical_shape != expected_shape:
        raise AssertionError(
            f"development parquet physical shape is {physical_shape}, expected {expected_shape}"
        )
    projection = _development_projection_columns(parquet.schema_arrow.names)
    development = pd.read_parquet(development_path, columns=projection)
    if development.shape != (expected_shape[0], len(projection)):
        raise AssertionError("development projection readback shape differs from Parquet metadata")
    return development, projection


def _chart_group_hash(cohort: pd.DataFrame) -> pd.Series:
    return cohort["CHART_NO"].map(sha256_value)


def _temporal_patient_disjoint_split(
    cohort: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    train = cohort.loc[cohort["__reg_year"].between(2020, 2023)].copy()
    validation = cohort.loc[cohort["__reg_year"].eq(2024)].copy()
    train_groups = _chart_group_hash(train)
    validation_groups = _chart_group_hash(validation)
    overlap_groups = (
        set(train_groups.loc[train_groups.ne("")])
        & set(validation_groups.loc[validation_groups.ne("")])
    )
    purge_mask = train_groups.isin(overlap_groups)
    train = train.loc[~purge_mask].copy()
    post_train_groups = _chart_group_hash(train)
    post_overlap = (
        set(post_train_groups.loc[post_train_groups.ne("")])
        & set(validation_groups.loc[validation_groups.ne("")])
    )
    details = {
        "strategy": PATIENT_DISJOINT_TEMPORAL_CONTRACT["strategy"],
        "group_source_column": PATIENT_DISJOINT_TEMPORAL_CONTRACT["group_source_column"],
        "outcome_independent": True,
        "pre_purge_split_counts": {
            "train_2020_2023": int(len(train) + purge_mask.sum()),
            "validation_2024": int(len(validation)),
        },
        "post_purge_split_counts": {
            "train_2020_2023": int(len(train)),
            "validation_2024": int(len(validation)),
        },
        "pre_purge_total_rows": int(len(train) + purge_mask.sum() + len(validation)),
        "post_purge_total_rows": int(len(train) + len(validation)),
        "purged_train_rows": int(purge_mask.sum()),
        "overlap_groups_before_purge": int(len(overlap_groups)),
        "overlap_groups_after_purge": int(len(post_overlap)),
    }
    return train, validation, details


def _metadata(cohort: pd.DataFrame) -> pd.DataFrame:
    metadata = pd.DataFrame(index=cohort.index)
    encounter_hash = cohort["ENCOUNTER_NO"].map(sha256_value)
    metadata["row_hash"] = encounter_hash.where(encounter_hash.ne(""), cohort.index.map(sha256_value))
    metadata["group_hash"] = _chart_group_hash(cohort)
    metadata["split_year"] = cohort["__reg_year"].astype("Int64")
    metadata["split"] = cohort["__split"]
    city = cohort.get("EMT_城市", pd.Series("UNKNOWN", index=cohort.index)).astype("string").fillna("").str.strip()
    metadata["city"] = city.mask(city.eq(""), "UNKNOWN")
    return metadata


def _build_part(
    cohort: pd.DataFrame,
    vocabulary: dict[str, Any],
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, list[str]]]:
    metadata = _metadata(cohort)
    targets = build_targets(cohort)
    features, text, source_map = transform_feature_split(cohort, vocabulary)
    text["row_hash"] = metadata["row_hash"].values
    text["split_year"] = metadata["split_year"].values
    text["split"] = metadata["split"].values
    full = pd.concat([metadata, targets, features], axis=1).reset_index(drop=True)
    return full, text.reset_index(drop=True), source_map


def _long_missingness_by_group(full: pd.DataFrame, feature_cols: list[str], group_cols: list[str]) -> pd.DataFrame:
    records: list[pd.DataFrame] = []
    grouped = full.groupby(group_cols, dropna=False, observed=True)
    for group_key, group in grouped:
        key_values = group_key if isinstance(group_key, tuple) else (group_key,)
        missing = group[feature_cols].isna().sum()
        frame = pd.DataFrame(
            {
                "feature": feature_cols,
                "n": len(group),
                "missing_n": missing.to_numpy(),
                "missing_rate": (missing / len(group)).to_numpy(),
            }
        )
        for column, value in zip(group_cols, key_values):
            frame[column] = value
        records.append(frame[group_cols + ["feature", "n", "missing_n", "missing_rate"]])
    return pd.concat(records, ignore_index=True) if records else pd.DataFrame(columns=group_cols + ["feature", "n", "missing_n", "missing_rate"])


def _missingness_by_outcome(full: pd.DataFrame, feature_cols: list[str]) -> pd.DataFrame:
    records: list[pd.DataFrame] = []
    for outcome in TARGET_COLUMNS:
        frame = _long_missingness_by_group(full, feature_cols, ["split_year", outcome]).rename(columns={outcome: "outcome_value"})
        frame.insert(1, "outcome", outcome)
        records.append(frame)
    return pd.concat(records, ignore_index=True)


def _reason_counts(full: pd.DataFrame, feature_cols: list[str]) -> pd.DataFrame:
    reason_cols = [
        name
        for name in feature_cols
        if name.startswith("MISSREASON_")
        or name.endswith("_unmeasurable")
        or name.endswith("__source_missing")
        or name.endswith("__explicit_none")
    ]
    records = []
    for year, group in full.groupby("split_year", observed=True):
        counts = group[reason_cols].sum(axis=0)
        for indicator, count in counts.items():
            records.append({"split_year": int(year), "reason_indicator": indicator, "count": int(count), "rate": float(count / len(group))})
    return pd.DataFrame(records)


def _pattern_frequency(full: pd.DataFrame) -> pd.DataFrame:
    pattern_cols = CORE_VITALS + list(SCORE_COMPONENTS)
    missing = full[pattern_cols].isna()
    patterns = missing.apply(lambda row: "|".join(row.index[row].tolist()) or "<complete>", axis=1)
    frame = pd.DataFrame({"split_year": full["split_year"], "missing_pattern": patterns})
    result = frame.value_counts(sort=True).rename("count").reset_index()
    denominators = frame.groupby("split_year").size()
    result["rate"] = result.apply(lambda row: row["count"] / denominators.loc[row["split_year"]], axis=1)
    return result


def _score_coverage(full: pd.DataFrame) -> pd.DataFrame:
    records = []
    for year, group in full.groupby("split_year", observed=True):
        for score, components in SCORE_COMPONENTS.items():
            records.append(
                {
                    "split_year": int(year),
                    "score": score,
                    "required_components": len(components),
                    "rows": len(group),
                    "available_n": int(group[f"{score}_available"].sum()),
                    "available_rate": float(group[f"{score}_available"].mean()),
                    "mean_observed_components": float(group[f"{score}_observed_components"].mean()),
                }
            )
    return pd.DataFrame(records)


def _complete_case_flow(full: pd.DataFrame, feature_cols: list[str]) -> pd.DataFrame:
    value_features = [
        name
        for name in feature_cols
        if feature_semantic_type(name) in {"continuous_or_ordinal", "clinical_score"}
        and name not in MODEL_FEATURE_EXCLUSIONS
    ]
    records = []
    for split, group in full.groupby("split", observed=True):
        masks = {
            "eligible_development_cohort": pd.Series(True, index=group.index),
            "core_vitals_complete": group[CORE_VITALS].notna().all(axis=1),
            "all_continuous_and_scores_complete": group[value_features].notna().all(axis=1),
        }
        for outcome in TARGET_COLUMNS:
            for step, mask in masks.items():
                records.append(
                    {
                        "split": split,
                        "outcome": outcome,
                        "step": step,
                        "rows": int(mask.sum()),
                        "events": int(group.loc[mask, outcome].sum()),
                        "retained_rate": float(mask.mean()),
                    }
                )
    return pd.DataFrame(records)


def _schema_records(full: pd.DataFrame, feature_cols: list[str], source_map: dict[str, list[str]]) -> list[dict[str, Any]]:
    records = []
    for name in feature_cols:
        semantic = feature_semantic_type(name)
        if semantic in {"continuous_or_ordinal", "clinical_score"}:
            primary = "fold_local_median_plus_indicator"
        elif semantic == "binary_indicator":
            primary = "none_binary_complete"
        else:
            primary = "none_preserve_missingness_semantics"
        records.append(
            {
                "name": name,
                "dtype": str(full[name].dtype),
                "nullable": bool(full[name].isna().any()),
                "semantic_type": semantic,
                "imputation_block": feature_imputation_block(name),
                "source_columns": source_map[name],
                "stage1a_imputation": "none",
                "stage1b_primary_handling": primary,
                "model_feature": name not in MODEL_FEATURE_EXCLUSIONS,
                "model_feature_exclusion_reason": MODEL_FEATURE_EXCLUSIONS.get(name),
                "structurally_unusable": name in STRUCTURALLY_UNUSABLE_FEATURES,
            }
        )
    return records


def _hardware_record() -> dict[str, Any]:
    record: dict[str, Any] = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "hostname": socket.gethostname(),
        "logical_cpu_count": os.cpu_count(),
    }
    try:
        import psutil

        memory = psutil.virtual_memory()
        record["ram_total_bytes"] = int(memory.total)
        record["ram_available_bytes_at_start"] = int(memory.available)
    except ImportError:
        record["ram_total_bytes"] = None
        record["ram_available_bytes_at_start"] = None
    try:
        import torch

        record["torch_version"] = torch.__version__
        record["cuda_available"] = bool(torch.cuda.is_available())
        record["cuda_device_count"] = int(torch.cuda.device_count()) if torch.cuda.is_available() else 0
        record["cuda_devices"] = [torch.cuda.get_device_name(index) for index in range(record["cuda_device_count"])]
    except ImportError:
        record["torch_version"] = None
        record["cuda_available"] = False
        record["cuda_device_count"] = 0
        record["cuda_devices"] = []
    return record


def _write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def build_stage1a_v2(source_manifest_path: Path, output_dir: Path, min_count: int = 20) -> dict[str, Any]:
    source_seal, development_path = load_source_seal(source_manifest_path)
    expected_development_shape = (
        source_seal["development_rows"],
        source_seal["development_columns"],
    )
    development, development_projection = _read_development_projection(
        development_path,
        expected_development_shape,
    )
    development["__reg_year"] = pd.to_datetime(development["REG_DATE"], errors="coerce").dt.year
    if development["__reg_year"].isna().any():
        raise AssertionError("development partition has missing REG_DATE year")
    future_rows = int(development["__reg_year"].ge(2025).sum())
    if future_rows:
        raise AssertionError(f"development partition contains {future_rows} rows from 2025 or later")
    if set(development["__reg_year"].astype(int).unique()) != {2020, 2021, 2022, 2023, 2024}:
        raise AssertionError("development partition years are not exactly 2020-2024")

    cohort, dedup_removed = _prepare_development_cohort(development)
    del development
    gc.collect()
    train, validation, temporal_split = _temporal_patient_disjoint_split(cohort)
    train["__split"] = "train_2020_2023"
    validation["__split"] = "validation_2024"
    encounter_overlap = set(train["ENCOUNTER_NO"].dropna()) & set(validation["ENCOUNTER_NO"].dropna())
    if encounter_overlap:
        raise AssertionError(f"encounter overlap across temporal splits: {len(encounter_overlap)}")
    actual_counts = {"train_2020_2023": len(train), "validation_2024": len(validation)}
    partition_expectation = source_seal["expected_post_stage1a"]
    expected_pre_counts = partition_expectation["pre_purge_split_counts"]
    expected_counts = partition_expectation["post_purge_split_counts"]
    if actual_counts != expected_counts:
        raise AssertionError(f"cohort key set changed: {actual_counts}; expected {expected_counts}")
    if dedup_removed != int(partition_expectation["dedup_removed_rows"]):
        raise AssertionError(
            f"dedup removed {dedup_removed}; expected {partition_expectation['dedup_removed_rows']}"
        )
    expected_temporal_split = {
        "strategy": PATIENT_DISJOINT_TEMPORAL_CONTRACT["strategy"],
        "group_source_column": PATIENT_DISJOINT_TEMPORAL_CONTRACT["group_source_column"],
        "outcome_independent": True,
        "pre_purge_split_counts": expected_pre_counts,
        "post_purge_split_counts": expected_counts,
        "pre_purge_total_rows": int(sum(expected_pre_counts.values())),
        "post_purge_total_rows": int(sum(expected_counts.values())),
        "purged_train_rows": int(partition_expectation["purged_train_rows"]),
        "overlap_groups_before_purge": int(partition_expectation["overlap_groups_before_purge"]),
        "overlap_groups_after_purge": int(partition_expectation["overlap_groups_after_purge"]),
    }
    if temporal_split != expected_temporal_split:
        raise AssertionError(
            f"patient-disjoint temporal split changed: {temporal_split}; expected {expected_temporal_split}"
        )

    vocabulary = fit_feature_vocabulary(train, min_count=min_count)
    train_full, train_text, train_source_map = _build_part(train, vocabulary)
    validation_full, validation_text, validation_source_map = _build_part(validation, vocabulary)
    if train_source_map != validation_source_map:
        raise AssertionError("train and validation feature source maps differ")
    if train_full.columns.tolist() != validation_full.columns.tolist():
        raise AssertionError("train and validation schemas differ")
    full = pd.concat([train_full, validation_full], ignore_index=True)
    text = pd.concat([train_text, validation_text], ignore_index=True)
    feature_cols = [name for name in train_source_map]
    source_map = train_source_map
    partition_provenance = {
        "partition_manifest_sha256": source_seal["partition_manifest_sha256"],
        "development_output_sha256": source_seal["development_sha256"],
        "blocking_attestation_sha256": source_seal["blocking_attestation_sha256"],
        "eligible_development_vs_2025_group_overlap": source_seal["verification"][
            "eligible_development_vs_2025_group_overlap"
        ],
        "expected_post_stage1a": partition_expectation,
    }

    expected_event_counts = partition_expectation.get("event_counts", {})
    for split, group in full.groupby("split", observed=True):
        actual_events = {outcome.removeprefix("y_"): int(group[outcome].sum()) for outcome in TARGET_COLUMNS}
        if actual_events != expected_event_counts.get(split):
            raise AssertionError(
                f"{split} event counts changed: {actual_events}; expected {expected_event_counts.get(split)}"
            )

    bad_names = assert_no_arrival_leakage(feature_cols)
    all_sources = set().union(*source_map.values())
    hard_forbidden_intersection = sorted((all_sources & HARD_FORBIDDEN_SOURCES) - ARRIVAL_TIMESTAMP_SOURCES)
    forbidden_source_hits = [
        source
        for source in sorted(all_sources)
        if (forbidden_feature_name(source) and source not in ARRIVAL_TIMESTAMP_SOURCES)
        or any(pattern in source for pattern in ARRIVAL_VITAL_SOURCE_PATTERNS)
    ]
    direct_id_remaining = [
        name
        for name in security_scan.DIRECT_IDENTIFIER_SOURCE_COLUMNS
        if name in full.columns or name in text.columns
    ]
    if bad_names or hard_forbidden_intersection or forbidden_source_hits or direct_id_remaining:
        raise AssertionError(
            f"leakage gate failed: features={bad_names[:5]}, forbidden={hard_forbidden_intersection[:5]}, "
            f"sources={forbidden_source_hits[:5]}, identifiers={direct_id_remaining[:5]}"
        )
    if int(full["split_year"].ge(2025).sum()) or int(text["split_year"].ge(2025).sum()):
        raise AssertionError("2025 rows reached a Stage1a feature or text frame")
    if full["row_hash"].duplicated().any() or text["row_hash"].duplicated().any():
        raise AssertionError("duplicate row_hash in Stage1a output")
    if set(full["row_hash"]) != set(text["row_hash"]):
        raise AssertionError("feature and text row_hash sets differ")

    output_dir.mkdir(parents=True, exist_ok=False)
    manifests_dir = output_dir / "manifests"
    manifests_dir.mkdir()
    feature_path = output_dir / "stage1a_features_le2024.parquet"
    text_path = output_dir / "stage1a_text_le2024.parquet"
    source_map_path = output_dir / "stage1a_feature_source_map_v2.json"
    schema_path = output_dir / "stage1a_schema_v2.json"
    vocabulary_path = output_dir / "categorical_vocabulary_v2.json"
    contract_path = output_dir / "missingness_contract_v2.csv"
    by_year_path = output_dir / "missingness_by_year_v2.csv"
    by_city_path = output_dir / "missingness_by_city_v2.csv"
    by_outcome_path = output_dir / "missingness_by_outcome_v2.csv"
    reason_path = output_dir / "missingness_reason_counts_v2.csv"
    pattern_path = output_dir / "missingness_pattern_frequency_v2.csv"
    score_path = output_dir / "score_component_coverage_v2.csv"
    complete_case_path = output_dir / "complete_case_flow_v2.csv"
    structural_rules_path = output_dir / "missingness_structural_rules_v2.json"
    hardware_path = output_dir / "hardware_v2.json"

    full.to_parquet(feature_path, index=False)
    text.to_parquet(text_path, index=False)
    _write_json(source_map_path, source_map)
    _write_json(vocabulary_path, vocabulary)
    schema_records = _schema_records(full, feature_cols, source_map)
    schema = {
        "contract_version": "p1-v2-stage1a-schema-1",
        "metadata_columns": ["row_hash", "group_hash", "split_year", "split", "city"],
        "target_columns": TARGET_COLUMNS,
        "feature_count": len(feature_cols),
        "model_feature_count": sum(record["model_feature"] for record in schema_records),
        "model_output_excluded_features": MODEL_FEATURE_EXCLUSIONS,
        "structurally_unusable_features": sorted(STRUCTURALLY_UNUSABLE_FEATURES),
        "imputation_blocks": {
            "raw_continuous_or_ordinal": [
                record["name"]
                for record in schema_records
                if record["imputation_block"] == "raw_continuous_or_ordinal"
            ],
            "other": "all remaining model features",
        },
        "features": schema_records,
        "vocabulary_fit_years": vocabulary["fit_years"],
        "validation_transform_only": True,
        "patient_disjoint_temporal_split": temporal_split,
        "patient_disjoint_partition": partition_provenance,
        "passive_score_recompute": passive_score_recompute_contract(),
    }
    _write_json(schema_path, schema)
    contract_records = [
        {**record, "source_columns": json.dumps(record["source_columns"], ensure_ascii=False)}
        for record in schema_records
    ]
    pd.DataFrame(contract_records).to_csv(contract_path, index=False, encoding="utf-8-sig")
    _long_missingness_by_group(full, feature_cols, ["split_year"]).to_csv(by_year_path, index=False, encoding="utf-8-sig")
    _long_missingness_by_group(full, feature_cols, ["city"]).to_csv(by_city_path, index=False, encoding="utf-8-sig")
    _missingness_by_outcome(full, feature_cols).to_csv(by_outcome_path, index=False, encoding="utf-8-sig")
    _reason_counts(full, feature_cols).to_csv(reason_path, index=False, encoding="utf-8-sig")
    _pattern_frequency(full).to_csv(pattern_path, index=False, encoding="utf-8-sig")
    _score_coverage(full).to_csv(score_path, index=False, encoding="utf-8-sig")
    _complete_case_flow(full, feature_cols).to_csv(complete_case_path, index=False, encoding="utf-8-sig")
    _write_json(
        structural_rules_path,
        {
            "schema_version": "p1-v2-missingness-structural-rules/1",
            "structurally_unusable_features": sorted(STRUCTURALLY_UNUSABLE_FEATURES),
            "rules": [],
        },
    )
    _write_json(hardware_path, _hardware_record())

    common_hashes = {
        path.name: file_sha256(path)
        for path in [
            feature_path,
            text_path,
            source_map_path,
            schema_path,
            vocabulary_path,
            contract_path,
            structural_rules_path,
        ]
    }
    for outcome in TARGET_COLUMNS:
        outcome_manifest = {
            "contract_version": "p1-v2-stage1a-outcome-1",
            "stage": "P1_01_Stage1a_v2",
            "outcome": outcome,
            "historical_2025_exposure": True,
            "2025_access_count": 0,
            "development_source_sha256": source_seal["development_sha256"],
            "feature_schema_sha256": common_hashes[schema_path.name],
            "feature_source_map_sha256": common_hashes[source_map_path.name],
            "feature_artifact_sha256": common_hashes[feature_path.name],
            "patient_disjoint_temporal_split": temporal_split,
            "patient_disjoint_partition": partition_provenance,
            "split_summary": {
                split: {
                    "rows": int(len(group)),
                    "events": int(group[outcome].sum()),
                    "prevalence": float(group[outcome].mean()),
                }
                for split, group in full.groupby("split", observed=True)
            },
        }
        _write_json(manifests_dir / f"{outcome}.json", outcome_manifest)

    preliminary_paths = sorted(path for path in output_dir.rglob("*") if path.is_file())
    if any("2025" in path.name for path in preliminary_paths):
        raise AssertionError("Stage1a v2 created a forbidden 2025-named artifact")
    artifact_hashes = {str(path.relative_to(output_dir)).replace("\\", "/"): file_sha256(path) for path in preliminary_paths}
    hashes_path = output_dir / "artifact_hashes_v2.json"

    manifest = {
        "contract_version": "p1-v2-stage1a-1",
        "stage": "P1_01_Stage1a_v2",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_seal_manifest": str(source_manifest_path.resolve()),
        "source_seal_manifest_sha256": file_sha256(source_manifest_path),
        "development_source": str(development_path),
        "development_source_sha256": source_seal["development_sha256"],
        "raw_shape_verified_by_source_seal": list(EXPECTED_SOURCE_SHAPE),
        "development_shape": list(expected_development_shape),
        "development_projection_column_count": len(development_projection),
        "development_projection_columns_sha256": hashlib.sha256(
            json.dumps(development_projection, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        ).hexdigest(),
        "cohort_split_counts": actual_counts,
        "dedup_removed_rows_global_dev": dedup_removed,
        "encounter_overlap_across_splits": 0,
        "patient_disjoint_temporal_split": temporal_split,
        "patient_disjoint_partition": partition_provenance,
        "feature_count": len(feature_cols),
        "target_columns": TARGET_COLUMNS,
        "strict_no_arrival_leakage": True,
        "arrival_time_derived_allowlist": sorted(ARRIVAL_TIME_DERIVED_ALLOWLIST),
        "arrival_feature_assertions": {
            "arrival_feature_hits": len(bad_names),
            "raw_arrival_source_hits": len(forbidden_source_hits),
            "hard_forbidden_intersection": len(hard_forbidden_intersection),
            "direct_identifier_columns_in_outputs": len(direct_id_remaining),
        },
        "vocabulary": {
            "fit_years": vocabulary["fit_years"],
            "transform_only_years": [2024],
            "min_count": min_count,
            "source_specific_other_rare": True,
        },
        "missingness": {
            "stage1a_statistical_imputation": False,
            "primary_stage1b_strategy": "fold_local_component_median_then_passive_score_recompute_then_residual_undefined_score_median_plus_indicators",
            "score_component_completeness_required": list(SCORE_COMPONENTS),
            "contract": contract_path.name,
            "structural_rules": structural_rules_path.name,
            "structural_rules_sha256": common_hashes[structural_rules_path.name],
            "structural_rules_are_explicit_only": True,
        },
        "passive_score_recompute": passive_score_recompute_contract(),
        "holdout_policy": {
            "historical_2025_exposure": True,
            "2025_access_count": 0,
            "2025_feature_artifact_created": False,
            "2025_text_artifact_created": False,
            "development_source_upload_forbidden": bool(source_seal["upload_forbidden"]),
        },
        "artifacts": {
            "features_le2024": feature_path.name,
            "text_le2024": text_path.name,
            "feature_source_map": source_map_path.name,
            "schema": schema_path.name,
            "vocabulary": vocabulary_path.name,
            "missingness_structural_rules": structural_rules_path.name,
            "outcome_manifests": "manifests/*.json",
            "artifact_hashes": hashes_path.name,
        },
        "artifact_sha256": artifact_hashes,
        "code_sha256": {
            "run_stage1a_v2.py": file_sha256(Path(__file__)),
            "p1_v2_stage1a_lib.py": file_sha256(Path(__file__).with_name("p1_v2_stage1a_lib.py")),
            "p1_v2_score_recompute.py": file_sha256(Path(__file__).with_name("p1_v2_score_recompute.py")),
        },
    }
    manifest_path = output_dir / "stage1a_feature_manifest_v2.json"
    _write_json(manifest_path, manifest)
    final_hashes = {
        str(path.relative_to(output_dir)).replace("\\", "/"): file_sha256(path)
        for path in sorted(output_dir.rglob("*"))
        if path.is_file()
    }
    _write_json(hashes_path, final_hashes)
    if any("2025" in path.name for path in output_dir.rglob("*")):
        raise AssertionError("Stage1a v2 created a forbidden 2025-named artifact")
    return manifest


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-manifest", type=Path, default=SOURCE_MANIFEST)
    parser.add_argument("--output-dir", type=Path, default=OUT_DIR)
    parser.add_argument("--min-count", type=int, default=20)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = args.output_dir.resolve()
    if output_dir.exists() and not args.overwrite:
        raise FileExistsError(f"output directory already exists: {output_dir}; pass --overwrite to supersede it")
    staging = output_dir.parent / f".{output_dir.name}.staging-{uuid.uuid4().hex}"
    staging.parent.mkdir(parents=True, exist_ok=True)
    try:
        manifest = build_stage1a_v2(args.source_manifest.resolve(), staging, min_count=args.min_count)
        superseded_archive = promote_stage1a_output(staging, output_dir, overwrite=args.overwrite)
    except Exception:
        if staging.exists():
            shutil.rmtree(staging)
        raise
    print(
        json.dumps(
            {
                "decision": "PASS",
                "manifest": str(output_dir / "stage1a_feature_manifest_v2.json"),
                "feature_count": manifest["feature_count"],
                "2025_access_count": 0,
                "superseded_archive": str(superseded_archive) if superseded_archive else None,
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
