from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import sys
import time
import warnings
from importlib import metadata
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qa_v2 import contextual_security_scan as security_scan  # noqa: E402

try:
    from .p1_v2_score_recompute import (  # noqa: E402
        MODEL_OUTPUT_EXCLUDED_FEATURES,
        MODEL_OUTPUT_EXCLUDED_SCORE_ALIASES,
        PASSIVE_SCORE_VALUE_COLUMNS,
        PassiveScoreRecomputeTransformer,
        formula_equivalence_evidence,
        passive_score_recompute_contract,
        passive_score_spec_sha256,
    )
except ImportError:
    from p1_v2_score_recompute import (  # noqa: E402
        MODEL_OUTPUT_EXCLUDED_FEATURES,
        MODEL_OUTPUT_EXCLUDED_SCORE_ALIASES,
        PASSIVE_SCORE_VALUE_COLUMNS,
        PassiveScoreRecomputeTransformer,
        formula_equivalence_evidence,
        passive_score_recompute_contract,
        passive_score_spec_sha256,
    )


DEFAULT_STAGE1A_DIR = ROOT / "outputs" / "v2" / "stage1a"
DEFAULT_FOLD_MAP = ROOT / "qa_v2" / "fixed_group_folds_v2.parquet"
OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
SCORE_LABELS = (
    "NEWS2",
    "rSIG",
    "rSIG_Age",
    "SIA_G",
    "SI_G",
    "SI",
    "mSI",
    "aSI",
    "rSI",
    "rSI_sMS",
    "rSI_GCSM",
    "SIAVPU",
    "sMS",
    "qSOFA",
    "MEWS",
    "REMS",
    "RTS",
    "rSI_GCS_alias",
)
SCORE_SOURCE_MAP = {"rSI_GCS_alias": "rSIG"}
ML_MODELS = (
    "logistic_l1",
    "logistic_l2",
    "decision_tree",
    "random_forest",
    "svm_rbf",
    "balanced_random_forest",
    "knn_classifier",
    "xgboost",
    "lightgbm",
    "catboost",
)
GBDT_MODELS = {"xgboost", "lightgbm", "catboost"}
KNN_CLASSIFIER_GRID = tuple(
    {"n_neighbors": neighbors, "weights": weights, "p": 2}
    for neighbors in (11, 31, 63)
    for weights in ("uniform", "distance")
)
warnings.filterwarnings("ignore", message="'penalty' was deprecated", category=FutureWarning)
warnings.filterwarnings("ignore", message="X does not have valid feature names", category=UserWarning)

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_lines(values: list[str]) -> str:
    return hashlib.sha256(("\n".join(values) + "\n").encode("utf-8")).hexdigest()


def atomic_json(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def atomic_parquet(path: Path, frame: pd.DataFrame) -> None:
    temporary = path.with_suffix(".tmp.parquet")
    frame.to_parquet(temporary, index=False)
    temporary.replace(path)


def atomic_joblib(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    joblib.dump(value, temporary)
    temporary.replace(path)


def current_baseline_code_hashes() -> dict[str, str]:
    score_path = Path(__file__).with_name("p1_v2_score_recompute.py")
    return {
        Path(__file__).name: sha256_file(Path(__file__).resolve()),
        score_path.name: sha256_file(score_path),
    }


def validate_runtime_hash_expectations(
    input_hashes: dict[str, str],
    code_hashes: dict[str, str],
    scientific_hashes: dict[str, str] | None = None,
) -> None:
    values = [
        ("P1_EXPECTED_INPUT_HASHES", input_hashes),
        ("P1_EXPECTED_CODE_SHA256", code_hashes),
    ]
    if scientific_hashes is not None:
        values.append(("P1_EXPECTED_PASSIVE_SCORE_BINDING", scientific_hashes))
    for variable, actual in values:
        encoded = os.environ.get(variable)
        if encoded is None:
            continue
        expected = json.loads(encoded)
        if expected != actual:
            raise ValueError(f"{variable} mismatch: expected={expected} actual={actual}")


def validate_existing_success(
    output_dir: Path,
    task_id: str,
    *,
    expected_input_hashes: dict[str, str] | None = None,
    expected_code_hashes: dict[str, str] | None = None,
    expected_formula_sha256: str | None = None,
    expected_scientific_hashes: dict[str, str] | None = None,
) -> dict[str, Any] | None:
    success_path = output_dir / "_SUCCESS.json"
    if not success_path.exists():
        return None
    success = json.loads(success_path.read_text(encoding="utf-8"))
    if success.get("task_id") != task_id or success.get("status") != "SUCCESS":
        raise ValueError("existing _SUCCESS belongs to a different or incomplete task")
    manifest_path = output_dir / success.get("manifest", "")
    if not manifest_path.is_file() or sha256_file(manifest_path) != success.get("manifest_sha256"):
        raise ValueError("existing _SUCCESS manifest hash mismatch")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("task_id") != task_id or manifest.get("2025_access_count") != 0:
        raise ValueError("existing manifest task/holdout contract mismatch")
    if manifest.get("artifact_hashes") != success.get("artifact_hashes"):
        raise ValueError("existing success and manifest artifact hashes differ")
    if expected_input_hashes is not None and manifest.get("input_hashes") != expected_input_hashes:
        raise ValueError("existing manifest input hashes differ from current locked inputs")
    if expected_code_hashes is not None and manifest.get("code_sha256") != expected_code_hashes:
        raise ValueError("existing manifest code hashes differ from current runners")
    if expected_formula_sha256 is not None:
        actual_formula = manifest.get("passive_score_recompute", {}).get("formula_sha256")
        if actual_formula != expected_formula_sha256:
            raise ValueError("existing manifest score formula hash mismatch")
    if (
        expected_scientific_hashes is not None
        and manifest.get("scientific_hashes") != expected_scientific_hashes
    ):
        raise ValueError("existing manifest scientific hashes differ from current contract")
    for filename, expected_hash in success.get("artifact_hashes", {}).items():
        path = output_dir / filename
        if not path.is_file() or sha256_file(path) != expected_hash:
            raise ValueError(f"existing artifact hash mismatch: {filename}")
    return success


def passive_score_scientific_hashes(
    input_hashes: dict[str, str],
    code_hashes: dict[str, str],
    runner_name: str,
    evidence: dict[str, Any],
) -> dict[str, str]:
    return {
        "data_sha256": input_hashes["features"],
        "feature_schema_sha256": input_hashes["schema"],
        "stage1a_manifest_sha256": input_hashes["manifest"],
        "fold_sha256": input_hashes["fold_map"],
        "task_registry_sha256": os.environ.get(
            "P1_TASK_REGISTRY_SHA256", "LOCAL_UNBOUND"
        ),
        "registry_task_sha256": os.environ.get(
            "P1_REGISTRY_TASK_SHA256", "LOCAL_UNBOUND"
        ),
        "runner_sha256": code_hashes[runner_name],
        "score_module_sha256": code_hashes["p1_v2_score_recompute.py"],
        "score_formula_sha256": str(evidence["formula_sha256"]),
        "passive_score_spec_sha256": passive_score_spec_sha256(),
        "formula_equivalence_evidence_sha256": str(evidence["evidence_sha256"]),
    }


def _forbidden_input(path: Path) -> bool:
    folded_parts = [part.casefold() for part in path.resolve().parts]
    return any("source_seal" in part or "2025" in part for part in folded_parts)


def load_stage1a_inputs(
    stage1a_dir: Path,
    fold_map_path: Path,
    outcome: str,
    *,
    smoke: bool,
) -> tuple[pd.DataFrame, pd.DataFrame, list[str], dict[str, Any], dict[str, Any]]:
    stage1a_dir = stage1a_dir.resolve()
    fold_map_path = fold_map_path.resolve()
    if _forbidden_input(stage1a_dir) or _forbidden_input(fold_map_path):
        raise ValueError("P1_02 refuses source_seal and every 2025-named input path")
    feature_path = stage1a_dir / "stage1a_features_le2024.parquet"
    schema_path = stage1a_dir / "stage1a_schema_v2.json"
    manifest_path = stage1a_dir / "stage1a_feature_manifest_v2.json"
    for path in (feature_path, schema_path, manifest_path, fold_map_path):
        if not path.is_file():
            raise FileNotFoundError(path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("strict_no_arrival_leakage") is not True:
        raise ValueError("Stage1a strict_no_arrival_leakage is not true")
    holdout = manifest.get("holdout_policy", {})
    if holdout.get("2025_access_count") != 0 or holdout.get("2025_feature_artifact_created") is not False:
        raise ValueError("Stage1a manifest does not certify zero 2025 access/artifacts")
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    schema_features = schema.get("features", [])
    pipeline_only_score_inputs = set(MODEL_OUTPUT_EXCLUDED_SCORE_ALIASES)
    for name in pipeline_only_score_inputs:
        matches = [row for row in schema_features if row.get("name") == name]
        if len(matches) != 1 or matches[0].get("model_feature") is not False:
            raise ValueError(
                f"pipeline-only passive score alias is not explicitly excluded by Stage1a: {name}"
            )
    feature_cols = [
        row["name"]
        for row in schema_features
        if row.get("model_feature", True) or row.get("name") in pipeline_only_score_inputs
    ]
    if not feature_cols or len(feature_cols) != len(set(feature_cols)):
        raise ValueError("Stage1a schema has an empty or duplicate feature order")
    frame = pd.read_parquet(feature_path)
    required = {"row_hash", "group_hash", "split_year", "split", f"y_{outcome}", *feature_cols}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise ValueError(f"Stage1a feature artifact lacks required columns: {missing[:20]}")
    direct_hits = security_scan.pii_column_hits(frame.columns)
    if direct_hits:
        raise ValueError(f"direct identifiers in Stage1a input: {direct_hits}")
    years = pd.to_numeric(frame["split_year"], errors="coerce")
    if years.isna().any() or int(years.max()) >= 2025:
        raise ValueError("P1_02 refuses any row from 2025 or later")
    allowed_splits = {"train_2020_2023", "validation_2024"}
    if set(frame["split"].dropna().unique()) != allowed_splits:
        raise ValueError(f"unexpected Stage1a splits: {sorted(frame['split'].dropna().unique())}")
    if frame["row_hash"].duplicated().any():
        raise ValueError("duplicate row_hash in Stage1a input")
    train = frame.loc[frame["split"].eq("train_2020_2023")].copy()
    validation = frame.loc[frame["split"].eq("validation_2024")].copy()
    if not pd.to_numeric(train["split_year"], errors="raise").between(2020, 2023).all():
        raise ValueError("training split contains a non-2020-2023 row")
    if not pd.to_numeric(validation["split_year"], errors="raise").eq(2024).all():
        raise ValueError("validation split contains a non-2024 row")

    fold_map = pd.read_parquet(fold_map_path)
    if "split_year" in fold_map and pd.to_numeric(fold_map["split_year"], errors="coerce").ge(2025).any():
        raise ValueError("fold map contains a row from 2025 or later")
    fold_map = fold_map.loc[fold_map["outcome"].eq(outcome)].copy()
    required_fold = {"row_hash", "group_hash", "fold"}
    if required_fold - set(fold_map.columns):
        raise ValueError(f"fold map lacks columns: {sorted(required_fold - set(fold_map.columns))}")
    if fold_map.duplicated("row_hash").any():
        raise ValueError("duplicate row_hash in outcome fold map")
    if set(fold_map["row_hash"].astype(str)) != set(train["row_hash"].astype(str)):
        raise ValueError("fold map row keys do not exactly match Stage1a training keys")
    folds = [int(value) for value in sorted(pd.to_numeric(fold_map["fold"], errors="raise").astype(int).unique())]
    if folds != list(range(len(folds))) or len(folds) < 2 or (not smoke and len(folds) != 5):
        raise ValueError(f"invalid fixed folds: {folds}")
    if fold_map.groupby("group_hash")["fold"].nunique().max() != 1:
        raise ValueError("patient group spans fixed folds")
    train["row_hash"] = train["row_hash"].astype(str)
    train = train.merge(fold_map[["row_hash", "group_hash", "fold"]], on="row_hash", how="left", validate="one_to_one", suffixes=("", "_fold"))
    if train["fold"].isna().any():
        raise ValueError("unassigned training rows")
    original_group = train["group_hash"].astype("string")
    expected_group = original_group.mask(original_group.isna() | original_group.str.strip().eq(""), train["row_hash"]).astype(str)
    if not expected_group.eq(train["group_hash_fold"].astype(str)).all():
        raise ValueError("fold map group hashes differ from Stage1a")
    train = train.drop(columns=["group_hash_fold"])
    for column in feature_cols:
        train[column] = pd.to_numeric(train[column], errors="coerce")
        validation[column] = pd.to_numeric(validation[column], errors="coerce")
    input_hashes = {
        "features": sha256_file(feature_path),
        "schema": sha256_file(schema_path),
        "manifest": sha256_file(manifest_path),
        "fold_map": sha256_file(fold_map_path),
    }
    return train, validation, feature_cols, schema, {"manifest": manifest, "hashes": input_hashes, "folds": folds}


def class_ratio(y: np.ndarray) -> float:
    positives = int(np.sum(y == 1))
    negatives = int(np.sum(y == 0))
    return max(1.0, negatives / max(positives, 1))


def resolve_device(device: str) -> str:
    if device != "auto":
        return device
    try:
        import torch

        return "cuda" if torch.cuda.is_available() else "cpu"
    except ImportError:
        return "cpu"


def make_estimator(
    model_name: str,
    *,
    params: dict[str, Any] | None,
    seed: int,
    y: np.ndarray,
    smoke: bool,
    device: str,
) -> Any:
    params = dict(params or {})
    if model_name == "logistic_l1":
        return LogisticRegression(
            penalty="l1", solver="liblinear", C=float(params.pop("C", 1.0)), max_iter=2000,
            class_weight="balanced", random_state=seed, l1_ratio=1.0,
        )
    if model_name == "logistic_l2":
        return LogisticRegression(
            penalty="l2", solver="liblinear", C=float(params.pop("C", 1.0)), max_iter=2000,
            class_weight="balanced", random_state=seed, l1_ratio=0.0,
        )
    if model_name == "decision_tree":
        return DecisionTreeClassifier(
            max_depth=int(params.pop("max_depth", 6)), min_samples_leaf=int(params.pop("min_samples_leaf", 20)),
            class_weight="balanced", random_state=seed,
        )
    if model_name == "random_forest":
        return RandomForestClassifier(
            n_estimators=int(params.pop("n_estimators", 20 if smoke else 300)),
            min_samples_leaf=int(params.pop("min_samples_leaf", 10)), class_weight="balanced_subsample",
            n_jobs=1, random_state=seed, **params,
        )
    if model_name == "balanced_random_forest":
        from imblearn.ensemble import BalancedRandomForestClassifier

        return BalancedRandomForestClassifier(
            n_estimators=int(params.pop("n_estimators", 20 if smoke else 300)),
            min_samples_leaf=int(params.pop("min_samples_leaf", 10)), sampling_strategy="all",
            replacement=True, bootstrap=False, n_jobs=1, random_state=seed, **params,
        )
    if model_name == "svm_rbf":
        return SVC(
            kernel="rbf", C=float(params.pop("C", 1.0)), gamma=params.pop("gamma", "scale"),
            class_weight="balanced", probability=True, random_state=seed, **params,
        )
    if model_name == "knn_classifier":
        return KNeighborsClassifier(
            n_neighbors=int(params.pop("n_neighbors", 31)),
            weights=str(params.pop("weights", "distance")),
            p=int(params.pop("p", 2)),
            algorithm="brute",
            metric="minkowski",
            n_jobs=1,
            **params,
        )
    ratio = class_ratio(y)
    if model_name == "xgboost":
        from xgboost import XGBClassifier

        defaults = {
            "n_estimators": 10 if smoke else 250,
            "max_depth": 4,
            "learning_rate": 0.05,
            "subsample": 0.85,
            "colsample_bytree": 0.85,
            "scale_pos_weight": ratio,
        }
        defaults.update(params)
        if device == "cuda":
            defaults["device"] = "cuda"
        return XGBClassifier(
            objective="binary:logistic", eval_metric="logloss", tree_method="hist", n_jobs=1,
            random_state=seed, verbosity=0, **defaults,
        )
    if model_name == "lightgbm":
        from lightgbm import LGBMClassifier

        defaults = {
            "n_estimators": 10 if smoke else 250,
            "num_leaves": 31,
            "learning_rate": 0.05,
            "subsample": 0.85,
            "colsample_bytree": 0.85,
            "scale_pos_weight": ratio,
        }
        defaults.update(params)
        if device == "cuda":
            defaults["device_type"] = "gpu"
        return LGBMClassifier(
            objective="binary", random_state=seed, n_jobs=1, verbosity=-1, **defaults,
        )
    if model_name == "catboost":
        from catboost import CatBoostClassifier

        defaults = {
            "iterations": 10 if smoke else 250,
            "depth": 6,
            "learning_rate": 0.05,
            "scale_pos_weight": ratio,
        }
        defaults.update(params)
        if device == "cuda":
            defaults.update({"task_type": "GPU", "devices": "0"})
        return CatBoostClassifier(
            loss_function="Logloss", verbose=False, allow_writing_files=False, random_seed=seed,
            thread_count=1, **defaults,
        )
    raise ValueError(f"unsupported ML model: {model_name}")


def primary_pipeline(
    model_name: str,
    *,
    feature_cols: list[str],
    params: dict[str, Any] | None,
    seed: int,
    y: np.ndarray,
    smoke: bool,
    device: str,
) -> Pipeline:
    steps: list[tuple[str, Any]] = [
        (
            "imputer",
            PassiveScoreRecomputeTransformer(
                tuple(feature_cols),
                strategy="median",
                add_indicator=True,
            ),
        )
    ]
    if model_name in {"logistic_l1", "logistic_l2", "svm_rbf", "knn_classifier"}:
        steps.append(("scaler", StandardScaler()))
    steps.append(("model", make_estimator(model_name, params=params, seed=seed, y=y, smoke=smoke, device=device)))
    return Pipeline(steps)


def predict_probability(model: Any, frame: pd.DataFrame) -> np.ndarray:
    prediction = np.asarray(model.predict_proba(frame))
    if prediction.ndim == 2:
        prediction = prediction[:, 1]
    prediction = prediction.reshape(-1).astype(float)
    if not np.isfinite(prediction).all() or (prediction < 0).any() or (prediction > 1).any():
        raise ValueError("non-finite or out-of-range probability")
    return prediction


def transformed_feature_names(model: Pipeline, feature_cols: list[str]) -> list[str]:
    imputer = model.named_steps.get("imputer")
    if imputer is None:
        return feature_cols
    return [str(name) for name in imputer.get_feature_names_out(feature_cols)]


def model_feature_importance(
    model: Pipeline,
    feature_cols: list[str],
    model_name: str,
) -> pd.DataFrame:
    estimator = model.named_steps["model"]
    names = transformed_feature_names(model, feature_cols)
    if model_name == "logistic_l1":
        values = np.asarray(estimator.coef_).reshape(-1)
        importance_type = "signed_l1_coefficient"
    elif model_name in GBDT_MODELS:
        values = np.asarray(estimator.feature_importances_).reshape(-1)
        importance_type = "model_feature_importance"
    else:
        return pd.DataFrame(columns=["feature", "importance", "absolute_importance", "importance_type", "rank"])
    if len(names) != len(values):
        raise ValueError(f"importance feature mismatch: names={len(names)} values={len(values)}")
    frame = pd.DataFrame(
        {
            "feature": names,
            "importance": values.astype(float),
            "absolute_importance": np.abs(values.astype(float)),
            "importance_type": importance_type,
        }
    ).sort_values(["absolute_importance", "feature"], ascending=[False, True], kind="mergesort")
    frame["rank"] = np.arange(1, len(frame) + 1)
    return frame.reset_index(drop=True)


def xgboost_treeshap(
    model: Pipeline,
    validation: pd.DataFrame,
    feature_cols: list[str],
    outcome: str,
    *,
    maximum_rows: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    import shap

    if maximum_rows < 1:
        raise ValueError("TreeSHAP maximum rows must be positive")
    sample = (
        validation.sample(n=maximum_rows, random_state=seed)
        if len(validation) > maximum_rows
        else validation.copy()
    )
    sample = sample.sort_values("row_hash", kind="mergesort")
    transformed = np.asarray(model.named_steps["imputer"].transform(sample[feature_cols]), dtype=np.float32)
    names = transformed_feature_names(model, feature_cols)
    explainer = shap.TreeExplainer(model.named_steps["model"])
    values = explainer.shap_values(transformed)
    if isinstance(values, list):
        values = values[-1]
    values = np.asarray(values)
    if values.ndim == 3:
        values = values[:, :, -1]
    if values.shape != transformed.shape:
        raise ValueError(f"TreeSHAP shape mismatch: values={values.shape} features={transformed.shape}")
    long = pd.DataFrame(
        {
            "row_hash": np.repeat(sample["row_hash"].astype(str).to_numpy(), len(names)),
            "outcome": outcome,
            "model": "xgboost",
            "feature": np.tile(np.asarray(names, dtype=object), len(sample)),
            "feature_value": transformed.reshape(-1).astype(float),
            "shap_value": values.reshape(-1).astype(float),
            "split": "validation_2024",
        }
    )
    importance = (
        long.assign(absolute_shap=long["shap_value"].abs())
        .groupby(["outcome", "model", "feature"], as_index=False, observed=True)["absolute_shap"]
        .mean()
        .rename(columns={"absolute_shap": "mean_abs_shap"})
        .sort_values(["mean_abs_shap", "feature"], ascending=[False, True], kind="mergesort")
        .reset_index(drop=True)
    )
    importance["rank"] = np.arange(1, len(importance) + 1)
    return long, importance, {
        "method": "TreeSHAP",
        "split": "validation_2024",
        "sample_rows": int(len(sample)),
        "maximum_rows": int(maximum_rows),
        "sampling": "deterministic_random_without_replacement_then_row_hash_sort",
        "seed": int(seed),
    }


def write_baseline_canary(
    model_path: Path,
    output_dir: Path,
    validation: pd.DataFrame,
    validation_predictions: pd.DataFrame,
    feature_cols: list[str],
    *,
    outcome: str,
    model_name: str,
    saved_model_is_score_bundle: bool,
    training: pd.DataFrame | None = None,
    reference_model: Any = None,
) -> tuple[dict[str, Any], list[Path]]:
    available = validation_predictions.sort_values("row_hash", kind="mergesort").head(100).copy()
    source_split = "validation_2024"
    expected_generation = "emitted_saved_validation_predictions"
    if available.empty:
        if training is None or reference_model is None:
            raise ValueError("estimable task has no rows for reload canary")
        eligible = training.loc[
            training.loc[:, feature_cols].notna().all(axis=1)
        ].sort_values("row_hash", kind="mergesort").head(100)
        if eligible.empty:
            raise ValueError("estimable task has no complete training rows for reload canary")
        inputs = eligible.loc[:, ["row_hash", *feature_cols]].reset_index(drop=True)
        predictor = reference_model.get("final") if saved_model_is_score_bundle else reference_model
        expected = pd.DataFrame(
            {
                "row_hash": inputs["row_hash"].astype(str),
                "outcome": outcome,
                "model": model_name,
                "prediction": predict_probability(predictor, inputs[feature_cols]),
            }
        )
        source_split = "train_2020_2023_canary_only"
        expected_generation = "in_memory_final_model_training_fallback"
    else:
        keys = available["row_hash"].astype(str).tolist()
        indexed = validation.assign(row_hash=validation["row_hash"].astype(str)).set_index("row_hash", drop=False)
        inputs = indexed.loc[keys, ["row_hash", *feature_cols]].reset_index(drop=True)
        expected = available[["row_hash", "outcome", "model", "prediction"]].reset_index(drop=True)
    input_path = output_dir / "canary_inputs.parquet"
    expected_path = output_dir / "canary_expected.parquet"
    atomic_parquet(input_path, inputs)
    atomic_parquet(expected_path, expected)
    reloaded = joblib.load(model_path)
    if saved_model_is_score_bundle:
        reloaded = reloaded["final"]
    actual = predict_probability(reloaded, inputs[feature_cols])
    error = np.abs(actual - expected["prediction"].to_numpy(dtype=float))
    maximum_error = float(error.max())
    if maximum_error > 1e-5:
        raise ValueError(f"reload canary error {maximum_error} exceeds 1e-5")
    return {
        "status": "PASS",
        "rows": int(len(inputs)),
        "input_features": feature_cols,
        "input_feature_order_sha256": sha256_lines(feature_cols),
        "expected_model": model_name,
        "source_split": source_split,
        "expected_generation": expected_generation,
        "maximum_absolute_error": maximum_error,
        "tolerance": 1e-5,
        "inputs_artifact": input_path.name,
        "expected_artifact": expected_path.name,
    }, [input_path, expected_path]


def split_estimability(
    coverage: pd.DataFrame,
    train: pd.DataFrame,
    validation: pd.DataFrame,
    outcome: str,
) -> dict[str, dict[str, Any]]:
    target = f"y_{outcome}"
    label_lookup = pd.concat(
        [train[["row_hash", target]], validation[["row_hash", target]]],
        ignore_index=True,
    ).set_index("row_hash")[target]
    result = {}
    for split, group in coverage.groupby("split", observed=True):
        eligible_hashes = group.loc[group["eligible"].astype(bool), "row_hash"].astype(str)
        labels = label_lookup.loc[eligible_hashes].astype(int).to_numpy()
        result[str(split)] = {
            "eligible_rows": int(len(labels)),
            "events": int(labels.sum()) if len(labels) else 0,
            "class_count": int(len(np.unique(labels))) if len(labels) else 0,
            "status": (
                "ESTIMATED"
                if len(labels) and len(np.unique(labels)) == 2
                else "NOT_ESTIMABLE"
            ),
        }
    return result


def metric_rows(
    y: np.ndarray,
    prediction: np.ndarray,
    *,
    outcome: str,
    model: str,
    split: str,
) -> list[dict[str, Any]]:
    y = np.asarray(y, dtype=int)
    prediction = np.asarray(prediction, dtype=float)
    estimable = len(y) > 0 and len(np.unique(y)) == 2 and np.isfinite(prediction).all()
    functions = {"AUROC": roc_auc_score, "AUPRC": average_precision_score, "Brier": brier_score_loss}
    rows = []
    for name, function in functions.items():
        rows.append(
            {
                "outcome": outcome,
                "model": model,
                "split": split,
                "metric": name,
                "value": float(function(y, prediction)) if estimable else None,
                "status": "ESTIMATED" if estimable else "NOT_ESTIMABLE",
                "n": int(len(y)),
                "events": int(y.sum()),
                "lower_ci": None,
                "upper_ci": None,
            }
        )
    return rows


def stratified_sample_indices(y: np.ndarray, maximum: int, seed: int) -> np.ndarray:
    if len(y) <= maximum:
        return np.arange(len(y))
    rng = np.random.default_rng(seed)
    positives = np.where(y == 1)[0]
    negatives = np.where(y == 0)[0]
    positive_take = min(len(positives), max(20, int(maximum * len(positives) / len(y))))
    negative_take = maximum - positive_take
    selected = np.concatenate(
        [rng.choice(positives, positive_take, replace=False), rng.choice(negatives, negative_take, replace=False)]
    )
    rng.shuffle(selected)
    return selected


def select_knn_classifier_params(
    train: pd.DataFrame,
    feature_cols: list[str],
    outcome: str,
    *,
    seed: int,
    smoke: bool,
) -> tuple[dict[str, Any], pd.DataFrame, dict[str, Any]]:
    target = pd.to_numeric(train[f"y_{outcome}"], errors="raise").astype(int).to_numpy()
    folds = sorted(pd.to_numeric(train["fold"], errors="raise").astype(int).unique())
    minimum_training_rows = min(int(train["fold"].ne(fold).sum()) for fold in folds)
    grid = (
        (
            {"n_neighbors": 3, "weights": "uniform", "p": 2},
            {"n_neighbors": 5, "weights": "distance", "p": 2},
        )
        if smoke
        else KNN_CLASSIFIER_GRID
    )
    candidates = [row for row in grid if int(row["n_neighbors"]) <= minimum_training_rows]
    if not candidates:
        raise ValueError("KNN classifier grid has no valid neighbor count for the fixed folds")

    predictions = [np.full(len(train), np.nan, dtype=float) for _ in candidates]
    fold_scores: list[dict[str, float]] = [{} for _ in candidates]
    maximum_neighbors = max(int(row["n_neighbors"]) for row in candidates)
    for fold in folds:
        fit_mask = train["fold"].ne(fold).to_numpy()
        test_mask = ~fit_mask
        reference = primary_pipeline(
            "knn_classifier",
            feature_cols=feature_cols,
            params={"n_neighbors": maximum_neighbors, "weights": "uniform", "p": 2},
            seed=seed + int(fold),
            y=target[fit_mask],
            smoke=smoke,
            device="cpu",
        )
        reference.fit(train.loc[fit_mask, feature_cols], target[fit_mask])
        transformed = reference[:-1].transform(train.loc[test_mask, feature_cols])
        distances, indices = reference.named_steps["model"].kneighbors(
            transformed, n_neighbors=maximum_neighbors, return_distance=True
        )
        neighbor_labels = target[fit_mask][indices]
        for candidate_index, candidate in enumerate(candidates):
            neighbors = int(candidate["n_neighbors"])
            labels = neighbor_labels[:, :neighbors]
            if candidate["weights"] == "uniform":
                fold_prediction = labels.mean(axis=1)
            else:
                selected_distances = distances[:, :neighbors]
                with np.errstate(divide="ignore"):
                    weights = 1.0 / selected_distances
                exact = np.isinf(weights)
                exact_rows = exact.any(axis=1)
                weights[exact_rows] = exact[exact_rows].astype(float)
                fold_prediction = np.sum(labels * weights, axis=1) / np.sum(
                    weights, axis=1
                )
            predictions[candidate_index][test_mask] = fold_prediction
            fold_scores[candidate_index][str(int(fold))] = float(
                average_precision_score(target[test_mask], fold_prediction)
            )

    records = []
    for candidate_index, candidate in enumerate(candidates):
        prediction = predictions[candidate_index]
        if not np.isfinite(prediction).all():
            raise ValueError("KNN classifier selection did not cover every development row")
        records.append(
            {
                "candidate_id": int(candidate_index),
                "n_neighbors": int(candidate["n_neighbors"]),
                "weights": str(candidate["weights"]),
                "p": int(candidate["p"]),
                "oof_auprc": float(average_precision_score(target, prediction)),
                "fold_auprc_json": json.dumps(
                    fold_scores[candidate_index], sort_keys=True
                ),
                "development_rows": int(len(train)),
                "fixed_fold_count": int(len(folds)),
                "validation_2024_fit_rows": 0,
                "validation_2024_monitor_rows": 0,
                "2025_access_count": 0,
            }
        )
    results = pd.DataFrame(records).sort_values("candidate_id", kind="mergesort")
    selected = results.sort_values(
        ["oof_auprc", "n_neighbors", "weights", "candidate_id"],
        ascending=[False, True, True, True],
        kind="mergesort",
    ).iloc[0]
    params = {
        "n_neighbors": int(selected["n_neighbors"]),
        "weights": str(selected["weights"]),
        "p": int(selected["p"]),
    }
    selection = {
        "method": "locked_compact_grid",
        "selection_metric": "AUPRC",
        "selection_split": "fixed_group_oof_2020_2023",
        "candidate_count": int(len(results)),
        "formal_grid": [dict(row) for row in KNN_CLASSIFIER_GRID],
        "selected_candidate_id": int(selected["candidate_id"]),
        "selected_oof_auprc": float(selected["oof_auprc"]),
        "selected_params": params,
        "seed": int(seed),
        "validation_2024_used_for_fit": False,
        "validation_2024_used_for_monitoring": False,
        "2025_access_count": 0,
    }
    return params, results, selection


def fit_fixed_oof(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    feature_cols: list[str],
    outcome: str,
    model_name: str,
    *,
    params: dict[str, Any] | None,
    seed: int,
    smoke: bool,
    device: str,
    svm_max_train: int,
) -> tuple[Any, pd.DataFrame, pd.DataFrame, list[dict[str, Any]], list[dict[str, Any]]]:
    target = f"y_{outcome}"
    y_train = pd.to_numeric(train[target], errors="raise").astype(int).to_numpy()
    y_validation = pd.to_numeric(validation[target], errors="raise").astype(int).to_numpy()
    oof_parts = []
    sample_records = []
    for fold in sorted(train["fold"].astype(int).unique()):
        fit_mask = train["fold"].astype(int).ne(fold).to_numpy()
        test_mask = ~fit_mask
        fit_indices = np.where(fit_mask)[0]
        if model_name == "svm_rbf":
            sampled = stratified_sample_indices(y_train[fit_indices], svm_max_train, seed + fold)
            fit_indices = fit_indices[sampled]
        sample_records.append(
            {"fold": int(fold), "training_rows": int(len(fit_indices)), "training_events": int(y_train[fit_indices].sum())}
        )
        if len(np.unique(y_train[fit_indices])) != 2:
            raise ValueError(f"fold {fold} training data lacks one outcome class")
        pipeline = primary_pipeline(
            model_name,
            feature_cols=feature_cols,
            params=params,
            seed=seed + fold,
            y=y_train[fit_indices],
            smoke=smoke,
            device=device,
        )
        pipeline.fit(train.iloc[fit_indices][feature_cols], y_train[fit_indices])
        indices = np.where(test_mask)[0]
        prediction = predict_probability(pipeline, train.iloc[indices][feature_cols])
        oof_parts.append(
            pd.DataFrame(
                {
                    "row_hash": train.iloc[indices]["row_hash"].astype(str).to_numpy(),
                    "outcome": outcome,
                    "model": model_name,
                    "split": "oof_2020_2023",
                    "fold": pd.array([int(fold)] * len(indices), dtype="Int8"),
                    "prediction": prediction,
                }
            )
        )
    oof = pd.concat(oof_parts, ignore_index=True)
    if len(oof) != len(train) or oof["row_hash"].duplicated().any():
        raise ValueError("OOF predictions do not cover each training row exactly once")
    final_indices = np.arange(len(train))
    if model_name == "svm_rbf":
        final_indices = stratified_sample_indices(y_train, svm_max_train, seed + 999)
    final_model = primary_pipeline(
        model_name,
        feature_cols=feature_cols,
        params=params,
        seed=seed,
        y=y_train[final_indices],
        smoke=smoke,
        device=device,
    )
    final_model.fit(train.iloc[final_indices][feature_cols], y_train[final_indices])
    validation_prediction = predict_probability(final_model, validation[feature_cols])
    validation_long = pd.DataFrame(
        {
            "row_hash": validation["row_hash"].astype(str).to_numpy(),
            "outcome": outcome,
            "model": model_name,
            "split": "validation_2024",
            "fold": pd.array([pd.NA] * len(validation), dtype="Int8"),
            "prediction": validation_prediction,
        }
    )
    keyed_y = train.set_index("row_hash")[target]
    oof_y = keyed_y.loc[oof["row_hash"]].astype(int).to_numpy()
    metrics = metric_rows(oof_y, oof["prediction"].to_numpy(), outcome=outcome, model=model_name, split="oof_2020_2023")
    metrics += metric_rows(y_validation, validation_prediction, outcome=outcome, model=model_name, split="validation_2024")
    return final_model, oof, validation_long, metrics, sample_records


def fit_score_task(
    train: pd.DataFrame,
    validation: pd.DataFrame,
    outcome: str,
    score: str,
    *,
    task_label: str,
    seed: int,
) -> tuple[Any, pd.DataFrame, pd.DataFrame, list[dict[str, Any]], pd.DataFrame]:
    target = f"y_{outcome}"
    output_model = f"score_{task_label}"

    def eligible(frame: pd.DataFrame) -> pd.Series:
        mask = pd.to_numeric(frame[score], errors="coerce").notna()
        available = f"{score}_available"
        if available in frame:
            mask &= pd.to_numeric(frame[available], errors="coerce").eq(1)
        return mask

    train_eligible = eligible(train)
    validation_eligible = eligible(validation)
    oof_parts = []
    models = {}
    for fold in sorted(train["fold"].astype(int).unique()):
        fit_mask = train["fold"].astype(int).ne(fold) & train_eligible
        test_mask = train["fold"].astype(int).eq(fold) & train_eligible
        y_fit = train.loc[fit_mask, target].astype(int).to_numpy()
        if len(np.unique(y_fit)) != 2:
            raise ValueError(f"eligible score training rows lack one class in fold {fold}")
        pipeline = Pipeline(
            [
                ("scaler", StandardScaler()),
                ("model", LogisticRegression(penalty="l2", solver="liblinear", class_weight="balanced", max_iter=1000, random_state=seed + fold, l1_ratio=0.0)),
            ]
        )
        pipeline.fit(train.loc[fit_mask, [score]], y_fit)
        prediction = predict_probability(pipeline, train.loc[test_mask, [score]])
        oof_parts.append(
            pd.DataFrame(
                {
                    "row_hash": train.loc[test_mask, "row_hash"].astype(str).to_numpy(),
                    "outcome": outcome,
                    "model": output_model,
                    "split": "oof_2020_2023",
                    "fold": pd.array([int(fold)] * int(test_mask.sum()), dtype="Int8"),
                    "prediction": prediction,
                }
            )
        )
        models[str(fold)] = pipeline
    final_y = train.loc[train_eligible, target].astype(int).to_numpy()
    if len(np.unique(final_y)) != 2:
        raise ValueError("eligible score training rows lack one outcome class")
    final_model = Pipeline(
        [
            ("scaler", StandardScaler()),
            ("model", LogisticRegression(penalty="l2", solver="liblinear", class_weight="balanced", max_iter=1000, random_state=seed, l1_ratio=0.0)),
        ]
    )
    final_model.fit(train.loc[train_eligible, [score]], final_y)
    models["final"] = final_model
    oof = pd.concat(oof_parts, ignore_index=True)
    validation_prediction = (
        predict_probability(final_model, validation.loc[validation_eligible, [score]])
        if validation_eligible.any()
        else np.array([], dtype=float)
    )
    validation_long = pd.DataFrame(
        {
            "row_hash": validation.loc[validation_eligible, "row_hash"].astype(str).to_numpy(),
            "outcome": outcome,
            "model": output_model,
            "split": "validation_2024",
            "fold": pd.array([pd.NA] * int(validation_eligible.sum()), dtype="Int8"),
            "prediction": validation_prediction,
        }
    )
    oof_y = train.set_index("row_hash").loc[oof["row_hash"], target].astype(int).to_numpy()
    validation_y = validation.loc[validation_eligible, target].astype(int).to_numpy()
    metrics = metric_rows(oof_y, oof["prediction"].to_numpy(), outcome=outcome, model=output_model, split="oof_2020_2023")
    metrics += metric_rows(validation_y, validation_prediction, outcome=outcome, model=output_model, split="validation_2024")
    coverage = pd.concat(
        [
            pd.DataFrame({"row_hash": train["row_hash"], "outcome": outcome, "model": output_model, "split": "oof_2020_2023", "eligible": train_eligible.to_numpy()}),
            pd.DataFrame({"row_hash": validation["row_hash"], "outcome": outcome, "model": output_model, "split": "validation_2024", "eligible": validation_eligible.to_numpy()}),
        ],
        ignore_index=True,
    )
    return models, oof, validation_long, metrics, coverage


def hpo_gbdt(
    model_name: str,
    train: pd.DataFrame,
    validation: pd.DataFrame,
    feature_cols: list[str],
    outcome: str,
    *,
    task_id: str,
    output_dir: Path,
    trials: int,
    seed: int,
    smoke: bool,
    device: str,
    binding_hashes: dict[str, str],
) -> tuple[dict[str, Any], pd.DataFrame, dict[str, Any]]:
    import optuna

    optuna.logging.set_verbosity(optuna.logging.WARNING)
    target = f"y_{outcome}"
    y_train = train[target].astype(int).to_numpy()
    y_validation = validation[target].astype(int).to_numpy()
    ratio_options = list(dict.fromkeys([1.0, 3.0, 10.0, 30.0, class_ratio(y_train)]))
    database = output_dir / "optuna.sqlite3"
    study_name = re.sub(r"[^A-Za-z0-9_.-]", "_", task_id)

    def objective(trial: optuna.Trial) -> float:
        if model_name == "xgboost":
            params = {
                "n_estimators": trial.suggest_int("n_estimators", 8 if smoke else 120, 16 if smoke else 500),
                "max_depth": trial.suggest_int("max_depth", 2, 6),
                "learning_rate": trial.suggest_float("learning_rate", 0.02, 0.2, log=True),
                "subsample": trial.suggest_float("subsample", 0.65, 1.0),
                "colsample_bytree": trial.suggest_float("colsample_bytree", 0.55, 1.0),
                "min_child_weight": trial.suggest_float("min_child_weight", 1.0, 20.0, log=True),
                "reg_lambda": trial.suggest_float("reg_lambda", 0.1, 30.0, log=True),
                "scale_pos_weight": trial.suggest_categorical("scale_pos_weight", ratio_options),
            }
        elif model_name == "lightgbm":
            params = {
                "n_estimators": trial.suggest_int("n_estimators", 8 if smoke else 120, 16 if smoke else 500),
                "num_leaves": trial.suggest_int("num_leaves", 8, 64),
                "max_depth": trial.suggest_int("max_depth", 2, 8),
                "learning_rate": trial.suggest_float("learning_rate", 0.02, 0.2, log=True),
                "subsample": trial.suggest_float("subsample", 0.65, 1.0),
                "colsample_bytree": trial.suggest_float("colsample_bytree", 0.55, 1.0),
                "min_child_samples": trial.suggest_int("min_child_samples", 5 if smoke else 20, 20 if smoke else 200),
                "reg_lambda": trial.suggest_float("reg_lambda", 0.1, 30.0, log=True),
                "scale_pos_weight": trial.suggest_categorical("scale_pos_weight", ratio_options),
            }
        else:
            params = {
                "iterations": trial.suggest_int("iterations", 8 if smoke else 120, 16 if smoke else 500),
                "depth": trial.suggest_int("depth", 3, 8),
                "learning_rate": trial.suggest_float("learning_rate", 0.02, 0.2, log=True),
                "l2_leaf_reg": trial.suggest_float("l2_leaf_reg", 1.0, 30.0, log=True),
                "scale_pos_weight": trial.suggest_categorical("scale_pos_weight", ratio_options),
            }
        pipeline = primary_pipeline(
            model_name,
            feature_cols=feature_cols,
            params=params,
            seed=seed + trial.number,
            y=y_train,
            smoke=smoke,
            device=device,
        )
        pipeline.fit(train[feature_cols], y_train)
        prediction = predict_probability(pipeline, validation[feature_cols])
        return float(average_precision_score(y_validation, prediction))

    storage_url = f"sqlite:///{database.as_posix()}"
    storage = optuna.storages.RDBStorage(storage_url)
    study = optuna.create_study(
        study_name=study_name,
        direction="maximize",
        storage=storage,
        load_if_exists=True,
        sampler=optuna.samplers.TPESampler(seed=seed),
    )
    existing_binding = study.user_attrs.get("p1_v2_binding_hashes")
    if existing_binding is None and study.trials:
        storage.remove_session()
        storage.engine.dispose()
        del study, storage
        raise ValueError("existing Optuna study lacks p1_v2 binding hashes")
    if existing_binding is not None and existing_binding != binding_hashes:
        message = (
            f"Optuna study binding hash mismatch: expected={binding_hashes} "
            f"actual={existing_binding}"
        )
        storage.remove_session()
        storage.engine.dispose()
        del study, storage
        raise ValueError(
            message
        )
    if existing_binding is None:
        study.set_user_attr("p1_v2_binding_hashes", binding_hashes)
    target_trials = 1 if smoke else int(trials)
    completed = sum(trial.state == optuna.trial.TrialState.COMPLETE for trial in study.trials)
    remaining = max(0, target_trials - completed)
    if remaining:
        study.optimize(objective, n_trials=remaining, show_progress_bar=False)
    completed = sum(trial.state == optuna.trial.TrialState.COMPLETE for trial in study.trials)
    if completed < target_trials:
        raise RuntimeError(f"Optuna has {completed}/{target_trials} completed trials")
    trials_frame = study.trials_dataframe()
    trials_frame = trials_frame.loc[
        trials_frame["state"].astype(str).eq("COMPLETE")
    ].reset_index(drop=True)
    best_params = dict(study.best_params)
    common_search_space = {
        "learning_rate": {"type": "float_log", "low": 0.02, "high": 0.2},
        "scale_pos_weight": {"type": "categorical", "choices": ratio_options},
    }
    if model_name == "xgboost":
        search_space = {
            "n_estimators": {"type": "int", "low": 8 if smoke else 120, "high": 16 if smoke else 500},
            "max_depth": {"type": "int", "low": 2, "high": 6},
            "subsample": {"type": "float", "low": 0.65, "high": 1.0},
            "colsample_bytree": {"type": "float", "low": 0.55, "high": 1.0},
            "min_child_weight": {"type": "float_log", "low": 1.0, "high": 20.0},
            "reg_lambda": {"type": "float_log", "low": 0.1, "high": 30.0},
            **common_search_space,
        }
    elif model_name == "lightgbm":
        search_space = {
            "n_estimators": {"type": "int", "low": 8 if smoke else 120, "high": 16 if smoke else 500},
            "num_leaves": {"type": "int", "low": 8, "high": 64},
            "max_depth": {"type": "int", "low": 2, "high": 8},
            "subsample": {"type": "float", "low": 0.65, "high": 1.0},
            "colsample_bytree": {"type": "float", "low": 0.55, "high": 1.0},
            "min_child_samples": {"type": "int", "low": 5 if smoke else 20, "high": 20 if smoke else 200},
            "reg_lambda": {"type": "float_log", "low": 0.1, "high": 30.0},
            **common_search_space,
        }
    else:
        search_space = {
            "iterations": {"type": "int", "low": 8 if smoke else 120, "high": 16 if smoke else 500},
            "depth": {"type": "int", "low": 3, "high": 8},
            "l2_leaf_reg": {"type": "float_log", "low": 1.0, "high": 30.0},
            **common_search_space,
        }
    hpo = {
        "engine": "Optuna TPE",
        "storage": database.name,
        "study_name": study_name,
        "target_trials": target_trials,
        "completed_trials": completed,
        "sampler": "TPESampler",
        "sampler_seed": seed,
        "search_space": search_space,
        "selection_split": "validation_2024",
        "selection_metric": "AUPRC",
        "uses_2025": False,
        "binding_hashes": binding_hashes,
    }
    storage.remove_session()
    storage.engine.dispose()
    return best_params, trials_frame, hpo


def package_versions() -> dict[str, str | None]:
    names = ("numpy", "pandas", "scikit-learn", "imbalanced-learn", "xgboost", "lightgbm", "catboost", "optuna", "joblib")
    result = {}
    for name in names:
        try:
            result[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            result[name] = None
    return result


def resolved_estimator_params(model: Any) -> dict[str, Any]:
    if isinstance(model, dict):
        model = model.get("final")
    if model is None or not hasattr(model, "get_params"):
        return {}
    resolved: dict[str, Any] = {}
    for name, value in model.get_params(deep=True).items():
        if isinstance(value, np.generic):
            value = value.item()
        if value is None or isinstance(value, (str, int, float, bool)):
            resolved[name] = value
        elif isinstance(value, (list, tuple)) and all(
            item is None or isinstance(item, (str, int, float, bool)) for item in value
        ):
            resolved[name] = list(value)
    return resolved


def validate_long_predictions(frame: pd.DataFrame) -> None:
    expected = ["task_id", "row_hash", "outcome", "model", "split", "fold", "y_true", "prediction"]
    if frame.columns.tolist() != expected:
        raise ValueError(f"prediction columns are not strict long schema: {frame.columns.tolist()}")
    if frame["task_id"].isna().any() or frame["task_id"].astype(str).str.strip().eq("").any():
        raise ValueError("prediction task_id is absent")
    if frame.duplicated(["task_id", "row_hash", "outcome", "model", "split"]).any():
        raise ValueError("duplicate strict-long predictions")
    y_true = pd.to_numeric(frame["y_true"], errors="coerce")
    if y_true.isna().any() or not y_true.isin([0, 1]).all():
        raise ValueError("invalid strict-long y_true values")
    prediction = pd.to_numeric(frame["prediction"], errors="coerce")
    if prediction.isna().any() or not prediction.between(0, 1).all():
        raise ValueError("invalid strict-long prediction values")
    if frame["split"].str.contains("2025", na=False).any():
        raise ValueError("2025 prediction reached P1_02")


def finalize_long_predictions(
    frame: pd.DataFrame,
    task_id: str,
    train: pd.DataFrame,
    validation: pd.DataFrame,
    outcome: str,
) -> pd.DataFrame:
    labels = pd.concat(
        [
            train[["row_hash", f"y_{outcome}"]],
            validation[["row_hash", f"y_{outcome}"]],
        ],
        ignore_index=True,
    ).copy()
    labels["row_hash"] = labels["row_hash"].astype(str)
    if labels["row_hash"].duplicated().any():
        raise ValueError("row_hash is duplicated across development and validation labels")
    label_lookup = labels.set_index("row_hash")[f"y_{outcome}"]
    finalized = frame.copy()
    finalized["row_hash"] = finalized["row_hash"].astype(str)
    finalized.insert(0, "task_id", task_id)
    finalized.insert(6, "y_true", finalized["row_hash"].map(label_lookup))
    finalized["y_true"] = pd.to_numeric(finalized["y_true"], errors="raise").astype("int8")
    validate_long_predictions(finalized)
    return finalized


def run_task(args: argparse.Namespace) -> dict[str, Any]:
    started = time.perf_counter()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    success_path = output_dir / "_SUCCESS.json"
    train, validation, feature_cols, schema, input_contract = load_stage1a_inputs(
        args.stage1a_dir, args.fold_map, args.outcome, smoke=args.smoke
    )
    code_hashes = current_baseline_code_hashes()
    score_recompute = passive_score_recompute_contract()
    formula_evidence = formula_equivalence_evidence()
    if formula_evidence["status"] != "PASS":
        raise ValueError("authoritative score formula equivalence evidence failed")
    scientific_hashes = passive_score_scientific_hashes(
        input_contract["hashes"],
        code_hashes,
        Path(__file__).name,
        formula_evidence,
    )
    validate_runtime_hash_expectations(
        input_contract["hashes"], code_hashes, scientific_hashes
    )
    existing = validate_existing_success(
        output_dir,
        args.task_id,
        expected_input_hashes=input_contract["hashes"],
        expected_code_hashes=code_hashes,
        expected_formula_sha256=score_recompute["formula_sha256"],
        expected_scientific_hashes=scientific_hashes,
    )
    if existing is not None:
        return existing
    model_name = args.model
    device = "cpu" if model_name == "knn_classifier" else resolve_device(args.device)
    hpo_binding_hashes = {
        "data_sha256": input_contract["hashes"]["features"],
        "schema_sha256": input_contract["hashes"]["schema"],
        "manifest_sha256": input_contract["hashes"]["manifest"],
        "fold_sha256": input_contract["hashes"]["fold_map"],
        "task_registry_sha256": os.environ.get(
            "P1_TASK_REGISTRY_SHA256", "LOCAL_UNBOUND"
        ),
        "registry_task_sha256": os.environ.get(
            "P1_REGISTRY_TASK_SHA256", "LOCAL_UNBOUND"
        ),
        "runner_sha256": code_hashes[Path(__file__).name],
        "score_formula_sha256": score_recompute["formula_sha256"],
        "feature_order_sha256": sha256_lines(feature_cols),
    }
    if (
        not args.smoke
        and model_name in {*GBDT_MODELS, "knn_classifier"}
        and "LOCAL_UNBOUND" in hpo_binding_hashes.values()
    ):
        raise ValueError("formal model-selection task requires task-registry binding hashes")
    score_source: str | None = None
    selection_artifact_paths: list[Path] = []
    if model_name in SCORE_LABELS:
        score_source = SCORE_SOURCE_MAP.get(model_name, model_name)
        if score_source not in feature_cols:
            raise ValueError(f"score source is absent from Stage1a schema: {score_source}")
        final_model, oof, validation_long, metrics, coverage = fit_score_task(
            train, validation, args.outcome, score_source, task_label=model_name, seed=args.seed
        )
        output_model = f"score_{model_name}"
        hpo = None
        params = {}
        sample_records: list[dict[str, Any]] = []
    elif model_name in ML_MODELS:
        params: dict[str, Any] = {}
        trials_frame = None
        hpo = None
        if model_name in GBDT_MODELS:
            params, trials_frame, hpo = hpo_gbdt(
                model_name,
                train,
                validation,
                feature_cols,
                args.outcome,
                task_id=args.task_id,
                output_dir=output_dir,
                trials=args.trials,
                seed=args.seed,
                smoke=args.smoke,
                device=device,
                binding_hashes=hpo_binding_hashes,
            )
            atomic_parquet(output_dir / "optuna_trials.parquet", trials_frame)
        elif model_name == "knn_classifier":
            params, trials_frame, hpo = select_knn_classifier_params(
                train,
                feature_cols,
                args.outcome,
                seed=args.seed,
                smoke=args.smoke,
            )
            selection_path = output_dir / "knn_grid_results.parquet"
            atomic_parquet(selection_path, trials_frame)
            selection_artifact_paths.append(selection_path)
            hpo["artifact"] = selection_path.name
        final_model, oof, validation_long, metrics, sample_records = fit_fixed_oof(
            train,
            validation,
            feature_cols,
            args.outcome,
            model_name,
            params=params,
            seed=args.seed,
            smoke=args.smoke,
            device=device,
            svm_max_train=args.svm_max_train,
        )
        output_model = model_name
        coverage = pd.concat(
            [
                pd.DataFrame({"row_hash": train["row_hash"], "outcome": args.outcome, "model": output_model, "split": "oof_2020_2023", "eligible": True}),
                pd.DataFrame({"row_hash": validation["row_hash"], "outcome": args.outcome, "model": output_model, "split": "validation_2024", "eligible": True}),
            ],
            ignore_index=True,
        )
    else:
        raise ValueError(f"model must be one of {list(SCORE_LABELS + ML_MODELS)}")

    predictions = pd.concat([oof, validation_long], ignore_index=True)
    predictions["fold"] = pd.array(predictions["fold"], dtype="Int8")
    predictions = finalize_long_predictions(predictions, args.task_id, train, validation, args.outcome)
    metrics_frame = pd.DataFrame(metrics)
    metrics_frame.insert(0, "task_id", args.task_id)
    coverage["eligible"] = coverage["eligible"].astype(bool)
    prediction_path = output_dir / "predictions.parquet"
    metrics_path = output_dir / "metrics.parquet"
    coverage_path = output_dir / "coverage.parquet"
    model_path = output_dir / "model.joblib"
    spec_path = output_dir / "spec.json"
    atomic_parquet(prediction_path, predictions)
    atomic_parquet(metrics_path, metrics_frame)
    atomic_parquet(coverage_path, coverage)
    atomic_joblib(model_path, final_model)
    extra_artifact_paths: list[Path] = list(selection_artifact_paths)
    canary_info, canary_paths = write_baseline_canary(
        model_path,
        output_dir,
        validation,
        validation_long,
        feature_cols if model_name in ML_MODELS else [score_source],
        outcome=args.outcome,
        model_name=output_model,
        saved_model_is_score_bundle=model_name in SCORE_LABELS,
        training=train,
        reference_model=final_model,
    )
    extra_artifact_paths.extend(canary_paths)
    importance_info = None
    tree_shap_info = None
    if model_name in {"logistic_l1", *GBDT_MODELS}:
        importance_path = output_dir / "feature_importance.parquet"
        importance_frame = model_feature_importance(final_model, feature_cols, model_name)
        atomic_parquet(importance_path, importance_frame)
        extra_artifact_paths.append(importance_path)
        importance_info = {
            "artifact": importance_path.name,
            "rows": int(len(importance_frame)),
            "importance_type": str(importance_frame["importance_type"].iloc[0]) if len(importance_frame) else None,
        }
    if model_name == "xgboost":
        shap_values_path = output_dir / "treeshap_values_2024.parquet"
        shap_importance_path = output_dir / "treeshap_importance_2024.parquet"
        shap_values, shap_importance, tree_shap_info = xgboost_treeshap(
            final_model,
            validation,
            feature_cols,
            args.outcome,
            maximum_rows=args.shap_max_rows,
            seed=args.seed,
        )
        atomic_parquet(shap_values_path, shap_values)
        atomic_parquet(shap_importance_path, shap_importance)
        extra_artifact_paths.extend([shap_values_path, shap_importance_path])
        tree_shap_info.update(
            {"values_artifact": shap_values_path.name, "importance_artifact": shap_importance_path.name}
        )
    score_recompute.update(
        {
            "applied_to_ml_pipeline": model_name in ML_MODELS,
            "standalone_score_complete_component_only": model_name in SCORE_LABELS,
            "input_passive_score_columns": [
                name for name in PASSIVE_SCORE_VALUE_COLUMNS if name in feature_cols
            ],
        }
    )
    split_estimates = split_estimability(
        coverage, train, validation, args.outcome
    )
    model_feature_order = (
        transformed_feature_names(final_model, feature_cols)
        if model_name in ML_MODELS
        else [str(score_source)]
    )
    forbidden_model_features = sorted(
        set(model_feature_order) & set(MODEL_OUTPUT_EXCLUDED_FEATURES)
    )
    if forbidden_model_features:
        raise ValueError(
            f"duplicate passive score aliases entered model features: {forbidden_model_features}"
        )
    spec = {
        "schema_version": "1.0",
        "task_id": args.task_id,
        "stage": "P1_02",
        "outcome": args.outcome,
        "requested_model": model_name,
        "output_model": output_model,
        "feature_order": feature_cols if model_name in ML_MODELS else [score_source],
        "feature_order_sha256": sha256_lines(feature_cols if model_name in ML_MODELS else [score_source]),
        "model_feature_order": model_feature_order,
        "model_feature_order_sha256": sha256_lines(model_feature_order),
        "model_output_excluded_features": list(MODEL_OUTPUT_EXCLUDED_FEATURES),
        "score_source": score_source if model_name in SCORE_LABELS else None,
        "score_alias": (
            {"task_label": model_name, "source_feature": score_source, "same_numeric_predictor": True}
            if model_name in SCORE_SOURCE_MAP
            else None
        ),
        "preprocessing": (
            "fold_local_component_median_then_passive_score_recompute_then_residual_undefined_score_median_plus_indicators"
            if model_name in ML_MODELS
            else "complete_component_rows_only_no_score_imputation"
        ),
        "passive_score_recompute": score_recompute,
        "passive_score_spec_sha256": scientific_hashes[
            "passive_score_spec_sha256"
        ],
        "formula_equivalence_evidence": formula_evidence,
        "scientific_hashes": scientific_hashes,
        "estimator_params": params,
        "resolved_estimator_params": resolved_estimator_params(final_model),
        "hpo": hpo,
        "feature_importance": importance_info,
        "tree_shap": tree_shap_info,
        "model_reload_canary": canary_info,
        "split_estimability": split_estimates,
        "probability_calibration": (
            {
                "method": "LIBSVM internal Platt sigmoid calibration",
                "fit_scope": "inside each fixed-fold training subset and final 2020-2023 fit only",
                "probability_enabled": True,
                "calibration_folds": 5,
                "validation_2024_used_for_calibration_fit": False,
            }
            if model_name == "svm_rbf"
            else None
        ),
        "fit_diagnostics": (
            {
                "convergence": "NOT_APPLICABLE",
                "reason": "KNeighborsClassifier is a non-iterative estimator",
                "development_selection_complete": True,
            }
            if model_name == "knn_classifier"
            else None
        ),
        "fixed_folds": input_contract["folds"],
        "seed": args.seed,
        "smoke": bool(args.smoke),
        "device": device,
        "svm_sampling": sample_records,
        "training_years": [2020, 2021, 2022, 2023],
        "validation_year": 2024,
        "uses_2025": False,
    }
    atomic_json(spec_path, spec)
    artifact_paths = [prediction_path, metrics_path, coverage_path, model_path, spec_path]
    artifact_paths.extend(extra_artifact_paths)
    if model_name in GBDT_MODELS:
        artifact_paths.extend([output_dir / "optuna_trials.parquet", output_dir / "optuna.sqlite3"])
    artifact_hashes = {path.name: sha256_file(path) for path in artifact_paths}
    hashes_path = output_dir / "hashes.json"
    atomic_json(
        hashes_path,
        {
            "schema_version": "1.0",
            "task_id": args.task_id,
            "input_hashes": input_contract["hashes"],
            "code_sha256": code_hashes,
            "scientific_hashes": scientific_hashes,
            "artifact_hashes": artifact_hashes,
        },
    )
    artifact_hashes[hashes_path.name] = sha256_file(hashes_path)
    manifest = {
        "schema_version": "1.0",
        "task_id": args.task_id,
        "stage": "P1_02",
        "status": "PASS",
        "outcome": args.outcome,
        "model": output_model,
        "input_hashes": input_contract["hashes"],
        "code_sha256": code_hashes,
        "scientific_hashes": scientific_hashes,
        "feature_order_sha256": spec["feature_order_sha256"],
        "model_feature_order_sha256": spec["model_feature_order_sha256"],
        "artifact_hashes": artifact_hashes,
        "prediction_rows": int(len(predictions)),
        "metric_rows": int(len(metrics_frame)),
        "coverage": {
            split: {
                "total": int(len(group)),
                "eligible": int(group["eligible"].sum()),
                "eligible_rate": float(group["eligible"].mean()),
            }
            for split, group in coverage.groupby("split", observed=True)
        },
        "split_estimability": split_estimates,
        "strict_long_predictions": True,
        "oof_uses_fixed_fold_map": True,
        "strict_no_arrival_leakage": True,
        "source_seal_input_refused": True,
        "primary_preprocessing": spec["preprocessing"],
        "passive_score_recompute": score_recompute,
        "passive_score_spec_sha256": scientific_hashes[
            "passive_score_spec_sha256"
        ],
        "formula_equivalence_evidence": formula_evidence,
        "model_reload_canary": canary_info,
        "historical_2025_exposure": True,
        "2025_access_count": 0,
        "source_seal_access_count": 0,
        "raw_data_access_count": 0,
        "runtime_seconds": float(time.perf_counter() - started),
        "runtime": {"python": platform.python_version(), "platform": platform.platform(), "packages": package_versions()},
    }
    manifest_path = output_dir / "task_manifest.json"
    atomic_json(manifest_path, manifest)
    success = {
        "schema_version": "1.0",
        "task_id": args.task_id,
        "status": "SUCCESS",
        "manifest": manifest_path.name,
        "manifest_sha256": sha256_file(manifest_path),
        "artifact_hashes": artifact_hashes,
    }
    atomic_json(success_path, success)
    return success


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run one executable EMT P1 Stage1b v2 model/score task")
    parser.add_argument("--outcome", required=True, choices=OUTCOMES)
    parser.add_argument("--model", required=True, choices=SCORE_LABELS + ML_MODELS)
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--stage1a-dir", type=Path, default=DEFAULT_STAGE1A_DIR)
    parser.add_argument("--fold-map", type=Path, default=DEFAULT_FOLD_MAP)
    parser.add_argument("--trials", type=int, default=50)
    parser.add_argument("--seed", type=int, default=20260710)
    parser.add_argument("--svm-max-train", type=int, default=20000)
    parser.add_argument("--shap-max-rows", type=int, default=500)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args(argv)
    if args.trials < 1:
        parser.error("--trials must be positive")
    if args.shap_max_rows < 1:
        parser.error("--shap-max-rows must be positive")
    return args


def main() -> None:
    args = parse_args()
    result = run_task(args)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
