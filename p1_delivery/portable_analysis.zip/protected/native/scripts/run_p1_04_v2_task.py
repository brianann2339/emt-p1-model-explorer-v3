from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import shutil
import sys
import time
import uuid
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Callable

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qa_v2 import contextual_security_scan as security_scan  # noqa: E402
from scripts import run_ablation_v2_task as ablation  # noqa: E402
from scripts import p1_04_execution_contract  # noqa: E402


OUTCOMES = p1_04_execution_contract.OUTCOMES
SENSITIVITIES = p1_04_execution_contract.SENSITIVITIES


TASK_FAMILIES = ("ablation_bundle", "sensitivity_bundle")
EXECUTABLE_SENSITIVITIES = tuple(value for value in SENSITIVITIES if value != "p3_ett")
CITY_COLUMNS = ("EMT_城市__台北", "EMT_城市__新北")
RESULT_METRICS = (
    "AUROC",
    "AUPRC",
    "Brier",
    "F1",
    "net_benefit",
    "calibration_intercept",
    "calibration_slope",
)
ROOT_ARTIFACTS = (
    "predictions.parquet",
    "metrics.parquet",
    "coverage.parquet",
    "spec.json",
    "hashes.json",
    "task_manifest.json",
)


class P104TaskError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def stable_offset(value: str) -> int:
    return int(hashlib.sha256(value.encode("utf-8")).hexdigest()[:8], 16)


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _task_identity(args: argparse.Namespace) -> None:
    if args.task_family == "ablation_bundle":
        expected = f"P1_04-ablation-{args.outcome}"
        if args.outcome not in OUTCOMES or args.sensitivity is not None:
            raise P104TaskError("ablation bundle requires exactly one locked outcome")
    else:
        expected = f"P1_04-sensitivity-{args.sensitivity}"
        if args.outcome is not None or args.sensitivity not in EXECUTABLE_SENSITIVITIES:
            raise P104TaskError("sensitivity bundle identity is unsupported or terminal")
    if args.task_id != expected:
        raise P104TaskError(f"task identity mismatch: expected {expected}")
    if args.smoke and args.fold is None:
        raise P104TaskError("--smoke requires --fold")
    if not args.smoke and args.fold is not None:
        raise P104TaskError("formal bundle must execute its complete fold contract")
    if args.bootstrap_b < 0 or (not args.smoke and args.bootstrap_b < 2000):
        raise P104TaskError("formal bundle requires at least 2,000 bootstrap replicates")


def _base_spec_path(args: argparse.Namespace, outcome: str) -> Path:
    path = args.base_spec_dir.resolve() / f"{outcome}_base_spec.json"
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def _binding(
    manifest_path: Path,
    artifact_path: Path,
    *,
    task_id: str,
    binding_id: str,
    expected_row_hashes: set[str],
    categorical_columns: set[str] | None = None,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    manifest = read_json(manifest_path)
    if (
        manifest.get("contract_version") != "p1-v2-p1-04-sidecar-adapter/1"
        or manifest.get("2025_access_count") != 0
        or manifest.get("arrival_derived_sidecars_in_main_model_features") is not False
        or manifest.get("formal_training_launched") is not False
    ):
        raise P104TaskError("invalid P1_04 sidecar binding manifest")
    values = manifest.get("bindings", {}).get(task_id)
    if not isinstance(values, list) or len(values) != 1:
        raise P104TaskError(f"missing unique sidecar binding for {task_id}")
    value = values[0]
    expected_use = {
        "ed_early_ablation_10_only": {
            "ablation": "10_prehospital_vs_ed_early",
            "arm": "plus_ed_early",
            "measurement_window": "arrival_initial_vitals",
            "task_id": task_id,
        },
        "raw_age_subgroup_only": {
            "sensitivity": "age_subgroup",
            "task_id": task_id,
        },
        "ed_congestion_tminus1h_only": {
            "sensitivity": "ed_congestion",
            "task_id": task_id,
            "temporal_cutoff": "t_minus_1_hour",
        },
    }[binding_id]
    expected_arrival_derived = binding_id != "raw_age_subgroup_only"
    if (
        value.get("binding_id") != binding_id
        or value.get("2025_access_count") != 0
        or value.get("maximum_year") != 2024
        or value.get("deidentified") is not True
        or value.get("arrival_derived") is not expected_arrival_derived
        or value.get("main_model_feature_allowed") is not False
        or value.get("allowed_use") != expected_use
        or str(value.get("sha256", "")).casefold() != sha256_file(artifact_path).casefold()
        or Path(str(value.get("path", ""))).name != artifact_path.name
    ):
        raise P104TaskError(f"sidecar binding mismatch for {task_id}")
    frame = pd.read_parquet(artifact_path)
    if (
        "row_hash" not in frame
        or frame["row_hash"].astype(str).duplicated().any()
        or set(frame["row_hash"].astype(str)) != expected_row_hashes
    ):
        raise P104TaskError(f"sidecar row keys mismatch for {task_id}")
    categorical_columns = categorical_columns or set()
    feature_columns = [column for column in frame.columns if column != "row_hash"]
    if not feature_columns or security_scan.pii_column_hits(feature_columns):
        raise P104TaskError(f"sidecar feature contract invalid for {task_id}")
    for column in feature_columns:
        if column in categorical_columns:
            continue
        if pd.to_numeric(frame[column], errors="coerce").notna().sum() != frame[column].notna().sum():
            raise P104TaskError(f"non-numeric sidecar feature {column}")
    return frame, value


def _runtime_ed_early_manifest(
    binding_manifest: Path,
    artifact_path: Path,
    *,
    task_id: str,
    expected_row_hashes: set[str],
    output_path: Path,
) -> Path:
    frame, _ = _binding(
        binding_manifest,
        artifact_path,
        task_id=task_id,
        binding_id="ed_early_ablation_10_only",
        expected_row_hashes=expected_row_hashes,
    )
    atomic_json(
        output_path,
        {
            "contract_version": ablation.ED_EARLY_BINDING_CONTRACT,
            "ed_early_ok": True,
            "isolated_sensitivity_only": True,
            "main_model_feature_allowed": False,
            "2025_access_count": 0,
            "measurement_window": "arrival_initial_vitals",
            "allowed_ablation": "10_prehospital_vs_ed_early",
            "allowed_arm": "plus_ed_early",
            "allowed_task_ids": [task_id],
            "leakage_audit_pass": True,
            "raw_arrival_timestamp_retained": False,
            "feature_columns": [column for column in frame.columns if column != "row_hash"],
            "artifact_sha256": sha256_file(artifact_path),
            "source_binding_manifest_sha256": sha256_file(binding_manifest),
        },
    )
    return output_path


def _validate_ablation_component(
    directory: Path,
    *,
    task_id: str,
    outcome: str,
    ablation_name: str,
    smoke: bool,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    success_name = "_SMOKE_PASS.json" if smoke else "_SUCCESS.json"
    required = (
        "predictions.parquet",
        "metrics.parquet",
        "models.joblib",
        "feature_manifest.json",
        "spec.json",
        "task_manifest.json",
        success_name,
    )
    if any(not (directory / name).is_file() for name in required):
        raise P104TaskError(f"incomplete ablation component {ablation_name}")
    success = read_json(directory / success_name)
    manifest = read_json(directory / "task_manifest.json")
    spec = read_json(directory / "spec.json")
    if (
        success.get("status") != ("SMOKE_PASS" if smoke else "SUCCESS")
        or success.get("task_id") != task_id
        or success.get("scientific_artifact") is smoke
        or success.get("promotion_allowed") is smoke
        or success.get("manifest_sha256") != sha256_file(directory / "task_manifest.json")
        or manifest.get("status") != ("SMOKE_PASS" if smoke else "PASS")
        or manifest.get("scientific_artifact") is smoke
        or manifest.get("promotion_allowed") is smoke
        or manifest.get("outcome") != outcome
        or manifest.get("ablation") != ablation_name
        or spec.get("ablation") != ablation_name
        or spec.get("scientific_artifact") is smoke
        or spec.get("promotion_allowed") is smoke
        or spec.get("2025_access_count") != 0
    ):
        raise P104TaskError(f"invalid ablation component seal {ablation_name}")
    for name, expected in manifest.get("artifact_hashes", {}).items():
        path = directory / name
        if not path.is_file() or sha256_file(path) != expected:
            raise P104TaskError(f"ablation component hash mismatch {ablation_name}/{name}")
    predictions = pd.read_parquet(directory / "predictions.parquet")
    metrics = pd.read_parquet(directory / "metrics.parquet")
    return predictions, metrics, spec


def _run_ablation_bundle(
    args: argparse.Namespace,
    staging: Path,
    component_runner: Callable[[argparse.Namespace], dict[str, Any]],
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    base_spec = _base_spec_path(args, args.outcome)
    features = pd.read_parquet(
        args.stage1a_dir.resolve() / "stage1a_features_le2024.parquet",
        columns=["row_hash"],
    )
    expected_rows = set(features["row_hash"].astype(str))
    runtime_ed_manifest = None
    if not args.smoke:
        if args.sidecar_binding_manifest is None or args.ed_early_artifact is None:
            raise P104TaskError("formal ablation bundle requires the bound ED-early sidecar")
        runtime_ed_manifest = _runtime_ed_early_manifest(
            args.sidecar_binding_manifest.resolve(),
            args.ed_early_artifact.resolve(),
            task_id=args.task_id,
            expected_row_hashes=expected_rows,
            output_path=staging / "runtime_bindings" / "ed_early_manifest.json",
        )
    prediction_frames = []
    metric_frames = []
    component_specs = {}
    for name in ablation.ABLATIONS:
        directory = staging / "components" / name
        child = SimpleNamespace(
            outcome=args.outcome,
            ablation=name,
            task_id=args.task_id,
            output_dir=directory,
            stage1a_dir=args.stage1a_dir.resolve(),
            fold_map=args.fold_map.resolve(),
            base_spec=base_spec,
            ed_early_artifact=(args.ed_early_artifact.resolve() if name == "10_prehospital_vs_ed_early" and not args.smoke else None),
            ed_early_manifest=(runtime_ed_manifest if name == "10_prehospital_vs_ed_early" and not args.smoke else None),
            seed=args.seed,
            smoke=args.smoke,
            fold=args.fold,
        )
        component_runner(child)
        predictions, metrics, spec = _validate_ablation_component(
            directory,
            task_id=args.task_id,
            outcome=args.outcome,
            ablation_name=name,
            smoke=args.smoke,
        )
        prediction_frames.append(predictions)
        metric_frames.append(metrics)
        component_specs[name] = {
            "spec": f"components/{name}/spec.json",
            "spec_sha256": sha256_file(directory / "spec.json"),
            "manifest": f"components/{name}/task_manifest.json",
            "manifest_sha256": sha256_file(directory / "task_manifest.json"),
            "arm_count": len(spec["arms"]),
        }
    return (
        pd.concat(prediction_frames, ignore_index=True),
        pd.concat(metric_frames, ignore_index=True),
        {
            "ablation_count": len(component_specs),
            "ablations": list(ablation.ABLATIONS),
            "components": component_specs,
            "base_spec": base_spec.name,
            "base_spec_sha256": sha256_file(base_spec),
        },
    )


def _load_outcome(args: argparse.Namespace, outcome: str) -> dict[str, Any]:
    base_spec_path = _base_spec_path(args, outcome)
    train, validation, _, feature_order, base_spec, input_hashes = ablation._validate_inputs(
        args.stage1a_dir.resolve(),
        args.fold_map.resolve(),
        base_spec_path,
        outcome,
        args.smoke,
    )
    return {
        "outcome": outcome,
        "train": train,
        "validation": validation,
        "features": feature_order,
        "base_spec": base_spec,
        "base_spec_path": base_spec_path,
        "input_hashes": input_hashes,
    }


def _arm(data: dict[str, Any], features: list[str] | None = None) -> dict[str, Any]:
    return {
        "model": str(data["base_spec"]["base_model"]),
        "params": dict(data["base_spec"]["estimator_params"]),
        "features": list(features or data["features"]),
    }


def _fit_cv(
    args: argparse.Namespace,
    data: dict[str, Any],
    *,
    label: str,
    grouped: bool,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any], dict[str, Any]]:
    train = data["train"]
    validation = data["validation"]
    outcome = data["outcome"]
    arm = _arm(data)
    features = arm["features"]
    y = train[f"y_{outcome}"].to_numpy(dtype="int8")
    if grouped:
        fold_values = pd.to_numeric(train["fold"], errors="raise").astype(int).to_numpy()
    else:
        fold_values = np.full(len(train), -1, dtype="int8")
        splitter = StratifiedKFold(n_splits=5, shuffle=True, random_state=args.seed)
        for fold, (_, evaluate) in enumerate(splitter.split(np.zeros((len(y), 1)), y)):
            fold_values[evaluate] = fold
    selected_folds = [args.fold] if args.smoke else list(range(5))
    predictions = []
    models = {}
    for fold in selected_folds:
        fit = train.loc[fold_values != fold]
        evaluate = train.loc[fold_values == fold]
        y_fit = fit[f"y_{outcome}"].to_numpy(dtype="int8")
        y_evaluate = evaluate[f"y_{outcome}"].to_numpy(dtype="int8")
        if len(np.unique(y_fit)) != 2 or len(np.unique(y_evaluate)) != 2:
            raise P104TaskError(f"{label}/{outcome}/fold{fold} lacks both classes")
        model = ablation._estimator(
            arm,
            y_fit,
            args.smoke,
            args.seed + stable_offset(f"{label}:{outcome}") + fold,
            fit[features],
        )
        model.fit(fit[features], y_fit)
        probability = np.clip(model.predict_proba(evaluate[features])[:, 1], 1e-6, 1 - 1e-6)
        predictions.append(
            pd.DataFrame(
                {
                    "task_id": args.task_id,
                    "row_hash": evaluate["row_hash"].astype(str),
                    "outcome": outcome,
                    "model": label,
                    "split": "oof_2020_2023",
                    "fold": int(fold),
                    "y_true": y_evaluate,
                    "prediction": probability,
                }
            )
        )
        models[f"{label}__fold{fold}"] = model
    frame = pd.concat(predictions, ignore_index=True)
    metrics = ablation._metric_rows(
        frame["y_true"].to_numpy(dtype="int8"),
        frame["prediction"].to_numpy(dtype="float64"),
        args.task_id,
        outcome,
        label,
        "oof_2020_2023",
        0.5,
    )
    if not args.smoke:
        y_train = train[f"y_{outcome}"].to_numpy(dtype="int8")
        model = ablation._estimator(
            arm,
            y_train,
            False,
            args.seed + stable_offset(f"{label}:{outcome}:final"),
            train[features],
        )
        model.fit(train[features], y_train)
        probability = np.clip(model.predict_proba(validation[features])[:, 1], 1e-6, 1 - 1e-6)
        y_validation = validation[f"y_{outcome}"].to_numpy(dtype="int8")
        validation_frame = pd.DataFrame(
            {
                "task_id": args.task_id,
                "row_hash": validation["row_hash"].astype(str),
                "outcome": outcome,
                "model": label,
                "split": "validation_2024",
                "fold": pd.array([None] * len(validation), dtype="Int8"),
                "y_true": y_validation,
                "prediction": probability,
            }
        )
        frame = pd.concat([frame, validation_frame], ignore_index=True)
        metrics.extend(
            ablation._metric_rows(
                y_validation,
                probability,
                args.task_id,
                outcome,
                label,
                "validation_2024",
                0.5,
            )
        )
        models[f"{label}__final"] = model
    spec = {
        "outcome": outcome,
        "model": label,
        "grouped": grouped,
        "feature_count": len(features),
        "feature_order_sha256": ablation.sha256_lines(features),
        "base_spec_sha256": sha256_file(data["base_spec_path"]),
        "folds": selected_folds,
    }
    return frame, pd.DataFrame(metrics), models, spec


def _fit_single(
    args: argparse.Namespace,
    data: dict[str, Any],
    *,
    fit: pd.DataFrame,
    evaluate: pd.DataFrame,
    features: list[str],
    label: str,
    split: str,
) -> tuple[pd.DataFrame, pd.DataFrame, Any]:
    outcome = data["outcome"]
    y_fit = fit[f"y_{outcome}"].to_numpy(dtype="int8")
    y_evaluate = evaluate[f"y_{outcome}"].to_numpy(dtype="int8")
    if len(np.unique(y_fit)) != 2 or len(np.unique(y_evaluate)) != 2:
        raise P104TaskError(f"{label}/{outcome} lacks both classes")
    arm = _arm(data, features)
    model = ablation._estimator(
        arm,
        y_fit,
        args.smoke,
        args.seed + stable_offset(f"{label}:{outcome}"),
        fit[features],
    )
    model.fit(fit[features], y_fit)
    probability = np.clip(model.predict_proba(evaluate[features])[:, 1], 1e-6, 1 - 1e-6)
    predictions = pd.DataFrame(
        {
            "task_id": args.task_id,
            "row_hash": evaluate["row_hash"].astype(str),
            "outcome": outcome,
            "model": label,
            "split": split,
            "fold": pd.array([None] * len(evaluate), dtype="Int8"),
            "y_true": y_evaluate,
            "prediction": probability,
        }
    )
    metrics = pd.DataFrame(
        ablation._metric_rows(
            y_evaluate,
            probability,
            args.task_id,
            outcome,
            label,
            split,
            0.5,
        )
    )
    return predictions, metrics, model


def _seal_sensitivity_component(
    directory: Path,
    *,
    task_id: str,
    outcome: str,
    sensitivity: str,
    predictions: pd.DataFrame,
    metrics: pd.DataFrame,
    models: dict[str, Any],
    spec: dict[str, Any],
    smoke: bool,
) -> dict[str, Any]:
    directory.mkdir(parents=True, exist_ok=False)
    predictions.to_parquet(directory / "predictions.parquet", index=False)
    metrics.to_parquet(directory / "metrics.parquet", index=False)
    joblib.dump(models, directory / "models.joblib")
    atomic_json(
        directory / "spec.json",
        {
            **spec,
            "smoke": smoke,
            "scientific_artifact": not smoke,
            "promotion_allowed": not smoke,
        },
    )
    hashes = {
        name: sha256_file(directory / name)
        for name in ("predictions.parquet", "metrics.parquet", "models.joblib", "spec.json")
    }
    atomic_json(directory / "hashes.json", hashes)
    manifest = {
        "contract_version": "p1-v2-p1-04-sensitivity-component/1",
        "task_id": task_id,
        "outcome": outcome,
        "sensitivity": sensitivity,
        "status": "SMOKE_PASS" if smoke else "PASS",
        "scientific_artifact": not smoke,
        "promotion_allowed": not smoke,
        "prediction_rows": len(predictions),
        "metric_rows": len(metrics),
        "2025_access_count": 0,
        "artifact_hashes": hashes,
    }
    atomic_json(directory / "component_manifest.json", manifest)
    atomic_json(
        directory / ("_SMOKE_PASS.json" if smoke else "_SUCCESS.json"),
        {
            "status": "SMOKE_PASS" if smoke else "PASS",
            "scientific_artifact": not smoke,
            "promotion_allowed": not smoke,
            "manifest_sha256": sha256_file(directory / "component_manifest.json"),
            "hashes_sha256": sha256_file(directory / "hashes.json"),
        },
    )
    return {
        "manifest": str(directory.name + "/component_manifest.json"),
        "manifest_sha256": sha256_file(directory / "component_manifest.json"),
        "spec_sha256": sha256_file(directory / "spec.json"),
    }


def _run_standard_sensitivity(
    args: argparse.Namespace,
    staging: Path,
    outcomes: tuple[str, ...],
    labels: tuple[tuple[str, bool], ...],
) -> tuple[list[pd.DataFrame], list[pd.DataFrame], dict[str, Any]]:
    predictions = []
    metrics = []
    components = {}
    for outcome in outcomes:
        data = _load_outcome(args, outcome)
        component_predictions = []
        component_metrics = []
        models = {}
        specs = []
        for label_prefix, grouped in labels:
            label = f"{args.sensitivity}__{label_prefix}"
            frame, metric, fitted, spec = _fit_cv(args, data, label=label, grouped=grouped)
            component_predictions.append(frame)
            component_metrics.append(metric)
            models.update(fitted)
            specs.append(spec)
        outcome_predictions = pd.concat(component_predictions, ignore_index=True)
        outcome_metrics = pd.concat(component_metrics, ignore_index=True)
        component_dir = staging / "components" / outcome
        components[outcome] = _seal_sensitivity_component(
            component_dir,
            task_id=args.task_id,
            outcome=outcome,
            sensitivity=args.sensitivity,
            predictions=outcome_predictions,
            metrics=outcome_metrics,
            models=models,
            spec={"arms": specs, "input_hashes": data["input_hashes"]},
            smoke=args.smoke,
        )
        predictions.append(outcome_predictions)
        metrics.append(outcome_metrics)
    return predictions, metrics, {"components": components}


def _run_city_holdout(
    args: argparse.Namespace,
    staging: Path,
) -> tuple[list[pd.DataFrame], list[pd.DataFrame], dict[str, Any]]:
    predictions = []
    metrics = []
    components = {}
    for outcome in OUTCOMES:
        data = _load_outcome(args, outcome)
        train = data["train"]
        validation = data["validation"]
        if any(column not in train or column not in validation for column in CITY_COLUMNS):
            raise P104TaskError("locked Stage1a artifact lacks exact Taipei/New Taipei indicators")
        features = [
            feature for feature in data["features"] if not feature.startswith("EMT_城市__")
        ]
        if not features:
            raise P104TaskError("city holdout removed every locked feature")
        directions = (
            (CITY_COLUMNS[0], CITY_COLUMNS[1], "taipei_to_new_taipei"),
            (CITY_COLUMNS[1], CITY_COLUMNS[0], "new_taipei_to_taipei"),
        )
        outcome_predictions = []
        outcome_metrics = []
        models = {}
        arm_specs = []
        for fit_city, evaluate_city, name in directions:
            fit = train.loc[pd.to_numeric(train[fit_city], errors="coerce").eq(1)]
            evaluate = validation.loc[
                pd.to_numeric(validation[evaluate_city], errors="coerce").eq(1)
            ]
            label = f"city_holdout__{name}"
            frame, metric, model = _fit_single(
                args,
                data,
                fit=fit,
                evaluate=evaluate,
                features=features,
                label=label,
                split="validation_2024",
            )
            outcome_predictions.append(frame)
            outcome_metrics.append(metric)
            models[label] = model
            arm_specs.append(
                {
                    "model": label,
                    "fit_city_indicator": fit_city,
                    "evaluate_city_indicator": evaluate_city,
                    "feature_count": len(features),
                    "city_identity_features_removed": True,
                }
            )
        outcome_prediction = pd.concat(outcome_predictions, ignore_index=True)
        outcome_metric = pd.concat(outcome_metrics, ignore_index=True)
        components[outcome] = _seal_sensitivity_component(
            staging / "components" / outcome,
            task_id=args.task_id,
            outcome=outcome,
            sensitivity=args.sensitivity,
            predictions=outcome_prediction,
            metrics=outcome_metric,
            models=models,
            spec={"arms": arm_specs, "input_hashes": data["input_hashes"]},
            smoke=args.smoke,
        )
        predictions.append(outcome_prediction)
        metrics.append(outcome_metric)
    return predictions, metrics, {"components": components}


def _run_age_subgroup(
    args: argparse.Namespace,
    staging: Path,
) -> tuple[list[pd.DataFrame], list[pd.DataFrame], dict[str, Any]]:
    if args.sidecar_binding_manifest is None or args.age_artifact is None:
        raise P104TaskError("age subgroup sensitivity requires its bound sidecar")
    all_rows = pd.read_parquet(
        args.stage1a_dir.resolve() / "stage1a_features_le2024.parquet",
        columns=["row_hash"],
    )
    age, binding = _binding(
        args.sidecar_binding_manifest.resolve(),
        args.age_artifact.resolve(),
        task_id=args.task_id,
        binding_id="raw_age_subgroup_only",
        expected_row_hashes=set(all_rows["row_hash"].astype(str)),
        categorical_columns={"age_group"},
    )
    predictions = []
    metrics = []
    components = {}
    for outcome in OUTCOMES:
        data = _load_outcome(args, outcome)
        raw, _, models, fit_spec = _fit_cv(
            args,
            data,
            label="age_subgroup__reference",
            grouped=True,
        )
        merged = raw.merge(age[["row_hash", "age_group"]], on="row_hash", validate="many_to_one")
        outcome_predictions = []
        outcome_metrics = []
        for group in ("18_64", "65_plus"):
            selected = merged.loc[merged["age_group"].eq(group)].drop(columns="age_group")
            selected["model"] = f"age_subgroup__{group}"
            if selected.empty:
                raise P104TaskError(f"empty age subgroup {group}")
            outcome_predictions.append(selected)
            for split, split_frame in selected.groupby("split", sort=True):
                outcome_metrics.append(
                    pd.DataFrame(
                        ablation._metric_rows(
                            split_frame["y_true"].to_numpy(dtype="int8"),
                            split_frame["prediction"].to_numpy(dtype="float64"),
                            args.task_id,
                            outcome,
                            f"age_subgroup__{group}",
                            str(split),
                            0.5,
                        )
                    )
                )
        outcome_prediction = pd.concat(outcome_predictions, ignore_index=True)
        outcome_metric = pd.concat(outcome_metrics, ignore_index=True)
        components[outcome] = _seal_sensitivity_component(
            staging / "components" / outcome,
            task_id=args.task_id,
            outcome=outcome,
            sensitivity=args.sensitivity,
            predictions=outcome_prediction,
            metrics=outcome_metric,
            models=models,
            spec={
                "reference_fit": fit_spec,
                "subgroups": ["18_64", "65_plus"],
                "raw_age_used_as_predictor": False,
                "sidecar_sha256": sha256_file(args.age_artifact.resolve()),
                "binding": binding,
            },
            smoke=args.smoke,
        )
        predictions.append(outcome_prediction)
        metrics.append(outcome_metric)
    return predictions, metrics, {"components": components}


def _run_ed_congestion(
    args: argparse.Namespace,
    staging: Path,
) -> tuple[list[pd.DataFrame], list[pd.DataFrame], dict[str, Any]]:
    if args.sidecar_binding_manifest is None or args.congestion_artifact is None:
        raise P104TaskError("ED congestion sensitivity requires its bound t-1h sidecar")
    all_rows = pd.read_parquet(
        args.stage1a_dir.resolve() / "stage1a_features_le2024.parquet",
        columns=["row_hash"],
    )
    congestion, binding = _binding(
        args.sidecar_binding_manifest.resolve(),
        args.congestion_artifact.resolve(),
        task_id=args.task_id,
        binding_id="ed_congestion_tminus1h_only",
        expected_row_hashes=set(all_rows["row_hash"].astype(str)),
    )
    congestion_features = [column for column in congestion if column != "row_hash"]
    predictions = []
    metrics = []
    components = {}
    for outcome in ("P1", "P2", "P3"):
        data = _load_outcome(args, outcome)
        train = data["train"].merge(congestion, on="row_hash", validate="one_to_one")
        validation = data["validation"].merge(congestion, on="row_hash", validate="one_to_one")
        temporal_train = train.loc[pd.to_numeric(train["split_year"]).le(2022)]
        temporal_validation = train.loc[pd.to_numeric(train["split_year"]).eq(2023)]
        arms = (
            ("prehospital_only", list(data["features"])),
            ("plus_ed_congestion_tminus1h", [*data["features"], *congestion_features]),
        )
        outcome_predictions = []
        outcome_metrics = []
        temporal_metrics = []
        models = {}
        for name, features in arms:
            label = f"ed_congestion__{name}"
            temporal_prediction, temporal_metric, _ = _fit_single(
                args,
                data,
                fit=temporal_train,
                evaluate=temporal_validation,
                features=features,
                label=label,
                split="oof_2020_2023",
            )
            temporal_metrics.extend(temporal_metric.to_dict("records"))
            frame, metric, model = _fit_single(
                args,
                data,
                fit=train,
                evaluate=validation,
                features=features,
                label=label,
                split="validation_2024",
            )
            outcome_predictions.append(frame)
            outcome_metrics.append(metric)
            models[label] = model
        outcome_prediction = pd.concat(outcome_predictions, ignore_index=True)
        outcome_metric = pd.concat(outcome_metrics, ignore_index=True)
        components[outcome] = _seal_sensitivity_component(
            staging / "components" / outcome,
            task_id=args.task_id,
            outcome=outcome,
            sensitivity=args.sensitivity,
            predictions=outcome_prediction,
            metrics=outcome_metric,
            models=models,
            spec={
                "temporal_split": {
                    "train": "2020-2022",
                    "validation": "2023",
                    "test": "2024",
                },
                "temporal_validation_metrics": temporal_metrics,
                "congestion_sidecar_sha256": sha256_file(args.congestion_artifact.resolve()),
                "binding": binding,
            },
            smoke=args.smoke,
        )
        predictions.append(outcome_prediction)
        metrics.append(outcome_metric)
    return predictions, metrics, {"components": components}


def _run_sensitivity_bundle(
    args: argparse.Namespace,
    staging: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    if args.sensitivity == "mortality_definition":
        frames, metrics, detail = _run_standard_sensitivity(
            args,
            staging,
            ("P1", "P2"),
            (("locked_definition", True),),
        )
    elif args.sensitivity == "grouped_vs_naive_cv":
        frames, metrics, detail = _run_standard_sensitivity(
            args,
            staging,
            OUTCOMES,
            (("patient_grouped", True), ("naive_row_stratified", False)),
        )
    elif args.sensitivity == "city_holdout":
        frames, metrics, detail = _run_city_holdout(args, staging)
    elif args.sensitivity == "age_subgroup":
        frames, metrics, detail = _run_age_subgroup(args, staging)
    elif args.sensitivity == "ed_congestion":
        frames, metrics, detail = _run_ed_congestion(args, staging)
    else:
        raise P104TaskError(f"unsupported executable sensitivity {args.sensitivity}")
    detail.update(
        {
            "sensitivity": args.sensitivity,
            "p3_ett_status": "NOT_ESTIMABLE",
            "p3_ett_scheduled": False,
            "p3_ett_proxy_inference_used": False,
        }
    )
    return pd.concat(frames, ignore_index=True), pd.concat(metrics, ignore_index=True), detail


def _bootstrap_cis(
    predictions: pd.DataFrame,
    metrics: pd.DataFrame,
    *,
    bootstrap_b: int,
    seed: int,
) -> pd.DataFrame:
    output = metrics.copy()
    if bootstrap_b <= 0:
        return output
    for (outcome, model, split), frame in predictions.groupby(
        ["outcome", "model", "split"], sort=True
    ):
        y = frame["y_true"].to_numpy(dtype="int8")
        probability = frame["prediction"].to_numpy(dtype="float64")
        positive = np.flatnonzero(y == 1)
        negative = np.flatnonzero(y == 0)
        if not len(positive) or not len(negative):
            continue
        rng = np.random.default_rng(seed + stable_offset(f"{outcome}:{model}:{split}"))
        values = {"AUROC": [], "AUPRC": []}
        for _ in range(bootstrap_b):
            indices = np.concatenate(
                [
                    rng.choice(positive, len(positive), replace=True),
                    rng.choice(negative, len(negative), replace=True),
                ]
            )
            values["AUROC"].append(roc_auc_score(y[indices], probability[indices]))
            values["AUPRC"].append(average_precision_score(y[indices], probability[indices]))
        for metric, samples in values.items():
            mask = (
                output["outcome"].eq(outcome)
                & output["model"].eq(model)
                & output["split"].eq(split)
                & output["metric"].eq(metric)
            )
            if int(mask.sum()) != 1:
                raise P104TaskError(f"metric row is not unique for CI: {outcome}/{model}/{split}/{metric}")
            output.loc[mask, "lower_ci"] = float(np.percentile(samples, 2.5))
            output.loc[mask, "upper_ci"] = float(np.percentile(samples, 97.5))
    return output


def _results_table(predictions: pd.DataFrame, metrics: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (outcome, model, split), frame in metrics.groupby(
        ["outcome", "model", "split"], sort=True
    ):
        by_metric = {str(row["metric"]): row for row in frame.to_dict("records")}
        reference = "locked_full" in str(model) or "reference" in str(model)
        row = {
            "task_id": str(frame.iloc[0]["task_id"]),
            "outcome": outcome,
            "experiment": str(model).split("__", 1)[0],
            "arm": str(model).split("__", 1)[1] if "__" in str(model) else str(model),
            "split": split,
            "n": int(frame.iloc[0]["n"]),
            "events": int(frame.iloc[0]["events"]),
            "prevalence": float(frame.iloc[0]["events"] / frame.iloc[0]["n"]) if int(frame.iloc[0]["n"]) else math.nan,
            "interpretation": "Reference arm." if reference else "Paired sensitivity arm; compare with its locked reference.",
        }
        for metric in RESULT_METRICS:
            value = by_metric.get(metric, {})
            row[metric] = value.get("value")
            if metric in {"AUROC", "AUPRC"}:
                row[f"{metric}_lower_ci"] = value.get("lower_ci")
                row[f"{metric}_upper_ci"] = value.get("upper_ci")
        rows.append(row)
    return pd.DataFrame(rows)


def _required_artifacts(task_family: str, smoke: bool) -> list[dict[str, Any]]:
    stage_specific = (
        "stage2b_ablation_results.csv"
        if task_family == "ablation_bundle"
        else "stage2b_sensitivity_results.csv"
    )
    return [
        {"path": "predictions.parquet", "kind": "prediction", "schema": "qa_v2/schemas/prediction.schema.json", "required": True},
        {"path": "metrics.parquet", "kind": "metric", "schema": "qa_v2/schemas/metric.schema.json", "required": True},
        {"path": "coverage.parquet", "kind": "coverage", "schema": {}, "required": True},
        {"path": "spec.json", "kind": "sealed_spec", "schema": {}, "required": True},
        {"path": "hashes.json", "kind": "hash_inventory", "schema": {}, "required": True},
        {"path": "task_manifest.json", "kind": "task_manifest", "schema": "qa_v2/schemas/task.schema.json", "required": True},
        {
            "path": "_SMOKE_PASS.json" if smoke else "_SUCCESS.json",
            "kind": "smoke_marker" if smoke else "success_marker",
            "schema": (
                {
                    "status": "SMOKE_PASS",
                    "scientific_artifact": False,
                    "promotion_allowed": False,
                }
                if smoke
                else {"status": "PASS", "scientific_artifact": True}
            ),
            "required": True,
        },
        {"path": stage_specific, "kind": "stage_specific_artifact", "schema": {}, "required": True},
    ]


def _binding_outcomes(args: argparse.Namespace) -> tuple[str, ...]:
    if args.task_family == "ablation_bundle":
        return (str(args.outcome),)
    if args.sensitivity == "mortality_definition":
        return ("P1", "P2")
    if args.sensitivity == "ed_congestion":
        return ("P1", "P2", "P3")
    return OUTCOMES


def _validate_scientific_inputs(
    args: argparse.Namespace,
    input_paths: dict[str, Path],
    input_hashes: dict[str, str],
) -> None:
    manifest = read_json(input_paths["manifest"])
    if (
        manifest.get("strict_no_arrival_leakage") is not True
        or manifest.get("holdout_policy", {}).get("2025_access_count") != 0
        or manifest.get("holdout_policy", {}).get("2025_feature_artifact_created")
        is not False
    ):
        raise P104TaskError("Stage1a scientific leakage contract differs")
    frame = pd.read_parquet(input_paths["features"])
    required = {
        "row_hash",
        "group_hash",
        "split_year",
        "split",
        *{f"y_{outcome}" for outcome in _binding_outcomes(args)},
    }
    if missing := sorted(required - set(frame.columns)):
        raise P104TaskError(f"Stage1a lacks pre-fit scientific columns: {missing[:20]}")
    if security_scan.pii_column_hits(frame.columns):
        raise P104TaskError("PII columns reached the P1_04 pre-fit gate")
    for column in frame.select_dtypes(include=["object", "string"]).columns:
        if any(
            security_scan.first_pii_pattern_hit(
                value,
                path=(str(column),),
                field=column,
            )
            for value in frame[column].dropna().astype(str)
        ):
            raise P104TaskError(f"PII-like values reached the pre-fit gate: {column}")
    years = pd.to_numeric(frame["split_year"], errors="coerce")
    if (
        years.isna().any()
        or years.ge(2025).any()
        or frame["split"].astype(str).str.contains("2025").any()
        or frame["row_hash"].astype(str).duplicated().any()
    ):
        raise P104TaskError("Stage1a temporal/key contract differs at the pre-fit gate")
    for outcome in _binding_outcomes(args):
        if not frame[f"y_{outcome}"].isin([0, 1]).all():
            raise P104TaskError(f"non-binary formal label for {outcome}")
    train = frame.loc[frame["split"].eq("train_2020_2023"), ["row_hash", "group_hash"]]
    folds = pd.read_parquet(input_paths["fold_map"])
    if "split_year" in folds and pd.to_numeric(
        folds["split_year"], errors="coerce"
    ).ge(2025).any():
        raise P104TaskError("2025 rows reached the P1_04 fold map")
    base_specs: dict[str, dict[str, Any]] = {}
    for outcome in _binding_outcomes(args):
        spec = read_json(input_paths[f"base_spec_{outcome}"])
        base_specs[outcome] = spec
        model = str(spec.get("base_model", "")).casefold()
        feature_order = [str(value) for value in spec.get("feature_order", [])]
        if (
            spec.get("status") != "LOCKED"
            or spec.get("outcome") != outcome
            or model not in ablation.SUPPORTED_LOCKED_BASE_MODELS
            or not isinstance(spec.get("estimator_params"), dict)
            or not spec["estimator_params"]
            or not feature_order
            or len(feature_order) != len(set(feature_order))
            or spec.get("feature_order_sha256") != ablation.sha256_lines(feature_order)
            or any(feature not in frame for feature in feature_order)
            or (not args.smoke and spec.get("smoke_only") is True)
            or (not args.smoke and not spec.get("xgboost_comparator_params"))
        ):
            raise P104TaskError(f"locked base spec contract differs before fit: {outcome}")
        for label in ("features", "schema", "manifest", "fold_map"):
            if str(spec.get("input_hashes", {}).get(label, "")).casefold() != input_hashes[
                label
            ].casefold():
                raise P104TaskError(f"locked base spec hash differs before fit: {outcome}/{label}")
        outcome_folds = folds.loc[
            folds["outcome"].eq(outcome), ["row_hash", "group_hash", "fold"]
        ].copy()
        if (
            outcome_folds["row_hash"].astype(str).duplicated().any()
            or set(outcome_folds["row_hash"].astype(str))
            != set(train["row_hash"].astype(str))
            or outcome_folds.groupby("group_hash")["fold"].nunique().max() != 1
            or (
                not args.smoke
                and sorted(
                    pd.to_numeric(outcome_folds["fold"], errors="raise")
                    .astype(int)
                    .unique()
                    .tolist()
                )
                != list(range(5))
            )
        ):
            raise P104TaskError(f"fixed fold contract differs before fit: {outcome}")
    if args.task_family == "ablation_bundle":
        spec = base_specs[str(args.outcome)]
        feature_order = [str(value) for value in spec["feature_order"]]
        for name in ablation.ABLATIONS:
            ablation._groups(spec, feature_order, name)
    if args.sensitivity == "city_holdout" and any(
        column not in frame for column in CITY_COLUMNS
    ):
        raise P104TaskError("locked Stage1a artifact lacks city indicators before fit")


def _collect_scientific_bindings(
    args: argparse.Namespace,
) -> tuple[dict[str, str], dict[str, str], dict[str, str]]:
    registry_path = ROOT / "qa_v2" / "task_registry.json"
    extension_path = ROOT / "qa_v2" / "p1_04_execution_extension.json"
    extension = p1_04_execution_contract.load_extension(
        extension_path,
        registry_path=registry_path,
    )
    if args.task_id not in extension["task_commands"]:
        raise P104TaskError("task is not executable in the P1_04 extension")
    registry = read_json(registry_path)
    registry_tasks = [
        task for task in registry["tasks"] if task.get("task_id") == args.task_id
    ]
    if len(registry_tasks) != 1:
        raise P104TaskError("canonical registry task identity is not unique")
    registry_sha256 = sha256_file(registry_path)
    registry_task_sha256 = canonical_sha256(registry_tasks[0])
    runtime_registry_sha256 = os.environ.get(
        "P1_TASK_REGISTRY_SHA256", "LOCAL_UNBOUND"
    )
    runtime_task_sha256 = os.environ.get("P1_REGISTRY_TASK_SHA256", "LOCAL_UNBOUND")
    if not args.smoke and (
        runtime_registry_sha256 != registry_sha256
        or runtime_task_sha256 != registry_task_sha256
    ):
        raise P104TaskError("formal task lacks exact canonical registry runtime bindings")
    stage1a_dir = args.stage1a_dir.resolve()
    input_paths = {
        "features": stage1a_dir / "stage1a_features_le2024.parquet",
        "schema": stage1a_dir / "stage1a_schema_v2.json",
        "manifest": stage1a_dir / "stage1a_feature_manifest_v2.json",
        "fold_map": args.fold_map.resolve(),
        **{
            f"base_spec_{outcome}": _base_spec_path(args, outcome)
            for outcome in _binding_outcomes(args)
        },
    }
    if not args.smoke:
        required_sidecars: tuple[tuple[str, Path | None], ...] = ()
        if args.task_family == "ablation_bundle":
            required_sidecars = (
                ("sidecar_binding_manifest", args.sidecar_binding_manifest),
                ("ed_early_artifact", args.ed_early_artifact),
            )
        elif args.sensitivity == "age_subgroup":
            required_sidecars = (
                ("sidecar_binding_manifest", args.sidecar_binding_manifest),
                ("age_artifact", args.age_artifact),
            )
        elif args.sensitivity == "ed_congestion":
            required_sidecars = (
                ("sidecar_binding_manifest", args.sidecar_binding_manifest),
                ("congestion_artifact", args.congestion_artifact),
            )
        if any(path is None for _, path in required_sidecars):
            raise P104TaskError("formal task lacks its required sidecar hash bindings")
    for label, path in (
        ("sidecar_binding_manifest", args.sidecar_binding_manifest),
        ("ed_early_artifact", args.ed_early_artifact),
        ("age_artifact", args.age_artifact),
        ("congestion_artifact", args.congestion_artifact),
    ):
        if path is not None:
            input_paths[label] = path.resolve()
    if any(not path.is_file() for path in input_paths.values()):
        raise P104TaskError("a scientific input disappeared before task sealing")
    input_hashes = {label: sha256_file(path) for label, path in input_paths.items()}
    _validate_scientific_inputs(args, input_paths, input_hashes)
    code_hashes = {
        Path(__file__).name: sha256_file(Path(__file__).resolve()),
        Path(ablation.__file__).name: sha256_file(Path(ablation.__file__).resolve()),
        Path(p1_04_execution_contract.__file__).name: sha256_file(
            Path(p1_04_execution_contract.__file__).resolve()
        ),
    }
    base_hashes = {
        outcome: input_hashes[f"base_spec_{outcome}"]
        for outcome in _binding_outcomes(args)
    }
    scientific_hashes = {
        "data_sha256": input_hashes["features"],
        "feature_schema_sha256": input_hashes["schema"],
        "stage1a_manifest_sha256": input_hashes["manifest"],
        "fold_sha256": input_hashes["fold_map"],
        "task_registry_sha256": registry_sha256,
        "registry_task_sha256": registry_task_sha256,
        "runner_sha256": code_hashes[Path(__file__).name],
        "ablation_runner_sha256": code_hashes[Path(ablation.__file__).name],
        "execution_contract_sha256": code_hashes[
            Path(p1_04_execution_contract.__file__).name
        ],
        "execution_extension_sha256": sha256_file(extension_path),
        "locked_base_specs_sha256": canonical_sha256(base_hashes),
        "runtime_task_registry_binding": runtime_registry_sha256,
        "runtime_registry_task_binding": runtime_task_sha256,
    }
    return input_hashes, code_hashes, scientific_hashes


def _scientific_bindings(
    args: argparse.Namespace,
) -> tuple[dict[str, str], dict[str, str], dict[str, str], dict[str, Any] | None]:
    input_hashes, code_hashes, scientific_hashes = _collect_scientific_bindings(args)
    authorization = None
    if not args.smoke:
        authorization_path = getattr(args, "launch_authorization_overlay", None)
        if authorization_path is None:
            raise P104TaskError("formal launch authorization overlay is required")
        try:
            authorization = p1_04_execution_contract.validate_formal_authorization_overlay(
                authorization_path.resolve(),
                task_id=args.task_id,
                task_family=args.task_family,
                outcome=args.outcome,
                sensitivity=args.sensitivity,
                input_hashes=input_hashes,
                code_sha256=code_hashes,
                scientific_hashes=scientific_hashes,
            )
        except p1_04_execution_contract.ExecutionContractError as error:
            raise P104TaskError(str(error)) from error
    return input_hashes, code_hashes, scientific_hashes, authorization


def _coverage_summary(
    args: argparse.Namespace,
    predictions: pd.DataFrame,
) -> tuple[float, int, int]:
    source = pd.read_parquet(
        args.stage1a_dir.resolve() / "stage1a_features_le2024.parquet",
        columns=["row_hash", "split"],
    )
    split_map = {
        "oof_2020_2023": "train_2020_2023",
        "validation_2024": "validation_2024",
    }
    prediction_splits = sorted(set(predictions["split"].astype(str)))
    outcomes = sorted(set(predictions["outcome"].astype(str)))
    expected_parts = []
    for split in prediction_splits:
        rows = source.loc[source["split"].eq(split_map[split]), ["row_hash"]].copy()
        for outcome in outcomes:
            part = rows.copy()
            part["outcome"] = outcome
            part["split"] = split
            expected_parts.append(part)
    expected = pd.concat(expected_parts, ignore_index=True).drop_duplicates(
        ["row_hash", "outcome", "split"]
    )
    covered = predictions[["row_hash", "outcome", "split"]].drop_duplicates()
    merged = covered.merge(
        expected,
        on=["row_hash", "outcome", "split"],
        how="left",
        indicator=True,
        validate="one_to_one",
    )
    if merged["_merge"].ne("both").any() or expected.empty:
        raise P104TaskError("bundle predictions fall outside the covered cohort contract")
    return len(covered) / len(expected), len(covered), len(expected)


def _finalize(
    args: argparse.Namespace,
    staging: Path,
    predictions: pd.DataFrame,
    metrics: pd.DataFrame,
    detail: dict[str, Any],
    started: float,
    scientific_bindings: tuple[
        dict[str, str],
        dict[str, str],
        dict[str, str],
        dict[str, Any] | None,
    ],
) -> dict[str, Any]:
    prediction_columns = [
        "task_id",
        "row_hash",
        "outcome",
        "model",
        "split",
        "fold",
        "y_true",
        "prediction",
    ]
    predictions = predictions[prediction_columns].copy()
    valid_splits = {"oof_2020_2023", "validation_2024"}
    row_hash_ok = predictions["row_hash"].astype(str).str.fullmatch(
        r"[0-9a-fA-F]{64}"
    )
    fold_values = pd.to_numeric(predictions["fold"], errors="coerce")
    oof = predictions["split"].eq("oof_2020_2023")
    if (
        predictions.empty
        or set(predictions["task_id"].astype(str)) != {args.task_id}
        or not row_hash_ok.all()
        or not set(predictions["outcome"].astype(str)).issubset(OUTCOMES)
        or predictions["model"].astype(str).eq("").any()
        or not set(predictions["split"].astype(str)).issubset(valid_splits)
        or not predictions["y_true"].isin([0, 1]).all()
        or fold_values.loc[oof].isna().any()
        or not fold_values.loc[oof].between(0, 4).all()
        or fold_values.loc[~oof].notna().any()
        or predictions.duplicated(["row_hash", "outcome", "model", "split"]).any()
        or predictions["split"].astype(str).str.contains("2025").any()
        or not predictions["prediction"].between(0, 1).all()
        or not np.isfinite(predictions["prediction"]).all()
    ):
        raise P104TaskError("invalid strict-long bundle predictions")
    metrics = _bootstrap_cis(
        predictions,
        metrics,
        bootstrap_b=min(args.bootstrap_b, 50) if args.smoke else args.bootstrap_b,
        seed=args.seed,
    )
    metric_columns = [
        "task_id",
        "outcome",
        "model",
        "split",
        "metric",
        "value",
        "status",
        "n",
        "events",
        "lower_ci",
        "upper_ci",
    ]
    if set(metrics.columns) != set(metric_columns):
        raise P104TaskError("bundle metric schema mismatch")
    metrics = metrics[metric_columns]
    finite_columns = ["value", "lower_ci", "upper_ci"]
    finite_ok = all(
        np.isfinite(pd.to_numeric(metrics[column], errors="coerce").dropna()).all()
        for column in finite_columns
    )
    if (
        set(metrics["task_id"].astype(str)) != {args.task_id}
        or not set(metrics["outcome"].astype(str)).issubset(OUTCOMES)
        or not set(metrics["split"].astype(str)).issubset(valid_splits)
        or not metrics["status"].isin(["ESTIMATED", "NOT_ESTIMABLE"]).all()
        or pd.to_numeric(metrics["n"], errors="coerce").isna().any()
        or pd.to_numeric(metrics["events"], errors="coerce").isna().any()
        or (pd.to_numeric(metrics["n"]) < 0).any()
        or (pd.to_numeric(metrics["events"]) < 0).any()
        or (pd.to_numeric(metrics["events"]) > pd.to_numeric(metrics["n"])).any()
        or not finite_ok
        or metrics.duplicated(["outcome", "model", "split", "metric"]).any()
    ):
        raise P104TaskError("invalid bundle metrics")
    coverage = predictions[["row_hash", "outcome", "model", "split"]].copy()
    coverage["eligible"] = True
    if coverage.duplicated(["row_hash", "outcome", "model", "split"]).any():
        raise P104TaskError("duplicate bundle coverage rows")
    result_name = (
        "stage2b_ablation_results.csv"
        if args.task_family == "ablation_bundle"
        else "stage2b_sensitivity_results.csv"
    )
    input_hashes, code_hashes, scientific_hashes, authorization = scientific_bindings
    coverage_fraction, covered_cohort_rows, expected_cohort_rows = _coverage_summary(
        args, predictions
    )
    scientific_artifact = not args.smoke
    scientific_status = "SMOKE_PASS" if args.smoke else "PASS"
    authorization_binding = (
        None
        if authorization is None
        else {
            "authorization_sha256": authorization["authorization_sha256"],
            "file_sha256": sha256_file(args.launch_authorization_overlay.resolve()),
        }
    )
    predictions.to_parquet(staging / "predictions.parquet", index=False)
    metrics.to_parquet(staging / "metrics.parquet", index=False)
    coverage.to_parquet(staging / "coverage.parquet", index=False)
    _results_table(predictions, metrics).to_csv(staging / result_name, index=False, encoding="utf-8")
    spec = {
        "contract_version": "p1-v2-p1-04-task-bundle/1",
        "task_id": args.task_id,
        "stage": "P1_04",
        "wave": "W02",
        "task_family": args.task_family,
        "outcome": args.outcome,
        "sensitivity": args.sensitivity,
        "lineage": "all_comer_v2",
        "scientific_artifact": scientific_artifact,
        "promotion_allowed": scientific_artifact,
        "scientific_status": scientific_status,
        "smoke": args.smoke,
        "fold": args.fold,
        "seed": args.seed,
        "bootstrap_b": min(args.bootstrap_b, 50) if args.smoke else args.bootstrap_b,
        "strict_no_arrival_leakage": True,
        "historical_2025_exposure": True,
        "2025_access_count": 0,
        "p3_ett_status": "NOT_ESTIMABLE",
        "p3_ett_proxy_inference_used": False,
        "input_hashes": input_hashes,
        "code_sha256": code_hashes,
        "scientific_hashes": scientific_hashes,
        "formal_launch_authorization": authorization_binding,
        **detail,
    }
    atomic_json(staging / "spec.json", spec)
    artifact_hashes = {
        path.relative_to(staging).as_posix(): sha256_file(path)
        for path in sorted(staging.rglob("*"))
        if path.is_file()
        and path.relative_to(staging).as_posix()
        not in {"hashes.json", "task_manifest.json", "_SUCCESS.json"}
    }
    hashes = {
        "schema_version": "1.0",
        "contract_version": "p1-v2-p1-04-hash-inventory/1",
        "task_id": args.task_id,
        "input_hashes": input_hashes,
        "code_sha256": code_hashes,
        "scientific_hashes": scientific_hashes,
        "formal_launch_authorization": authorization_binding,
        "artifact_hashes": artifact_hashes,
    }
    atomic_json(staging / "hashes.json", hashes)
    manifest = {
        "task_id": args.task_id,
        "stage": "P1_04",
        "wave": "W02",
        "task_family": args.task_family,
        "status": "completed",
        "outcome": args.outcome,
        "model": None,
        "compute_target": "kaggle_gpu",
        "privacy_class": "deidentified_numeric",
        "estimated_gpu_hours": None,
        "required_artifacts": _required_artifacts(args.task_family, args.smoke),
        "contract_version": "p1-v2-p1-04-task-manifest/1",
        "scientific_status": scientific_status,
        "scientific_artifact": scientific_artifact,
        "promotion_allowed": scientific_artifact,
        "formal_success_schema": not args.smoke,
        "lineage": "all_comer_v2",
        "prediction_rows": len(predictions),
        "metric_rows": len(metrics),
        "coverage_rows": len(coverage),
        "coverage_fraction": coverage_fraction,
        "covered_cohort_rows": covered_cohort_rows,
        "expected_cohort_rows": expected_cohort_rows,
        "hash_inventory_sha256": sha256_file(staging / "hashes.json"),
        "scientific_hashes": scientific_hashes,
        "formal_launch_authorization": authorization_binding,
        "artifact_hashes": {
            name: sha256_file(staging / name)
            for name in ("predictions.parquet", "metrics.parquet", "coverage.parquet", "spec.json", result_name)
        },
        "strict_no_arrival_leakage": True,
        "historical_2025_exposure": True,
        "2025_access_count": 0,
        "p3_ett_status": "NOT_ESTIMABLE",
        "runtime_seconds": time.perf_counter() - started,
        "runtime": {"python": platform.python_version(), "platform": platform.platform()},
    }
    atomic_json(staging / "task_manifest.json", manifest)
    success = {
        "status": scientific_status,
        "task_id": args.task_id,
        "scientific_artifact": scientific_artifact,
        "promotion_allowed": scientific_artifact,
        "formal_success_schema": not args.smoke,
        "manifest_sha256": sha256_file(staging / "task_manifest.json"),
        "hashes_sha256": sha256_file(staging / "hashes.json"),
        "2025_access_count": 0,
    }
    success_name = "_SMOKE_PASS.json" if args.smoke else "_SUCCESS.json"
    atomic_json(staging / success_name, success)
    required = {*ROOT_ARTIFACTS, result_name, success_name}
    if not required.issubset(
        {path.name for path in staging.iterdir() if path.is_file()}
    ):
        raise P104TaskError("root task artifact set is incomplete")
    return success


def run_task(
    args: argparse.Namespace,
    *,
    component_runner: Callable[[argparse.Namespace], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    _task_identity(args)
    output_dir = args.output_dir.resolve()
    if output_dir.exists():
        raise P104TaskError(f"immutable task output already exists: {output_dir}")
    scientific_bindings = _scientific_bindings(args)
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    staging = output_dir.parent / f".{output_dir.name}.{uuid.uuid4().hex}.staging"
    staging.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    try:
        if args.task_family == "ablation_bundle":
            predictions, metrics, detail = _run_ablation_bundle(
                args,
                staging,
                component_runner or ablation.run_task,
            )
        else:
            predictions, metrics, detail = _run_sensitivity_bundle(args, staging)
        success = _finalize(
            args,
            staging,
            predictions,
            metrics,
            detail,
            started,
            scientific_bindings,
        )
        os.replace(staging, output_dir)
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise
    return success


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run one sealed EMT P1 v2 P1_04 task bundle")
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--task-family", choices=TASK_FAMILIES, required=True)
    parser.add_argument("--outcome", choices=OUTCOMES)
    parser.add_argument("--sensitivity", choices=SENSITIVITIES)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--stage1a-dir", type=Path, default=ROOT / "outputs" / "v2" / "stage1a")
    parser.add_argument("--fold-map", type=Path, default=ROOT / "qa_v2" / "fixed_group_folds_v2.parquet")
    parser.add_argument("--base-spec-dir", type=Path, required=True)
    parser.add_argument("--sidecar-binding-manifest", type=Path)
    parser.add_argument("--ed-early-artifact", type=Path)
    parser.add_argument("--age-artifact", type=Path)
    parser.add_argument("--congestion-artifact", type=Path)
    parser.add_argument("--launch-authorization-overlay", type=Path)
    parser.add_argument("--seed", type=int, default=20260710)
    parser.add_argument("--bootstrap-b", type=int, default=2000)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--fold", type=int, choices=range(5))
    return parser.parse_args(argv)


def main() -> int:
    print(json.dumps(run_task(parse_args()), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
