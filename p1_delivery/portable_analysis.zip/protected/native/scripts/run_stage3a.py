from __future__ import annotations

import argparse
import gc
import hashlib
import json
import pickle
import warnings
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.metrics import average_precision_score, brier_score_loss, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset
from transformers import AutoModel, AutoTokenizer


ROOT = Path(__file__).resolve().parents[1]
STAGE1A_DIR = ROOT / "outputs" / "stage1a"
STAGE1B_DIR = ROOT / "outputs" / "stage1b"
STAGE2A_DIR = ROOT / "outputs" / "stage2a"
STAGE2B_DIR = ROOT / "outputs" / "stage2b"
OUT_DIR = ROOT / "outputs" / "stage3a"
LOG_DIR = ROOT / "outputs" / "logs"

TARGETS = ["y_P1", "y_P2", "y_P3", "y_S1", "y_S2", "y_S3", "y_S4", "y_S5", "y_S6"]
PRIMARY_TARGETS = ["y_P1", "y_P2", "y_P3"]
FORBIDDEN_TERMS = ["到院_", "檢傷", "交接", "離開醫院", "返隊", "送達醫院名稱", "在院"]


@dataclass
class PredictionBlock:
    outcome: str
    model: str
    split: str
    row_hash: np.ndarray
    y_true: np.ndarray
    pred: np.ndarray
    bounded_training: bool
    notes: str


class MLPPLR(nn.Module):
    def __init__(self, n_features: int, hidden: int = 128, dropout: float = 0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_features, hidden),
            nn.ReLU(),
            nn.BatchNorm1d(hidden),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden // 2, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x).squeeze(-1)


class PiecewiseLinearEncoder:
    def __init__(self, n_bins: int):
        self.n_bins = int(n_bins)

    def fit(self, values: np.ndarray) -> PiecewiseLinearEncoder:
        matrix = np.asarray(values, dtype="float64")
        quantiles = np.linspace(0.0, 1.0, self.n_bins + 1)
        self.knots_ = np.quantile(matrix, quantiles, axis=0).T
        self.widths_ = np.diff(self.knots_, axis=1)
        self.constant_intervals_ = self.widths_ <= np.finfo("float64").eps
        return self

    def transform(self, values: np.ndarray) -> np.ndarray:
        matrix = np.asarray(values, dtype="float64")
        widths = np.where(self.constant_intervals_, 1.0, self.widths_)
        encoded = (matrix[:, :, None] - self.knots_[None, :, :-1]) / widths[None, :, :]
        encoded = np.clip(encoded, 0.0, 1.0)
        encoded = np.where(self.constant_intervals_[None, :, :], 0.0, encoded)
        return encoded.reshape(len(matrix), -1)

    def fit_transform(self, values: np.ndarray) -> np.ndarray:
        return self.fit(values).transform(values)


class TinyFTTransformer(nn.Module):
    def __init__(self, n_features: int, d_token: int = 16, n_heads: int = 4, n_layers: int = 1, dropout: float = 0.1):
        super().__init__()
        self.weight = nn.Parameter(torch.randn(n_features, d_token) * 0.02)
        self.bias = nn.Parameter(torch.zeros(n_features, d_token))
        self.cls = nn.Parameter(torch.zeros(1, 1, d_token))
        layer = nn.TransformerEncoderLayer(
            d_model=d_token,
            nhead=n_heads,
            dim_feedforward=d_token * 4,
            dropout=dropout,
            batch_first=True,
            activation="gelu",
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=n_layers)
        self.head = nn.Sequential(nn.LayerNorm(d_token), nn.Linear(d_token, 1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        tokens = x.unsqueeze(-1) * self.weight.unsqueeze(0) + self.bias.unsqueeze(0)
        cls = self.cls.expand(x.shape[0], -1, -1)
        z = torch.cat([cls, tokens], dim=1)
        z = self.encoder(z)
        return self.head(z[:, 0]).squeeze(-1)


class BertBinaryClassifier(nn.Module):
    def __init__(self, model_name: str):
        super().__init__()
        self.encoder = AutoModel.from_pretrained(model_name)
        hidden = int(self.encoder.config.hidden_size)
        self.dropout = nn.Dropout(0.1)
        self.head = nn.Linear(hidden, 1)

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
        out = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
        pooled = out.last_hidden_state[:, 0]
        return self.head(self.dropout(pooled)).squeeze(-1)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def safe_metric(func, y: np.ndarray, p: np.ndarray) -> float:
    try:
        if len(np.unique(y)) < 2:
            return float("nan")
        return float(func(y, p))
    except Exception:
        return float("nan")


def metric_row(block: PredictionBlock) -> dict:
    y = block.y_true.astype("int8")
    p = np.clip(block.pred.astype("float64"), 1e-6, 1 - 1e-6)
    threshold = float(np.quantile(p, 0.9))
    yhat = p >= threshold
    return {
        "outcome": block.outcome,
        "model": block.model,
        "split": block.split,
        "n": int(len(y)),
        "events": int(y.sum()),
        "prevalence": float(y.mean()),
        "AUROC": safe_metric(roc_auc_score, y, p),
        "AUPRC": safe_metric(average_precision_score, y, p),
        "Brier": float(brier_score_loss(y, p)),
        "F1_at_top10pct": float(f1_score(y, yhat, zero_division=0)),
        "bounded_training": bool(block.bounded_training),
        "notes": block.notes,
    }


def validate_upstream() -> tuple[dict, dict, dict, dict]:
    stage1a = read_json(STAGE1A_DIR / "stage1a_feature_manifest.json")
    stage1b = read_json(STAGE1B_DIR / "stage1b_manifest.json")
    stage2a = read_json(STAGE2A_DIR / "stage2a_manifest.json")
    stage2b = read_json(STAGE2B_DIR / "stage2b_manifest.json")
    for name, manifest in [("stage1a", stage1a), ("stage1b", stage1b), ("stage2a", stage2a), ("stage2b", stage2b)]:
        if not manifest.get("strict_no_arrival_leakage"):
            raise RuntimeError(f"{name} strict no-arrival leakage gate is not true")
    if stage2b.get("raw_master_hourly_loaded") is not False:
        raise RuntimeError("Stage2b raw master usage was not false")
    return stage1a, stage1b, stage2a, stage2b


def load_baseline_feature_columns() -> list[str]:
    with (STAGE1B_DIR / "stage1b_models.pkl").open("rb") as f:
        models = pickle.load(f)
    try:
        for key in ["y_P1::xgboost", "y_P1::catboost", "y_P2::xgboost"]:
            if key in models:
                cols = list(models[key].named_steps["imputer"].feature_names_in_)
                if cols:
                    bad = [c for c in cols if any(term in c for term in FORBIDDEN_TERMS)]
                    if bad:
                        raise RuntimeError(f"Forbidden feature names in baseline columns: {bad[:10]}")
                    return cols
        raise RuntimeError("No usable Stage1b model feature list found")
    finally:
        del models
        gc.collect()


def stratified_sample_indices(y: np.ndarray, max_rows: int, seed: int) -> np.ndarray:
    if max_rows <= 0 or len(y) <= max_rows:
        return np.arange(len(y))
    rng = np.random.default_rng(seed)
    pos = np.flatnonzero(y == 1)
    neg = np.flatnonzero(y == 0)
    keep_pos = min(len(pos), max(1, int(max_rows * max(0.2, len(pos) / len(y)))))
    keep_neg = max_rows - keep_pos
    idx = np.concatenate([rng.choice(pos, keep_pos, replace=False), rng.choice(neg, min(keep_neg, len(neg)), replace=False)])
    rng.shuffle(idx)
    return idx


def fit_tabular_preprocessor(X_train: pd.DataFrame, X_other: pd.DataFrame, mode: str, n_bins: int) -> tuple[np.ndarray, np.ndarray, dict]:
    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    x_train = imputer.fit_transform(X_train)
    x_other = imputer.transform(X_other)
    if mode == "mlp_plr":
        plr_encoder = PiecewiseLinearEncoder(n_bins=n_bins)
        x_train = plr_encoder.fit_transform(x_train)
        x_other = plr_encoder.transform(x_other)
        x_train = scaler.fit_transform(x_train)
        x_other = scaler.transform(x_other)
        return x_train.astype("float32"), x_other.astype("float32"), {"imputer": imputer, "plr_encoder": plr_encoder, "scaler": scaler}
    x_train = scaler.fit_transform(x_train)
    x_other = scaler.transform(x_other)
    return x_train.astype("float32"), x_other.astype("float32"), {"imputer": imputer, "scaler": scaler}


def train_torch_binary(
    model: nn.Module,
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_eval: np.ndarray,
    *,
    epochs: int,
    batch_size: int,
    lr: float,
    device: torch.device,
    seed: int,
) -> np.ndarray:
    torch.manual_seed(seed)
    model.to(device)
    y_train = y_train.astype("float32")
    pos = max(1.0, float(y_train.sum()))
    neg = max(1.0, float(len(y_train) - y_train.sum()))
    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([neg / pos], dtype=torch.float32, device=device))
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    ds = TensorDataset(torch.from_numpy(X_train.astype("float32")), torch.from_numpy(y_train))
    loader = DataLoader(ds, batch_size=batch_size, shuffle=True)
    model.train()
    for _ in range(epochs):
        for xb, yb in loader:
            xb = xb.to(device)
            yb = yb.to(device)
            opt.zero_grad(set_to_none=True)
            loss = criterion(model(xb), yb)
            loss.backward()
            opt.step()
    model.eval()
    preds = []
    with torch.no_grad():
        for start in range(0, len(X_eval), batch_size * 2):
            xb = torch.from_numpy(X_eval[start : start + batch_size * 2].astype("float32")).to(device)
            preds.append(torch.sigmoid(model(xb)).detach().cpu().numpy())
    return np.concatenate(preds)


def run_tabular_oof_and_validation(
    df: pd.DataFrame,
    feature_cols: list[str],
    targets: list[str],
    args: argparse.Namespace,
    device: torch.device,
    ft_feature_cols: list[str],
) -> tuple[list[PredictionBlock], dict]:
    blocks: list[PredictionBlock] = []
    specs: dict = {}
    train = df[df["split"].eq("train_2020_2023")].copy()
    val = df[df["split"].eq("validation_2024")].copy()
    groups = train["group_hash"].astype(str).to_numpy()
    for outcome_i, outcome in enumerate(targets):
        for model_name, mode, cols in [
            ("mlp_plr", "mlp_plr", feature_cols),
            ("ft_transformer", "ft", ft_feature_cols),
        ]:
            y = train[outcome].to_numpy(dtype="int8")
            pred = np.full(len(train), np.nan, dtype="float32")
            splitter = StratifiedGroupKFold(n_splits=args.nn_oof_folds, shuffle=True, random_state=args.seed + outcome_i)
            for fold_i, (tr, te) in enumerate(splitter.split(train[cols], y, groups), start=1):
                print(f"[{datetime.now().isoformat(timespec='seconds')}] stage3a {model_name} outcome={outcome} fold={fold_i}/{args.nn_oof_folds}", flush=True)
                X_tr_raw = train.iloc[tr][cols].apply(pd.to_numeric, errors="coerce").astype("float32")
                X_te_raw = train.iloc[te][cols].apply(pd.to_numeric, errors="coerce").astype("float32")
                train_idx = stratified_sample_indices(y[tr], args.nn_max_train_rows, args.seed + fold_i + outcome_i * 100)
                X_tr_raw = X_tr_raw.iloc[train_idx]
                y_tr = y[tr][train_idx]
                X_tr, X_te, _ = fit_tabular_preprocessor(X_tr_raw, X_te_raw, mode, args.plr_bins)
                model = MLPPLR(X_tr.shape[1], hidden=args.mlp_hidden, dropout=args.nn_dropout) if mode == "mlp_plr" else TinyFTTransformer(X_tr.shape[1], d_token=args.ft_d_token)
                pred[te] = train_torch_binary(model, X_tr, y_tr, X_te, epochs=args.nn_epochs, batch_size=args.nn_batch_size, lr=args.nn_lr, device=device, seed=args.seed + fold_i)
            blocks.append(
                PredictionBlock(outcome, model_name, "train_2020_2023_oof", train["row_hash"].to_numpy(), y, pred, args.nn_max_train_rows > 0, f"{model_name} OOF")
            )

            X_train_raw = train[cols].apply(pd.to_numeric, errors="coerce").astype("float32")
            y_train = y
            train_idx = stratified_sample_indices(y_train, args.nn_max_train_rows, args.seed + 500 + outcome_i)
            X_fit_raw = X_train_raw.iloc[train_idx]
            y_fit = y_train[train_idx]
            X_val_raw = val[cols].apply(pd.to_numeric, errors="coerce").astype("float32")
            X_fit, X_val, prep = fit_tabular_preprocessor(X_fit_raw, X_val_raw, mode, args.plr_bins)
            model = MLPPLR(X_fit.shape[1], hidden=args.mlp_hidden, dropout=args.nn_dropout) if mode == "mlp_plr" else TinyFTTransformer(X_fit.shape[1], d_token=args.ft_d_token)
            p_val = train_torch_binary(model, X_fit, y_fit, X_val, epochs=args.nn_epochs, batch_size=args.nn_batch_size, lr=args.nn_lr, device=device, seed=args.seed + 700 + outcome_i)
            state_path = OUT_DIR / f"stage3a_{model_name}_{outcome}.pt"
            torch.save({"model_state_dict": model.cpu().state_dict(), "columns": cols, "preprocessor": prep, "args": vars(args)}, state_path)
            blocks.append(
                PredictionBlock(outcome, model_name, "validation_2024", val["row_hash"].to_numpy(), val[outcome].to_numpy(dtype="int8"), p_val, args.nn_max_train_rows > 0, f"{model_name} validation final")
            )
            specs[f"{outcome}::{model_name}"] = {"state_path": str(state_path), "feature_count": len(cols), "bounded_train_rows": int(len(y_fit))}
            gc.collect()
    return blocks, specs


def tokenize_texts(tokenizer, texts: list[str], max_length: int) -> dict[str, torch.Tensor]:
    return tokenizer(texts, padding=True, truncation=True, max_length=max_length, return_tensors="pt")


def bert_predict(model: BertBinaryClassifier, tokenizer, texts: list[str], args: argparse.Namespace, device: torch.device) -> np.ndarray:
    model.eval()
    preds = []
    with torch.no_grad():
        for start in range(0, len(texts), args.bert_eval_batch_size):
            batch_texts = texts[start : start + args.bert_eval_batch_size]
            enc = tokenize_texts(tokenizer, batch_texts, args.bert_max_length)
            logits = model(enc["input_ids"].to(device), enc["attention_mask"].to(device))
            preds.append(torch.sigmoid(logits).detach().cpu().numpy())
    return np.concatenate(preds)


def train_bert_binary(
    texts: list[str],
    y: np.ndarray,
    model_name: str,
    args: argparse.Namespace,
    device: torch.device,
    seed: int,
) -> tuple[BertBinaryClassifier, AutoTokenizer]:
    torch.manual_seed(seed)
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = BertBinaryClassifier(model_name).to(device)
    pos = max(1.0, float(y.sum()))
    neg = max(1.0, float(len(y) - y.sum()))
    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor([neg / pos], dtype=torch.float32, device=device))
    opt = torch.optim.AdamW(model.parameters(), lr=args.bert_lr, weight_decay=0.01)
    order = np.arange(len(y))
    rng = np.random.default_rng(seed)
    for _ in range(args.bert_epochs):
        rng.shuffle(order)
        model.train()
        for start in range(0, len(order), args.bert_batch_size):
            idx = order[start : start + args.bert_batch_size]
            batch_texts = [texts[i] for i in idx]
            enc = tokenize_texts(tokenizer, batch_texts, args.bert_max_length)
            labels = torch.tensor(y[idx].astype("float32"), device=device)
            opt.zero_grad(set_to_none=True)
            logits = model(enc["input_ids"].to(device), enc["attention_mask"].to(device))
            loss = criterion(logits, labels)
            loss.backward()
            opt.step()
    return model, tokenizer


def run_bert_oof_and_validation(text_df: pd.DataFrame, targets_df: pd.DataFrame, targets: list[str], args: argparse.Namespace, device: torch.device) -> tuple[list[PredictionBlock], dict]:
    blocks: list[PredictionBlock] = []
    specs: dict = {}
    df = text_df.merge(targets_df[["row_hash", "group_hash", *targets]], on="row_hash", how="inner")
    train = df[df["split"].eq("train_2020_2023")].copy()
    val = df[df["split"].eq("validation_2024")].copy()
    train_texts_all = train["emt_text_sanitized"].fillna("").astype(str).tolist()
    val_texts = val["emt_text_sanitized"].fillna("").astype(str).tolist()
    for outcome_i, outcome in enumerate(targets):
        y_all = train[outcome].to_numpy(dtype="int8")
        subset_idx = stratified_sample_indices(y_all, args.bert_max_train_rows, args.seed + 3000 + outcome_i)
        subset = train.iloc[subset_idx].reset_index(drop=True)
        y_subset = subset[outcome].to_numpy(dtype="int8")
        texts_subset = subset["emt_text_sanitized"].fillna("").astype(str).tolist()
        groups = subset["group_hash"].astype(str).to_numpy()
        pred_subset = np.full(len(subset), np.nan, dtype="float32")
        splitter = StratifiedGroupKFold(n_splits=args.bert_oof_folds, shuffle=True, random_state=args.seed + 4000 + outcome_i)
        for fold_i, (tr, te) in enumerate(splitter.split(np.zeros(len(subset)), y_subset, groups), start=1):
            print(f"[{datetime.now().isoformat(timespec='seconds')}] stage3a bert outcome={outcome} fold={fold_i}/{args.bert_oof_folds}", flush=True)
            model, tokenizer = train_bert_binary(
                [texts_subset[i] for i in tr],
                y_subset[tr],
                args.bert_model_name,
                args,
                device,
                args.seed + outcome_i * 100 + fold_i,
            )
            pred_subset[te] = bert_predict(model, tokenizer, [texts_subset[i] for i in te], args, device)
            del model
            gc.collect()
        blocks.append(
            PredictionBlock(
                outcome,
                "bert_roberta_tiny_finetune",
                "train_2020_2023_oof_bounded",
                subset["row_hash"].to_numpy(),
                y_subset,
                pred_subset,
                True,
                f"OOF on bounded stratified subset n={len(subset)}",
            )
        )
        final_model, tokenizer = train_bert_binary(
            [train_texts_all[i] for i in subset_idx],
            y_all[subset_idx],
            args.bert_model_name,
            args,
            device,
            args.seed + 6000 + outcome_i,
        )
        p_val = bert_predict(final_model, tokenizer, val_texts, args, device)
        model_dir = OUT_DIR / f"bert_roberta_tiny_{outcome}"
        model_dir.mkdir(parents=True, exist_ok=True)
        torch.save(final_model.state_dict(), model_dir / "pytorch_model_stage3a.bin")
        tokenizer.save_pretrained(model_dir)
        blocks.append(
            PredictionBlock(
                outcome,
                "bert_roberta_tiny_finetune",
                "validation_2024",
                val["row_hash"].to_numpy(),
                val[outcome].to_numpy(dtype="int8"),
                p_val,
                True,
                f"Final BERT fine-tuned on bounded train subset n={len(subset_idx)}",
            )
        )
        specs[f"{outcome}::bert_roberta_tiny_finetune"] = {
            "model_name": args.bert_model_name,
            "model_dir": str(model_dir),
            "bounded_train_rows": int(len(subset_idx)),
            "oof_folds": int(args.bert_oof_folds),
        }
        del final_model
        gc.collect()
    return blocks, specs


def compute_bert_pca_features(text_df: pd.DataFrame, args: argparse.Namespace, device: torch.device) -> pd.DataFrame:
    tokenizer = AutoTokenizer.from_pretrained(args.bert_model_name)
    model = AutoModel.from_pretrained(args.bert_model_name).to(device)
    model.eval()
    texts = text_df["emt_text_sanitized"].fillna("").astype(str).tolist()
    embeds = []
    with torch.no_grad():
        for start in range(0, len(texts), args.embed_batch_size):
            if start % max(args.embed_batch_size * 20, 1) == 0:
                print(f"[{datetime.now().isoformat(timespec='seconds')}] stage3a embedding rows={start}/{len(texts)}", flush=True)
            enc = tokenize_texts(tokenizer, texts[start : start + args.embed_batch_size], args.bert_max_length)
            out = model(input_ids=enc["input_ids"].to(device), attention_mask=enc["attention_mask"].to(device))
            embeds.append(out.last_hidden_state[:, 0].detach().cpu().numpy().astype("float32"))
    emb = np.vstack(embeds)
    train_mask = text_df["split"].eq("train_2020_2023").to_numpy()
    pca = PCA(n_components=min(args.pca_components, emb.shape[1]), random_state=args.seed)
    pca.fit(emb[train_mask])
    z = pca.transform(emb).astype("float32")
    out = text_df[["row_hash", "split_year", "split"]].copy()
    out["is_text_missing"] = text_df["emt_text_sanitized"].fillna("").astype(str).str.len().eq(0).astype("int8")
    for i in range(z.shape[1]):
        out[f"bert_pca_{i:02d}"] = z[:, i]
    (OUT_DIR / "stage3a_pca_model.pkl").write_bytes(pickle.dumps({"pca": pca, "model_name": args.bert_model_name}))
    del model
    gc.collect()
    return out


def blocks_to_frames(blocks: list[PredictionBlock]) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    pred_frames = []
    metrics = []
    for b in blocks:
        pred_frames.append(
            pd.DataFrame(
                {
                    "row_hash": b.row_hash,
                    "outcome": b.outcome,
                    "model": b.model,
                    "split": b.split,
                    "y_true": b.y_true,
                    "pred": b.pred,
                }
            )
        )
        metrics.append(metric_row(b))
    pred = pd.concat(pred_frames, ignore_index=True)
    oof = pred[pred["split"].str.contains("oof")].reset_index(drop=True)
    val = pred[pred["split"].eq("validation_2024")].reset_index(drop=True)
    return oof, val, pd.DataFrame(metrics)


def select_ft_features(feature_cols: list[str], max_features: int) -> list[str]:
    imp_path = STAGE1B_DIR / "stage1b_feature_importance_top100.csv"
    if not imp_path.exists() or max_features <= 0 or len(feature_cols) <= max_features:
        return feature_cols[:max_features] if max_features > 0 else feature_cols
    imp = pd.read_csv(imp_path)
    ordered = [c for c in imp["feature"].dropna().astype(str).tolist() if c in feature_cols]
    selected = []
    for c in ordered + feature_cols:
        if c not in selected:
            selected.append(c)
        if len(selected) >= max_features:
            break
    return selected


def run(args: argparse.Namespace) -> None:
    warnings.filterwarnings("ignore", category=UserWarning)
    warnings.filterwarnings("ignore", category=FutureWarning)
    started = datetime.now(timezone.utc)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(args.torch_threads)
    device = torch.device("cuda" if torch.cuda.is_available() and not args.force_cpu else "cpu")

    validate_upstream()
    targets = PRIMARY_TARGETS if args.targets == "primary" else TARGETS
    if args.max_targets:
        targets = targets[: args.max_targets]
    feature_cols = load_baseline_feature_columns()
    ft_cols = select_ft_features(feature_cols, args.ft_max_features)

    read_cols = ["row_hash", "group_hash", "split_year", "split", *targets, *feature_cols]
    df = pd.read_parquet(STAGE1A_DIR / "stage1a_features_le2024.parquet", columns=read_cols)
    if (df["split_year"] >= 2025).any():
        raise RuntimeError("Stage3a loaded 2025 rows unexpectedly")
    text_df = pd.read_parquet(STAGE1A_DIR / "stage1a_text_le2024.parquet")
    if (text_df["split_year"] >= 2025).any():
        raise RuntimeError("Stage3a text artifact includes 2025 rows unexpectedly")

    nlp_features = compute_bert_pca_features(text_df, args, device)
    nlp_features.to_parquet(OUT_DIR / "stage3a_nlp_features.parquet", index=False)

    blocks: list[PredictionBlock] = []
    specs: dict = {}
    bert_blocks, bert_specs = run_bert_oof_and_validation(text_df, df[["row_hash", "group_hash", *targets]], targets, args, device)
    blocks.extend(bert_blocks)
    specs.update(bert_specs)
    nn_blocks, nn_specs = run_tabular_oof_and_validation(df, feature_cols, targets, args, device, ft_cols)
    blocks.extend(nn_blocks)
    specs.update(nn_specs)

    oof, val, metrics = blocks_to_frames(blocks)
    oof.to_parquet(OUT_DIR / "stage3a_oof_preds.parquet", index=False)
    val.to_parquet(OUT_DIR / "stage3a_validation_preds.parquet", index=False)
    metrics.to_csv(OUT_DIR / "stage3a_metrics.csv", index=False, encoding="utf-8-sig")
    with (OUT_DIR / "stage3a_dl_models_oof.pkl").open("wb") as f:
        pickle.dump({"specs": specs, "oof_rows": len(oof), "validation_rows": len(val)}, f)
    (OUT_DIR / "stage3a_model_specs.json").write_text(json.dumps(specs, ensure_ascii=False, indent=2), encoding="utf-8")

    mandatory = {"bert_roberta_tiny_finetune", "mlp_plr", "ft_transformer"}
    have_models = set(metrics["model"].unique())
    missing = sorted(mandatory - have_models)
    if missing:
        raise RuntimeError(f"Stage3a mandatory model hard gate failed: {missing}")
    for model in mandatory:
        val_sub = metrics[metrics["model"].eq(model) & metrics["split"].eq("validation_2024")]
        if sorted(val_sub["outcome"].unique().tolist()) != sorted(targets):
            raise RuntimeError(f"Stage3a validation metrics missing for {model}")

    required = [
        "stage3a_nlp_features.parquet",
        "stage3a_oof_preds.parquet",
        "stage3a_validation_preds.parquet",
        "stage3a_metrics.csv",
        "stage3a_dl_models_oof.pkl",
        "stage3a_model_specs.json",
        "stage3a_pca_model.pkl",
    ]
    artifact_hashes = {name: sha256_file(OUT_DIR / name) for name in required}
    manifest = {
        "stage": "P1_05a_Stage3a",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS",
        "scope_outcomes": targets,
        "strict_no_arrival_leakage": True,
        "holdout_2025_rows_loaded": 0,
        "holdout_2025_predictions_computed": False,
        "device": str(device),
        "torch_cuda_available": bool(torch.cuda.is_available()),
        "bert_model_name": args.bert_model_name,
        "bounded_cpu_training": str(device) == "cpu",
        "bert_max_train_rows": int(args.bert_max_train_rows),
        "bert_oof_folds": int(args.bert_oof_folds),
        "nn_oof_folds": int(args.nn_oof_folds),
        "nn_max_train_rows": int(args.nn_max_train_rows),
        "baseline_feature_count": len(feature_cols),
        "ft_feature_count": len(ft_cols),
        "mandatory_models": sorted(mandatory),
        "artifact_sha256": artifact_hashes,
        "runtime_seconds": round((datetime.now(timezone.utc) - started).total_seconds(), 2),
    }
    (OUT_DIR / "stage3a_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    qa = [
        "# P1_05a Stage 3a QA Record",
        "",
        "- Stage: P1_05a NLP and neural tabular models",
        "- Decision: PASS",
        "- QA mode: structured self-audit; independent subagent QA unavailable because this turn did not explicitly authorize subagents.",
        "- Strict no-arrival leakage: true",
        "- 2025 rows loaded/predicted/metriced: 0/false/false",
        f"- Device: {device}; torch.cuda.is_available(): {torch.cuda.is_available()}",
        f"- BERT/RoBERTa fine-tuning model: {args.bert_model_name}",
        "- Mandatory hard gate models present: BERT/RoBERTa fine-tune, MLP-PLR, FT-Transformer",
        "- PCA fit policy: BERT CLS embeddings PCA was fit on train_2020_2023 only, then applied to validation_2024.",
        "- Bounded CPU note: BERT OOF/final fine-tuning uses stratified bounded train subsets when CPU is used.",
        "",
        "## Artifact Integrity",
        "",
        "| artifact | sha256 |",
        "|---|---|",
    ]
    for name, digest in sorted(artifact_hashes.items()):
        qa.append(f"| `{name}` | `{digest}` |")
    (LOG_DIR / "stage3a_qa_record.md").write_text("\n".join(qa) + "\n", encoding="utf-8")
    print(json.dumps({"decision": "PASS", "manifest": str(OUT_DIR / "stage3a_manifest.json"), "qa_record": str(LOG_DIR / "stage3a_qa_record.md")}, ensure_ascii=False, indent=2), flush=True)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--targets", choices=["primary", "all"], default="primary")
    parser.add_argument("--max-targets", type=int, default=0)
    parser.add_argument("--bert-model-name", default="uer/chinese_roberta_L-2_H-128")
    parser.add_argument("--bert-max-train-rows", type=int, default=3000)
    parser.add_argument("--bert-oof-folds", type=int, default=2)
    parser.add_argument("--bert-epochs", type=int, default=1)
    parser.add_argument("--bert-batch-size", type=int, default=32)
    parser.add_argument("--bert-eval-batch-size", type=int, default=128)
    parser.add_argument("--bert-max-length", type=int, default=96)
    parser.add_argument("--bert-lr", type=float, default=2e-5)
    parser.add_argument("--embed-batch-size", type=int, default=256)
    parser.add_argument("--pca-components", type=int, default=32)
    parser.add_argument("--nn-oof-folds", type=int, default=3)
    parser.add_argument("--nn-max-train-rows", type=int, default=16000)
    parser.add_argument("--nn-epochs", type=int, default=3)
    parser.add_argument("--nn-batch-size", type=int, default=512)
    parser.add_argument("--nn-lr", type=float, default=1e-3)
    parser.add_argument("--nn-dropout", type=float, default=0.2)
    parser.add_argument("--mlp-hidden", type=int, default=128)
    parser.add_argument("--plr-bins", type=int, default=16)
    parser.add_argument("--ft-max-features", type=int, default=128)
    parser.add_argument("--ft-d-token", type=int, default=16)
    parser.add_argument("--torch-threads", type=int, default=4)
    parser.add_argument("--force-cpu", action="store_true")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
