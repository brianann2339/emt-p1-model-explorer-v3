from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.experimental import enable_iterative_imputer  # noqa: F401
from sklearn.impute import IterativeImputer, KNNImputer, SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.utils import check_random_state
from sklearn.utils.validation import check_is_fitted


if __name__.startswith("scripts."):
    sys.modules.setdefault("p1_v2_score_recompute", sys.modules[__name__])


PASSIVE_SCORE_VALUE_COLUMNS = (
    "MAP",
    "SI",
    "mSI",
    "aSI",
    "rSI",
    "rSIG",
    "rSIG_Age",
    "SI_G",
    "SIA_G",
    "SIAVPU",
    "sMS",
    "rSI_sMS",
    "rSI_GCS",
    "rSI_GCSM",
    "qSOFA",
    "NEWS2",
    "MEWS",
    "REMS",
    "RTS",
)
MODEL_OUTPUT_EXCLUDED_SCORE_ALIASES = {"rSI_GCS": "rSIG"}
MODEL_OUTPUT_EXCLUDED_FEATURES = ("rSI_GCS", "MISS_rSI_GCS")
SCORE_FORMULA_VERSION = "p1-v2-score-formulas/2"
SCORE_COMPONENT_BOUNDS = {
    "EMT_年齡": (18.0, 115.0),
    "prehosp_sbp": (40.0, 300.0),
    "prehosp_dbp": (20.0, 200.0),
    "prehosp_hr": (0.0, 250.0),
    "prehosp_rr": (0.0, 60.0),
    "prehosp_spo2": (50.0, 100.0),
    "prehosp_bt": (25.0, 43.0),
    "prehosp_gcs": (3.0, 15.0),
    "prehosp_gcs_m": (1.0, 6.0),
    "EMT_現場_意識_AVPU": (1.0, 4.0),
    "has_oxygen": (0.0, 1.0),
}
DISCRETE_SCORE_COMPONENTS = (
    "prehosp_gcs",
    "prehosp_gcs_m",
    "EMT_現場_意識_AVPU",
    "has_oxygen",
)
SCORE_BASE_COMPONENT_COLUMNS = (
    "EMT_年齡",
    "prehosp_sbp",
    "prehosp_dbp",
    "prehosp_hr",
    "prehosp_rr",
    "prehosp_spo2",
    "prehosp_bt",
    "prehosp_gcs",
    "prehosp_gcs_m",
    "EMT_現場_意識_AVPU",
    "has_oxygen",
)
COMPLETE_SCORE_COMPONENTS = {
    "NEWS2": ["prehosp_rr", "prehosp_spo2", "prehosp_bt", "prehosp_sbp", "prehosp_hr", "consciousness", "has_oxygen"],
    "MEWS": ["prehosp_rr", "prehosp_bt", "prehosp_sbp", "prehosp_hr", "EMT_現場_意識_AVPU"],
    "REMS": ["EMT_年齡", "MAP", "prehosp_hr", "prehosp_rr", "prehosp_spo2", "prehosp_gcs"],
    "RTS": ["prehosp_gcs", "prehosp_sbp", "prehosp_rr"],
    "qSOFA": ["prehosp_rr", "prehosp_sbp", "consciousness"],
}
SCORE_VALUE_REQUIRED_COMPONENTS = {
    "MAP": ("prehosp_sbp", "prehosp_dbp"),
    "SI": ("prehosp_hr", "prehosp_sbp"),
    "mSI": ("prehosp_hr", "prehosp_sbp", "prehosp_dbp"),
    "aSI": ("EMT_年齡", "prehosp_hr", "prehosp_sbp"),
    "rSI": ("prehosp_sbp", "prehosp_hr"),
    "rSIG": ("prehosp_sbp", "prehosp_hr", "prehosp_gcs"),
    "rSIG_Age": ("prehosp_sbp", "prehosp_hr", "prehosp_gcs", "EMT_年齡"),
    "SI_G": ("prehosp_hr", "prehosp_sbp", "prehosp_gcs"),
    "SIA_G": ("prehosp_hr", "prehosp_sbp", "EMT_年齡", "prehosp_gcs"),
    "SIAVPU": ("prehosp_hr", "prehosp_sbp", "EMT_現場_意識_AVPU"),
    "sMS": ("prehosp_gcs_m",),
    "rSI_sMS": ("prehosp_gcs_m", "prehosp_hr", "prehosp_sbp"),
    "rSI_GCS": ("prehosp_gcs", "prehosp_hr", "prehosp_sbp"),
    "rSI_GCSM": ("prehosp_sbp", "prehosp_hr", "prehosp_gcs_m"),
    "qSOFA": ("prehosp_rr", "prehosp_sbp"),
    "NEWS2": ("prehosp_rr", "prehosp_spo2", "prehosp_bt", "prehosp_sbp", "prehosp_hr", "has_oxygen"),
    "MEWS": ("prehosp_rr", "prehosp_bt", "prehosp_sbp", "prehosp_hr", "EMT_現場_意識_AVPU"),
    "REMS": ("EMT_年齡", "prehosp_sbp", "prehosp_dbp", "prehosp_hr", "prehosp_rr", "prehosp_spo2", "prehosp_gcs"),
    "RTS": ("prehosp_gcs", "prehosp_sbp", "prehosp_rr"),
}
FORMULA_EQUIVALENCE_CANARY_COMPONENTS = {
    "EMT_年齡": [40.0, 70.0, 45.0, 50.0, 60.0],
    "prehosp_sbp": [120.0, 90.0, 91.0, 100.0, None],
    "prehosp_dbp": [80.0, 60.0, 50.0, 70.0, 80.0],
    "prehosp_hr": [80.0, 110.0, 41.0, 0.0, 90.0],
    "prehosp_rr": [16.0, 24.0, 9.0, 22.0, 16.0],
    "prehosp_spo2": [98.0, 92.0, 92.0, 95.0, 98.0],
    "prehosp_bt": [37.0, 38.6, 35.1, 36.0, 37.0],
    "prehosp_gcs": [15.0, 11.0, 5.0, 14.0, 15.0],
    "prehosp_gcs_m": [6.0, 4.0, 5.0, 6.0, 6.0],
    "EMT_現場_意識_AVPU": [4.0, 2.0, 3.0, 4.0, 4.0],
    "has_oxygen": [0.0, 1.0, 0.0, 1.0, 0.0],
}
FORMULA_EQUIVALENCE_EXPECTED = {
    "MAP": [93.33333333333333, 70.0, 63.666666666666664, 80.0, None],
    "SI": [0.6666666666666666, 1.2222222222222223, 0.45054945054945056, 0.0, None],
    "mSI": [0.8571428571428572, 1.5714285714285714, 0.6439790575916231, 0.0, None],
    "aSI": [26.666666666666664, 85.55555555555556, 20.274725274725274, 0.0, None],
    "rSI": [1.5, 0.8181818181818182, 2.2195121951219514, None, None],
    "rSIG": [22.5, 9.0, 11.097560975609756, None, None],
    "rSIG_Age": [0.5625, 0.12857142857142856, 0.24661246612466126, None, None],
    "SI_G": [0.04444444444444444, 0.11111111111111112, 0.09010989010989011, 0.0, None],
    "SIA_G": [1.7777777777777777, 7.777777777777778, 4.054945054945055, 0.0, None],
    "SIAVPU": [2.6666666666666665, 2.4444444444444446, 1.3516483516483517, 0.0, None],
    "sMS": [3.0, 1.0, 2.0, 3.0, 3.0],
    "rSI_sMS": [4.5, 0.8181818181818181, 4.439024390243902, None, None],
    "rSI_GCS": [22.5, 9.0, 11.097560975609756, None, None],
    "rSI_GCSM": [9.0, 3.272727272727273, 11.097560975609756, None, None],
    "qSOFA": [0.0, 3.0, 2.0, 3.0, None],
    "NEWS2": [0.0, 14.0, 10.0, 14.0, None],
    "MEWS": [1.0, 8.0, 3.0, 5.0, None],
    "REMS": [0.0, 8.0, 12.0, 6.0, None],
    "RTS": [7.8408, 6.904, 4.4488, 7.8408, None],
}


def _numeric_series(frame: pd.DataFrame, name: str) -> pd.Series:
    if name not in frame:
        return pd.Series(np.nan, index=frame.index, dtype="float64")
    return pd.to_numeric(frame[name], errors="coerce").astype("float64")


def _safe_div(numerator: pd.Series, denominator: pd.Series) -> pd.Series:
    return numerator / denominator.replace(0, np.nan)


def _score_by_cutpoints(values: pd.Series, cutpoints: list[float], scores: list[int]) -> pd.Series:
    bins = [-math.inf, *cutpoints, math.inf]
    categories = pd.cut(values, bins=bins, labels=False, right=False)
    return categories.map(dict(enumerate(scores))).astype("float64")


def compute_score_values_v2(features: pd.DataFrame) -> pd.DataFrame:
    age = _numeric_series(features, "EMT_年齡")
    sbp = _numeric_series(features, "prehosp_sbp")
    dbp = _numeric_series(features, "prehosp_dbp")
    hr = _numeric_series(features, "prehosp_hr")
    rr = _numeric_series(features, "prehosp_rr")
    spo2 = _numeric_series(features, "prehosp_spo2")
    bt = _numeric_series(features, "prehosp_bt")
    gcs = _numeric_series(features, "prehosp_gcs")
    gcs_m = _numeric_series(features, "prehosp_gcs_m")
    avpu = _numeric_series(features, "EMT_現場_意識_AVPU")
    oxygen = _numeric_series(features, "has_oxygen")
    map_value = (sbp + 2 * dbp) / 3
    si = _safe_div(hr, sbp)
    sms = pd.Series(np.nan, index=features.index, dtype="float64")
    sms = sms.mask(gcs_m.eq(6), 3).mask(gcs_m.eq(5), 2).mask(gcs_m.le(4), 1)
    consciousness_observed = gcs.notna() | avpu.notna()
    consciousness_abnormal = (
        (gcs.lt(15) & gcs.notna()) | (avpu.lt(4) & avpu.notna())
    ).astype("float64").where(consciousness_observed)

    values = pd.DataFrame(
        {
            "MAP": map_value,
            "SI": si,
            "mSI": _safe_div(hr, map_value),
            "aSI": age * si,
            "rSI": _safe_div(sbp, hr),
            "rSIG": _safe_div(sbp, hr) * gcs,
            "rSIG_Age": _safe_div(_safe_div(sbp, hr) * gcs, age),
            "SI_G": _safe_div(si, gcs),
            "SIA_G": _safe_div(si * age, gcs),
            "SIAVPU": si * avpu,
            "sMS": sms,
            "rSI_sMS": _safe_div(sms, si),
            "rSI_GCS": _safe_div(gcs, si),
            "rSI_GCSM": _safe_div(sbp, hr) * gcs_m,
        },
        index=features.index,
    )

    qsofa_components = [rr, sbp, consciousness_abnormal]
    values["qSOFA"] = (
        rr.ge(22).astype("float64")
        + sbp.le(100).astype("float64")
        + consciousness_abnormal.fillna(0)
    ).where(pd.concat(qsofa_components, axis=1).notna().all(axis=1))

    news_components = [rr, spo2, bt, sbp, hr, consciousness_abnormal, oxygen]
    values["NEWS2"] = (
        _score_by_cutpoints(rr, [9, 12, 21, 25], [3, 1, 0, 2, 3])
        + _score_by_cutpoints(spo2, [92, 94, 96], [3, 2, 1, 0])
        + _score_by_cutpoints(bt, [35.1, 36.1, 38.1, 39.1], [3, 1, 0, 1, 2])
        + _score_by_cutpoints(sbp, [91, 101, 111, 220], [3, 2, 1, 0, 3])
        + _score_by_cutpoints(hr, [41, 51, 91, 111, 131], [3, 1, 0, 1, 2, 3])
        + consciousness_abnormal * 3
        + oxygen * 2
    ).where(pd.concat(news_components, axis=1).notna().all(axis=1))

    mews_components = [rr, bt, sbp, hr, avpu]
    values["MEWS"] = (
        _score_by_cutpoints(rr, [9, 15, 21, 30], [3, 0, 1, 2, 3])
        + _score_by_cutpoints(bt, [35.1, 38.5], [2, 0, 2])
        + _score_by_cutpoints(sbp, [71, 81, 101, 200], [3, 2, 1, 0, 2])
        + _score_by_cutpoints(hr, [41, 51, 101, 111, 130], [2, 1, 0, 1, 2, 3])
        + (4 - avpu).clip(lower=0, upper=3)
    ).where(pd.concat(mews_components, axis=1).notna().all(axis=1))

    rems_components = [age, map_value, hr, rr, spo2, gcs]
    values["REMS"] = (
        _score_by_cutpoints(age, [45, 55, 65, 75], [0, 2, 3, 5, 6])
        + _score_by_cutpoints(map_value, [50, 70, 110, 130, 160], [4, 2, 0, 2, 3, 4])
        + _score_by_cutpoints(hr, [40, 55, 70, 110, 140, 180], [4, 3, 2, 0, 2, 3, 4])
        + _score_by_cutpoints(rr, [6, 10, 12, 25, 35, 50], [4, 2, 1, 0, 1, 3, 4])
        + _score_by_cutpoints(spo2, [76, 86, 90], [4, 3, 1, 0])
        + _score_by_cutpoints(gcs, [5, 8, 11, 14], [4, 3, 2, 1, 0])
    ).where(pd.concat(rems_components, axis=1).notna().all(axis=1))

    rts_components = [gcs, sbp, rr]
    values["RTS"] = (
        0.9368 * _score_by_cutpoints(gcs, [4, 6, 9, 13], [0, 1, 2, 3, 4])
        + 0.7326 * _score_by_cutpoints(sbp, [1, 50, 76, 90], [0, 1, 2, 3, 4])
        + 0.2908 * _score_by_cutpoints(rr, [1, 6, 10, 30], [0, 1, 2, 4, 3])
    ).where(pd.concat(rts_components, axis=1).notna().all(axis=1))
    return values.loc[:, PASSIVE_SCORE_VALUE_COLUMNS].replace([np.inf, -np.inf], np.nan)


def score_formula_sha256() -> str:
    return hashlib.sha256(Path(__file__).resolve().read_bytes()).hexdigest()


def _canonical_sha256(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def recomputable_score_columns(feature_names: tuple[str, ...] | list[str]) -> tuple[str, ...]:
    available = set(feature_names)
    result = []
    for score in PASSIVE_SCORE_VALUE_COLUMNS:
        required = set(SCORE_VALUE_REQUIRED_COMPONENTS[score])
        if not required.issubset(available):
            continue
        if score in {"qSOFA", "NEWS2"} and not ({"prehosp_gcs", "EMT_現場_意識_AVPU"} & available):
            continue
        result.append(score)
    return tuple(result)


def passive_score_recompute_contract() -> dict[str, Any]:
    return {
        "enabled": True,
        "formula_source": "p1_v2_score_recompute.compute_score_values_v2",
        "formula_version": SCORE_FORMULA_VERSION,
        "formula_sha256": score_formula_sha256(),
        "passive_score_value_columns": list(PASSIVE_SCORE_VALUE_COLUMNS),
        "all_19_passive_score_values_required": True,
        "all_19_passive_score_values_recomputed_and_attested": True,
        "model_output_excluded_score_aliases": MODEL_OUTPUT_EXCLUDED_SCORE_ALIASES,
        "model_output_excluded_features": list(MODEL_OUTPUT_EXCLUDED_FEATURES),
        "base_component_columns": list(SCORE_BASE_COMPONENT_COLUMNS),
        "direct_score_value_imputation": False,
        "original_missingness_availability_counts_preserved": True,
        "fit_scope": "training_fold_only_then_final_2020_2023",
        "ordinal_projection": {
            "prehosp_gcs": [3, 15],
            "EMT_現場_意識_AVPU": [1, 4],
            "prehosp_gcs_m": [1, 6],
        },
        "binary_component_imputation": {"has_oxygen": "training_fold_mode"},
        "component_projection_bounds": {
            name: [lower, upper]
            for name, (lower, upper) in SCORE_COMPONENT_BOUNDS.items()
        },
        "direct_score_imputation_for_missing_components": False,
        "residual_mathematical_undefined_imputation": "fold_local_median_after_passive_recompute",
        "undefined_score_indicators": [
            f"UNDEFINED_SCORE_{name}" for name in PASSIVE_SCORE_VALUE_COLUMNS
        ],
        "tree_native_residual_policy": "retain_nan_plus_undefined_indicator",
        "NEWS2_variant": "SpO2_scale_1_with_prehospital_oxygen_proxy",
        "generic_airway_adjunct_counts_as_supplemental_oxygen": False,
        "prehosp_dbp_source_policy": "ambulance_dbp_only",
    }


def passive_score_spec_sha256() -> str:
    return _canonical_sha256(passive_score_recompute_contract())


def formula_equivalence_evidence(tolerance: float = 1e-12) -> dict[str, Any]:
    actual = compute_score_values_v2(
        pd.DataFrame(FORMULA_EQUIVALENCE_CANARY_COMPONENTS)
    )
    expected = pd.DataFrame(FORMULA_EQUIVALENCE_EXPECTED).loc[
        :, PASSIVE_SCORE_VALUE_COLUMNS
    ]
    finite_actual = np.isfinite(actual.to_numpy(dtype=float))
    finite_expected = np.isfinite(expected.to_numpy(dtype=float))
    missingness_mismatch_count = int(np.not_equal(finite_actual, finite_expected).sum())
    error = (actual - expected).abs()
    per_score = {}
    for name in PASSIVE_SCORE_VALUE_COLUMNS:
        finite = error[name].dropna()
        per_score[name] = float(finite.max()) if len(finite) else 0.0
    maximum_error = max(per_score.values(), default=0.0)
    evidence = {
        "status": (
            "PASS"
            if maximum_error <= tolerance and missingness_mismatch_count == 0
            else "FAIL"
        ),
        "method": "locked_normal_boundary_hr_zero_and_missing_component_vectors_against_all_19_authoritative_outputs",
        "formula_sha256": score_formula_sha256(),
        "passive_score_spec_sha256": passive_score_spec_sha256(),
        "score_count": len(PASSIVE_SCORE_VALUE_COLUMNS),
        "score_names": list(PASSIVE_SCORE_VALUE_COLUMNS),
        "canary_component_sha256": _canonical_sha256(
            FORMULA_EQUIVALENCE_CANARY_COMPONENTS
        ),
        "locked_expected_sha256": _canonical_sha256(FORMULA_EQUIVALENCE_EXPECTED),
        "per_score_maximum_absolute_error": per_score,
        "maximum_absolute_error": maximum_error,
        "missingness_mismatch_count": missingness_mismatch_count,
        "tolerance": tolerance,
    }
    evidence["evidence_sha256"] = _canonical_sha256(evidence)
    return evidence


class PassiveScoreRecomputeTransformer(BaseEstimator, TransformerMixin):
    def __init__(
        self,
        feature_names: tuple[str, ...],
        strategy: str = "median",
        add_indicator: bool = True,
        continuous_features: tuple[str, ...] = (),
        core_features: tuple[str, ...] = (),
        delta: float = 0.0,
        random_state: int | None = None,
        max_iter: int = 10,
        n_nearest_features: int = 5,
    ) -> None:
        self.feature_names = feature_names
        self.strategy = strategy
        self.add_indicator = add_indicator
        self.continuous_features = continuous_features
        self.core_features = core_features
        self.delta = delta
        self.random_state = random_state
        self.max_iter = max_iter
        self.n_nearest_features = n_nearest_features

    def _frame(self, X: Any) -> pd.DataFrame:
        if isinstance(X, pd.DataFrame):
            missing = sorted(set(self.feature_names) - set(X.columns))
            if missing:
                raise ValueError(f"score recompute input lacks features: {missing[:20]}")
            frame = X.loc[:, self.feature_names].copy()
        else:
            values = np.asarray(X)
            if values.ndim != 2 or values.shape[1] != len(self.feature_names):
                raise ValueError("score recompute input shape differs from feature_names")
            frame = pd.DataFrame(values, columns=self.feature_names)
        return frame.apply(pd.to_numeric, errors="coerce")

    def fit(self, X: Any, y: Any = None) -> "PassiveScoreRecomputeTransformer":
        frame = self._frame(X)
        self.n_features_in_ = len(self.feature_names)
        self.feature_names_in_ = np.asarray(self.feature_names, dtype=object)
        passive = set(PASSIVE_SCORE_VALUE_COLUMNS)
        present_passive = passive & set(self.feature_names)
        if present_passive != passive:
            missing = sorted(passive - present_passive)
            raise ValueError(f"all 19 passive score values are required: {missing}")
        recomputable = set(recomputable_score_columns(self.feature_names))
        if recomputable != passive:
            missing = sorted(passive - recomputable)
            raise ValueError(f"all 19 passive score values must be recomputable: {missing}")
        excluded_features = set(MODEL_OUTPUT_EXCLUDED_FEATURES)
        self.active_feature_names_ = tuple(
            name
            for name in self.feature_names
            if name not in passive and name not in excluded_features
        )
        self.recomputed_score_names_ = tuple(
            name
            for name in self.feature_names
            if name in recomputable
        )
        self.excluded_score_names_ = ()
        active = frame.loc[:, self.active_feature_names_]
        oxygen = pd.to_numeric(active.get("has_oxygen"), errors="coerce")
        if oxygen is not None:
            counts = oxygen.dropna().clip(0, 1).round().value_counts()
            self.oxygen_mode_ = float(
                min(counts.loc[counts.eq(counts.max())].index) if len(counts) else 0.0
            )
        else:
            self.oxygen_mode_ = None
        self.indicator_feature_names_ = tuple(
            name
            for name in self.active_feature_names_
            if self.add_indicator and self.strategy != "native" and active[name].isna().any()
        )
        if self.strategy in {"median", "mean", "mnar"}:
            simple_strategy = "mean" if self.strategy == "mean" else "median"
            self.simple_imputer_ = SimpleImputer(
                strategy=simple_strategy,
                add_indicator=False,
                keep_empty_features=True,
            ).fit(active)
            self.standard_deviation_ = active.std(ddof=0).fillna(0)
        elif self.strategy in {"knn", "bayesian"}:
            self.continuous_feature_names_ = tuple(
                name for name in self.continuous_features if name in self.active_feature_names_
            )
            self.modeled_continuous_feature_names_ = tuple(
                name
                for name in self.continuous_feature_names_
                if active[name].notna().any()
            )
            self.empty_continuous_feature_names_ = tuple(
                name
                for name in self.continuous_feature_names_
                if name not in self.modeled_continuous_feature_names_
            )
            continuous_set = set(self.continuous_feature_names_)
            self.other_feature_names_ = tuple(
                name for name in self.active_feature_names_ if name not in continuous_set
            )
            if self.modeled_continuous_feature_names_:
                continuous = active.loc[:, self.modeled_continuous_feature_names_]
                if self.strategy == "knn":
                    self.continuous_scaler_ = StandardScaler().fit(continuous)
                    scaled = self.continuous_scaler_.transform(continuous)
                    self.continuous_imputer_ = KNNImputer(
                        n_neighbors=5,
                        add_indicator=False,
                        keep_empty_features=True,
                    ).fit(scaled)
                else:
                    self.continuous_imputer_ = IterativeImputer(
                        sample_posterior=True,
                        max_iter=self.max_iter,
                        n_nearest_features=(
                            min(self.n_nearest_features, len(self.modeled_continuous_feature_names_))
                            if len(self.modeled_continuous_feature_names_) > 1
                            else None
                        ),
                        initial_strategy="median",
                        add_indicator=False,
                        keep_empty_features=True,
                        random_state=self.random_state,
                    ).fit(continuous)
            if self.other_feature_names_:
                self.other_imputer_ = SimpleImputer(
                    strategy="median",
                    add_indicator=False,
                    keep_empty_features=True,
                ).fit(active.loc[:, self.other_feature_names_])
        elif self.strategy != "native":
            raise ValueError(self.strategy)
        imputed_training = self._imputed_active(frame)
        training_scores = compute_score_values_v2(imputed_training)
        training_undefined = self._mathematical_undefined_mask(
            imputed_training, training_scores
        )
        self.score_safety_values_ = {}
        if self.strategy != "native":
            for name in PASSIVE_SCORE_VALUE_COLUMNS:
                finite = training_scores.loc[~training_undefined[name], name].dropna()
                if finite.empty:
                    raise ValueError(
                        f"no finite training-fold value for residual score safety imputation: {name}"
                    )
                self.score_safety_values_[name] = float(finite.median())
        excluded_model_scores = set(MODEL_OUTPUT_EXCLUDED_SCORE_ALIASES)
        excluded_model_features = set(MODEL_OUTPUT_EXCLUDED_FEATURES)
        self.model_output_excluded_score_aliases_ = dict(
            MODEL_OUTPUT_EXCLUDED_SCORE_ALIASES
        )
        base_names = [
            name
            for name in self.feature_names
            if (name not in passive or name in self.recomputed_score_names_)
            and name not in excluded_model_features
        ]
        self.output_feature_names_ = tuple(
            [
                *base_names,
                *(
                    f"UNDEFINED_SCORE_{name}"
                    for name in PASSIVE_SCORE_VALUE_COLUMNS
                    if name not in excluded_model_scores
                ),
                *(f"missingindicator_{name}" for name in self.indicator_feature_names_),
            ]
        )
        forbidden_outputs = {
            "rSI_GCS",
            "MISS_rSI_GCS",
            "UNDEFINED_SCORE_rSI_GCS",
        } & set(self.output_feature_names_)
        if forbidden_outputs:
            raise ValueError(
                f"duplicate passive score alias outputs remain: {sorted(forbidden_outputs)}"
            )
        return self

    def _project_score_components(
        self, values: pd.DataFrame, original: pd.DataFrame
    ) -> pd.DataFrame:
        projected = values.copy()
        for name, (lower, upper) in SCORE_COMPONENT_BOUNDS.items():
            if name in projected:
                projected[name] = projected[name].clip(lower=lower, upper=upper)
                if name in DISCRETE_SCORE_COMPONENTS:
                    projected[name] = projected[name].round()
        if "has_oxygen" in projected:
            if self.strategy != "native":
                projected.loc[original["has_oxygen"].isna(), "has_oxygen"] = self.oxygen_mode_
            projected["has_oxygen"] = projected["has_oxygen"].clip(lower=0, upper=1).round()
        return projected

    def _mathematical_undefined_mask(
        self, active: pd.DataFrame, scores: pd.DataFrame
    ) -> pd.DataFrame:
        result = pd.DataFrame(False, index=active.index, columns=PASSIVE_SCORE_VALUE_COLUMNS)
        available = set(active.columns)
        for name in PASSIVE_SCORE_VALUE_COLUMNS:
            required = SCORE_VALUE_REQUIRED_COMPONENTS[name]
            complete = pd.Series(True, index=active.index)
            for component in required:
                if component not in available:
                    complete &= False
                else:
                    complete &= active[component].notna()
            if name in {"qSOFA", "NEWS2"}:
                consciousness = pd.Series(False, index=active.index)
                for component in ("prehosp_gcs", "EMT_現場_意識_AVPU"):
                    if component in available:
                        consciousness |= active[component].notna()
                complete &= consciousness
            result[name] = complete & scores[name].isna()
        return result

    def _imputed_active(self, frame: pd.DataFrame) -> pd.DataFrame:
        active = frame.loc[:, self.active_feature_names_]
        if self.strategy == "native":
            return self._project_score_components(active, active)
        if self.strategy in {"median", "mean", "mnar"}:
            values = pd.DataFrame(
                self.simple_imputer_.transform(active),
                columns=self.active_feature_names_,
                index=frame.index,
            )
            if self.strategy == "mnar":
                missing = active.isna()
                for name in self.core_features:
                    if name in values:
                        values.loc[missing[name], name] += self.delta * float(
                            self.standard_deviation_.get(name, 0.0)
                        )
            return self._project_score_components(values, active)
        values = pd.DataFrame(index=frame.index)
        if self.modeled_continuous_feature_names_:
            continuous = active.loc[:, self.modeled_continuous_feature_names_]
            if self.strategy == "knn":
                scaled = self.continuous_scaler_.transform(continuous)
                transformed = self.continuous_imputer_.transform(scaled)
                transformed = self.continuous_scaler_.inverse_transform(transformed)
            else:
                use_posterior = bool(
                    getattr(self, "_training_posterior_transform_", False)
                )
                self.continuous_imputer_.sample_posterior = use_posterior
                if use_posterior:
                    self.continuous_imputer_.random_state_ = check_random_state(
                        self.random_state
                    )
                transformed = self.continuous_imputer_.transform(continuous)
            values.loc[:, self.modeled_continuous_feature_names_] = transformed
        for name in self.empty_continuous_feature_names_:
            values[name] = 0.0
        if self.other_feature_names_:
            values.loc[:, self.other_feature_names_] = self.other_imputer_.transform(
                active.loc[:, self.other_feature_names_]
            )
        return self._project_score_components(
            values.loc[:, self.active_feature_names_], active
        )

    def fit_transform(self, X: Any, y: Any = None, **fit_params: Any) -> np.ndarray:
        self.fit(X, y)
        self._training_posterior_transform_ = self.strategy == "bayesian"
        try:
            return self.transform(X)
        finally:
            self._training_posterior_transform_ = False

    def transform(self, X: Any) -> np.ndarray:
        check_is_fitted(self, "output_feature_names_")
        frame = self._frame(X)
        active = self._imputed_active(frame)
        scores = compute_score_values_v2(active)
        undefined = self._mathematical_undefined_mask(active, scores)
        if self.strategy != "native":
            for name, value in self.score_safety_values_.items():
                scores.loc[undefined[name], name] = value
        output = pd.DataFrame(index=frame.index)
        active_names = set(self.active_feature_names_)
        recomputed = set(self.recomputed_score_names_)
        for name in self.output_feature_names_:
            if name in active_names:
                output[name] = active[name]
            elif name in recomputed:
                output[name] = scores[name]
            elif name.startswith("UNDEFINED_SCORE_"):
                source = name.removeprefix("UNDEFINED_SCORE_")
                output[name] = undefined[source].astype("float64")
            elif name.startswith("missingindicator_"):
                source = name.removeprefix("missingindicator_")
                output[name] = frame[source].isna().astype("float64")
        if output.shape[1] != len(self.output_feature_names_):
            raise ValueError(
                "passive score transform output width differs from feature names"
            )
        return output.to_numpy(dtype=float)

    def get_feature_names_out(self, input_features: Any = None) -> np.ndarray:
        check_is_fitted(self, "output_feature_names_")
        return np.asarray(self.output_feature_names_, dtype=object)
