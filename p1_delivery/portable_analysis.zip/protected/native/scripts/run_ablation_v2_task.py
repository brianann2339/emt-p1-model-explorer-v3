from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import re
import sys
import time
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.impute import KNNImputer, SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss, f1_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qa_v2 import contextual_security_scan as security_scan  # noqa: E402


OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
ED_EARLY_BINDING_CONTRACT = "p1-v2-p1-04-ed-early-runtime-binding/1"
ABLATIONS = (
    "01_standardization",
    "02_time_variables",
    "03_emt_treatment",
    "04_gcs_consciousness",
    "05_shock_index_rsig",
    "06_vital_only_vs_full",
    "07_logistic_vs_xgboost",
    "08_median_vs_knn",
    "09_class_weight_smotenc_threshold",
    "10_prehospital_vs_ed_early",
    "11_collaborator_variables",
    "12_remove_distance",
)
SUPPORTED_LOCKED_BASE_MODELS = ("xgboost", "lightgbm", "catboost")
GROUP_FOR_ABLATION = {
    "02_time_variables": "time_variables",
    "03_emt_treatment": "emt_treatment",
    "04_gcs_consciousness": "gcs_consciousness",
    "05_shock_index_rsig": "shock_index_rsig",
    "11_collaborator_variables": "collaborator_variables_exact",
    "12_remove_distance": "distance",
}
class AblationError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_lines(values: list[str]) -> str:
    return hashlib.sha256(("\n".join(values) + "\n").encode("utf-8")).hexdigest()


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _validate_ed_early_sidecar(
    artifact_path: Path,
    manifest_path: Path,
    *,
    task_id: str,
    expected_row_hashes: set[str],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if (
        manifest.get("contract_version") != ED_EARLY_BINDING_CONTRACT
        or manifest.get("ed_early_ok") is not True
        or manifest.get("isolated_sensitivity_only") is not True
        or manifest.get("main_model_feature_allowed") is not False
        or manifest.get("2025_access_count") != 0
        or manifest.get("measurement_window") != "arrival_initial_vitals"
        or manifest.get("allowed_ablation") != "10_prehospital_vs_ed_early"
        or manifest.get("allowed_arm") != "plus_ed_early"
        or task_id not in manifest.get("allowed_task_ids", [])
        or manifest.get("leakage_audit_pass") is not True
        or manifest.get("raw_arrival_timestamp_retained") is not False
        or str(manifest.get("artifact_sha256", "")).casefold()
        != sha256_file(artifact_path).casefold()
    ):
        raise AblationError("invalid ED-early sidecar binding")
    sidecar = pd.read_parquet(artifact_path)
    feature_columns = [str(value) for value in manifest.get("feature_columns", [])]
    if (
        not feature_columns
        or sidecar.columns.tolist() != ["row_hash", *feature_columns]
        or sidecar["row_hash"].astype(str).duplicated().any()
        or set(sidecar["row_hash"].astype(str)) != expected_row_hashes
    ):
        raise AblationError("invalid ED-early sidecar keys or feature contract")
    if security_scan.pii_column_hits(feature_columns):
        raise AblationError("PII columns in ED-early sidecar")
    if any(
        "year" in column.casefold()
        and pd.to_numeric(sidecar[column], errors="coerce").ge(2025).any()
        for column in feature_columns
    ):
        raise AblationError("2025 rows in ED-early sidecar")
    if any(
        pd.to_numeric(sidecar[column], errors="coerce").notna().sum()
        != sidecar[column].notna().sum()
        for column in feature_columns
    ):
        raise AblationError("ED-early sidecar features must be numeric")
    return sidecar, manifest


def _validate_inputs(
    stage1a_dir: Path,
    fold_map_path: Path,
    base_spec_path: Path,
    outcome: str,
    smoke: bool,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, list[str], dict[str, Any], dict[str, str]]:
    paths = {
        "features": stage1a_dir / "stage1a_features_le2024.parquet",
        "schema": stage1a_dir / "stage1a_schema_v2.json",
        "manifest": stage1a_dir / "stage1a_feature_manifest_v2.json",
        "fold_map": fold_map_path,
        "base_spec": base_spec_path,
    }
    for label, path in paths.items():
        folded = str(path.resolve()).casefold()
        if "source_seal" in folded or "2025" in path.name.casefold():
            raise AblationError(f"forbidden {label} path: {path}")
        if not path.is_file():
            raise FileNotFoundError(path)
    manifest = json.loads(paths["manifest"].read_text(encoding="utf-8"))
    base_spec = json.loads(paths["base_spec"].read_text(encoding="utf-8"))
    if manifest.get("strict_no_arrival_leakage") is not True:
        raise AblationError("Stage1a strict_no_arrival_leakage is not true")
    holdout = manifest.get("holdout_policy", {})
    if holdout.get("2025_access_count") != 0 or holdout.get("2025_feature_artifact_created") is not False:
        raise AblationError("Stage1a does not certify zero 2025 access/artifacts")
    if base_spec.get("status") != "LOCKED" or base_spec.get("outcome") != outcome:
        raise AblationError("base spec is not LOCKED for the requested outcome")
    base_model = str(base_spec.get("base_model", "")).casefold()
    if base_model not in SUPPORTED_LOCKED_BASE_MODELS:
        raise AblationError(f"unsupported locked base model {base_model}")
    if not isinstance(base_spec.get("estimator_params"), dict) or not base_spec["estimator_params"]:
        raise AblationError("locked base spec lacks exact estimator_params")
    if not smoke and base_spec.get("smoke_only") is True:
        raise AblationError("smoke-only base spec cannot run a formal ablation")
    if not smoke and not base_spec.get("xgboost_comparator_params"):
        raise AblationError("formal base spec lacks locked xgboost_comparator_params")
    feature_order = [str(value) for value in base_spec.get("feature_order", [])]
    if not feature_order or len(feature_order) != len(set(feature_order)):
        raise AblationError("locked base feature order is empty or duplicated")
    if base_spec.get("feature_order_sha256") != sha256_lines(feature_order):
        raise AblationError("locked base feature order hash mismatch")
    hashes = {label: sha256_file(path) for label, path in paths.items() if label != "base_spec"}
    locked_hashes = base_spec.get("input_hashes", {})
    for label, actual in hashes.items():
        if str(locked_hashes.get(label, "")).casefold() != actual.casefold():
            raise AblationError(f"locked base input hash mismatch: {label}")
    frame = pd.read_parquet(paths["features"])
    required = {"row_hash", "group_hash", "split_year", "split", f"y_{outcome}", *feature_order}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise AblationError(f"Stage1a lacks locked columns: {missing[:20]}")
    pii = security_scan.pii_column_hits(frame.columns)
    if pii:
        raise AblationError(f"PII columns in ablation input: {pii}")
    for column in frame.select_dtypes(include=["object", "string"]).columns:
        if any(
            security_scan.first_pii_pattern_hit(value, path=(str(column),), field=column)
            for value in frame[column].dropna().astype(str)
        ):
            raise AblationError(f"PII-like values in ablation input column {column}")
    years = pd.to_numeric(frame["split_year"], errors="coerce")
    if years.isna().any() or years.ge(2025).any() or frame["split"].astype(str).str.contains("2025").any():
        raise AblationError("2025 rows reached P1_04")
    if frame["row_hash"].astype(str).duplicated().any():
        raise AblationError("duplicate Stage1a row_hash")
    for column in feature_order:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    train = frame.loc[frame["split"].eq("train_2020_2023")].copy()
    validation = frame.loc[frame["split"].eq("validation_2024")].copy()
    folds = pd.read_parquet(fold_map_path)
    if "split_year" in folds and pd.to_numeric(folds["split_year"], errors="coerce").ge(2025).any():
        raise AblationError("2025 rows in fold map")
    folds = folds.loc[folds["outcome"].eq(outcome), ["row_hash", "group_hash", "fold"]].copy()
    if folds["row_hash"].astype(str).duplicated().any():
        raise AblationError("duplicate fold row_hash")
    if set(folds["row_hash"].astype(str)) != set(train["row_hash"].astype(str)):
        raise AblationError("fixed fold keys do not equal training keys")
    if folds.groupby("group_hash")["fold"].nunique().max() != 1:
        raise AblationError("patient group spans fixed folds")
    train = train.merge(folds, on="row_hash", validate="one_to_one", suffixes=("", "_locked"))
    if not train["group_hash"].astype(str).eq(train["group_hash_locked"].astype(str)).all():
        raise AblationError("locked fold group hashes differ")
    train = train.drop(columns="group_hash_locked")
    fold_values = sorted(pd.to_numeric(train["fold"], errors="raise").astype(int).unique().tolist())
    if not smoke and fold_values != list(range(5)):
        raise AblationError(f"formal ablation requires fixed folds 0..4, got {fold_values}")
    return train, validation, folds, feature_order, base_spec, {**hashes, "base_spec": sha256_file(base_spec_path)}


def _groups(base_spec: dict[str, Any], feature_order: list[str], ablation: str) -> dict[str, list[str]]:
    raw = base_spec.get("feature_groups", {})
    groups = {name: [str(value) for value in values] for name, values in raw.items()}
    required = set(GROUP_FOR_ABLATION.values()) | {"vital_only", "knn_continuous"}
    for name in required:
        if not groups.get(name):
            raise AblationError(f"locked base spec lacks non-empty feature group {name}")
        unknown = sorted(set(groups[name]) - set(feature_order))
        if unknown:
            raise AblationError(f"feature group {name} contains unlocked features: {unknown[:10]}")
    if ablation == "11_collaborator_variables":
        allowed = {"sMS", "rSI_sMS", "SIAVPU", "aSI", "mSI"}
        if any(re.sub(r"^MISS_", "", value) not in allowed for value in groups["collaborator_variables_exact"]):
            raise AblationError("collaborator_variables_exact contains a feature outside the five-item contract")
    return groups


def _arms(ablation: str, base_spec: dict[str, Any], feature_order: list[str]) -> list[dict[str, Any]]:
    groups = _groups(base_spec, feature_order, ablation)
    base_model = str(base_spec.get("base_model", "xgboost"))
    base_params = dict(base_spec.get("estimator_params", {}))
    base = {"name": "locked_full", "model": base_model, "features": feature_order, "params": base_params}
    if ablation == "01_standardization":
        return [
            {"name": "logistic_scaled", "model": "logistic_l2", "features": feature_order, "scaled": True},
            {"name": "logistic_unscaled", "model": "logistic_l2", "features": feature_order, "scaled": False},
        ]
    if ablation in GROUP_FOR_ABLATION:
        group = groups[GROUP_FOR_ABLATION[ablation]]
        return [base, {**base, "name": f"without_{GROUP_FOR_ABLATION[ablation]}", "features": [c for c in feature_order if c not in group]}]
    if ablation == "06_vital_only_vs_full":
        return [base, {**base, "name": "vital_only", "features": groups["vital_only"]}]
    if ablation == "07_logistic_vs_xgboost":
        return [
            {"name": "logistic_l2", "model": "logistic_l2", "features": feature_order, "scaled": True},
            {"name": "xgboost", "model": "xgboost", "features": feature_order, "params": base_spec.get("xgboost_comparator_params", {})},
        ]
    if ablation == "08_median_vs_knn":
        return [
            {"name": "median", "model": base_model, "features": feature_order, "params": base_params, "imputer": "median"},
            {"name": "knn", "model": base_model, "features": feature_order, "params": base_params, "imputer": "knn", "knn_columns": groups["knn_continuous"]},
        ]
    if ablation == "09_class_weight_smotenc_threshold":
        return [
            {"name": "class_weight", "model": "logistic_l2", "features": feature_order, "scaled": True, "class_weight": "balanced"},
            {"name": "smotenc", "model": "logistic_l2", "features": feature_order, "scaled": True, "smotenc": True},
            {"name": "threshold_shift", "model": "logistic_l2", "features": feature_order, "scaled": True, "threshold_shift": True},
        ]
    if ablation == "10_prehospital_vs_ed_early":
        return [base, {**base, "name": "plus_ed_early", "add_ed_early": True}]
    raise AblationError(f"unknown ablation {ablation}")


def _estimator(
    arm: dict[str, Any], y: np.ndarray, smoke: bool, seed: int, X: pd.DataFrame
) -> Any:
    if arm.get("imputer") == "knn":
        knn_columns = [column for column in arm.get("knn_columns", []) if column in X.columns]
        other_columns = [column for column in X.columns if column not in knn_columns]
        if not knn_columns:
            raise AblationError("KNN arm lacks locked continuous/ordinal columns")
        transformers: list[tuple[str, Any, list[str]]] = [
            ("knn_continuous", KNNImputer(n_neighbors=5), knn_columns)
        ]
        if other_columns:
            transformers.append(("median_other", SimpleImputer(strategy="median"), other_columns))
        imputer: Any = ColumnTransformer(transformers, remainder="drop")
    else:
        imputer = SimpleImputer(strategy="median")
    model_name = arm["model"]
    params = dict(arm.get("params", {}))
    if model_name == "logistic_l2":
        class_weight = arm.get("class_weight", "balanced" if not arm.get("threshold_shift") else None)
        steps: list[tuple[str, Any]] = [("imputer", imputer)]
        if arm.get("scaled", True):
            steps.append(("scaler", StandardScaler()))
        if arm.get("smotenc"):
            from imblearn.over_sampling import SMOTENC
            from imblearn.pipeline import Pipeline as ImbPipeline

            categorical = []
            for index, column in enumerate(X.columns):
                values = pd.to_numeric(X[column], errors="coerce").dropna().unique()
                if len(values) and len(values) <= 2 and set(values).issubset({0, 1}):
                    categorical.append(index)
            if not categorical:
                raise AblationError("SMOTENC arm has no locked binary categorical features")
            steps.append(("smotenc", SMOTENC(categorical_features=categorical, sampling_strategy="auto", k_neighbors=max(1, min(3, int(y.sum()) - 1)), random_state=seed)))
            steps.append(("model", LogisticRegression(max_iter=500, solver="liblinear", random_state=seed)))
            return ImbPipeline(steps)
        steps.append(("model", LogisticRegression(max_iter=500, solver="liblinear", class_weight=class_weight, random_state=seed)))
        return Pipeline(steps)
    ratio = max(1.0, float((y == 0).sum()) / max(1, int((y == 1).sum())))
    if model_name == "xgboost":
        from xgboost import XGBClassifier

        defaults = {"n_estimators": 4 if smoke else 250, "max_depth": 3, "learning_rate": 0.05, "scale_pos_weight": ratio}
        defaults.update(params)
        if smoke:
            defaults["n_estimators"] = min(4, int(defaults.get("n_estimators", 4)))
        return Pipeline([("imputer", imputer), ("model", XGBClassifier(objective="binary:logistic", eval_metric="logloss", tree_method="hist", n_jobs=1, random_state=seed, **defaults))])
    if model_name == "lightgbm":
        from lightgbm import LGBMClassifier

        defaults = {"n_estimators": 4 if smoke else 250, "num_leaves": 31, "learning_rate": 0.05, "scale_pos_weight": ratio}
        defaults.update(params)
        if smoke:
            defaults["n_estimators"] = min(4, int(defaults.get("n_estimators", 4)))
        return Pipeline([("imputer", imputer), ("model", LGBMClassifier(objective="binary", n_jobs=1, random_state=seed, verbosity=-1, **defaults))])
    if model_name == "catboost":
        from catboost import CatBoostClassifier

        defaults = {"iterations": 4 if smoke else 250, "depth": 4, "learning_rate": 0.05, "scale_pos_weight": ratio}
        defaults.update(params)
        if smoke:
            defaults["iterations"] = min(4, int(defaults.get("iterations", 4)))
        return Pipeline([("imputer", imputer), ("model", CatBoostClassifier(verbose=False, allow_writing_files=False, random_seed=seed, thread_count=1, **defaults))])
    raise AblationError(f"unsupported locked base model {model_name}")


def _metric_rows(
    y: np.ndarray,
    probability: np.ndarray,
    task_id: str,
    outcome: str,
    model: str,
    split: str,
    threshold: float,
) -> list[dict[str, Any]]:
    clipped_threshold = float(np.clip(threshold, 1e-6, 1 - 1e-6))
    predicted = probability >= clipped_threshold
    tp = int(((y == 1) & predicted).sum())
    fp = int(((y == 0) & predicted).sum())
    net_benefit = tp / len(y) - fp / len(y) * clipped_threshold / (1 - clipped_threshold)
    calibration_intercept: float | None = None
    calibration_slope: float | None = None
    if len(np.unique(y)) == 2:
        try:
            logit = np.log(np.clip(probability, 1e-6, 1 - 1e-6) / np.clip(1 - probability, 1e-6, 1 - 1e-6)).reshape(-1, 1)
            calibrator = LogisticRegression(C=1e6, solver="lbfgs", max_iter=1000)
            calibrator.fit(logit, y)
            calibration_intercept = float(calibrator.intercept_[0])
            calibration_slope = float(calibrator.coef_[0, 0])
            if not math.isfinite(calibration_intercept) or not math.isfinite(calibration_slope):
                calibration_intercept = calibration_slope = None
        except Exception:
            calibration_intercept = calibration_slope = None
    values = {
        "AUROC": float(roc_auc_score(y, probability)) if len(np.unique(y)) == 2 else None,
        "AUPRC": float(average_precision_score(y, probability)) if len(np.unique(y)) == 2 else None,
        "Brier": float(brier_score_loss(y, probability)),
        "F1": float(f1_score(y, predicted, zero_division=0)),
        "net_benefit": float(net_benefit),
        "calibration_intercept": calibration_intercept,
        "calibration_slope": calibration_slope,
    }
    return [
        {"task_id": task_id, "outcome": outcome, "model": model, "split": split, "metric": metric, "value": value, "status": "ESTIMATED" if value is not None else "NOT_ESTIMABLE", "n": int(len(y)), "events": int(y.sum()), "lower_ci": None, "upper_ci": None}
        for metric, value in values.items()
    ]


def run_task(args: argparse.Namespace) -> dict[str, Any]:
    started = time.perf_counter()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    train, validation, _, feature_order, base_spec, input_hashes = _validate_inputs(
        args.stage1a_dir.resolve(), args.fold_map.resolve(), args.base_spec.resolve(), args.outcome, args.smoke
    )
    arms = _arms(args.ablation, base_spec, feature_order)
    if any(not arm["features"] for arm in arms):
        raise AblationError("an ablation arm has no features")
    if args.smoke and args.fold is None:
        raise AblationError("--smoke requires --fold")
    if not args.smoke and args.fold is not None:
        raise AblationError("formal run must execute all five folds; omit --fold")
    available_folds = sorted(pd.to_numeric(train["fold"], errors="raise").astype(int).unique().tolist())
    folds = [args.fold] if args.smoke else available_folds
    if any(fold not in available_folds for fold in folds):
        raise AblationError(f"requested fold is unavailable: {folds}")
    predictions: list[pd.DataFrame] = []
    metrics: list[dict[str, Any]] = []
    models: dict[str, Any] = {}
    arm_specs = []
    for arm_index, arm in enumerate(arms):
        features = list(arm["features"])
        arm_name = f"{args.ablation}__{arm['name']}"
        smoke_ed_early = False
        if arm.get("add_ed_early"):
            if args.smoke:
                for frame in (train, validation):
                    frame["ED_EARLY_SMOKE_PROBE"] = frame["row_hash"].astype(str).map(lambda value: int(value[:8], 16) / 0xFFFFFFFF)
                features.append("ED_EARLY_SMOKE_PROBE")
                smoke_ed_early = True
            else:
                if args.ed_early_artifact is None or args.ed_early_manifest is None:
                    raise AblationError("formal ED-early ablation requires isolated sidecar and manifest")
                sidecar, sidecar_manifest = _validate_ed_early_sidecar(
                    args.ed_early_artifact,
                    args.ed_early_manifest,
                    task_id=args.task_id,
                    expected_row_hashes=set(train["row_hash"].astype(str))
                    | set(validation["row_hash"].astype(str)),
                )
                ed_features = [str(value) for value in sidecar_manifest["feature_columns"]]
                input_hashes["ed_early_artifact"] = sha256_file(args.ed_early_artifact)
                input_hashes["ed_early_manifest"] = sha256_file(args.ed_early_manifest)
                train = train.merge(sidecar, on="row_hash", how="left", validate="one_to_one")
                validation = validation.merge(sidecar, on="row_hash", how="left", validate="one_to_one")
                features.extend(ed_features)
        arm_thresholds = []
        arm_oof_frames: list[pd.DataFrame] = []
        for fold in folds:
            fit = train.loc[train["fold"].ne(fold)]
            evaluate = train.loc[train["fold"].eq(fold)]
            y_fit = fit[f"y_{args.outcome}"].to_numpy(dtype="int8")
            y_evaluate = evaluate[f"y_{args.outcome}"].to_numpy(dtype="int8")
            if len(np.unique(y_fit)) != 2 or len(np.unique(y_evaluate)) != 2:
                raise AblationError(
                    f"fixed fold {fold} lacks both classes for {args.outcome}"
                )
            model = _estimator(
                arm,
                y_fit,
                args.smoke,
                args.seed + arm_index * 10 + fold,
                fit[features],
            )
            model.fit(fit[features], y_fit)
            probability = np.clip(model.predict_proba(evaluate[features])[:, 1], 1e-6, 1 - 1e-6)
            threshold = 0.5
            if arm.get("threshold_shift"):
                fit_probability = model.predict_proba(fit[features])[:, 1]
                threshold = float(np.quantile(fit_probability, 1 - float(y_fit.mean())))
            arm_thresholds.append(threshold)
            arm_oof_frames.append(pd.DataFrame({"task_id": args.task_id, "row_hash": evaluate["row_hash"].astype(str), "outcome": args.outcome, "model": arm_name, "split": "oof_2020_2023", "fold": int(fold), "y_true": y_evaluate, "prediction": probability}))
            models[f"{arm_name}__fold{fold}"] = model
        arm_oof = pd.concat(arm_oof_frames, ignore_index=True)
        metrics.extend(
            _metric_rows(
                arm_oof["y_true"].to_numpy(dtype="int8"),
                arm_oof["prediction"].to_numpy(dtype="float64"),
                args.task_id,
                args.outcome,
                arm_name,
                "oof_2020_2023",
                float(np.mean(arm_thresholds)),
            )
        )
        predictions.append(arm_oof)
        if not args.smoke:
            y_train = train[f"y_{args.outcome}"].to_numpy(dtype="int8")
            final_model = _estimator(
                arm, y_train, False, args.seed + arm_index * 100, train[features]
            )
            final_model.fit(train[features], y_train)
            probability = np.clip(final_model.predict_proba(validation[features])[:, 1], 1e-6, 1 - 1e-6)
            threshold = float(np.mean(arm_thresholds)) if arm_thresholds else 0.5
            y_validation = validation[f"y_{args.outcome}"].to_numpy(dtype="int8")
            predictions.append(pd.DataFrame({"task_id": args.task_id, "row_hash": validation["row_hash"].astype(str), "outcome": args.outcome, "model": arm_name, "split": "validation_2024", "fold": pd.array([None] * len(validation), dtype="Int8"), "y_true": y_validation, "prediction": probability}))
            metrics.extend(_metric_rows(y_validation, probability, args.task_id, args.outcome, arm_name, "validation_2024", threshold))
            models[f"{arm_name}__final"] = final_model
        arm_specs.append({"arm": arm_name, "model": arm["model"], "feature_count": len(features), "feature_order_sha256": sha256_lines(features), "thresholds": arm_thresholds, "smoke_synthetic_ed_early": smoke_ed_early, "code_path_only_not_real_ed_early": smoke_ed_early})
    prediction_frame = pd.concat(predictions, ignore_index=True)
    prediction_frame = prediction_frame[["task_id", "row_hash", "outcome", "model", "split", "fold", "y_true", "prediction"]]
    if prediction_frame.duplicated(["row_hash", "outcome", "model", "split"]).any():
        raise AblationError("duplicate strict-long predictions")
    if prediction_frame["split"].str.contains("2025").any() or not prediction_frame["prediction"].between(0, 1).all():
        raise AblationError("invalid/2025 predictions")
    metric_frame = pd.DataFrame(metrics)
    prediction_path = output_dir / "predictions.parquet"
    metric_path = output_dir / "metrics.parquet"
    model_path = output_dir / "models.joblib"
    feature_path = output_dir / "feature_manifest.json"
    spec_path = output_dir / "spec.json"
    prediction_frame.to_parquet(prediction_path, index=False)
    metric_frame.to_parquet(metric_path, index=False)
    joblib.dump(models, model_path)
    atomic_json(feature_path, {"ablation": args.ablation, "locked_base_feature_order_sha256": base_spec["feature_order_sha256"], "arms": arm_specs})
    ed_early_status = None
    if args.ablation == "10_prehospital_vs_ed_early":
        ed_early_status = "CODE_PATH_ONLY_NOT_REAL_ED_EARLY" if args.smoke else "FORMAL_SIDECAR_VALIDATED"
    spec = {"contract_version": "p1-v2-ablation-task/1", "task_id": args.task_id, "stage": "P1_04", "outcome": args.outcome, "ablation": args.ablation, "smoke": args.smoke, "scientific_artifact": not args.smoke, "promotion_allowed": not args.smoke, "folds": folds, "validation_2024_executed": not args.smoke, "ed_early_validation_status": ed_early_status, "base_spec_sha256": input_hashes["base_spec"], "input_hashes": input_hashes, "arms": arm_specs, "2025_access_count": 0}
    atomic_json(spec_path, spec)
    artifacts = [prediction_path, metric_path, model_path, feature_path, spec_path]
    artifact_hashes = {path.name: sha256_file(path) for path in artifacts}
    manifest = {"contract_version": "p1-v2-ablation-manifest/1", "task_id": args.task_id, "status": "SMOKE_PASS" if args.smoke else "PASS", "scientific_artifact": not args.smoke, "promotion_allowed": not args.smoke, "outcome": args.outcome, "ablation": args.ablation, "locked_base_spec": True, "fixed_folds": folds, "prediction_rows": len(prediction_frame), "metric_rows": len(metric_frame), "validation_2024_executed": not args.smoke, "ed_early_validation_status": ed_early_status, "historical_2025_exposure": True, "2025_access_count": 0, "artifact_hashes": artifact_hashes, "runtime_seconds": time.perf_counter() - started, "runtime": {"python": platform.python_version(), "platform": platform.platform()}}
    manifest_path = output_dir / "task_manifest.json"
    atomic_json(manifest_path, manifest)
    success = {"status": "SMOKE_PASS" if args.smoke else "SUCCESS", "task_id": args.task_id, "scientific_artifact": not args.smoke, "promotion_allowed": not args.smoke, "manifest": manifest_path.name, "manifest_sha256": sha256_file(manifest_path), "artifact_hashes": artifact_hashes}
    atomic_json(output_dir / ("_SMOKE_PASS.json" if args.smoke else "_SUCCESS.json"), success)
    return success


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run one locked EMT P1 v2 P1_04 ablation task")
    parser.add_argument("--outcome", choices=OUTCOMES, required=True)
    parser.add_argument("--ablation", choices=ABLATIONS, required=True)
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--stage1a-dir", type=Path, default=ROOT / "outputs" / "v2" / "stage1a")
    parser.add_argument("--fold-map", type=Path, default=ROOT / "qa_v2" / "fixed_group_folds_v2.parquet")
    parser.add_argument("--base-spec", type=Path, default=ROOT / "outputs" / "v2" / "w00_locked_base_spec.json")
    parser.add_argument("--ed-early-artifact", type=Path)
    parser.add_argument("--ed-early-manifest", type=Path)
    parser.add_argument("--seed", type=int, default=20260710)
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--fold", type=int, choices=range(5))
    return parser.parse_args(argv)


def main() -> int:
    result = run_task(parse_args())
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
