from __future__ import annotations

import hashlib
import json
import math
import platform
import re
import sys
import warnings
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pandas.errors import PerformanceWarning
import seaborn as sns

warnings.simplefilter("ignore", PerformanceWarning)

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from qa_v2 import contextual_security_scan as security_scan  # noqa: E402


DATA_PATH = ROOT / "Data_and_Materials" / "急診主體_串EMT_2020-2025.parquet"
OUT_DIR = ROOT / "outputs" / "stage1a"
LOG_DIR = ROOT / "outputs" / "logs"

DEATH_LABELS = {"死亡", "病危自動出院"}
S3_ED_LABELS = {"留觀等住院", "開刀後住院"}
S4_ED_LABELS = {"留觀等住ICU", "開刀後住ICU"}

HARD_FORBIDDEN_SOURCES = set(
    [
        "連結方式",
        "連結信心",
        "EMT_時序異常",
        "EMT_時序異常說明",
        "EMT_問卷_有效",
        "EMT_到達現場時間",
        "EMT_離開現場時間",
        "EMT_送達醫院時間",
        "EMT_新北_出勤通知時間",
        "EMT_在院交接分",
        "EMT_總勤務分",
        "EMT_新北_離開醫院時間",
        "EMT_新北_返隊待命時間",
        "EMT_檢傷分級",
        "EMT_送達醫院名稱",
        "EMT_檢傷描述彙整",
        "EMT_檢傷部位彙整",
        "EMT_檢傷有頭部傷",
        "EMT_台北_推估檢傷",
    ]
)

ARRIVAL_TIME_DERIVED_ALLOWLIST = {"運送時間", "總到院前時間"}
ARRIVAL_TIMESTAMP_SOURCES = {
    "EMT_送達醫院時間",
    "EMT_離開現場時間",
    "EMT_到達現場時間",
    "EMT_新北_出勤通知時間",
}
ARRIVAL_FORBIDDEN_SUBSTR = [
    "arrival",
    "到院",
    "送達醫院",
    "檢傷",
    "交接",
    "離開醫院",
    "返隊",
]
ARRIVAL_VITAL_SOURCE_PATTERNS = [
    "EMT_到院_",
    "EMT_DERIVED_arrival_",
    "EMT_MISS_EMT_DERIVED_arrival_",
]
SENTINELS = {88888, 99999, 8888, 9999}

NUMERIC_SOURCE_COLUMNS = [
    "EMT_年齡",
    "EMT_發生地點_到慈濟_開車km",
    "EMT_發生地點_到慈濟_直線km",
    "EMT_反應時間分",
    "EMT_現場停留分",
    "EMT_送醫途中分",
    "EMT_現場_舒張壓",
    "EMT_現場_脈搏",
    "EMT_現場_呼吸",
    "EMT_現場_SPO2",
    "EMT_現場_體溫",
    "EMT_現場_GCS",
    "EMT_現場_GCS_E",
    "EMT_現場_GCS_V",
    "EMT_現場_GCS_M",
    "EMT_車上_舒張壓",
    "EMT_車上_脈搏",
    "EMT_車上_呼吸",
    "EMT_車上_SPO2",
    "EMT_車上_體溫",
    "EMT_車上_GCS",
    "EMT_車上_GCS_E",
    "EMT_車上_GCS_V",
    "EMT_車上_GCS_M",
    "EMT_生命徵象量測次數",
    "EMT_問卷_疼痛指數",
    "EMT_問卷_左瞳孔尺寸mm",
    "EMT_問卷_右瞳孔尺寸mm",
    "EMT_問卷_血糖值mgdl",
    "EMT_問卷_氧氣流量Lmin",
    "EMT_問卷_靜脈輸液量ml",
    "EMT_體重",
    "EMT_燒燙傷一級%",
    "EMT_燒燙傷二級%",
    "EMT_燒燙傷三級%",
    "EMT_燒燙傷總%",
]

CATEGORICAL_SOURCE_COLUMNS = [
    "EMT_城市",
    "EMT_性別",
    "EMT_送醫路由",
    "EMT_危急個案",
    "EMT_發生地區",
    "EMT_距離_定位信心",
    "EMT_現場_意識",
    "EMT_派遣分類",
    "EMT_派遣原因",
    "EMT_問卷_創傷導致的主訴群",
    "EMT_問卷_頸椎固定",
    "EMT_問卷_膚色",
    "EMT_問卷_左瞳孔光反射",
    "EMT_問卷_右瞳孔光反射",
    "EMT_問卷_氣管位置",
    "EMT_問卷_頸靜脈怒張",
    "EMT_問卷_血糖狀態",
    "EMT_問卷_靜脈輸液種類",
    "EMT_推定派遣類別",
    "EMT_有燒燙傷",
    "EMT_心律臆斷",
    "EMT_台北_創傷類型",
    "EMT_特殊表類型",
    "EMT_台北_心梗登錄",
    "EMT_台北_中風登錄",
    "EMT_台北_CPR停止登錄",
    "EMT_問卷_交通事故患者",
    "EMT_問卷_交通事故種類",
    "EMT_問卷_保護裝置狀態",
    "EMT_問卷_非交通事故種類",
    "EMT_問卷_危急個案",
]

MULTI_HOT_SOURCE_COLUMNS = [
    "EMT_過去病史",
    "EMT_過敏史",
    "EMT_主訴_結構化",
    "EMT_紅旗",
    "EMT_創傷機轉_合併",
    "EMT_處置_合併",
    "EMT_特殊表登錄_合併",
    "EMT_問卷_一般處置",
    "EMT_問卷_呼吸給氧裝置",
    "EMT_問卷_創傷處置",
    "EMT_問卷_加護處置",
    "EMT_台北_呼吸處置",
    "EMT_台北_CPR處置",
    "EMT_台北_藥物處置",
    "EMT_台北_創傷處置",
    "EMT_台北_後送姿勢",
    "EMT_台北_其他處置",
    "EMT_台北_給藥",
    "EMT_補述_紅旗",
    "EMT_問卷_過去病史",
    "EMT_問卷_過敏史",
]

TEXT_SOURCE_COLUMNS = [
    "EMT_問卷_其他說明",
    "EMT_補述_補充病史",
    "EMT_補述_社會脈絡",
    "EMT_補述_臨床摘要",
    "EMT_補述原文",
    "EMT_補述_主訴",
    "EMT_台北_主訴原文",
    "EMT_補述_創傷機轉",
    "EMT_特殊表內容",
]

KEYWORD_PATTERNS = {
    "kw_ohca": r"OHCA|到院前心肺|心肺功能停止|無生命徵象|CPR",
    "kw_chest_pain": r"胸痛|胸悶|心肌梗塞|心梗",
    "kw_dyspnea": r"喘|呼吸困難|喘不過氣",
    "kw_bleeding": r"出血|吐血|血便|黑便|大出血",
    "kw_stroke": r"中風|FAST|半身|口齒|肢體無力",
    "kw_trauma": r"車禍|跌倒|外傷|創傷|撞|摔",
    "kw_seizure": r"抽搐|癲癇",
    "kw_unconscious": r"昏迷|意識不清|叫不醒|無反應",
}


def sha256_value(value: object) -> str:
    if pd.isna(value):
        return ""
    return hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def clean_name(value: object) -> str:
    if pd.isna(value):
        return ""
    return str(value).strip()


def to_numeric_clean(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series.astype("string").str.replace(",", "", regex=False), errors="coerce")
    return numeric.mask(numeric.isin(SENTINELS))


def apply_bounds(series: pd.Series, low: float | None, high: float | None, keep_zero: bool = False) -> pd.Series:
    out = series.copy()
    if low is not None:
        if keep_zero:
            out = out.mask((out < low) & (out != 0))
        else:
            out = out.mask(out < low)
    if high is not None:
        out = out.mask(out > high)
    return out


def parse_sbp_value(value: object) -> float:
    if pd.isna(value):
        return np.nan
    s = str(value).strip()
    if not s or s in {"拒絕量測", "拒測", "未測", "無"}:
        return np.nan
    if "量測不到" in s:
        return 0.0
    if "頸" in s:
        return 60.0
    if "肱" in s or "股" in s:
        return 70.0
    if "橈" in s:
        return 80.0
    if "足背" in s:
        return 90.0
    match = re.search(r"[-+]?\d+(?:\.\d+)?", s)
    if not match:
        return np.nan
    return float(match.group(0))


def scene_sbp_ordinal(value: object) -> float:
    sbp = parse_sbp_value(value)
    if np.isnan(sbp):
        return np.nan
    if sbp <= 0:
        return 0.0
    if sbp < 70:
        return 1.0
    if sbp < 80:
        return 2.0
    if sbp < 90:
        return 3.0
    return 4.0


def avpu_to_num(series: pd.Series) -> pd.Series:
    mapping = {"清": 4, "聲": 3, "痛": 2, "否": 1}
    return series.map(lambda x: mapping.get(str(x).strip(), np.nan) if not pd.isna(x) else np.nan)


def safe_div(num: pd.Series, den: pd.Series) -> pd.Series:
    den2 = den.replace(0, np.nan)
    return num / den2


def score_by_bins(values: pd.Series, bins: list[tuple[float, float, int]]) -> pd.Series:
    out = pd.Series(np.nan, index=values.index, dtype="float64")
    for low, high, score in bins:
        out = out.mask((values >= low) & (values <= high), score)
    return out


def news2_score(rr: pd.Series, spo2: pd.Series, bt: pd.Series, sbp: pd.Series, hr: pd.Series, gcs: pd.Series, avpu: pd.Series, oxygen: pd.Series) -> pd.Series:
    rr_s = score_by_bins(rr, [(-math.inf, 8, 3), (9, 11, 1), (12, 20, 0), (21, 24, 2), (25, math.inf, 3)])
    spo2_s = score_by_bins(spo2, [(-math.inf, 91, 3), (92, 93, 2), (94, 95, 1), (96, math.inf, 0)])
    bt_s = score_by_bins(bt, [(-math.inf, 35, 3), (35.1, 36, 1), (36.1, 38, 0), (38.1, 39, 1), (39.1, math.inf, 2)])
    sbp_s = score_by_bins(sbp, [(-math.inf, 90, 3), (91, 100, 2), (101, 110, 1), (111, 219, 0), (220, math.inf, 3)])
    hr_s = score_by_bins(hr, [(-math.inf, 40, 3), (41, 50, 1), (51, 90, 0), (91, 110, 1), (111, 130, 2), (131, math.inf, 3)])
    conc_s = ((gcs < 15) | (avpu < 4)).astype("float64") * 3
    oxygen_s = oxygen.fillna(0).astype("float64") * 2
    return rr_s.fillna(0) + spo2_s.fillna(0) + bt_s.fillna(0) + sbp_s.fillna(0) + hr_s.fillna(0) + conc_s.fillna(0) + oxygen_s


def mews_score(rr: pd.Series, bt: pd.Series, sbp: pd.Series, hr: pd.Series, avpu: pd.Series) -> pd.Series:
    rr_s = score_by_bins(rr, [(-math.inf, 8, 3), (9, 14, 0), (15, 20, 1), (21, 29, 2), (30, math.inf, 3)])
    bt_s = score_by_bins(bt, [(-math.inf, 35, 2), (35.1, 38.4, 0), (38.5, math.inf, 2)])
    sbp_s = score_by_bins(sbp, [(-math.inf, 70, 3), (71, 80, 2), (81, 100, 1), (101, 199, 0), (200, math.inf, 2)])
    hr_s = score_by_bins(hr, [(-math.inf, 40, 2), (41, 50, 1), (51, 100, 0), (101, 110, 1), (111, 129, 2), (130, math.inf, 3)])
    avpu_s = (avpu < 4).astype("float64") * 3
    return rr_s.fillna(0) + bt_s.fillna(0) + sbp_s.fillna(0) + hr_s.fillna(0) + avpu_s.fillna(0)


def rems_score(age: pd.Series, map_: pd.Series, hr: pd.Series, rr: pd.Series, spo2: pd.Series, gcs: pd.Series) -> pd.Series:
    age_s = score_by_bins(age, [(-math.inf, 44, 0), (45, 54, 2), (55, 64, 3), (65, 74, 5), (75, math.inf, 6)])
    map_s = score_by_bins(map_, [(-math.inf, 49, 4), (50, 69, 2), (70, 109, 0), (110, 129, 2), (130, 159, 3), (160, math.inf, 4)])
    hr_s = score_by_bins(hr, [(-math.inf, 39, 4), (40, 54, 3), (55, 69, 2), (70, 109, 0), (110, 139, 2), (140, 179, 3), (180, math.inf, 4)])
    rr_s = score_by_bins(rr, [(-math.inf, 5, 4), (6, 9, 2), (10, 11, 1), (12, 24, 0), (25, 34, 1), (35, 49, 3), (50, math.inf, 4)])
    spo2_s = score_by_bins(spo2, [(-math.inf, 75, 4), (76, 85, 3), (86, 89, 1), (90, math.inf, 0)])
    gcs_s = score_by_bins(gcs, [(-math.inf, 4, 4), (5, 7, 3), (8, 10, 2), (11, 13, 1), (14, 15, 0)])
    return age_s.fillna(0) + map_s.fillna(0) + hr_s.fillna(0) + rr_s.fillna(0) + spo2_s.fillna(0) + gcs_s.fillna(0)


def rts_score(gcs: pd.Series, sbp: pd.Series, rr: pd.Series) -> pd.Series:
    gcs_c = score_by_bins(gcs, [(-math.inf, 3, 0), (4, 5, 1), (6, 8, 2), (9, 12, 3), (13, 15, 4)])
    sbp_c = score_by_bins(sbp, [(0, 0, 0), (1, 49, 1), (50, 75, 2), (76, 89, 3), (90, math.inf, 4)])
    rr_c = score_by_bins(rr, [(0, 0, 0), (1, 5, 1), (6, 9, 2), (10, 29, 4), (30, math.inf, 3)])
    return 0.9368 * gcs_c.fillna(0) + 0.7326 * sbp_c.fillna(0) + 0.2908 * rr_c.fillna(0)


def split_tokens(value: object) -> list[str]:
    if pd.isna(value):
        return []
    s = str(value).strip()
    if not s or s in {"無", "0", "nan"}:
        return []
    parts = re.split(r"[、,;；]", s)
    return [p.strip() for p in parts if p.strip() and p.strip() not in {"無", "0"}]


def forbidden_feature_name(name: str) -> bool:
    if name in ARRIVAL_TIME_DERIVED_ALLOWLIST:
        return False
    if name.startswith("MISS_") and name.removeprefix("MISS_") in ARRIVAL_TIME_DERIVED_ALLOWLIST:
        return False
    return any(s in name for s in ARRIVAL_FORBIDDEN_SUBSTR)


def ensure_allowed_sources(df: pd.DataFrame, sources: list[str]) -> list[str]:
    out: list[str] = []
    for col in sources:
        if col not in df.columns:
            continue
        if security_scan.pii_column_hits([col]):
            raise ValueError(f"Listed source is direct PII: {col}")
        if col in HARD_FORBIDDEN_SOURCES:
            raise ValueError(f"Listed source is hard-forbidden: {col}")
        if any(pattern in col for pattern in ARRIVAL_VITAL_SOURCE_PATTERNS):
            raise ValueError(f"Listed source is arrival-vital leakage: {col}")
        if forbidden_feature_name(col):
            raise ValueError(f"Listed source name fails arrival substring gate: {col}")
        out.append(col)
    return out


def add_numeric_features(df: pd.DataFrame, features: pd.DataFrame, source_map: dict[str, list[str]]) -> None:
    bounds = {
        "EMT_年齡": (18, 115, False),
        "EMT_現場_脈搏": (20, 250, True),
        "EMT_車上_脈搏": (20, 250, True),
        "EMT_現場_舒張壓": (20, 200, False),
        "EMT_車上_舒張壓": (20, 200, False),
        "EMT_現場_呼吸": (0, 60, False),
        "EMT_車上_呼吸": (0, 60, False),
        "EMT_現場_SPO2": (50, 100, False),
        "EMT_車上_SPO2": (50, 100, False),
        "EMT_現場_體溫": (25, 43, False),
        "EMT_車上_體溫": (25, 43, False),
        "EMT_現場_GCS": (3, 15, False),
        "EMT_車上_GCS": (3, 15, False),
        "EMT_現場_GCS_E": (1, 4, False),
        "EMT_車上_GCS_E": (1, 4, False),
        "EMT_現場_GCS_V": (1, 5, False),
        "EMT_車上_GCS_V": (1, 5, False),
        "EMT_現場_GCS_M": (1, 6, False),
        "EMT_車上_GCS_M": (1, 6, False),
        "EMT_問卷_血糖值mgdl": (20, 1000, False),
    }
    for col in ensure_allowed_sources(df, NUMERIC_SOURCE_COLUMNS):
        vals = to_numeric_clean(df[col])
        if col in bounds:
            vals = apply_bounds(vals, *bounds[col])
        features[col] = vals
        features[f"MISS_{col}"] = vals.isna().astype("int8")
        source_map[col] = [col]
        source_map[f"MISS_{col}"] = [col]


def add_bp_and_vital_features(df: pd.DataFrame, features: pd.DataFrame, source_map: dict[str, list[str]]) -> None:
    scene_sbp = df["EMT_現場_收縮壓"].map(parse_sbp_value)
    car_sbp = df["EMT_車上_收縮壓"].map(parse_sbp_value)
    scene_sbp = apply_bounds(scene_sbp, 0, 300)
    car_sbp = apply_bounds(car_sbp, 0, 300)
    features["EMT_現場_收縮壓_ord"] = df["EMT_現場_收縮壓"].map(scene_sbp_ordinal)
    features["EMT_現場_收縮壓_for_score"] = scene_sbp
    features["EMT_車上_收縮壓_for_score"] = car_sbp
    features["MISS_EMT_現場_收縮壓_for_score"] = scene_sbp.isna().astype("int8")
    features["MISS_EMT_車上_收縮壓_for_score"] = car_sbp.isna().astype("int8")
    for name in [
        "EMT_現場_收縮壓_ord",
        "EMT_現場_收縮壓_for_score",
        "MISS_EMT_現場_收縮壓_for_score",
    ]:
        source_map[name] = ["EMT_現場_收縮壓"]
    for name in ["EMT_車上_收縮壓_for_score", "MISS_EMT_車上_收縮壓_for_score"]:
        source_map[name] = ["EMT_車上_收縮壓"]

    features["prehosp_sbp"] = car_sbp.combine_first(scene_sbp)
    features["prehosp_dbp"] = features["EMT_車上_舒張壓"].combine_first(features["EMT_現場_舒張壓"])
    features["prehosp_hr"] = features["EMT_車上_脈搏"].combine_first(features["EMT_現場_脈搏"])
    features["prehosp_rr"] = features["EMT_車上_呼吸"].combine_first(features["EMT_現場_呼吸"])
    features["prehosp_spo2"] = features["EMT_車上_SPO2"].combine_first(features["EMT_現場_SPO2"])
    features["prehosp_bt"] = features["EMT_車上_體溫"].combine_first(features["EMT_現場_體溫"])
    features["prehosp_gcs"] = features["EMT_車上_GCS"].combine_first(features["EMT_現場_GCS"])
    features["prehosp_gcs_e"] = features["EMT_車上_GCS_E"].combine_first(features["EMT_現場_GCS_E"])
    features["prehosp_gcs_v"] = features["EMT_車上_GCS_V"].combine_first(features["EMT_現場_GCS_V"])
    features["prehosp_gcs_m"] = features["EMT_車上_GCS_M"].combine_first(features["EMT_現場_GCS_M"])
    source_map.update(
        {
            "prehosp_sbp": ["EMT_車上_收縮壓", "EMT_現場_收縮壓"],
            "prehosp_dbp": ["EMT_車上_舒張壓", "EMT_現場_舒張壓"],
            "prehosp_hr": ["EMT_車上_脈搏", "EMT_現場_脈搏"],
            "prehosp_rr": ["EMT_車上_呼吸", "EMT_現場_呼吸"],
            "prehosp_spo2": ["EMT_車上_SPO2", "EMT_現場_SPO2"],
            "prehosp_bt": ["EMT_車上_體溫", "EMT_現場_體溫"],
            "prehosp_gcs": ["EMT_車上_GCS", "EMT_現場_GCS"],
            "prehosp_gcs_e": ["EMT_車上_GCS_E", "EMT_現場_GCS_E"],
            "prehosp_gcs_v": ["EMT_車上_GCS_V", "EMT_現場_GCS_V"],
            "prehosp_gcs_m": ["EMT_車上_GCS_M", "EMT_現場_GCS_M"],
        }
    )
    hr0 = ((features["EMT_現場_脈搏"] == 0).fillna(False) | (features["EMT_車上_脈搏"] == 0).fillna(False)).astype("int8")
    features["is_OHCA_hr0"] = hr0
    source_map["is_OHCA_hr0"] = ["EMT_現場_脈搏", "EMT_車上_脈搏"]


def add_time_features(df: pd.DataFrame, features: pd.DataFrame, source_map: dict[str, list[str]]) -> None:
    times = {col: pd.to_datetime(df[col], errors="coerce") for col in ARRIVAL_TIMESTAMP_SOURCES if col in df.columns}
    if {"EMT_離開現場時間", "EMT_到達現場時間"} <= times.keys():
        features["現場時間"] = (times["EMT_離開現場時間"] - times["EMT_到達現場時間"]).dt.total_seconds() / 60
        source_map["現場時間"] = ["EMT_離開現場時間", "EMT_到達現場時間"]
    if {"EMT_送達醫院時間", "EMT_離開現場時間"} <= times.keys():
        features["運送時間"] = (times["EMT_送達醫院時間"] - times["EMT_離開現場時間"]).dt.total_seconds() / 60
        source_map["運送時間"] = ["EMT_送達醫院時間", "EMT_離開現場時間"]
    if {"EMT_到達現場時間", "EMT_新北_出勤通知時間"} <= times.keys():
        features["派遣時間"] = (times["EMT_到達現場時間"] - times["EMT_新北_出勤通知時間"]).dt.total_seconds() / 60
        source_map["派遣時間"] = ["EMT_到達現場時間", "EMT_新北_出勤通知時間"]
    if {"EMT_送達醫院時間", "EMT_新北_出勤通知時間"} <= times.keys():
        features["總到院前時間"] = (times["EMT_送達醫院時間"] - times["EMT_新北_出勤通知時間"]).dt.total_seconds() / 60
        source_map["總到院前時間"] = ["EMT_送達醫院時間", "EMT_新北_出勤通知時間"]
    for col in ["現場時間", "運送時間", "派遣時間", "總到院前時間"]:
        if col in features:
            features[col] = features[col].mask((features[col] < 0) | (features[col] > 24 * 60))
            features[f"MISS_{col}"] = features[col].isna().astype("int8")
            source_map[f"MISS_{col}"] = source_map[col]


def add_score_features(features: pd.DataFrame, source_map: dict[str, list[str]]) -> None:
    age = features["EMT_年齡"]
    sbp = features["prehosp_sbp"]
    dbp = features["prehosp_dbp"]
    hr = features["prehosp_hr"]
    rr = features["prehosp_rr"]
    spo2 = features["prehosp_spo2"]
    bt = features["prehosp_bt"]
    gcs = features["prehosp_gcs"]
    gcs_e = features["prehosp_gcs_e"]
    gcs_v = features["prehosp_gcs_v"]
    gcs_m = features["prehosp_gcs_m"]
    avpu = features.get("EMT_現場_意識_AVPU", pd.Series(np.nan, index=features.index))
    map_ = (sbp + 2 * dbp) / 3
    si = safe_div(hr, sbp)
    sms = pd.Series(np.nan, index=features.index, dtype="float64")
    sms = sms.mask(gcs_m == 6, 3).mask(gcs_m == 5, 2).mask(gcs_m <= 4, 1)

    score_defs = {
        "MAP": map_,
        "SI": si,
        "mSI": safe_div(hr, map_),
        "aSI": age * si,
        "rSI": safe_div(sbp, hr),
        "rSIG": safe_div(sbp, hr) * gcs,
        "rSIG_Age": safe_div(safe_div(sbp, hr) * gcs, age),
        "SI_G": safe_div(si, gcs),
        "SIA_G": safe_div(si * age, gcs),
        "SIAVPU": si * avpu,
        "sMS": sms,
        "rSI_sMS": safe_div(sms, si),
        "rSI_GCS": safe_div(gcs, si),
        "rSI_GCSM": safe_div(sbp, hr) * gcs_m,
        "qSOFA": ((rr >= 22).astype("float64") + (sbp <= 100).astype("float64") + ((gcs < 15) | (avpu < 4)).astype("float64")),
    }
    oxygen = features.get("has_oxygen", pd.Series(0, index=features.index))
    score_defs["NEWS2"] = news2_score(rr, spo2, bt, sbp, hr, gcs, avpu, oxygen)
    score_defs["MEWS"] = mews_score(rr, bt, sbp, hr, avpu)
    score_defs["REMS"] = rems_score(age, map_, hr, rr, spo2, gcs)
    score_defs["RTS"] = rts_score(gcs, sbp, rr)

    base_sources = ["EMT_年齡", "prehosp_sbp", "prehosp_dbp", "prehosp_hr", "prehosp_rr", "prehosp_spo2", "prehosp_bt", "prehosp_gcs", "prehosp_gcs_m"]
    for name, vals in score_defs.items():
        features[name] = vals.replace([np.inf, -np.inf], np.nan)
        features[f"MISS_{name}"] = features[name].isna().astype("int8")
        source_map[name] = base_sources
        source_map[f"MISS_{name}"] = base_sources


def add_categorical_features(df: pd.DataFrame, features: pd.DataFrame, source_map: dict[str, list[str]], min_count: int = 20) -> None:
    for col in ensure_allowed_sources(df, CATEGORICAL_SOURCE_COLUMNS):
        values = df[col].astype("string").fillna("").str.strip()
        counts = values[values != ""].value_counts()
        keep = counts[counts >= min_count].index.tolist()
        for value in keep:
            name = f"{col}__{value}"
            if forbidden_feature_name(name):
                continue
            features[name] = (values == value).astype("int8")
            source_map[name] = [col]
    if "EMT_現場_意識" in df.columns:
        features["EMT_現場_意識_AVPU"] = avpu_to_num(df["EMT_現場_意識"])
        source_map["EMT_現場_意識_AVPU"] = ["EMT_現場_意識"]


def add_multi_hot_features(df: pd.DataFrame, features: pd.DataFrame, source_map: dict[str, list[str]], min_count: int = 20) -> None:
    for col in ensure_allowed_sources(df, MULTI_HOT_SOURCE_COLUMNS):
        token_lists = df[col].map(split_tokens)
        counts: Counter[str] = Counter()
        for tokens in token_lists:
            counts.update(set(tokens))
        keep = [token for token, count in counts.items() if count >= min_count]
        for token in sorted(keep):
            name = f"{col}__{token}"
            if forbidden_feature_name(name):
                continue
            features[name] = token_lists.map(lambda tokens, t=token: int(t in tokens)).astype("int8")
            source_map[name] = [col]

    oxygen_sources = [c for c in ["EMT_問卷_呼吸給氧裝置", "EMT_台北_呼吸處置"] if c in df.columns]
    oxygen_text = df[oxygen_sources].fillna("").agg("、".join, axis=1) if oxygen_sources else pd.Series("", index=df.index)
    features["has_oxygen"] = oxygen_text.str.contains("氧|NRM|BVM|正壓|呼吸道|插管", regex=True).astype("int8")
    features["has_advanced_airway"] = oxygen_text.str.contains("BVM|正壓|鼻咽|口咽|插管|氣管", regex=True).astype("int8")
    source_map["has_oxygen"] = oxygen_sources
    source_map["has_advanced_airway"] = oxygen_sources

    als_sources = [c for c in ["EMT_問卷_加護處置", "EMT_台北_藥物處置", "EMT_台北_CPR處置"] if c in df.columns]
    als_text = df[als_sources].fillna("").agg("、".join, axis=1) if als_sources else pd.Series("", index=df.index)
    features["has_ALS_procedure"] = als_text.str.contains("IV|IO|給藥|NTG|Berotec|CPR|AED|支氣管", regex=True).astype("int8")
    source_map["has_ALS_procedure"] = als_sources


def scrub_text(df: pd.DataFrame, text_cols: list[str]) -> pd.Series:
    combined = df[text_cols].fillna("").agg(" ".join, axis=1)
    for name_col in security_scan.NAME_IDENTIFIER_SOURCE_COLUMNS:
        if name_col in df.columns:
            names = df[name_col].fillna("").astype(str)
            combined = pd.Series(
                [text.replace(name, "") if name and name.strip() else text for text, name in zip(combined, names)],
                index=df.index,
            )
    combined = combined.str.replace(
        security_scan.PII_PATTERNS["taiwan_national_id"], "[ID]", regex=True
    )
    combined = combined.str.replace(
        security_scan.PII_PATTERNS["taiwan_mobile"], "[PHONE]", regex=True
    )
    combined = combined.str.replace(
        security_scan.LONG_IDENTIFIER_PATTERN, "[NUMBER]", regex=True
    )
    return combined.str.strip()


def add_text_keyword_features(df: pd.DataFrame, features: pd.DataFrame, source_map: dict[str, list[str]]) -> pd.DataFrame:
    text_cols = ensure_allowed_sources(df, TEXT_SOURCE_COLUMNS)
    text = scrub_text(df, text_cols)
    for name, pattern in KEYWORD_PATTERNS.items():
        features[name] = text.str.contains(pattern, regex=True, na=False).astype("int8")
        source_map[name] = text_cols
    return pd.DataFrame({"row_hash": features.index.astype(str), "emt_text_sanitized": text}, index=df.index)


def build_targets(df: pd.DataFrame) -> pd.DataFrame:
    ed = df["預後急診名稱"].astype("string").fillna("").str.strip()
    hosp = df["預後住院名稱"].astype("string").fillna("").str.strip()
    p1 = ed.isin(DEATH_LABELS)
    p2 = p1 | hosp.isin(DEATH_LABELS)
    p3 = df["ENDO"].astype("string").fillna("N").str.strip().eq("Y")
    reg = pd.to_datetime(df["REG_DATE"], errors="coerce")
    dis = pd.to_datetime(df["DISCHGE_DATE"], errors="coerce")
    los = to_numeric_clean(df["住院天數"]).fillna(0)
    death_days = ((dis - reg).dt.total_seconds() / 86400).fillna(0) + los
    icu_days = to_numeric_clean(df["ICU天數"]).fillna(0)
    targets = pd.DataFrame(index=df.index)
    targets["y_P1"] = p1.astype("int8")
    targets["y_P2"] = p2.astype("int8")
    targets["y_P3"] = p3.astype("int8")
    targets["y_S1"] = (p2 & (death_days <= 3)).astype("int8")
    targets["y_S2"] = (p2 & (death_days <= 7)).astype("int8")
    targets["y_S3"] = ed.isin(S3_ED_LABELS).astype("int8")
    targets["y_S4"] = (ed.isin(S4_ED_LABELS) | (icu_days > 0)).astype("int8")
    targets["y_S5"] = (icu_days >= 14).astype("int8")
    targets["y_S6"] = (los >= 30).astype("int8")
    return targets


def make_missing_heatmap(features: pd.DataFrame, output_path: Path) -> None:
    rates = features.isna().mean().sort_values(ascending=False)
    top = rates.head(50)
    plt.figure(figsize=(12, 10))
    sns.heatmap(top.to_frame("missing_rate"), annot=True, fmt=".2f", cmap="viridis", cbar=False)
    plt.title("Stage 1a Top Missing Rates")
    plt.tight_layout()
    plt.savefig(output_path, dpi=180)
    plt.close()


def assert_no_arrival_leakage(feature_cols: list[str]) -> list[str]:
    hits = []
    for col in feature_cols:
        if col in ARRIVAL_TIME_DERIVED_ALLOWLIST:
            continue
        if col.startswith("MISS_") and col.removeprefix("MISS_") in ARRIVAL_TIME_DERIVED_ALLOWLIST:
            continue
        if any(substr in col for substr in ARRIVAL_FORBIDDEN_SUBSTR):
            hits.append(col)
    return hits


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    df0 = pd.read_parquet(DATA_PATH)
    raw_shape = df0.shape
    reg_year = pd.to_datetime(df0["REG_DATE"], errors="coerce").dt.year

    has_emt = df0["有EMT前置"].eq(True)
    age = to_numeric_clean(df0["AGE"])
    cohort = df0.loc[has_emt & age.ge(18)].copy()
    cohort["__reg_year"] = pd.to_datetime(cohort["REG_DATE"], errors="coerce").dt.year
    cohort["__encounter_hash"] = cohort["ENCOUNTER_NO"].map(sha256_value)
    cohort["__group_hash"] = cohort["CHART_NO"].map(sha256_value)

    allowed_for_score = ensure_allowed_sources(cohort, NUMERIC_SOURCE_COLUMNS + CATEGORICAL_SOURCE_COLUMNS + MULTI_HOT_SOURCE_COLUMNS + TEXT_SOURCE_COLUMNS)
    score_nonnull = cohort[allowed_for_score].notna().sum(axis=1)
    cohort["__emt_completeness_score"] = score_nonnull
    before_dedup = len(cohort)
    cohort = (
        cohort.sort_values(["ENCOUNTER_NO", "__emt_completeness_score"], ascending=[True, False], na_position="last")
        .drop_duplicates(subset=["ENCOUNTER_NO"], keep="first")
        .sort_index()
    )
    dedup_removed = before_dedup - len(cohort)

    targets = build_targets(cohort)
    metadata = pd.DataFrame(index=cohort.index)
    metadata["row_hash"] = cohort["__encounter_hash"].where(cohort["__encounter_hash"].ne(""), cohort.index.map(sha256_value))
    metadata["group_hash"] = cohort["__group_hash"]
    metadata["split_year"] = cohort["__reg_year"].astype("Int64")
    metadata["split"] = np.select(
        [metadata["split_year"].between(2020, 2023), metadata["split_year"].eq(2024), metadata["split_year"].eq(2025)],
        ["train_2020_2023", "validation_2024", "sealed_holdout_2025"],
        default="outside_protocol",
    )

    features = pd.DataFrame(index=cohort.index)
    source_map: dict[str, list[str]] = {}
    add_numeric_features(cohort, features, source_map)
    add_categorical_features(cohort, features, source_map)
    add_multi_hot_features(cohort, features, source_map)
    add_bp_and_vital_features(cohort, features, source_map)
    add_time_features(cohort, features, source_map)
    add_score_features(features, source_map)
    text_frame = add_text_keyword_features(cohort, features, source_map)
    text_frame["row_hash"] = metadata["row_hash"].values
    text_frame["split_year"] = metadata["split_year"].values
    text_frame["split"] = metadata["split"].values

    bad_names = assert_no_arrival_leakage(features.columns.tolist())
    if bad_names:
        raise AssertionError(f"arrival leakage feature names: {bad_names[:20]}")
    hard_forbidden_intersection = sorted((set().union(*source_map.values()) & HARD_FORBIDDEN_SOURCES) - ARRIVAL_TIMESTAMP_SOURCES)
    allowed_timestamp_use = sorted(set().union(*source_map.values()) & ARRIVAL_TIMESTAMP_SOURCES)
    forbidden_source_hits = [
        src
        for src in sorted(set().union(*source_map.values()))
        if (forbidden_feature_name(src) and src not in ARRIVAL_TIMESTAMP_SOURCES)
        or any(pattern in src for pattern in ARRIVAL_VITAL_SOURCE_PATTERNS)
    ]
    if hard_forbidden_intersection:
        raise AssertionError(f"hard-forbidden source intersection: {hard_forbidden_intersection}")
    if forbidden_source_hits:
        raise AssertionError(f"forbidden source hits: {forbidden_source_hits}")
    direct_id_remaining = security_scan.pii_column_hits([*features.columns, *metadata.columns])
    if direct_id_remaining:
        raise AssertionError(f"direct identifiers leaked into output: {direct_id_remaining}")

    feature_cols = features.columns.tolist()
    full = pd.concat([metadata.reset_index(drop=True), targets.reset_index(drop=True), features.reset_index(drop=True)], axis=1)
    text_full = text_frame.reset_index(drop=True)
    le2024 = full[full["split_year"].le(2024)].copy()
    holdout = full[full["split_year"].eq(2025)].copy()
    text_le2024 = text_full[text_full["split_year"].le(2024)].copy()
    text_holdout = text_full[text_full["split_year"].eq(2025)].copy()

    le2024_path = OUT_DIR / "stage1a_features_le2024.parquet"
    holdout_path = OUT_DIR / "stage1a_features_2025_sealed.parquet"
    text_le2024_path = OUT_DIR / "stage1a_text_le2024.parquet"
    text_holdout_path = OUT_DIR / "stage1a_text_2025_sealed.parquet"
    le2024.to_parquet(le2024_path, index=False)
    holdout.to_parquet(holdout_path, index=False)
    text_le2024.to_parquet(text_le2024_path, index=False)
    text_holdout.to_parquet(text_holdout_path, index=False)

    feature_list_path = OUT_DIR / "stage1a_feature_columns.txt"
    feature_list_path.write_text("\n".join(feature_cols) + "\n", encoding="utf-8")
    source_map_path = OUT_DIR / "stage1a_feature_source_map.json"
    source_map_path.write_text(json.dumps(source_map, ensure_ascii=False, indent=2), encoding="utf-8")

    missing_heatmap_path = OUT_DIR / "stage1a_missing_rate_heatmap.png"
    make_missing_heatmap(features, missing_heatmap_path)

    le2024_counts = (
        pd.concat([metadata, targets], axis=1)
        .loc[metadata["split_year"].le(2024), ["split_year"] + targets.columns.tolist()]
        .groupby("split_year")
        .agg(["sum", "mean"])
    )
    target_summary = {}
    for col in targets.columns:
        mask = metadata["split_year"].le(2024)
        target_summary[col] = {
            "events_le2024": int(targets.loc[mask, col].sum()),
            "prevalence_le2024": float(targets.loc[mask, col].mean()),
        }

    artifact_hashes = {}
    for path in [le2024_path, holdout_path, text_le2024_path, text_holdout_path]:
        artifact_hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    split_counts_md = "\n".join(
        ["| split | rows |", "|---|---:|"]
        + [f"| {split} | {count} |" for split, count in metadata["split"].value_counts().items()]
    )

    manifest = {
        "stage": "P1_01_Stage1a",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "input": str(DATA_PATH),
        "raw_shape": list(raw_shape),
        "cohort_rows_after_filter_dedup": int(len(cohort)),
        "dedup_removed_rows": int(dedup_removed),
        "split_counts": metadata["split"].value_counts().to_dict(),
        "feature_count": len(feature_cols),
        "target_columns": targets.columns.tolist(),
        "target_summary_le2024": target_summary,
        "strict_no_arrival_leakage": True,
        "arrival_time_derived_allowlist": sorted(ARRIVAL_TIME_DERIVED_ALLOWLIST),
        "arrival_timestamp_sources_used_only_for_allowed_durations": allowed_timestamp_use,
        "arrival_forbidden_removed_features": sorted([c for c in cohort.columns if forbidden_feature_name(c) and c not in ARRIVAL_TIMESTAMP_SOURCES]),
        "arrival_forbidden_source_columns": sorted([c for c in cohort.columns if any(pattern in c for pattern in ARRIVAL_VITAL_SOURCE_PATTERNS)]),
        "arrival_feature_assertions": {
            "arrival_feature_hits": len(bad_names),
            "raw_arrival_source_hits": len(forbidden_source_hits),
            "arrival_vital_source_hits": len([src for src in source_map.values() for s in src if any(pattern in s for pattern in ARRIVAL_VITAL_SOURCE_PATTERNS)]),
            "hard_forbidden_intersection": len(hard_forbidden_intersection),
            "direct_identifier_columns_in_outputs": len(direct_id_remaining),
        },
        "pii_removed_columns": security_scan.pii_column_hits(df0.columns),
        "holdout_policy": {
            "2025_rows_written_to_sealed_artifact": int(len(holdout)),
            "2025_predictions_computed": False,
            "2025_metrics_computed": False,
            "downstream_prelock_artifact": le2024_path.name,
        },
        "runtime": {
            "python": platform.python_version(),
            "platform": platform.platform(),
        },
        "artifacts": {
            "features_le2024": str(le2024_path),
            "features_2025_sealed": str(holdout_path),
            "text_le2024": str(text_le2024_path),
            "text_2025_sealed": str(text_holdout_path),
            "feature_columns": str(feature_list_path),
            "feature_source_map": str(source_map_path),
            "missing_rate_heatmap": str(missing_heatmap_path),
        },
        "artifact_sha256": artifact_hashes,
    }

    manifest_path = OUT_DIR / "stage1a_feature_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    target_summary_md = "\n".join(
        f"| {k} | {v['events_le2024']} | {v['prevalence_le2024']:.6f} |" for k, v in target_summary.items()
    )
    qa_md = f"""# P1_01 Stage 1a QA Record

- Stage: P1_01 Stage 1a data cleaning and feature engineering
- Decision: PASS
- QA mode: structured self-audit; independent subagent QA unavailable because this turn did not explicitly authorize subagents.
- Command: `python -X utf8 scripts/run_stage1a.py`
- Strict no-arrival leakage: true
- Raw shape: {raw_shape[0]} rows x {raw_shape[1]} columns
- Cohort after EMT/adult filter and encounter dedup: {len(cohort)} rows
- Deduplicated rows removed: {dedup_removed}
- Feature count: {len(feature_cols)}
- 2025 holdout predictions/metrics computed before lock: false/false

## Split Counts

{split_counts_md}

## Outcome Summary <=2024

| outcome | events | prevalence |
|---|---:|---:|
{target_summary_md}

## Leakage Assertions

- arrival_feature_hits: {len(bad_names)}
- raw_arrival_source_hits: {len(forbidden_source_hits)}
- arrival_vital_source_hits: {manifest['arrival_feature_assertions']['arrival_vital_source_hits']}
- hard_forbidden_intersection: {len(hard_forbidden_intersection)}
- direct_identifier_columns_in_outputs: {len(direct_id_remaining)}
- allowed timestamp-derived duration features: {', '.join(sorted(ARRIVAL_TIME_DERIVED_ALLOWLIST))}
- timestamp sources used only for allowed durations: {', '.join(allowed_timestamp_use)}

## Artifact Integrity

| artifact | sha256 |
|---|---|
{chr(10).join(f'| `{name}` | `{digest}` |' for name, digest in artifact_hashes.items())}

## Prompt Coverage

- Loaded parquet input with pandas/pyarrow.
- Printed and persisted schema-derived feature manifest.
- Removed direct identifiers from modeling outputs and kept only hashes.
- Filtered `有EMT前置 == True` and adult encounters.
- Deduplicated repeated `ENCOUNTER_NO` by EMT-source completeness.
- Built all nine outcomes P1-P3 and S1-S6.
- Converted sentinel values to missing and kept missing indicators.
- Implemented mixed blood-pressure parsing and prehospital-only vital derivations.
- Created SI, mSI, aSI, rSI, rSIG, rSI-sMS, qSOFA, NEWS2, MEWS, REMS, and RTS.
- Preserved EMT prehospital airway/oxygen/procedure features for P3 as required by Prompt0/P1_01.
- Split <=2024 working artifact from sealed 2025 holdout artifact.
"""
    qa_path = LOG_DIR / "stage1a_qa_record.md"
    qa_path.write_text(qa_md, encoding="utf-8")

    access_log_path = OUT_DIR / "stage1a_holdout_access_log.txt"
    access_log_path.write_text(
        "\n".join(
            [
                f"created_at_utc={manifest['created_at_utc']}",
                "stage=P1_01_Stage1a",
                "purpose=sealed artifact preparation only",
                f"rows_2025={len(holdout)}",
                f"sealed_artifact={holdout_path}",
                f"sealed_artifact_sha256={artifact_hashes[holdout_path.name]}",
                "predictions_computed=false",
                "metrics_computed=false",
                "allowed_for_downstream_before_P1_06=false",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    print(json.dumps({"decision": "PASS", "manifest": str(manifest_path), "qa_record": str(qa_path)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
