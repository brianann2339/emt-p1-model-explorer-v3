from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import time
from dataclasses import dataclass, field
from itertools import product
from pathlib import Path
from typing import Any, Callable

import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import RobustScaler

from scripts.run_stage1b_v2_task import (
    atomic_joblib,
    atomic_json,
    atomic_parquet,
    load_stage1a_inputs,
    package_versions,
    sha256_file,
    sha256_lines,
)


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_STAGE1A_DIR = ROOT / "outputs" / "v2" / "stage1a"
DEFAULT_FOLD_MAP = DEFAULT_STAGE1A_DIR / "fixed_group_folds_v2.parquet"
DEFAULT_REGISTRY_EXTENSION = (
    ROOT / "qa_v2" / "stage3b_core_model_optimization_v2_registry_extension.json"
)
OUTCOMES = ("P1", "P2", "P3", "S1", "S2", "S3", "S4", "S5", "S6")
MODELS = ("tabpfn_standard", "tabpfn_finetuned", "tabicl")
LINEAGE = "core_model_optimization_v2"
SCIENCE_COMPLETE_RELOAD_PENDING = "SCIENCE_COMPLETE_RELOAD_PENDING"
# The PriorLabs cloud backend answers every predict from a fresh remote inference, so two calls on
# one fitted model disagree by far more than the 1e-5 reload canary allows. The deltas below were
# measured on P1_05b-coreopt-P1-tabpfn_standard (2026-08-08) and are recorded in the canary receipt
# so the artifact states what it can and cannot guarantee. See CANARY_REDEFINITION_AUTHORIZATION.
NONDETERMINISTIC_REMOTE_BACKENDS = frozenset({"priorlabs_cloud_v3_non_thinking"})
NONDETERMINISM_WITHIN_RUN_DELTA = 0.0127352886
NONDETERMINISM_RELOAD_DELTA = 0.01847
CANARY_REDEFINITION_AUTHORIZATION = {
    "decision": "reload canary is a local consistency check for remote stochastic backends",
    "approved_by": "project user, in discussion with Claude",
    "approved_on_utc": "2026-08-08",
    "scope": (
        "priorlabs_cloud_v3_non_thinking backend only; offline CUDA tabpfn_standard and every "
        "other backend keep the 1e-5 numerical reload canary"
    ),
    "evidence": (
        "canary_expected.parquet and predictions.parquet describe the same 100 validation_2024 "
        "rows from the same fitted model in the same run, and already differ by max 0.01274 / "
        "mean 0.00051; the post-reload comparison measured 0.01847 against a 1e-5 tolerance"
    ),
    "rationale": (
        "no tolerance choice can make bit-level reload reproducibility true for a stochastic "
        "remote backend, and each re-prediction bills a full training context for 100 rows"
    ),
    "precedent": (
        "the identical assertion was redefined for tabpfn_thinking with user approval on "
        "2026-08-05; see run_stage3b_v2_task.CANARY_REDEFINITION_AUTHORIZATION"
    ),
    "status": "SETTLED — do not revert or re-test at provider cost without new user approval",
}
TASK_FAMILY = "stage3b_core_model_optimization_v2"
TABICL_S2_LEGACY_TASK_ID = "P1_05b-coreopt-S2-tabicl"
TABICL_S2_LEGACY_RUNNER_SHA256 = (
    "079496b57fd52e1928e9e99d8136fcaf246c95f8d44b9f22a527e550c7e93235"
)
TABICL_S2_LEGACY_RUNTIME_CONTEXT_SHA256 = (
    "0b19a30d76c35c20594078b072959a30bf7992d411aa5b6321af7cd4bb4a9b08"
)
TABICL_S2_LEGACY_BINDING_SHA256 = (
    "05c300e7c5af9c806cc193b8a9c926a3722d11610e77982541ec2a6750037607"
)
TABICL_S2_LEGACY_COMPLETED_KEYS_SHA256 = (
    "628dfc79307fa875b8bd6cdec161d94109889a50fdd2094241001253a544cf66"
)
TABICL_S2_LOCKED_CONFIG_SHA256 = (
    "03119933dfddbe68165ed7fb3793b1858d413355aca4d8290c95f485c40d744e"
)
TABICL_S2_LOCKED_SEED = 20260716
FINETUNE_CHECKPOINT_ROOT_ENV = "STAGE3B_TABPFN_FINETUNE_CHECKPOINT_ROOT"
FINETUNE_EPOCHS = 20
FINETUNE_LEARNING_RATE = 1e-5
FINETUNE_SAVE_CHECKPOINT_INTERVAL = 1
FINETUNE_CANARY_CONTEXT_SAMPLES = 1024
FINETUNE_CANARY_INFERENCE_SAMPLES = 4096
FINETUNE_CANARY_ENVELOPES = {
    1: (FINETUNE_CANARY_CONTEXT_SAMPLES, FINETUNE_CANARY_INFERENCE_SAMPLES),
    2: (2048, 8192),
    3: (4096, 8192),
}
FINETUNE_FORMAL_CONTEXT_SAMPLES = 4096
FINETUNE_FORMAL_INFERENCE_SAMPLES = 8192
FINETUNE_CANARY_FOLD = 0
DEVELOPMENT_YEARS = (2020, 2021, 2022, 2023)
FIXED_FOLDS = (0, 1, 2, 3, 4)
SEARCH_SEED = 20260715
BASE_VALIDATION_SEEDS = (20260716, 20260717, 20260718)
EXTENDED_VALIDATION_SEEDS = BASE_VALIDATION_SEEDS + (20260719, 20260720)
FIT_RESERVE_MULTIPLIER = 1.25
CHECKPOINT_FINALIZATION_RESERVE_SECONDS = 300.0
FEATURE_COUNTS = (32, 64, 128, "all")
CONTEXT_ROW_POLICIES = ("full_or_model_limit", "half_model_limit")
PREPROCESSING_POLICIES = ("median_indicator", "robust_indicator")
CONTEXT_BAGGING_POLICIES = ("prevalence_stratified", "event_enriched")
ENSEMBLE_AXES = {
    "tabpfn_standard": {"estimator_counts": (4, 8), "bag_counts": (1, 2)},
    "tabpfn_finetuned": {"estimator_counts": (1, 2), "bag_counts": (1, 2)},
    "tabicl": {"estimator_counts": (1, 2), "bag_counts": (2, 4)},
}


class Stage3bCoreOptimizationError(RuntimeError):
    pass


def atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.tmp")
    try:
        shutil.copy2(source, temporary)
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def offline_model_path(model: str) -> Path:
    environment_keys = {
        "tabpfn_standard": "STAGE3B_TABPFN_STANDARD_MODEL_PATH",
        "tabpfn_finetuned": "STAGE3B_TABPFN_FINETUNED_MODEL_PATH",
        "tabicl": "STAGE3B_TABICL_MODEL_PATH",
    }
    value = os.environ.get(environment_keys[model], "")
    path = Path(value)
    if not value or path.is_symlink() or not path.is_file():
        raise Stage3bCoreOptimizationError(
            f"verified offline pretrained model path is missing: {model}"
        )
    return path.resolve(strict=True)


@dataclass(frozen=True)
class SearchPolicy:
    minimum_complete_configurations: int = 32
    top_configurations: int = 5
    seed_revalidation_configurations: int = 3
    base_validation_seeds: tuple[int, ...] = BASE_VALIDATION_SEEDS
    extended_validation_seeds: tuple[int, ...] = EXTENDED_VALIDATION_SEEDS
    instability_tolerance: float = 0.01
    session_limit_hours: float = 9.75
    new_fit_cutoff_hours: float = 9.25
    p90_fit_seconds: float = 900.0
    fit_reserve_multiplier: float = FIT_RESERVE_MULTIPLIER
    checkpoint_finalization_reserve_seconds: float = (
        CHECKPOINT_FINALIZATION_RESERVE_SECONDS
    )


@dataclass
class RunBudget:
    deadline: float | None
    maximum_new_evaluations: int | None = None
    new_evaluations: int = 0
    new_fit_cutoff: float | None = None
    p90_fit_seconds: float = 0.0
    fit_reserve_multiplier: float = FIT_RESERVE_MULTIPLIER
    checkpoint_finalization_reserve_seconds: float = (
        CHECKPOINT_FINALIZATION_RESERVE_SECONDS
    )

    @property
    def fit_reserve_seconds(self) -> float:
        return (
            self.p90_fit_seconds * self.fit_reserve_multiplier
            + self.checkpoint_finalization_reserve_seconds
        )

    def claim(self, *, now: float | None = None) -> bool:
        observed = time.perf_counter() if now is None else now
        if self.new_fit_cutoff is not None and observed >= self.new_fit_cutoff:
            return False
        if (
            self.deadline is not None
            and observed + self.fit_reserve_seconds > self.deadline
        ):
            return False
        if (
            self.maximum_new_evaluations is not None
            and self.new_evaluations >= self.maximum_new_evaluations
        ):
            return False
        self.new_evaluations += 1
        return True


@dataclass
class FittedContextEnsemble:
    feature_order: list[str]
    transformer: Any
    estimators: list[Any]
    runtime_checkpoint_dirs: list[Path] = field(default_factory=list, repr=False)
    runtime_fit_records: list[dict[str, Any]] = field(default_factory=list, repr=False)

    def predict_proba(self, frame: pd.DataFrame) -> np.ndarray:
        values = self.transformer.transform(frame[self.feature_order])
        probabilities = [
            np.asarray(estimator.predict_proba(values), dtype="float64")[:, 1]
            for estimator in self.estimators
        ]
        probability = np.mean(np.vstack(probabilities), axis=0)
        return np.column_stack([1.0 - probability, probability])


Backend = Callable[..., tuple[np.ndarray, Any]]


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def tabicl_s2_legacy_expected_binding_hashes(
    current_binding_hashes: dict[str, str],
    legacy_runner_sha256: str,
) -> dict[str, str]:
    if legacy_runner_sha256 != TABICL_S2_LEGACY_RUNNER_SHA256:
        raise Stage3bCoreOptimizationError(
            "legacy checkpoint compatibility is limited to exact TabICL S2"
        )
    return {
        **current_binding_hashes,
        "runner_sha256": legacy_runner_sha256,
        "runtime_context_sha256": TABICL_S2_LEGACY_RUNTIME_CONTEXT_SHA256,
    }


def validate_tabicl_s2_legacy_checkpoint(
    output_dir: Path,
    *,
    task_id: str,
    outcome: str,
    model: str,
    legacy_runner_sha256: str,
    expected_binding_hashes: dict[str, str],
) -> dict[str, str]:
    if (
        task_id != TABICL_S2_LEGACY_TASK_ID
        or outcome != "S2"
        or model != "tabicl"
        or legacy_runner_sha256 != TABICL_S2_LEGACY_RUNNER_SHA256
    ):
        raise Stage3bCoreOptimizationError(
            "legacy checkpoint compatibility is limited to exact TabICL S2"
        )
    manifest_path = output_dir / "checkpoint_manifest.json"
    if manifest_path.is_symlink() or not manifest_path.is_file():
        raise Stage3bCoreOptimizationError(
            "legacy TabICL S2 checkpoint manifest is missing"
        )
    manifest = read_json(manifest_path)
    binding_hashes = manifest.get("binding_hashes")
    if (
        manifest.get("task_id") != TABICL_S2_LEGACY_TASK_ID
        or manifest.get("status") != "PARTIAL"
        or not isinstance(binding_hashes, dict)
        or canonical_sha256(binding_hashes) != TABICL_S2_LEGACY_BINDING_SHA256
        or binding_hashes != expected_binding_hashes
    ):
        raise Stage3bCoreOptimizationError(
            "legacy TabICL S2 checkpoint binding differs"
        )
    completed = manifest.get("completed_keys")
    if not isinstance(completed, list):
        raise Stage3bCoreOptimizationError(
            "legacy TabICL S2 completed checkpoint keys are invalid"
        )
    allowed_new = {
        ("locked_oof", 3),
        ("locked_oof", 4),
        ("locked_final", -1),
    }
    original = []
    observed_new = set()
    for record in completed:
        identity = (record.get("phase"), record.get("fold"))
        if identity in allowed_new:
            if (
                record.get("config_sha256") != TABICL_S2_LOCKED_CONFIG_SHA256
                or record.get("seed") != TABICL_S2_LOCKED_SEED
                or identity in observed_new
            ):
                raise Stage3bCoreOptimizationError(
                    "legacy TabICL S2 continuation key differs"
                )
            observed_new.add(identity)
        else:
            original.append(record)
    if (
        len(original) != 238
        or len(completed) != 238 + len(observed_new)
        or canonical_sha256(original) != TABICL_S2_LEGACY_COMPLETED_KEYS_SHA256
    ):
        raise Stage3bCoreOptimizationError(
            "legacy TabICL S2 frozen checkpoint subset differs"
        )
    return dict(binding_hashes)


def finetune_checkpoint_directory(
    *,
    configuration: dict[str, Any],
    selected_feature_order: list[str],
    fit_rows: pd.DataFrame,
    fit_indices: np.ndarray,
    monitor_rows: pd.DataFrame,
    target_column: str,
    checkpoint_scope: dict[str, Any],
    finetune_context_samples: int | None,
    finetune_inference_samples: int | None,
    full_outer_pool: bool,
    member_seed: int,
    bag: int,
    member: int,
) -> Path:
    root_value = os.environ.get(FINETUNE_CHECKPOINT_ROOT_ENV, "")
    root = Path(root_value)
    if not root_value or not root.is_absolute() or root.is_symlink():
        raise Stage3bCoreOptimizationError(
            "fine-tune checkpoint root is missing or unsafe"
        )
    root.mkdir(parents=True, exist_ok=True)
    if root.is_symlink() or not root.is_dir():
        raise Stage3bCoreOptimizationError("fine-tune checkpoint root is unsafe")
    root = root.resolve(strict=True)
    selected_fit = fit_rows.iloc[fit_indices]
    binding = {
        "contract_version": "p1-v2-stage3b-finetune-fit-checkpoint/1",
        "config_sha256": configuration["config_sha256"],
        "checkpoint_scope": checkpoint_scope,
        "selected_feature_order_sha256": sha256_lines(selected_feature_order),
        "target_column": target_column,
        "member_seed": int(member_seed),
        "bag": int(bag),
        "member": int(member),
        "fit_row_count": int(len(selected_fit)),
        "fit_row_hashes_sha256": sha256_lines(
            selected_fit["row_hash"].astype(str).tolist()
        ),
        "fit_targets_sha256": sha256_lines(
            selected_fit[target_column].astype("int8").astype(str).tolist()
        ),
        "monitor_row_count": int(len(monitor_rows)),
        "monitor_row_hashes_sha256": sha256_lines(
            monitor_rows["row_hash"].astype(str).tolist()
        ),
        "monitor_targets_sha256": sha256_lines(
            monitor_rows[target_column].astype("int8").astype(str).tolist()
        ),
        "epochs": FINETUNE_EPOCHS,
        "learning_rate": FINETUNE_LEARNING_RATE,
        "use_activation_checkpointing": True,
        "save_checkpoint_interval": FINETUNE_SAVE_CHECKPOINT_INTERVAL,
        "n_finetune_ctx_plus_query_samples": finetune_context_samples,
        "n_inference_subsample_samples": finetune_inference_samples,
        "full_outer_pool": full_outer_pool,
    }
    identity = canonical_sha256(binding)
    checkpoint_dir = root / identity
    binding_path = checkpoint_dir / "fit_binding.json"
    if checkpoint_dir.exists():
        if checkpoint_dir.is_symlink() or not checkpoint_dir.is_dir():
            raise Stage3bCoreOptimizationError(
                "fine-tune checkpoint directory is unsafe"
            )
        if not binding_path.is_file() or read_json(binding_path) != {
            "fit_identity": binding,
            "fit_identity_sha256": identity,
        }:
            raise Stage3bCoreOptimizationError(
                "fine-tune checkpoint binding differs before resume"
            )
    else:
        checkpoint_dir.mkdir()
        atomic_json(
            binding_path,
            {"fit_identity": binding, "fit_identity_sha256": identity},
        )
    resolved = checkpoint_dir.resolve(strict=True)
    try:
        resolved.relative_to(root)
    except ValueError as error:
        raise Stage3bCoreOptimizationError(
            "fine-tune checkpoint directory escapes its root"
        ) from error
    return resolved


def select_latest_complete_finetune_checkpoint(
    checkpoint_dir: Path,
    *,
    train_size: int,
) -> dict[str, Any]:
    try:
        import torch
        from tabpfn.finetuning.train_util import (
            get_checkpoint_path_and_epoch_from_output_dir,
        )
    except ImportError as error:
        raise Stage3bCoreOptimizationError(
            "fine-tune checkpoint resume API is unavailable"
        ) from error
    candidates: list[tuple[int, Path]] = []
    for path in checkpoint_dir.glob("checkpoint_*_[0-9]*.pth"):
        if path.is_symlink() or not path.is_file():
            raise Stage3bCoreOptimizationError(
                "fine-tune numbered checkpoint is unsafe"
            )
        try:
            epoch = int(path.stem.rsplit("_", 1)[1])
        except (IndexError, ValueError) as error:
            raise Stage3bCoreOptimizationError(
                "fine-tune numbered checkpoint epoch is invalid"
            ) from error
        if epoch < 1 or epoch > FINETUNE_EPOCHS:
            raise Stage3bCoreOptimizationError(
                "fine-tune numbered checkpoint epoch is outside the locked run"
            )
        candidates.append((epoch, path))
    selected: tuple[int, Path] | None = None
    rejected = []
    for epoch, path in sorted(candidates, key=lambda value: value[0], reverse=True):
        try:
            checkpoint = torch.load(path, map_location="cpu", weights_only=True)
            saved_epoch = int(checkpoint["epoch"])
        except (EOFError, KeyError, OSError, RuntimeError, TypeError, ValueError):
            rejected.append(
                {"path": path.name, "sha256": sha256_file(path), "epoch": epoch}
            )
            continue
        if saved_epoch != epoch:
            raise Stage3bCoreOptimizationError(
                "fine-tune checkpoint filename/payload epoch differs"
            )
        selected = (epoch, path)
        break
    for _, path in candidates:
        if selected is None or path != selected[1]:
            path.unlink()
    selected_record = None
    if selected is not None:
        official_path, official_epoch = get_checkpoint_path_and_epoch_from_output_dir(
            output_dir=checkpoint_dir,
            train_size=train_size,
            get_best=False,
        )
        if official_path != selected[1] or int(official_epoch) != selected[0]:
            raise Stage3bCoreOptimizationError(
                "fine-tune official resume API did not select the latest checkpoint"
            )
        selected_record = {
            "path": selected[1].name,
            "sha256": sha256_file(selected[1]),
            "epoch": selected[0],
            "next_epoch": selected[0] + 1,
            "official_get_best": False,
        }
    audit = {
        "contract_version": "p1-v2-stage3b-finetune-resume-selection/1",
        "train_size": int(train_size),
        "selected_checkpoint": selected_record,
        "rejected_incomplete_checkpoints": rejected,
    }
    audit["resume_selection_sha256"] = canonical_sha256(audit)
    atomic_json(checkpoint_dir / "resume_selection.json", audit)
    return audit


def take_runtime_checkpoint_dirs(model_state: Any) -> list[Path]:
    if not isinstance(model_state, FittedContextEnsemble):
        return []
    paths = list(model_state.runtime_checkpoint_dirs)
    model_state.runtime_checkpoint_dirs.clear()
    return paths


def remove_completed_finetune_checkpoints(paths: list[Path]) -> None:
    if not paths:
        return
    root_value = os.environ.get(FINETUNE_CHECKPOINT_ROOT_ENV, "")
    if not root_value:
        raise Stage3bCoreOptimizationError("fine-tune checkpoint root is missing")
    root = Path(root_value)
    if root.is_symlink() or not root.is_dir():
        raise Stage3bCoreOptimizationError("fine-tune checkpoint root is unsafe")
    root = root.resolve(strict=True)
    for path in paths:
        if path.is_symlink() or not path.is_dir():
            raise Stage3bCoreOptimizationError(
                "completed fine-tune checkpoint directory is unsafe"
            )
        path = path.resolve(strict=True)
        if path.parent != root:
            raise Stage3bCoreOptimizationError(
                "completed fine-tune checkpoint escapes its exact root"
            )
        binding_path = path / "fit_binding.json"
        binding = read_json(binding_path)
        if (
            binding.get("fit_identity_sha256") != path.name
            or canonical_sha256(binding.get("fit_identity")) != path.name
        ):
            raise Stage3bCoreOptimizationError(
                "completed fine-tune checkpoint binding differs"
            )
        shutil.rmtree(path)


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise Stage3bCoreOptimizationError(f"JSON root is not an object: {path}")
    return value


def model_search_axes(model: str) -> dict[str, list[Any]]:
    if model not in MODELS:
        raise Stage3bCoreOptimizationError(f"unsupported Stage3b core model: {model}")
    return {
        "feature_counts": list(FEATURE_COUNTS),
        "context_row_policies": list(CONTEXT_ROW_POLICIES),
        "preprocessing_policies": list(PREPROCESSING_POLICIES),
        "context_bagging_policies": list(CONTEXT_BAGGING_POLICIES),
        "estimator_counts": list(ENSEMBLE_AXES[model]["estimator_counts"]),
        "bag_counts": list(ENSEMBLE_AXES[model]["bag_counts"]),
    }


def candidate_configurations(model: str) -> list[dict[str, Any]]:
    axes = model_search_axes(model)
    configurations = []
    for values in product(
        axes["feature_counts"],
        axes["context_row_policies"],
        axes["preprocessing_policies"],
        axes["context_bagging_policies"],
        axes["estimator_counts"],
        axes["bag_counts"],
    ):
        configuration = {
            "feature_count": values[0],
            "context_row_policy": values[1],
            "preprocessing": values[2],
            "context_bagging": values[3],
            "estimator_count": values[4],
            "bag_count": values[5],
        }
        configuration["config_sha256"] = canonical_sha256(configuration)
        configurations.append(configuration)
    return sorted(configurations, key=lambda value: value["config_sha256"])


def screening_configurations(model: str, minimum: int) -> list[dict[str, Any]]:
    configurations = candidate_configurations(model)
    if len(configurations) < minimum:
        raise Stage3bCoreOptimizationError(
            f"candidate grid is smaller than the minimum: {len(configurations)} < {minimum}"
        )
    return configurations[:minimum]


def exact_registry_task(
    registry_path: Path,
    task_id: str,
    outcome: str,
    model: str,
) -> tuple[dict[str, Any], dict[str, str]]:
    registry = read_json(registry_path)
    if (
        registry.get("registry_kind")
        != "stage3b_core_model_optimization_v2_extension"
        or registry.get("lineage") != LINEAGE
        or registry.get("2025_access_count") != 0
    ):
        raise Stage3bCoreOptimizationError("Stage3b optimization registry header differs")
    tasks = registry.get("tasks")
    expected_pairs = {(item, family) for item in OUTCOMES for family in MODELS}
    if (
        not isinstance(tasks, list)
        or len(tasks) != 27
        or {(task.get("outcome"), task.get("model")) for task in tasks}
        != expected_pairs
        or len({task.get("task_id") for task in tasks}) != 27
    ):
        raise Stage3bCoreOptimizationError(
            "Stage3b optimization registry must be the exact 27-task cross product"
        )
    matches = [task for task in tasks if task.get("task_id") == task_id]
    if len(matches) != 1:
        raise Stage3bCoreOptimizationError(f"registry task is absent or duplicated: {task_id}")
    task = matches[0]
    expected = {
        "task_id": f"P1_05b-coreopt-{outcome}-{model}",
        "stage": "P1_05b",
        "wave": "W04_CORE",
        "task_family": TASK_FAMILY,
        "outcome": outcome,
        "model": model,
        "lineage": LINEAGE,
        "scientific_artifact": True,
    }
    drift = {
        key: (value, task.get(key))
        for key, value in expected.items()
        if task.get(key) != value
    }
    contract = task.get("optimization_contract", {})
    if drift or contract.get("search_axes") != model_search_axes(model):
        raise Stage3bCoreOptimizationError(
            f"Stage3b optimization registry task drift: {drift}"
        )
    return task, {
        "registry_extension_sha256": sha256_file(registry_path),
        "registry_task_sha256": canonical_sha256(task),
        "selection_contract_sha256": canonical_sha256(
            registry.get("selection_contract")
        ),
    }


def validate_development_frame(
    frame: pd.DataFrame,
    *,
    require_all_folds: bool = True,
) -> None:
    required = {"row_hash", "group_hash", "split", "split_year", "fold"}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise Stage3bCoreOptimizationError(
            f"development frame lacks required columns: {missing}"
        )
    years = pd.to_numeric(frame["split_year"], errors="coerce")
    folds = pd.to_numeric(frame["fold"], errors="coerce")
    observed_folds = tuple(sorted(int(value) for value in folds.dropna().unique()))
    group_fold_counts = (
        frame.assign(_fold=folds)
        .groupby("group_hash", observed=True)["_fold"]
        .nunique()
    )
    if (
        frame.empty
        or frame["row_hash"].astype(str).duplicated().any()
        or frame["group_hash"].isna().any()
        or set(frame["split"].astype(str)) != {"train_2020_2023"}
        or years.isna().any()
        or not years.between(2020, 2023).all()
        or folds.isna().any()
        or not set(observed_folds) <= set(FIXED_FOLDS)
        or (require_all_folds and observed_folds != FIXED_FOLDS)
        or group_fold_counts.gt(1).any()
    ):
        raise Stage3bCoreOptimizationError(
            "optimization fit/monitor/selection requires locked 2020-2023 group folds"
        )


def validate_validation_frame(
    development: pd.DataFrame,
    validation: pd.DataFrame,
) -> None:
    required = {"row_hash", "split", "split_year"}
    if required - set(validation.columns):
        raise Stage3bCoreOptimizationError("validation frame lacks temporal keys")
    years = pd.to_numeric(validation["split_year"], errors="coerce")
    if (
        validation.empty
        or validation["row_hash"].astype(str).duplicated().any()
        or set(validation["split"].astype(str)) != {"validation_2024"}
        or years.isna().any()
        or not years.eq(2024).all()
        or set(development["row_hash"].astype(str))
        & set(validation["row_hash"].astype(str))
    ):
        raise Stage3bCoreOptimizationError(
            "2024 validation must be disjoint and predict-only"
        )


def checkpoint_key(
    config_sha256: str,
    fold: int,
    seed: int,
    phase: str,
) -> dict[str, Any]:
    payload = {
        "config_sha256": config_sha256,
        "fold": int(fold),
        "seed": int(seed),
        "phase": phase,
    }
    return {**payload, "checkpoint_key_sha256": canonical_sha256(payload)}


def remaining_locked_checkpoint_keys(
    store: CheckpointStore,
    config_sha256: str,
    seed: int,
) -> list[dict[str, Any]]:
    expected = [
        checkpoint_key(config_sha256, fold, seed, "locked_oof")
        for fold in FIXED_FOLDS
    ]
    expected.append(checkpoint_key(config_sha256, -1, seed, "locked_final"))
    return [key for key in expected if store.get(key) is None]


class CheckpointStore:
    def __init__(
        self,
        output_dir: Path,
        *,
        task_id: str,
        binding_hashes: dict[str, str],
        policy: SearchPolicy,
    ):
        self.output_dir = output_dir
        self.record_dir = output_dir / "checkpoint_records"
        self.manifest_path = output_dir / "checkpoint_manifest.json"
        self.task_id = task_id
        self.binding_hashes = dict(binding_hashes)
        self.policy = policy
        self.record_dir.mkdir(parents=True, exist_ok=True)
        if self.manifest_path.exists():
            self.manifest = read_json(self.manifest_path)
            if self.manifest.get("binding_hashes") != self.binding_hashes:
                raise Stage3bCoreOptimizationError(
                    "checkpoint manifest exact binding hashes differ"
                )
            for record in self.manifest.get("completed_keys", []):
                path = self.output_dir / record["record_path"]
                if sha256_file(path) != record["record_sha256"]:
                    raise Stage3bCoreOptimizationError(
                        "checkpoint record hash differs before resume"
                    )
        else:
            self.manifest = {
                "schema_version": "1.0",
                "task_id": task_id,
                "lineage": LINEAGE,
                "status": "PARTIAL",
                "binding_hashes": self.binding_hashes,
                "checkpoint_key_fields": [
                    "config_sha256",
                    "fold",
                    "seed",
                    "phase",
                ],
                "completed_keys": [],
                "session_limit_hours": policy.session_limit_hours,
                "new_fit_cutoff_hours": policy.new_fit_cutoff_hours,
                "p90_fit_seconds": policy.p90_fit_seconds,
                "fit_reserve_multiplier": policy.fit_reserve_multiplier,
                "checkpoint_finalization_reserve_seconds": (
                    policy.checkpoint_finalization_reserve_seconds
                ),
                "session_limit_role": "checkpoint_resume_boundary_not_model_cap",
                "exact_hash_resume_required": True,
            }
            self._write_manifest()

    def _write_manifest(self) -> None:
        self.manifest["completed_keys"] = sorted(
            self.manifest["completed_keys"],
            key=lambda value: value["checkpoint_key_sha256"],
        )
        atomic_json(self.manifest_path, self.manifest)

    def get(self, key: dict[str, Any]) -> dict[str, Any] | None:
        matches = [
            record
            for record in self.manifest["completed_keys"]
            if record["checkpoint_key_sha256"] == key["checkpoint_key_sha256"]
        ]
        if not matches:
            return None
        if len(matches) != 1 or any(matches[0][name] != key[name] for name in key):
            raise Stage3bCoreOptimizationError("checkpoint key identity differs")
        path = self.output_dir / matches[0]["record_path"]
        payload = read_json(path)
        if (
            payload.get("checkpoint_key") != key
            or payload.get("binding_hashes") != self.binding_hashes
        ):
            raise Stage3bCoreOptimizationError("checkpoint record binding differs")
        return payload["result"]

    def put(self, key: dict[str, Any], result: dict[str, Any]) -> None:
        existing = self.get(key)
        if existing is not None:
            if existing != result:
                raise Stage3bCoreOptimizationError(
                    "checkpoint key already exists with a different result"
                )
            return
        relative = Path("checkpoint_records") / f"{key['checkpoint_key_sha256']}.json"
        path = self.output_dir / relative
        atomic_json(
            path,
            {
                "schema_version": "1.0",
                "task_id": self.task_id,
                "lineage": LINEAGE,
                "checkpoint_key": key,
                "binding_hashes": self.binding_hashes,
                "result": result,
            },
        )
        self.manifest["completed_keys"].append(
            {
                **key,
                "record_path": relative.as_posix(),
                "record_sha256": sha256_file(path),
            }
        )
        self._write_manifest()

    def set_status(self, status: str) -> None:
        self.manifest["status"] = status
        self._write_manifest()


def selected_feature_order(
    feature_order: list[str],
    feature_count: int | str,
    *,
    model_limit_features: int,
    fit_rows: pd.DataFrame | None = None,
) -> list[str]:
    if feature_count == "all":
        requested = list(feature_order)
    elif isinstance(feature_count, int) and feature_count >= 1:
        requested = list(feature_order[: min(feature_count, len(feature_order))])
    else:
        raise Stage3bCoreOptimizationError("feature count is invalid")
    if model_limit_features < 1:
        raise Stage3bCoreOptimizationError("model feature limit is invalid")
    if fit_rows is None:
        selected = requested[:model_limit_features]
    else:
        missing = fit_rows[requested].isna().any(axis=0)
        selected = []
        transformed_width = 0
        for feature in requested:
            width = 1 + int(bool(missing[feature]))
            if transformed_width + width <= model_limit_features:
                selected.append(feature)
                transformed_width += width
    if not selected:
        raise Stage3bCoreOptimizationError(
            "runtime max_features cannot admit any configured feature"
        )
    return selected


def make_transformer(policy: str) -> Any:
    if policy == "median_indicator":
        return SimpleImputer(strategy="median", add_indicator=True)
    if policy == "robust_indicator":
        return Pipeline(
            [
                ("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                ("scale", RobustScaler()),
            ]
        )
    raise Stage3bCoreOptimizationError(f"unsupported preprocessing policy: {policy}")


def context_indices(
    target: np.ndarray,
    *,
    maximum_rows: int,
    policy: str,
    seed: int,
) -> np.ndarray:
    labels = np.asarray(target, dtype="int8")
    if maximum_rows >= len(labels):
        return np.arange(len(labels), dtype=int)
    rng = np.random.default_rng(seed)
    positive = np.flatnonzero(labels == 1)
    negative = np.flatnonzero(labels == 0)
    if not len(positive) or not len(negative):
        raise Stage3bCoreOptimizationError("context bagging requires both outcome classes")
    if policy == "prevalence_stratified":
        positive_count = int(round(maximum_rows * len(positive) / len(labels)))
    elif policy == "event_enriched":
        positive_count = maximum_rows // 2
    else:
        raise Stage3bCoreOptimizationError(
            f"unsupported context bagging policy: {policy}"
        )
    positive_count = min(len(positive), max(1, positive_count))
    negative_count = min(len(negative), maximum_rows - positive_count)
    remaining = maximum_rows - positive_count - negative_count
    if remaining:
        positive_count += min(len(positive) - positive_count, remaining)
        remaining = maximum_rows - positive_count - negative_count
        negative_count += min(len(negative) - negative_count, remaining)
    selected = np.concatenate(
        [
            rng.choice(positive, positive_count, replace=False),
            rng.choice(negative, negative_count, replace=False),
        ]
    )
    return np.sort(selected.astype(int))


def context_row_limit(
    row_count: int,
    model_limit_rows: int,
    policy: str,
    *,
    transformed_feature_count: int = 1,
    model_limit_cells: int | None = None,
) -> int:
    if policy == "full_or_model_limit":
        maximum = min(row_count, model_limit_rows)
    elif policy == "half_model_limit":
        maximum = min(row_count, max(2, model_limit_rows // 2))
    else:
        raise Stage3bCoreOptimizationError(f"unsupported context row policy: {policy}")
    if transformed_feature_count < 1:
        raise Stage3bCoreOptimizationError("transformed feature count is invalid")
    if model_limit_cells is not None:
        maximum = min(maximum, model_limit_cells // transformed_feature_count)
    if maximum < 2:
        raise Stage3bCoreOptimizationError(
            "runtime row/cell limits cannot admit a two-row context"
        )
    return maximum


def finetune_epoch_coverage(
    target: np.ndarray,
    *,
    context_samples: int,
) -> dict[str, Any]:
    pool_rows = int(len(target))
    if context_samples < 2 or pool_rows < 2:
        raise Stage3bCoreOptimizationError("fine-tune coverage envelope is invalid")
    full_chunks = pool_rows // context_samples
    remainder = pool_rows % context_samples
    minimum_remainder = 2000
    chunk_count = full_chunks + int(remainder >= minimum_remainder)
    class_counts = np.unique(np.asarray(target, dtype="int8"), return_counts=True)[1]
    minimum_class_count = int(class_counts.min()) if len(class_counts) else 0
    if chunk_count <= 1:
        covered_rows = pool_rows if pool_rows >= minimum_remainder else 0
        mode = "single_chunk_or_empty"
    elif minimum_class_count >= chunk_count:
        covered_rows = pool_rows
        mode = "stratified_kfold_full_pool"
    else:
        covered_rows = full_chunks * context_samples
        if remainder >= minimum_remainder:
            covered_rows += remainder
        mode = "non_stratified_fixed_chunks"
    return {
        "outer_sampling_pool_rows": pool_rows,
        "n_finetune_ctx_plus_query_samples": int(context_samples),
        "query_rows_per_chunk": int(context_samples * 0.2),
        "chunk_count_per_epoch": int(chunk_count),
        "actual_rows_covered_per_epoch": int(covered_rows),
        "actual_row_coverage_fraction_per_epoch": float(covered_rows / pool_rows),
        "coverage_mode": mode,
        "minimum_class_count": minimum_class_count,
        "epoch_seed_rule": "member_seed_plus_zero_based_epoch",
    }


def resolve_device(device: str) -> str:
    if device != "auto":
        return device
    try:
        import torch

        return "cuda" if torch.cuda.is_available() else "cpu"
    except ImportError:
        return "cpu"


def formal_finetune_backend_kwargs(model: str) -> dict[str, Any]:
    if model != "tabpfn_finetuned":
        return {}
    return {
        "finetune_context_samples": FINETUNE_FORMAL_CONTEXT_SAMPLES,
        "finetune_inference_samples": FINETUNE_FORMAL_INFERENCE_SAMPLES,
        "finetune_full_outer_pool": True,
    }


def fit_predict_backend(
    *,
    model: str,
    configuration: dict[str, Any],
    fit_rows: pd.DataFrame,
    predict_rows: pd.DataFrame,
    feature_order: list[str],
    target_column: str,
    seed: int,
    device: str,
    model_limit_rows: int,
    model_limit_features: int,
    model_limit_cells: int | None,
    monitor_rows: pd.DataFrame | None,
    checkpoint_scope: dict[str, Any] | None = None,
    finetune_context_samples: int | None = None,
    finetune_inference_samples: int | None = None,
    finetune_full_outer_pool: bool = False,
) -> tuple[np.ndarray, FittedContextEnsemble]:
    selected = selected_feature_order(
        feature_order,
        configuration["feature_count"],
        model_limit_features=model_limit_features,
        fit_rows=fit_rows,
    )
    transformer = make_transformer(configuration["preprocessing"])
    fit_values = transformer.fit_transform(fit_rows[selected])
    predict_values = transformer.transform(predict_rows[selected])
    monitor_values = (
        None if monitor_rows is None else transformer.transform(monitor_rows[selected])
    )
    transformed_feature_count = int(fit_values.shape[1])
    if transformed_feature_count > model_limit_features:
        raise Stage3bCoreOptimizationError(
            "transformed feature count exceeds runtime max_features"
        )
    target = fit_rows[target_column].to_numpy(dtype="int8")
    maximum_rows = (
        len(fit_rows)
        if model == "tabpfn_finetuned" and finetune_full_outer_pool
        else context_row_limit(
            len(fit_rows),
            model_limit_rows,
            configuration["context_row_policy"],
            transformed_feature_count=transformed_feature_count,
            model_limit_cells=model_limit_cells,
        )
    )
    estimators = []
    probabilities = []
    runtime_checkpoint_dirs: list[Path] = []
    runtime_fit_records: list[dict[str, Any]] = []
    for bag in range(int(configuration["bag_count"])):
        bag_seed = int(seed + bag * 1009)
        indices = context_indices(
            target,
            maximum_rows=maximum_rows,
            policy=configuration["context_bagging"],
            seed=bag_seed,
        )
        if model == "tabpfn_standard":
            from tabpfn import TabPFNClassifier

            estimator = TabPFNClassifier(
                device=device,
                n_estimators=int(configuration["estimator_count"]),
                random_state=bag_seed,
                model_path=offline_model_path(model),
            )
            estimator.fit(fit_values[indices], target[indices])
            estimators.append(estimator)
            probabilities.append(
                np.asarray(estimator.predict_proba(predict_values), dtype="float64")[:, 1]
            )
            continue
        for member in range(int(configuration["estimator_count"])):
            member_seed = int(bag_seed + member * 7919)
            runtime_record: dict[str, Any] | None = None
            torch_module: Any = None
            if model == "tabpfn_finetuned":
                if monitor_rows is None or monitor_values is None:
                    raise Stage3bCoreOptimizationError(
                        "fine-tuned TabPFN requires a development-only monitor fold"
                    )
                if checkpoint_scope is None:
                    raise Stage3bCoreOptimizationError(
                        "fine-tuned TabPFN requires an exact outer checkpoint scope"
                    )
                from tabpfn.finetuning import FinetunedTabPFNClassifier

                np.random.seed(member_seed)
                try:
                    import torch

                    torch.manual_seed(member_seed)
                    if torch.cuda.is_available():
                        torch.cuda.manual_seed_all(member_seed)
                    torch_module = torch
                except ImportError:
                    pass
                if (
                    finetune_context_samples is None
                    or finetune_inference_samples is None
                    or not finetune_full_outer_pool
                ):
                    raise Stage3bCoreOptimizationError(
                        "fine-tune formal memory envelope/full outer pool is required"
                    )
                estimator_kwargs: dict[str, Any] = {
                    "device": device,
                    "epochs": FINETUNE_EPOCHS,
                    "learning_rate": FINETUNE_LEARNING_RATE,
                    "use_activation_checkpointing": True,
                    "save_checkpoint_interval": FINETUNE_SAVE_CHECKPOINT_INTERVAL,
                    "extra_classifier_kwargs": {
                        "model_path": offline_model_path(model)
                    },
                }
                if finetune_context_samples is not None:
                    estimator_kwargs.update(
                        {
                            "n_finetune_ctx_plus_query_samples": int(
                                finetune_context_samples
                            ),
                            "n_inference_subsample_samples": int(
                                finetune_inference_samples
                            ),
                            "random_state": member_seed,
                        }
                    )
                estimator = FinetunedTabPFNClassifier(
                    **estimator_kwargs
                )
                checkpoint_dir = finetune_checkpoint_directory(
                    configuration=configuration,
                    selected_feature_order=selected,
                    fit_rows=fit_rows,
                    fit_indices=indices,
                    monitor_rows=monitor_rows,
                    target_column=target_column,
                    checkpoint_scope=checkpoint_scope,
                    finetune_context_samples=finetune_context_samples,
                    finetune_inference_samples=finetune_inference_samples,
                    full_outer_pool=finetune_full_outer_pool,
                    member_seed=member_seed,
                    bag=bag,
                    member=member,
                )
                select_latest_complete_finetune_checkpoint(
                    checkpoint_dir,
                    train_size=len(indices),
                )
                if (
                    torch_module is not None
                    and device.startswith("cuda")
                    and torch_module.cuda.is_available()
                ):
                    torch_module.cuda.synchronize()
                    torch_module.cuda.empty_cache()
                    torch_module.cuda.reset_peak_memory_stats()
                estimator.fit(
                    fit_values[indices],
                    target[indices],
                    X_val=monitor_values,
                    y_val=monitor_rows[target_column].to_numpy(dtype="int8"),
                    output_dir=checkpoint_dir,
                )
                runtime_checkpoint_dirs.append(checkpoint_dir)
                coverage = (
                    finetune_epoch_coverage(
                        target[indices], context_samples=finetune_context_samples
                    )
                    if finetune_context_samples is not None
                    else None
                )
                runtime_record = {
                    "bag": int(bag),
                    "member": int(member),
                    "bag_seed": bag_seed,
                    "member_seed": member_seed,
                    "epoch_seeds": [
                        member_seed + epoch for epoch in range(FINETUNE_EPOCHS)
                    ],
                    "outer_fit_pool_rows": int(len(fit_rows)),
                    "backend_input_rows": int(len(indices)),
                    "backend_input_row_coverage": float(len(indices) / len(fit_rows)),
                    "full_outer_pool": finetune_full_outer_pool,
                    "n_inference_subsample_samples": finetune_inference_samples,
                    "epoch_coverage": coverage,
                    "cuda_available": bool(
                        torch_module is not None
                        and torch_module.cuda.is_available()
                    ),
                    "gpu_name": (
                        torch_module.cuda.get_device_name(0)
                        if torch_module is not None
                        and torch_module.cuda.is_available()
                        else None
                    ),
                    "fit_peak_allocated_bytes": (
                        int(torch_module.cuda.max_memory_allocated())
                        if torch_module is not None
                        and torch_module.cuda.is_available()
                        else None
                    ),
                    "fit_peak_reserved_bytes": (
                        int(torch_module.cuda.max_memory_reserved())
                        if torch_module is not None
                        and torch_module.cuda.is_available()
                        else None
                    ),
                }
            elif model == "tabicl":
                from tabicl import TabICLClassifier

                estimator = TabICLClassifier(
                    device=device,
                    random_state=member_seed,
                    model_path=offline_model_path(model),
                    allow_auto_download=False,
                )
                estimator.fit(fit_values[indices], target[indices])
            else:
                raise Stage3bCoreOptimizationError(f"unsupported model: {model}")
            estimators.append(estimator)
            probabilities.append(
                np.asarray(estimator.predict_proba(predict_values), dtype="float64")[:, 1]
            )
            if runtime_record is not None:
                if runtime_record["cuda_available"]:
                    torch_module.cuda.synchronize()
                    runtime_record["total_peak_allocated_bytes"] = int(
                        torch_module.cuda.max_memory_allocated()
                    )
                    runtime_record["total_peak_reserved_bytes"] = int(
                        torch_module.cuda.max_memory_reserved()
                    )
                else:
                    runtime_record["total_peak_allocated_bytes"] = None
                    runtime_record["total_peak_reserved_bytes"] = None
                runtime_fit_records.append(runtime_record)
    probability = np.mean(np.vstack(probabilities), axis=0)
    return probability, FittedContextEnsemble(
        selected,
        transformer,
        estimators,
        runtime_checkpoint_dirs=runtime_checkpoint_dirs,
        runtime_fit_records=runtime_fit_records,
    )


def development_fit_monitor_rows(
    model: str,
    outer_fit_rows: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame | None]:
    validate_development_frame(outer_fit_rows, require_all_folds=False)
    if model != "tabpfn_finetuned":
        return outer_fit_rows, None
    folds = sorted(
        int(value)
        for value in pd.to_numeric(outer_fit_rows["fold"], errors="raise").unique()
    )
    monitor_fold = folds[0]
    monitor = outer_fit_rows.loc[outer_fit_rows["fold"].astype(int).eq(monitor_fold)]
    fit = outer_fit_rows.loc[outer_fit_rows["fold"].astype(int).ne(monitor_fold)]
    if set(fit["group_hash"].astype(str)) & set(monitor["group_hash"].astype(str)):
        raise Stage3bCoreOptimizationError("fine-tune group monitor overlaps fit rows")
    return fit, monitor


def evaluate_configuration_fold(
    development: pd.DataFrame,
    feature_order: list[str],
    target_column: str,
    model: str,
    configuration: dict[str, Any],
    *,
    fold: int,
    seed: int,
    device: str,
    model_limit_rows: int,
    model_limit_features: int,
    model_limit_cells: int | None,
    task_id: str,
    phase: str,
    backend: Backend = fit_predict_backend,
) -> tuple[dict[str, Any], np.ndarray, pd.DataFrame, list[Path]]:
    validate_development_frame(development)
    outer_fit = development.loc[development["fold"].astype(int).ne(fold)]
    predict_rows = development.loc[development["fold"].astype(int).eq(fold)]
    fit_rows, monitor_rows = development_fit_monitor_rows(model, outer_fit)
    probability, model_state = backend(
        model=model,
        configuration=configuration,
        fit_rows=fit_rows,
        predict_rows=predict_rows,
        feature_order=feature_order,
        target_column=target_column,
        seed=seed,
        device=device,
        model_limit_rows=model_limit_rows,
        model_limit_features=model_limit_features,
        model_limit_cells=model_limit_cells,
        monitor_rows=monitor_rows,
        checkpoint_scope={
            "task_id": task_id,
            "phase": phase,
            "fold": int(fold),
            "outer_seed": int(seed),
        },
        **formal_finetune_backend_kwargs(model),
    )
    probability = np.asarray(probability, dtype="float64")
    if len(probability) != len(predict_rows) or not np.isfinite(probability).all():
        raise Stage3bCoreOptimizationError("configuration prediction shape/value differs")
    if not pd.Series(probability).between(0, 1).all():
        raise Stage3bCoreOptimizationError("configuration prediction is outside [0,1]")
    target = predict_rows[target_column].to_numpy(dtype="int8")
    runtime_checkpoint_dirs = take_runtime_checkpoint_dirs(model_state)
    return (
        {
            "config_sha256": configuration["config_sha256"],
            "fold": int(fold),
            "seed": int(seed),
            "auprc": float(average_precision_score(target, probability)),
            "auroc": float(roc_auc_score(target, probability)),
            "brier": float(brier_score_loss(target, probability)),
            "fit_maximum_year": int(fit_rows["split_year"].max()),
            "monitor_maximum_year": (
                None
                if monitor_rows is None
                else int(monitor_rows["split_year"].max())
            ),
            "prediction_maximum_year": int(predict_rows["split_year"].max()),
            "validation_2024_access_count": 0,
            "2025_access_count": 0,
        },
        probability,
        predict_rows,
        runtime_checkpoint_dirs,
    )


def run_configuration_phase(
    development: pd.DataFrame,
    feature_order: list[str],
    target_column: str,
    model: str,
    configurations: list[dict[str, Any]],
    seeds: tuple[int, ...],
    *,
    phase: str,
    store: CheckpointStore,
    budget: RunBudget,
    device: str,
    model_limit_rows: int,
    model_limit_features: int = 1000000,
    model_limit_cells: int | None = None,
    backend: Backend = fit_predict_backend,
) -> tuple[pd.DataFrame, bool]:
    rows = []
    for configuration in configurations:
        for seed in seeds:
            for fold in FIXED_FOLDS:
                key = checkpoint_key(
                    configuration["config_sha256"], fold, seed, phase
                )
                result = store.get(key)
                if result is None:
                    if not budget.claim():
                        return pd.DataFrame(rows), False
                    result, _, _, runtime_checkpoint_dirs = evaluate_configuration_fold(
                        development,
                        feature_order,
                        target_column,
                        model,
                        configuration,
                        fold=fold,
                        seed=seed,
                        device=device,
                        model_limit_rows=model_limit_rows,
                        model_limit_features=model_limit_features,
                        model_limit_cells=model_limit_cells,
                        task_id=store.task_id,
                        phase=phase,
                        backend=backend,
                    )
                    store.put(key, result)
                    remove_completed_finetune_checkpoints(runtime_checkpoint_dirs)
                rows.append({"phase": phase, **result})
    return pd.DataFrame(rows), True


def top_configurations(
    results: pd.DataFrame,
    configurations: list[dict[str, Any]],
    count: int,
) -> list[dict[str, Any]]:
    summary = (
        results.groupby("config_sha256", as_index=False)
        .agg(mean_auprc=("auprc", "mean"), mean_brier=("brier", "mean"))
        .sort_values(
            ["mean_auprc", "mean_brier", "config_sha256"],
            ascending=[False, True, True],
            kind="mergesort",
        )
    )
    lookup = {value["config_sha256"]: value for value in configurations}
    return [lookup[value] for value in summary.head(count)["config_sha256"]]


def boundary_hit(model: str, configurations: list[dict[str, Any]]) -> bool:
    axes = model_search_axes(model)
    return any(
        configuration["feature_count"] == "all"
        or configuration["context_row_policy"] == "full_or_model_limit"
        or configuration["estimator_count"] == max(axes["estimator_counts"])
        or configuration["bag_count"] == max(axes["bag_counts"])
        for configuration in configurations
    )


def seed_instability(results: pd.DataFrame, tolerance: float) -> bool:
    seed_means = (
        results.groupby(["config_sha256", "seed"], as_index=False)["auprc"]
        .mean()
        .groupby("config_sha256")["auprc"]
        .std(ddof=0)
    )
    return bool(seed_means.fillna(0).gt(tolerance).any())


def choose_locked_configuration(
    revalidation: pd.DataFrame,
    configurations: list[dict[str, Any]],
) -> dict[str, Any]:
    ranked = (
        revalidation.groupby("config_sha256", as_index=False)
        .agg(mean_auprc=("auprc", "mean"), mean_brier=("brier", "mean"))
        .sort_values(
            ["mean_auprc", "mean_brier", "config_sha256"],
            ascending=[False, True, True],
            kind="mergesort",
        )
    )
    selected = str(ranked.iloc[0]["config_sha256"])
    return next(value for value in configurations if value["config_sha256"] == selected)


def run_locked_oof(
    task_id: str,
    outcome: str,
    model: str,
    development: pd.DataFrame,
    feature_order: list[str],
    configuration: dict[str, Any],
    *,
    seed: int,
    store: CheckpointStore,
    budget: RunBudget,
    device: str,
    model_limit_rows: int,
    model_limit_features: int = 1000000,
    model_limit_cells: int | None = None,
    backend: Backend = fit_predict_backend,
) -> tuple[pd.DataFrame, bool]:
    parts = []
    prediction_dir = store.output_dir / "checkpoint_predictions"
    prediction_dir.mkdir(parents=True, exist_ok=True)
    target_column = f"y_{outcome}"
    for fold in FIXED_FOLDS:
        key = checkpoint_key(configuration["config_sha256"], fold, seed, "locked_oof")
        result = store.get(key)
        if result is None:
            if not budget.claim():
                return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(), False
            metrics, probability, predict_rows, runtime_checkpoint_dirs = (
                evaluate_configuration_fold(
                    development,
                    feature_order,
                    target_column,
                    model,
                    configuration,
                    fold=fold,
                    seed=seed,
                    device=device,
                    model_limit_rows=model_limit_rows,
                    model_limit_features=model_limit_features,
                    model_limit_cells=model_limit_cells,
                    task_id=task_id,
                    phase="locked_oof",
                    backend=backend,
                )
            )
            path = prediction_dir / f"{key['checkpoint_key_sha256']}.parquet"
            part = pd.DataFrame(
                {
                    "task_id": task_id,
                    "row_hash": predict_rows["row_hash"].astype(str),
                    "outcome": outcome,
                    "model": model,
                    "split": "oof_2020_2023",
                    "fold": fold,
                    "y_true": predict_rows[target_column].to_numpy(dtype="int8"),
                    "prediction": probability,
                }
            )
            atomic_parquet(path, part)
            result = {
                **metrics,
                "prediction_path": path.relative_to(store.output_dir).as_posix(),
                "prediction_sha256": sha256_file(path),
            }
            store.put(key, result)
            remove_completed_finetune_checkpoints(runtime_checkpoint_dirs)
        path = store.output_dir / result["prediction_path"]
        if sha256_file(path) != result["prediction_sha256"]:
            raise Stage3bCoreOptimizationError("locked OOF checkpoint hash differs")
        parts.append(pd.read_parquet(path))
    return pd.concat(parts, ignore_index=True), True


def run_locked_validation(
    task_id: str,
    outcome: str,
    model: str,
    development: pd.DataFrame,
    validation: pd.DataFrame,
    feature_order: list[str],
    configuration: dict[str, Any],
    *,
    seed: int,
    store: CheckpointStore,
    budget: RunBudget,
    device: str,
    model_limit_rows: int,
    model_limit_features: int = 1000000,
    model_limit_cells: int | None = None,
    backend: Backend = fit_predict_backend,
    load_model: bool = True,
) -> tuple[pd.DataFrame, Any, bool]:
    validate_development_frame(development)
    validate_validation_frame(development, validation)
    key = checkpoint_key(configuration["config_sha256"], -1, seed, "locked_final")
    result = store.get(key)
    model_state = None
    if result is None:
        if not budget.claim():
            return pd.DataFrame(), None, False
        fit_rows, monitor_rows = development_fit_monitor_rows(model, development)
        probability, model_state = backend(
            model=model,
            configuration=configuration,
            fit_rows=fit_rows,
            predict_rows=validation,
            feature_order=feature_order,
            target_column=f"y_{outcome}",
            seed=seed,
            device=device,
            model_limit_rows=model_limit_rows,
            model_limit_features=model_limit_features,
            model_limit_cells=model_limit_cells,
            monitor_rows=monitor_rows,
            checkpoint_scope={
                "task_id": task_id,
                "phase": "locked_final",
                "fold": -1,
                "outer_seed": int(seed),
            },
            **formal_finetune_backend_kwargs(model),
        )
        runtime_checkpoint_dirs = take_runtime_checkpoint_dirs(model_state)
        probability = np.asarray(probability, dtype="float64")
        if len(probability) != len(validation):
            raise Stage3bCoreOptimizationError("2024 prediction row count differs")
        final_dir = store.output_dir / "checkpoint_final"
        final_dir.mkdir(parents=True, exist_ok=True)
        prediction_path = final_dir / f"{key['checkpoint_key_sha256']}.parquet"
        model_path = final_dir / f"{key['checkpoint_key_sha256']}.joblib"
        part = pd.DataFrame(
            {
                "task_id": task_id,
                "row_hash": validation["row_hash"].astype(str),
                "outcome": outcome,
                "model": model,
                "split": "validation_2024",
                "fold": pd.array([pd.NA] * len(validation), dtype="Int8"),
                "y_true": validation[f"y_{outcome}"].to_numpy(dtype="int8"),
                "prediction": probability,
            }
        )
        atomic_parquet(prediction_path, part)
        atomic_joblib(model_path, model_state)
        result = {
            "config_sha256": configuration["config_sha256"],
            "fold": -1,
            "seed": seed,
            "fit_maximum_year": int(fit_rows["split_year"].max()),
            "monitor_maximum_year": (
                None
                if monitor_rows is None
                else int(monitor_rows["split_year"].max())
            ),
            "validation_year": 2024,
            "validation_2024_fit_rows": 0,
            "validation_2024_monitor_rows": 0,
            "2025_access_count": 0,
            "prediction_path": prediction_path.relative_to(store.output_dir).as_posix(),
            "prediction_sha256": sha256_file(prediction_path),
            "model_path": model_path.relative_to(store.output_dir).as_posix(),
            "model_sha256": sha256_file(model_path),
        }
        store.put(key, result)
        remove_completed_finetune_checkpoints(runtime_checkpoint_dirs)
    prediction_path = store.output_dir / result["prediction_path"]
    model_path = store.output_dir / result["model_path"]
    if (
        sha256_file(prediction_path) != result["prediction_sha256"]
        or sha256_file(model_path) != result["model_sha256"]
    ):
        raise Stage3bCoreOptimizationError("locked final checkpoint hash differs")
    if load_model:
        model_state = joblib.load(model_path)
    elif model_state is None:
        model_state = model_path
    return pd.read_parquet(prediction_path), model_state, True


def metric_rows(predictions: pd.DataFrame, task_id: str, outcome: str, model: str) -> pd.DataFrame:
    rows = []
    for split, frame in predictions.groupby("split", sort=False):
        target = frame["y_true"].to_numpy(dtype="int8")
        probability = frame["prediction"].to_numpy(dtype="float64")
        for metric, value in (
            ("AUROC", roc_auc_score(target, probability)),
            ("AUPRC", average_precision_score(target, probability)),
            ("Brier", brier_score_loss(target, probability)),
        ):
            rows.append(
                {
                    "task_id": task_id,
                    "outcome": outcome,
                    "model": model,
                    "split": split,
                    "metric": metric,
                    "value": float(value),
                    "n": len(frame),
                    "events": int(target.sum()),
                }
            )
    return pd.DataFrame(rows)


def write_model_reload_canary(
    output_dir: Path,
    model_path: Path,
    model_state: Any,
    validation: pd.DataFrame,
    feature_order: list[str],
    *,
    task_id: str,
    outcome: str,
    model: str,
    defer_reload_validation: bool = False,
    remote_stochastic_backend: bool = False,
    reference_predictions: pd.DataFrame | None = None,
    reference_predictions_path: Path | None = None,
) -> tuple[Path, Path, dict[str, Any]]:
    if len(validation) < 100:
        raise Stage3bCoreOptimizationError(
            "formal Stage3b core validation has fewer than 100 canary rows"
        )
    source = validation.sort_values("row_hash", kind="mergesort").head(100)
    inputs = source[["row_hash", *feature_order]].reset_index(drop=True)
    if reference_predictions is None:
        expected_probability = np.asarray(
            model_state.predict_proba(inputs[feature_order]), dtype="float64"
        )[:, 1]
    else:
        required = {"row_hash", "prediction"}
        if (
            required - set(reference_predictions.columns)
            or reference_predictions["row_hash"].astype(str).duplicated().any()
        ):
            raise Stage3bCoreOptimizationError(
                "Stage3b core canary reference predictions differ"
            )
        by_row = reference_predictions.assign(
            row_hash=reference_predictions["row_hash"].astype(str)
        ).set_index("row_hash")["prediction"]
        expected_probability = pd.to_numeric(
            inputs["row_hash"].astype(str).map(by_row), errors="coerce"
        ).to_numpy(dtype="float64")
    expected = pd.DataFrame(
        {
            "row_hash": inputs["row_hash"].astype(str),
            "outcome": outcome,
            "model": model,
            "prediction": expected_probability,
        },
        columns=["row_hash", "outcome", "model", "prediction"],
    )
    inputs_path = output_dir / "canary_inputs.parquet"
    expected_path = output_dir / "canary_expected.parquet"
    atomic_parquet(inputs_path, inputs)
    atomic_parquet(expected_path, expected)
    if (
        len(inputs) != 100
        or inputs["row_hash"].astype(str).duplicated().any()
        or not np.isfinite(expected_probability).all()
        or not pd.Series(expected_probability).between(0, 1).all()
    ):
        raise Stage3bCoreOptimizationError(
            "Stage3b core model canary reference differs"
        )
    if defer_reload_validation:
        if (
            reference_predictions is None
            or reference_predictions_path is None
            or not reference_predictions_path.is_file()
            or not model_path.is_file()
        ):
            raise Stage3bCoreOptimizationError(
                "Stage3b core deferred reload artifact binding differs"
            )
        return inputs_path, expected_path, {
            "status": SCIENCE_COMPLETE_RELOAD_PENDING,
            "task_id": task_id,
            "row_count": 100,
            "maximum_absolute_error": None,
            "tolerance": 1e-5,
            "inputs_sha256": sha256_file(inputs_path),
            "expected_sha256": sha256_file(expected_path),
            "model_sha256": sha256_file(model_path),
            "reference_predictions_sha256": sha256_file(
                reference_predictions_path
            ),
            "feature_order_sha256": sha256_lines(feature_order),
        }
    if remote_stochastic_backend:
        reloaded = joblib.load(model_path)
        if not hasattr(reloaded, "predict_proba"):
            raise Stage3bCoreOptimizationError(
                "Stage3b core sealed model cannot perform canary probability inference"
            )
        return inputs_path, expected_path, {
            "status": "PASS_LOCAL_RELOAD_ONLY",
            "task_id": task_id,
            "row_count": 100,
            "maximum_absolute_error": None,
            "tolerance": 1e-5,
            "reload_numerical_fidelity_asserted": False,
            "backend_determinism": "remote_stochastic_inference",
            "reloaded_estimator_type": type(reloaded).__name__,
            "observed_within_run_absolute_delta": NONDETERMINISM_WITHIN_RUN_DELTA,
            "observed_reload_absolute_delta": NONDETERMINISM_RELOAD_DELTA,
            "superseded_tolerance": 1e-5,
            "authorization": CANARY_REDEFINITION_AUTHORIZATION,
            "inputs_sha256": sha256_file(inputs_path),
            "expected_sha256": sha256_file(expected_path),
            "model_sha256": sha256_file(model_path),
            "feature_order_sha256": sha256_lines(feature_order),
        }
    reloaded = joblib.load(model_path)
    observed = np.asarray(
        reloaded.predict_proba(inputs[feature_order]), dtype="float64"
    )[:, 1]
    maximum_error = float(np.max(np.abs(observed - expected_probability)))
    if (
        not np.isfinite(observed).all()
        or not pd.Series(expected_probability).between(0, 1).all()
        or maximum_error > 1e-5
    ):
        raise Stage3bCoreOptimizationError(
            f"Stage3b core model reload canary differs: {maximum_error}"
        )
    return inputs_path, expected_path, {
        "status": "PASS",
        "task_id": task_id,
        "row_count": 100,
        "maximum_absolute_error": maximum_error,
        "tolerance": 1e-5,
        "inputs_sha256": sha256_file(inputs_path),
        "expected_sha256": sha256_file(expected_path),
    }


def write_partial(
    output_dir: Path,
    task_id: str,
    phase: str,
    store: CheckpointStore,
) -> dict[str, Any]:
    store.set_status("PARTIAL")
    payload = {
        "schema_version": "1.0",
        "task_id": task_id,
        "status": "PARTIAL",
        "phase": phase,
        "lineage": LINEAGE,
        "checkpoint_manifest": "checkpoint_manifest.json",
        "checkpoint_manifest_sha256": sha256_file(store.manifest_path),
        "exact_hash_resume_required": True,
        "session_limit_role": "checkpoint_resume_boundary_not_model_cap",
    }
    atomic_json(output_dir / "_PARTIAL.json", payload)
    return payload


def write_science_complete_reload_pending(
    output_dir: Path,
    task_id: str,
    store: CheckpointStore,
    task_manifest_path: Path,
    canary: dict[str, Any],
) -> dict[str, Any]:
    if (
        canary.get("status") != SCIENCE_COMPLETE_RELOAD_PENDING
        or canary.get("maximum_absolute_error") is not None
        or canary.get("tolerance") != 1e-5
        or canary.get("model_sha256")
        != sha256_file(output_dir / "model.joblib")
        or canary.get("reference_predictions_sha256")
        != sha256_file(output_dir / "predictions.parquet")
        or canary.get("inputs_sha256")
        != sha256_file(output_dir / "canary_inputs.parquet")
        or canary.get("expected_sha256")
        != sha256_file(output_dir / "canary_expected.parquet")
        or canary.get("feature_order_sha256")
        != sha256_lines(
            pd.read_parquet(output_dir / "canary_inputs.parquet").columns.tolist()[
                1:
            ]
        )
    ):
        raise Stage3bCoreOptimizationError(
            "independent reload pending artifact binding differs"
        )
    store.set_status("PARTIAL")
    payload = {
        "schema_version": "1.0",
        "task_id": task_id,
        "status": "PARTIAL",
        "phase": SCIENCE_COMPLETE_RELOAD_PENDING,
        "lineage": LINEAGE,
        "scientific_artifact": True,
        "checkpoint_manifest": "checkpoint_manifest.json",
        "checkpoint_manifest_sha256": sha256_file(store.manifest_path),
        "task_manifest": task_manifest_path.name,
        "task_manifest_sha256": sha256_file(task_manifest_path),
        "exact_hash_resume_required": True,
        "independent_t4_reload_validation_required": True,
        "model_reload_canary": canary,
        "session_limit_role": "checkpoint_resume_boundary_not_model_cap",
    }
    atomic_json(output_dir / "_PARTIAL.json", payload)
    success_path = output_dir / "_SUCCESS.json"
    if success_path.exists():
        success_path.unlink()
    return payload


def finetune_memory_canary_configuration() -> dict[str, Any]:
    expected = {
        "feature_count": 64,
        "context_row_policy": "full_or_model_limit",
        "preprocessing": "median_indicator",
        "context_bagging": "prevalence_stratified",
        "estimator_count": 1,
        "bag_count": 1,
    }
    matches = [
        value
        for value in candidate_configurations("tabpfn_finetuned")
        if all(value[key] == item for key, item in expected.items())
    ]
    if len(matches) != 1:
        raise Stage3bCoreOptimizationError(
            "fine-tune memory canary configuration is not unique"
        )
    return matches[0]


def finetune_memory_canary_envelope(generation: int) -> tuple[int, int]:
    try:
        return FINETUNE_CANARY_ENVELOPES[int(generation)]
    except (KeyError, TypeError, ValueError) as error:
        raise Stage3bCoreOptimizationError(
            "fine-tune memory canary generation is invalid"
        ) from error


def run_finetune_memory_canary(
    args: argparse.Namespace,
    development: pd.DataFrame,
    feature_order: list[str],
    store: CheckpointStore,
    *,
    device: str,
    backend: Backend,
) -> dict[str, Any]:
    configuration = finetune_memory_canary_configuration()
    generation = int(getattr(args, "finetune_memory_canary_generation", 1))
    context_samples, inference_samples = finetune_memory_canary_envelope(generation)
    captured: dict[str, Any] = {}

    def memory_backend(**kwargs: Any) -> tuple[np.ndarray, Any]:
        kwargs.update(
            finetune_context_samples=context_samples,
            finetune_inference_samples=inference_samples,
            finetune_full_outer_pool=True,
        )
        probability, model_state = backend(**kwargs)
        captured["fit_records"] = list(
            getattr(model_state, "runtime_fit_records", [])
        )
        return probability, model_state

    metrics, probability, predict_rows, runtime_checkpoint_dirs = (
        evaluate_configuration_fold(
            development,
            feature_order,
            f"y_{args.outcome}",
            args.model,
            configuration,
            fold=FINETUNE_CANARY_FOLD,
            seed=SEARCH_SEED,
            device=device,
            model_limit_rows=args.model_limit_rows,
            model_limit_features=args.model_limit_features,
            model_limit_cells=args.model_limit_cells,
            task_id=args.task_id,
            phase="search_cv",
            backend=memory_backend,
        )
    )
    fit_records = captured.get("fit_records", [])
    if len(fit_records) != 1:
        raise Stage3bCoreOptimizationError(
            "fine-tune memory canary did not emit one exact fit record"
        )
    fit_record = fit_records[0]
    if (
        device == "cuda"
        and (
            fit_record.get("cuda_available") is not True
            or not fit_record.get("gpu_name")
            or int(fit_record.get("total_peak_reserved_bytes") or 0) <= 0
        )
    ):
        raise Stage3bCoreOptimizationError(
            "fine-tune memory canary lacks effective CUDA/VRAM evidence"
        )
    prediction = pd.DataFrame(
        {
            "task_id": args.task_id,
            "row_hash": predict_rows["row_hash"].astype(str),
            "outcome": args.outcome,
            "model": args.model,
            "split": "oof_2020_2023_memory_canary",
            "fold": FINETUNE_CANARY_FOLD,
            "y_true": predict_rows[f"y_{args.outcome}"].to_numpy(dtype="int8"),
            "prediction": probability,
        }
    )
    prediction_path = store.output_dir / "finetune_memory_canary_oof.parquet"
    atomic_parquet(prediction_path, prediction)
    key = checkpoint_key(
        configuration["config_sha256"],
        FINETUNE_CANARY_FOLD,
        SEARCH_SEED,
        "search_cv",
    )
    result = {
        **metrics,
        "prediction_path": prediction_path.relative_to(store.output_dir).as_posix(),
        "prediction_sha256": sha256_file(prediction_path),
        "memory_envelope": {
            "n_finetune_ctx_plus_query_samples": context_samples,
            "n_inference_subsample_samples": inference_samples,
            "full_outer_pool": True,
        },
        "runtime_fit_record": fit_record,
    }
    store.put(key, result)
    remove_completed_finetune_checkpoints(runtime_checkpoint_dirs)
    store.set_status("PARTIAL")
    outer_fit = development.loc[
        development["fold"].astype(int).ne(FINETUNE_CANARY_FOLD)
    ]
    fit_rows, monitor_rows = development_fit_monitor_rows(args.model, outer_fit)
    first = prediction.sort_values("row_hash", kind="mergesort").iloc[0]
    evidence = {
        "contract_version": "p1-v2-stage3b-finetune-memory-canary/1",
        "status": "PASS",
        "scientific_artifact": True,
        "artifact_role": "memory_canary_not_final_model",
        "task_id": args.task_id,
        "outcome": args.outcome,
        "model": args.model,
        "config_sha256": configuration["config_sha256"],
        "memory_canary_generation": generation,
        "fold": FINETUNE_CANARY_FOLD,
        "seed": SEARCH_SEED,
        "outer_fold_fit_rows_before_monitor": int(len(outer_fit)),
        "full_outer_sampling_pool_rows_after_monitor": int(len(fit_rows)),
        "development_monitor_rows": int(len(monitor_rows)),
        "runtime_fit_record": fit_record,
        "effective_outer_checkpoint": {
            "completed_key_count": len(store.manifest["completed_keys"]),
            "checkpoint_manifest_sha256": sha256_file(store.manifest_path),
            "record_sha256": store.manifest["completed_keys"][0]["record_sha256"],
        },
        "first_oof_prediction": {
            "row_hash": str(first["row_hash"]),
            "y_true": int(first["y_true"]),
            "prediction": float(first["prediction"]),
        },
        "prediction_artifact": {
            "path": prediction_path.name,
            "sha256": sha256_file(prediction_path),
            "row_count": int(len(prediction)),
        },
        "allocator": os.environ.get("PYTORCH_ALLOC_CONF"),
        "development_years": list(DEVELOPMENT_YEARS),
        "validation_2024_access_count": 0,
        "2025_access_count": 0,
    }
    evidence["canary_evidence_sha256"] = canonical_sha256(evidence)
    evidence_path = store.output_dir / "finetune_memory_canary_evidence.json"
    atomic_json(evidence_path, evidence)
    partial = write_partial(
        store.output_dir,
        args.task_id,
        "finetune_memory_canary_pass",
        store,
    )
    return {**partial, "canary_evidence_sha256": sha256_file(evidence_path)}


def run_task(
    args: argparse.Namespace,
    *,
    backend: Backend = fit_predict_backend,
    runner_path: Path | None = None,
) -> dict[str, Any]:
    started = time.perf_counter()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    task, registry_hashes = exact_registry_task(
        args.registry_extension.resolve(), args.task_id, args.outcome, args.model
    )
    development, validation, feature_order, _, input_contract = load_stage1a_inputs(
        args.stage1a_dir.resolve(),
        args.fold_map.resolve(),
        args.outcome,
        smoke=args.smoke,
    )
    validate_development_frame(development)
    validate_validation_frame(development, validation)
    policy = SearchPolicy(
        minimum_complete_configurations=args.minimum_complete_configurations,
        top_configurations=args.top_configurations,
        seed_revalidation_configurations=args.seed_revalidation_configurations,
        base_validation_seeds=tuple(BASE_VALIDATION_SEEDS[: args.base_validation_seeds]),
        extended_validation_seeds=tuple(
            EXTENDED_VALIDATION_SEEDS[: args.extended_validation_seeds]
        ),
        instability_tolerance=args.instability_tolerance,
        session_limit_hours=args.session_limit_hours,
        new_fit_cutoff_hours=args.new_fit_cutoff_hours,
        p90_fit_seconds=args.p90_fit_seconds,
    )
    device = resolve_device(args.device)
    finetune_runtime = formal_finetune_backend_kwargs(args.model)
    if args.finetune_memory_canary:
        context_samples, inference_samples = finetune_memory_canary_envelope(
            args.finetune_memory_canary_generation
        )
        finetune_runtime.update(
            finetune_context_samples=context_samples,
            finetune_inference_samples=inference_samples,
            finetune_full_outer_pool=True,
        )
    binding_hashes = {
        **{f"input_{key}_sha256": value for key, value in input_contract["hashes"].items()},
        **registry_hashes,
        "runner_sha256": sha256_file(
            Path(__file__).resolve() if runner_path is None else runner_path.resolve()
        ),
        "feature_order_sha256": sha256_lines(feature_order),
        "task_contract_sha256": canonical_sha256(task),
        "search_policy_sha256": canonical_sha256(policy.__dict__),
        "runtime_context_sha256": canonical_sha256(
            {
                "device": device,
                "model_limit_rows": args.model_limit_rows,
                "model_limit_features": args.model_limit_features,
                "model_limit_cells": args.model_limit_cells,
                "model_limit_evidence_sha256": args.model_limit_evidence_sha256,
                "p90_fit_seconds": policy.p90_fit_seconds,
                "fit_reserve_multiplier": policy.fit_reserve_multiplier,
                "checkpoint_finalization_reserve_seconds": (
                    policy.checkpoint_finalization_reserve_seconds
                ),
                "finetune_memory_canary": args.finetune_memory_canary,
                "finetune_memory_canary_generation": (
                    args.finetune_memory_canary_generation
                    if args.finetune_memory_canary
                    else 0
                ),
                "finetune_context_samples": (
                    finetune_runtime.get("finetune_context_samples")
                ),
                "finetune_inference_samples": (
                    finetune_runtime.get("finetune_inference_samples")
                ),
                "finetune_full_outer_pool": finetune_runtime.get(
                    "finetune_full_outer_pool", False
                ),
            }
        ),
        "model_limit_evidence_sha256": args.model_limit_evidence_sha256,
    }
    if args.checkpoint_binding_runner_sha256 is not None:
        legacy_binding_hashes = tabicl_s2_legacy_expected_binding_hashes(
            binding_hashes,
            args.checkpoint_binding_runner_sha256,
        )
        binding_hashes = validate_tabicl_s2_legacy_checkpoint(
            output_dir,
            task_id=args.task_id,
            outcome=args.outcome,
            model=args.model,
            legacy_runner_sha256=args.checkpoint_binding_runner_sha256,
            expected_binding_hashes=legacy_binding_hashes,
        )
    store = CheckpointStore(
        output_dir,
        task_id=args.task_id,
        binding_hashes=binding_hashes,
        policy=policy,
    )
    deadline = started + policy.session_limit_hours * 3600
    budget = RunBudget(
        deadline,
        args.max_new_evaluations,
        new_fit_cutoff=started + policy.new_fit_cutoff_hours * 3600,
        p90_fit_seconds=policy.p90_fit_seconds,
        fit_reserve_multiplier=policy.fit_reserve_multiplier,
        checkpoint_finalization_reserve_seconds=(
            policy.checkpoint_finalization_reserve_seconds
        ),
    )
    configurations = screening_configurations(
        args.model, policy.minimum_complete_configurations
    )
    if args.finetune_memory_canary:
        return run_finetune_memory_canary(
            args,
            development,
            feature_order,
            store,
            device=device,
            backend=backend,
        )
    search_results, complete = run_configuration_phase(
        development,
        feature_order,
        f"y_{args.outcome}",
        args.model,
        configurations,
        (SEARCH_SEED,),
        phase="search_cv",
        store=store,
        budget=budget,
        device=device,
        model_limit_rows=args.model_limit_rows,
        model_limit_features=args.model_limit_features,
        model_limit_cells=args.model_limit_cells,
        backend=backend,
    )
    if not complete:
        return write_partial(output_dir, args.task_id, "search_cv", store)
    atomic_parquet(output_dir / "search_cv_results.parquet", search_results)
    top_five = top_configurations(
        search_results, configurations, policy.top_configurations
    )
    seed_candidates = top_five[: policy.seed_revalidation_configurations]
    base_revalidation, complete = run_configuration_phase(
        development,
        feature_order,
        f"y_{args.outcome}",
        args.model,
        seed_candidates,
        policy.base_validation_seeds,
        phase="seed_revalidation",
        store=store,
        budget=budget,
        device=device,
        model_limit_rows=args.model_limit_rows,
        model_limit_features=args.model_limit_features,
        model_limit_cells=args.model_limit_cells,
        backend=backend,
    )
    if not complete:
        return write_partial(output_dir, args.task_id, "seed_revalidation", store)
    unstable = seed_instability(base_revalidation, policy.instability_tolerance)
    at_boundary = boundary_hit(args.model, seed_candidates)
    revalidation = base_revalidation
    seeds_used = policy.base_validation_seeds
    if unstable or at_boundary:
        extension_seeds = tuple(
            seed
            for seed in policy.extended_validation_seeds
            if seed not in policy.base_validation_seeds
        )
        extension, complete = run_configuration_phase(
            development,
            feature_order,
            f"y_{args.outcome}",
            args.model,
            seed_candidates,
            extension_seeds,
            phase="seed_revalidation",
            store=store,
            budget=budget,
            device=device,
            model_limit_rows=args.model_limit_rows,
            model_limit_features=args.model_limit_features,
            model_limit_cells=args.model_limit_cells,
            backend=backend,
        )
        if not complete:
            return write_partial(output_dir, args.task_id, "seed_revalidation", store)
        revalidation = pd.concat([base_revalidation, extension], ignore_index=True)
        seeds_used = policy.extended_validation_seeds
    atomic_parquet(output_dir / "top3_seed_revalidation.parquet", revalidation)
    locked = choose_locked_configuration(revalidation, seed_candidates)
    oof, complete = run_locked_oof(
        args.task_id,
        args.outcome,
        args.model,
        development,
        feature_order,
        locked,
        seed=seeds_used[0],
        store=store,
        budget=budget,
        device=device,
        model_limit_rows=args.model_limit_rows,
        model_limit_features=args.model_limit_features,
        model_limit_cells=args.model_limit_cells,
        backend=backend,
    )
    if not complete:
        return write_partial(output_dir, args.task_id, "locked_oof", store)
    defer_reload_validation = args.model == "tabicl" and not args.smoke
    remote_stochastic_backend = (
        args.device in NONDETERMINISTIC_REMOTE_BACKENDS and not args.smoke
    )
    validation_predictions, final_model, complete = run_locked_validation(
        args.task_id,
        args.outcome,
        args.model,
        development,
        validation,
        feature_order,
        locked,
        seed=seeds_used[0],
        store=store,
        budget=budget,
        device=device,
        model_limit_rows=args.model_limit_rows,
        model_limit_features=args.model_limit_features,
        model_limit_cells=args.model_limit_cells,
        backend=backend,
        load_model=not defer_reload_validation,
    )
    if not complete:
        return write_partial(output_dir, args.task_id, "locked_final", store)
    predictions = pd.concat([oof, validation_predictions], ignore_index=True)
    metrics = metric_rows(predictions, args.task_id, args.outcome, args.model)
    prediction_path = output_dir / "predictions.parquet"
    metric_path = output_dir / "metrics.parquet"
    model_path = output_dir / "model.joblib"
    atomic_parquet(prediction_path, predictions)
    atomic_parquet(metric_path, metrics)
    if defer_reload_validation and isinstance(final_model, Path):
        atomic_copy(final_model, model_path)
    else:
        atomic_joblib(model_path, final_model)
    canary_input_path, canary_expected_path, canary = write_model_reload_canary(
        output_dir,
        model_path,
        final_model,
        validation,
        feature_order,
        task_id=args.task_id,
        outcome=args.outcome,
        model=args.model,
        defer_reload_validation=defer_reload_validation,
        remote_stochastic_backend=remote_stochastic_backend,
        reference_predictions=(
            validation_predictions
            if defer_reload_validation or remote_stochastic_backend
            else None
        ),
        reference_predictions_path=(
            prediction_path
            if defer_reload_validation or remote_stochastic_backend
            else None
        ),
    )
    reload_pending = canary["status"] == SCIENCE_COMPLETE_RELOAD_PENDING
    spec = {
        "schema_version": "1.0",
        "task_id": args.task_id,
        "lineage": LINEAGE,
        "stage": "P1_05b",
        "wave": "W04_CORE",
        "outcome": args.outcome,
        "model": args.model,
        "selection_contract": {
            "development_years": list(DEVELOPMENT_YEARS),
            "fixed_group_folds": len(FIXED_FOLDS),
            "validation_year": 2024,
            "validation_role": "predict_only_after_lock",
            "validation_2024_labels_used_for_fit_monitor_selection": False,
            "2025_access_count": 0,
        },
        "search_contract": {
            "minimum_complete_configurations": policy.minimum_complete_configurations,
            "complete_configurations": len(configurations),
            "systematic_axes": model_search_axes(args.model),
            "context_limit_source": "runtime_model_limit_full_data_preferred",
            "model_limit_rows": args.model_limit_rows,
            "model_limit_features": args.model_limit_features,
            "model_limit_cells": args.model_limit_cells,
            "model_limit_evidence_sha256": args.model_limit_evidence_sha256,
            "top_configurations": policy.top_configurations,
            "top_configurations_fixed_group_folds": len(FIXED_FOLDS),
        },
        "seed_revalidation": {
            "configurations": policy.seed_revalidation_configurations,
            "base_seed_count": len(policy.base_validation_seeds),
            "seeds_used": list(seeds_used),
            "unstable": unstable,
            "boundary_hit": at_boundary,
            "extended_to_five": len(seeds_used) == 5,
        },
        "locked_configuration": locked,
        "checkpoint_contract": {
            "key_fields": ["config_sha256", "fold", "seed", "phase"],
            "session_limit_hours": policy.session_limit_hours,
            "new_fit_cutoff_hours": policy.new_fit_cutoff_hours,
            "p90_fit_seconds": policy.p90_fit_seconds,
            "fit_reserve_multiplier": policy.fit_reserve_multiplier,
            "checkpoint_finalization_reserve_seconds": (
                policy.checkpoint_finalization_reserve_seconds
            ),
            "session_limit_role": "checkpoint_resume_boundary_not_model_cap",
            "exact_hash_resume_required": True,
        },
        "input_hashes": binding_hashes,
        "model_reload_canary": canary,
        "validation_2024_fit_rows": 0,
        "validation_2024_monitor_rows": 0,
        "historical_2025_exposure": True,
        "uses_2025": False,
    }
    spec_path = output_dir / "spec.json"
    atomic_json(spec_path, spec)
    sealed_payload = {
        "contract_version": "p1-v2-stage3b-coreopt-sealed-model/1",
        "status": (
            SCIENCE_COMPLETE_RELOAD_PENDING if reload_pending else "PASS"
        ),
        "task_id": args.task_id,
        "outcome": args.outcome,
        "model": args.model,
        "lineage": LINEAGE,
        "selected_config_sha256": locked["config_sha256"],
        "feature_order_sha256": sha256_lines(feature_order),
        "model_sha256": sha256_file(model_path),
        "spec_sha256": sha256_file(spec_path),
        "canary_inputs_sha256": sha256_file(canary_input_path),
        "canary_expected_sha256": sha256_file(canary_expected_path),
        "canary_row_count": 100,
        "canary_maximum_absolute_error": canary["maximum_absolute_error"],
        "canary_tolerance": 1e-5,
        "input_hashes": binding_hashes,
        "maximum_year": 2024,
        "2025_access_count": 0,
        "historical_2025_exposure": True,
    }
    sealed_payload["sealed_payload_sha256"] = canonical_sha256(sealed_payload)
    sealed_path = output_dir / "sealed_model_manifest.json"
    atomic_json(sealed_path, sealed_payload)
    artifact_paths = {
        "predictions.parquet": prediction_path,
        "metrics.parquet": metric_path,
        "model.joblib": model_path,
        "spec.json": spec_path,
        "search_cv_results.parquet": output_dir / "search_cv_results.parquet",
        "top3_seed_revalidation.parquet": output_dir
        / "top3_seed_revalidation.parquet",
        "checkpoint_manifest.json": store.manifest_path,
        "canary_inputs.parquet": canary_input_path,
        "canary_expected.parquet": canary_expected_path,
        "sealed_model_manifest.json": sealed_path,
    }
    store.set_status("PARTIAL" if reload_pending else "COMPLETE")
    manifest = {
        "schema_version": "1.0",
        "task_id": args.task_id,
        "status": (
            SCIENCE_COMPLETE_RELOAD_PENDING if reload_pending else "PASS"
        ),
        "lineage": LINEAGE,
        "scientific_artifact": True,
        "outcome": args.outcome,
        "model": args.model,
        "artifact_hashes": {
            name: sha256_file(path) for name, path in artifact_paths.items()
        },
        "binding_hashes": binding_hashes,
        "model_limits": {
            "max_train_rows": args.model_limit_rows,
            "max_features": args.model_limit_features,
            "max_cells": args.model_limit_cells,
            "evidence_sha256": args.model_limit_evidence_sha256,
            "p90_fit_seconds": policy.p90_fit_seconds,
        },
        "development_years": list(DEVELOPMENT_YEARS),
        "validation_year": 2024,
        "validation_2024_fit_rows": 0,
        "validation_2024_monitor_rows": 0,
        "2025_access_count": 0,
        "historical_2025_exposure": True,
        "model_reload_canary": canary,
        "runtime": {
            "wall_seconds": time.perf_counter() - started,
            "device": device,
            "platform": platform.platform(),
            "packages": package_versions(),
            "fit_reserve_seconds": budget.fit_reserve_seconds,
        },
    }
    manifest_path = output_dir / "task_manifest.json"
    atomic_json(manifest_path, manifest)
    if reload_pending:
        return write_science_complete_reload_pending(
            output_dir,
            args.task_id,
            store,
            manifest_path,
            canary,
        )
    success = {
        "schema_version": "1.0",
        "task_id": args.task_id,
        "status": "SUCCESS",
        "lineage": LINEAGE,
        "scientific_artifact": True,
        "manifest": manifest_path.name,
        "manifest_sha256": sha256_file(manifest_path),
        "model_reload_canary": canary,
    }
    atomic_json(output_dir / "_SUCCESS.json", success)
    partial_path = output_dir / "_PARTIAL.json"
    if partial_path.exists():
        partial_path.unlink()
    return success


def validate_formal_arguments(args: argparse.Namespace) -> None:
    if args.smoke:
        if args.checkpoint_binding_runner_sha256 is not None:
            raise Stage3bCoreOptimizationError(
                "smoke execution cannot adopt a formal checkpoint binding"
            )
        return
    if args.finetune_memory_canary:
        if (
            args.outcome != "P1"
            or args.model != "tabpfn_finetuned"
            or args.task_id != "P1_05b-coreopt-P1-tabpfn_finetuned"
            or args.device != "cuda"
            or args.max_new_evaluations is not None
            or args.p90_fit_seconds is None
            or args.model_limit_evidence_sha256 is None
            or args.finetune_memory_canary_generation
            not in FINETUNE_CANARY_ENVELOPES
            or args.checkpoint_binding_runner_sha256 is not None
        ):
            raise Stage3bCoreOptimizationError(
                "fine-tune memory canary arguments drift"
            )
        return
    expected = {
        "minimum_complete_configurations": 32,
        "top_configurations": 5,
        "seed_revalidation_configurations": 3,
        "base_validation_seeds": 3,
        "extended_validation_seeds": 5,
        "session_limit_hours": 9.75,
        "new_fit_cutoff_hours": 9.25,
    }
    drift = {
        key: (value, getattr(args, key))
        for key, value in expected.items()
        if getattr(args, key) != value
    }
    if (
        drift
        or args.max_new_evaluations is not None
        or args.p90_fit_seconds is None
        or args.model_limit_evidence_sha256 is None
        or args.finetune_memory_canary_generation != 1
    ):
        raise Stage3bCoreOptimizationError(
            f"formal Stage3b core optimization arguments drift: {drift}"
        )
    if args.device == "cpu":
        raise Stage3bCoreOptimizationError(
            "formal Stage3b core optimization requires GPU/API execution"
        )
    if args.checkpoint_binding_runner_sha256 is not None and (
        args.task_id != TABICL_S2_LEGACY_TASK_ID
        or args.outcome != "S2"
        or args.model != "tabicl"
        or args.checkpoint_binding_runner_sha256
        != TABICL_S2_LEGACY_RUNNER_SHA256
    ):
        raise Stage3bCoreOptimizationError(
            "formal legacy checkpoint binding arguments drift"
        )


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run one EMT P1 v2 Stage3b core-model optimization task"
    )
    parser.add_argument("--outcome", required=True, choices=OUTCOMES)
    parser.add_argument("--model", required=True, choices=MODELS)
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--stage1a-dir", type=Path, default=DEFAULT_STAGE1A_DIR)
    parser.add_argument("--fold-map", type=Path, default=DEFAULT_FOLD_MAP)
    parser.add_argument(
        "--registry-extension", type=Path, default=DEFAULT_REGISTRY_EXTENSION
    )
    parser.add_argument("--minimum-complete-configurations", type=int, default=32)
    parser.add_argument("--top-configurations", type=int, default=5)
    parser.add_argument("--seed-revalidation-configurations", type=int, default=3)
    parser.add_argument("--base-validation-seeds", type=int, default=3)
    parser.add_argument("--extended-validation-seeds", type=int, default=5)
    parser.add_argument("--instability-tolerance", type=float, default=0.01)
    parser.add_argument("--session-limit-hours", type=float, default=9.75)
    parser.add_argument("--new-fit-cutoff-hours", type=float, default=9.25)
    parser.add_argument("--model-limit-rows", type=int, default=10000)
    parser.add_argument("--model-limit-features", type=int)
    parser.add_argument("--model-limit-cells", type=int)
    parser.add_argument("--model-limit-evidence-sha256")
    parser.add_argument("--p90-fit-seconds", type=float)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="cuda")
    parser.add_argument("--max-new-evaluations", type=int)
    parser.add_argument("--checkpoint-binding-runner-sha256")
    parser.add_argument("--finetune-memory-canary", action="store_true")
    parser.add_argument(
        "--finetune-memory-canary-generation",
        type=int,
        choices=tuple(FINETUNE_CANARY_ENVELOPES),
        default=1,
    )
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args(argv)
    if (
        args.minimum_complete_configurations < 1
        or args.top_configurations < args.seed_revalidation_configurations
        or args.base_validation_seeds != 3
        or args.extended_validation_seeds not in {3, 5}
        or args.model_limit_rows < 2
        or args.model_limit_features is None
        or args.model_limit_features < 1
        or (args.model_limit_cells is not None and args.model_limit_cells < 2)
        or args.p90_fit_seconds is None
        or args.p90_fit_seconds <= 0
        or args.model_limit_evidence_sha256 is None
        or len(args.model_limit_evidence_sha256) != 64
        or any(
            character not in "0123456789abcdef"
            for character in args.model_limit_evidence_sha256
        )
        or not 0 < args.new_fit_cutoff_hours < args.session_limit_hours
    ):
        parser.error("Stage3b core optimization argument bounds are invalid")
    validate_formal_arguments(args)
    return args


def main() -> None:
    args = parse_args()
    result = run_task(args)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
