# Aggregate data dictionary

Each P1_04 arm-table row is one task × experiment arm × split × probability presentation. It is not one patient. `task_id` encodes specialty, outcome and analysis; `group` is medicine or surgery. `split` is development out-of-fold or temporal validation (2024; congestion has its separately recorded chronology).

`N` counts eligible encounters and `events` counts positive outcomes in that exact arm; empty numerical cells mean unavailable/not estimable and must not be replaced with zero. `AUROC`, `AUPRC`, `Brier` are unitless. Their `_lower_ci` and `_upper_ci` fields are existing individual-arm 95% intervals, not paired difference intervals. `AUROC_status`, `AUPRC_status`, `Brier_status` retain estimability labels.

`sensitivity`, `specificity`, `PPV`, `NPV`, `F1`, `TP`, `FP`, `TN`, `FN` use the recorded comparator threshold. `threshold_min/max/mean` document whether a fixed threshold or fold-specific rule was used. `net benefit` belongs to that recorded probability threshold; its interpretation is not transferable to the final model's clinical operating point.

`feature_count` is the locked input-column count in the P1_04 experiment, including transformed indicators, not the effective degrees of freedom. `feature_set_id` binds its exact feature order. `events_per_input_dimension` is a descriptive ratio; it is not a universal sample-size sufficiency test for regularized, neural, foundation or ensemble models.

`presentation` and `probability_layer` prevent attaching raw intervals to a separately calibrated estimate. `completion_status` is a computation/estimability disposition. `source_result_receipt_sha256` and `source_validation_sha256` link output to its evidence. Neither task completion nor this replay promotes scientific/formal acceptance.

Outcomes: P1 ED death/critical discharge; P2 ED or inpatient death/critical discharge; P3 recorded ENDO=Y (missing mapped to N); S1/S2 P2 within 3/7 days; S3 specified observation/ward admission dispositions; S4 ICU admission; S5 ICU stay ≥14 days; S6 total stay ≥30 days. These labels abbreviate exact source definitions bound in the research methods manifest. OP_NAME is a hospital-derived retrospective specialty router, not a primary predictor known before hospital arrival.
