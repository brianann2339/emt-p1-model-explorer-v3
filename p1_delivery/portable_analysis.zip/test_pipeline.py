import json
import shutil
import tempfile
import unittest
from pathlib import Path

from pipeline import run


class AggregateReplay(unittest.TestCase):
    def test_real_fixture_and_deterministic_replay(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = Path(__file__).with_name("fixtures")
            first = run(source, root / "a")
            second = run(source, root / "b")
            self.assertEqual(first["completed_task_dispositions"], 494)
            self.assertEqual(first["status_counts"]["VALIDATED_NOT_ESTIMABLE"], 9)
            self.assertEqual(first["events_dimension_rows"], 27)
            self.assertEqual(first, second)
            self.assertEqual((root / "a/output_hashes.json").read_bytes(), (root / "b/output_hashes.json").read_bytes())

    def test_modified_aggregate_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            shutil.copytree(Path(__file__).with_name("fixtures"), root / "inputs")
            path = root / "inputs/completion.csv"
            path.write_bytes(path.read_bytes() + b"\n")
            with self.assertRaisesRegex(ValueError, "Fixture bytes changed"):
                run(root / "inputs", root / "out")


if __name__ == "__main__":
    unittest.main()
