# EMT P1 real aggregate analysis replay

This portable package reproduces the analysis tables from the completed Medicine/Surgery P1_04 study using its real, already-computed aggregate fixtures. It also includes 41 source-aligned aggregate collections for current 324-model CI/calibration, 270 paired comparisons, both specialty descriptive cohorts, current-row baseline points and 2,025 metric intervals and earlier reference results. It replaces the earlier synthetic-only demonstration as the public analysis replay. It does not reconstruct model fitting, individual predictions, bootstrap samples or direct SHAP computation.

Use CPython 3.12 or later. Create and activate a fresh environment, then run:

```text
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install --no-index -r requirements.lock.txt
python -B -m unittest -v test_pipeline
python -B pipeline.py --output replay_output
```

Use a new output directory per run. No GPU, network, credentials or cloud account is required. The locked fixtures contain 494 logical task dispositions, 18 arm tables and their existing descriptive comparisons. The program checks exact fixture hashes, task uniqueness, pre-2025 split scope, denominator/confusion/F1 arithmetic, and reproduces each same-cohort point difference from its two arm estimates. It retains the source individual-arm confidence intervals. It never derives a paired confidence interval from two marginal intervals or subtracts results for different cohorts.

Outputs are a 2024 arm table, same-cohort descriptive differences, event/input-dimension appendix, limited/not-estimable dispositions and a deterministic results manifest. Values are research comparator estimates under the recorded raw/calibrated layer and recorded threshold; they are not the final deployment threshold and do not change the accepted model registry.

The fixture manifest binds every public file and upstream evidence SHA. Absolute workstation paths and cohort row-set hashes are omitted from the public P104 fixture columns; scientific result receipt hashes remain. No patient rows, free text, personal identifiers, model binaries, tokens or raw 2025 files are included. Aggregate fixtures are real study summaries, not synthetic observations. The current-model supplement reuses already-computed frozen aggregate metrics; all P104 arm comparisons are pre-2025. No new frozen evaluation is performed. Earlier strict-v2 reference cohorts retain their separate scope and must not supply confidence intervals for different current models.

For a future authorized private replay, `private_inputs.example.json` specifies manifests for cohorts, folds, features, outcomes, model registry, runtime locks, evaluation code and thresholds. `validate_private_inputs.py` verifies supplied prerequisite bytes only; it deliberately does not claim to execute the protected multi-runtime training study. Actual full model reproduction also needs the approved private data entitlement, protected model/data files and each original GPU runtime. This package supplies the interface and records that unexecuted scope explicitly.

## Added original source route and Overall analysis

The closeout fixtures now include accepted Overall sensitivity/DNR tables, source-bound cohort flow, all 324 locked operating points and source-recorded net benefit. `protected/README.md` documents seven byte-exact original stage entry points and separate runtime locks. `python protected_pipeline.py verify-code` verifies their source bytes; `plan` resolves hashed private inputs without executing a model. `run --execute` dispatches the explicitly supplied native stage command only in a fresh output location. This route is packaged and tested, but no protected training or 2025 unsealing was executed. The default aggregate pipeline remains CPU-only and independent of these optional native-model dependencies.

The completed corrected text-gain collections are in fixtures/corrected_text/. They cover 54 pairs and 108 split-specific disjoint-patient contrasts; the old fixtures/supplements/text_gain.csv is audit-only and is not the current confidence-interval authority. The exact correction source and its protected saved-probability postprocessing route are packaged beside the unchanged original Stage3a source.
