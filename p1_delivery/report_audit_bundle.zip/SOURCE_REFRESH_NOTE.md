# Current export serialization binding

The supplement catalog was serialized again after its terminal receipt. Its current file SHA is `73630e4ec6f7ecb3f9c0f28d09e965312df83ecdd5987f67389771b65764e167`; the earlier terminal receipt records `22ae916febc4220e03ff38046e4d405f3a31fe86e6e8bc3462ff14b2ce1acc88`. This mismatch is not represented as an exact terminal-receipt hash match.

The report refresh instead binds the current PASS export validation to the actual catalog, independently hashes all 58 referenced JSON/CSV files, and compares all 1,764 new CI rows and 270 paired rows to their native current-statistics aggregate Parquet records. The 180 retained CI rows are compared exactly to their source export. `current_export_revalidation.json` records the actual result and numeric comparison count. No raw2025 or predictive-model access was used.

The historical terminal receipt is retained as completion-history evidence. Current report `sources.json`, fixture manifest and output archives bind the verified current bytes. The upstream terminal receipt was not edited by this report workstream.
