# Remaining closeout after the completed reporting additions

Completed: source-bound cohort flow; all accepted Overall sensitivity/DNR numerical tables; targeted primary-source literature; source-recorded net benefit; all 324 operating points; seven original native entrypoints plus the corrected statistics postprocessor; fresh real-aggregate replay; all 36 no-text model tasks and 54-pair/108-contrast disjoint-patient correction. No further GPU computation is required for these items.

The remaining factual limits are specific:

- The 108 Overall frozen calibration-bin aggregates were not produced/found in the authoritative source inventory. This is an absent-source-aggregate gap, not NOT_ESTIMABLE. Existing calibration intercept/slope and all current2024 calibration/DCA remain available. No new raw2025 read or evaluation is performed to fill the bins.
- The accepted Overall authority locks twelve components for each outcome, not a separately documented nine-outcome cross-family deployment recommendation. All 108 thresholds are included, and all 17 recorded specialty research choices plus Surgery/P1 no-representative are shown. A preexisting Overall recommendation or author decision must be confirmed rather than invented or selected on 2025.
- The source-owner declarations and clinical measurement/ascertainment/workflow facts in AUTHOR_DECLARATIONS.md remain author-owned. The computational TRIPOD/PROBAST map and event/input appendix are complete; no new appraisal mandate or universal EPV rule is added.
- Original-code staging/dispatch and real aggregate replay are implemented and tested. Full protected fitting, patient-bootstrap replay on another machine and heterogeneous GPU runtime installation are not executed and are not claimed.
- Source metadata absent from the inspected original model receipts remains “not recorded”; it is not filled by inference or repeat training.

Original Overall W02 intervals are explicitly row-stratified bootstrap; current Stage2a analyses and corrected text comparisons use their documented disjoint patient-group methods. Legacy overlapping-strata text intervals are retained only for audit. Immutable accepted outputs and their acceptance flags are unchanged. Root-owned current public-byte/browser QA determines final website publication readiness.
